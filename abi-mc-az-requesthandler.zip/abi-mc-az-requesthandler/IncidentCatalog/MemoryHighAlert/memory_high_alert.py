import logging,json
from shared_code.compute_client import ComputeClient
from shared_code.db import DB


class AzVMMemoryHighAlert:
    def __init__(self, data):
        self.data = data
        self.subscription_id = data["SubscriptionId"]
        self.resource_group_name = data["ResourceGroupName"]
        self.vm_name = data["ResourceName"]
        self.vm_id = data["ResourceId"]
        self.threshold = data["Threshold"]
        self.zone = data["Zone"].lower()
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.compute_client = ComputeClient().get_compute_client(self.subscription_id, self.cloud)
        self.objdb = DB()

    def get_vm_os_type(self):
        response = self.compute_client.virtual_machines.get(self.resource_group_name, self.vm_name)
        if response.storage_profile.os_disk.os_type == 'Windows':
            return 'windows'
        return 'linux'

    def run_top_memory_processes(self, os_type):
        if os_type == 'windows':
            command = {
                'command_id': 'RunPowerShellScript',
                'script': [
                    "Get-Process | Sort-Object WorkingSet64 -Descending | Select-Object -First 20 Id, ProcessName, @{N='Memory(MB)';E={[math]::Round($_.WorkingSet64/1MB,2)}}, @{N='CPU(s)';E={[math]::Round($_.CPU,2)}}, @{N='Path';E={$_.Path}} | Format-Table -AutoSize | Out-String -Width 500"
                ]
            }
        else:
            command = {
                'command_id': 'RunShellScript',
                'script': [
                    "ps aux --sort=-%mem | head -21 | awk '{cmd=\"\"; for(i=11;i<=NF;i++) cmd=cmd $i \" \"; printf \"%-10s %-7s %-5s %-5s %s\\n\", $1, $2, $3, $4, cmd}'"
                ]
            }
        poller = self.compute_client.virtual_machines.begin_run_command(
            self.resource_group_name, self.vm_name, command
        )
        result = poller.result()
        output = result.value[0].message.strip() if result.value else "No output"
        return output

    def store_run_command_output(self, event_id, output):
        sql_query = """
            UPDATE tblActivityMemoryHighAlert
            SET RunCommand = ?, Status = 'Success'
            WHERE EventId = ? AND Status = 'In-Progress'
        """
        values = (output, event_id)
        self.objdb.executescalar(sql_query=sql_query, action="update", values=values)

    async def handle_memory_high_alert(self):
        logging.info(f"Memory High Alert received for VM {self.vm_name} in RG {self.resource_group_name} "
                      f"(Subscription: {self.subscription_id}, Threshold: {self.threshold}%)")
        try:
            os_type = self.get_vm_os_type()
            logging.info(f"VM {self.vm_name} OS type: {os_type}")
            output = self.run_top_memory_processes(os_type)
            logging.info(f"RunCommand output for VM {self.vm_name}: {output[:500]}")
            self.store_run_command_output(self.data["EventId"], output)
            logging.info(f"Stored RunCommand output for VM {self.vm_name}, EventId: {self.data['EventId']}")
        except Exception as e:
            logging.error(f"Error running Memory analysis on VM {self.vm_name}: {e}")
            self.store_run_command_output(self.data["EventId"], f"ERROR: {str(e)}")
            raise e
        return True
