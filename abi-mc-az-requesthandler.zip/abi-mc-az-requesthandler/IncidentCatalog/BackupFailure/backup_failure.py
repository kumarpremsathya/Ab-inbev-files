import logging,json,asyncio
from shared_code import lock_manager
from shared_code.resourcegraph_client import ResourceGraph
from shared_code.recoveryservices_client import RecoveryServicesBkpClient
from IncidentCatalog.DiskCleanup.disk_cleanup import AzVMDiskCleanup
from shared_code.compute_client import ComputeClient
from shared_code.lock_manager import LockManager
import azure.mgmt.resourcegraph as arg

class AzVMBackupFailure:
    def __init__(self,data):
        self.data = data
        self.subscription_id = data["SubscriptionId"]
        self.resource_group_name = data["ResourceGroupName"]
        self.vm_name = data["ResourceName"]
        self.vm_id = data["ResourceId"]
        self.vault_name = data["VaultName"]
        self.zone = data['Zone'].lower()
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.enabled_errorcodes = [
            400141,  # UserErrorResourceGroupNotFound / Failed
            380022,  # ExtensionSnapshotFailedCOM
            520025,  # UserErrorSQLPODoesNotExist
        ]

    def get_backup_health(self):
        azenvironment = "AzurePublicCloud" if self.zone.lower() != "china" else "AzureChinaCloud"
        argClient = ResourceGraph().get_resorce_graph(azenvironment)
        argQueryOptions = arg.models.QueryRequestOptions(result_format="objectArray")
        strQuery = f"""
            RecoveryServicesResources 
            | where type in~ ('Microsoft.RecoveryServices/vaults/backupFabrics/protectionContainers/protectedItems')
            | extend vaultName = case(type =~ 'microsoft.dataprotection/backupVaults/backupInstances',split(split(id, '/Microsoft.DataProtection/backupVaults/')[1],'/')[0],type =~ 'Microsoft.RecoveryServices/vaults/backupFabrics/protectionContainers/protectedItems',split(split(id, '/Microsoft.RecoveryServices/vaults/')[1],'/')[0],'--')
            | extend dataSourceType = case(type=~'Microsoft.RecoveryServices/vaults/backupFabrics/protectionContainers/protectedItems',properties.backupManagementType,type =~ 'microsoft.dataprotection/backupVaults/backupInstances',properties.dataSourceSetInfo.datasourceType,'--')
            | where properties.dataSourceSetInfo.resourceID =~ '{self.vm_id}'
            | extend details = properties.healthDetails
        """
        argQuery = arg.models.QueryRequest(query=strQuery, options=argQueryOptions)
        argResults = argClient.resources(argQuery)
        result = argResults.as_dict()
        while("skip_token" in result.keys() and result["skip_token"]!= None):
            argQueryOptions = arg.models.QueryRequestOptions(skip_token=result["skip_token"],result_format="objectArray")
            argQuery = arg.models.QueryRequest(query=strQuery, options=argQueryOptions)
            argResults = argClient.resources(argQuery).as_dict()
            result["count"] += argResults["count"]
            result["data"] += argResults["data"]
            result["skip_token"] = argResults["skip_token"] if "skip_token" in argResults.keys() else None
        for vm in result["data"]:
            for detail in vm["details"]:
                if detail["code"] in self.enabled_errorcodes:
                    self.workload_type = vm['properties']["workloadType"]
                    self.backup_management_type = vm['properties']["backupManagementType"]
                    self.protected_item_type = vm['properties']["protectedItemType"]
                    self.container_name = vm['properties']["containerName"]
                    self.protected_item_name = vm['name']
                    return {'error_code': detail["code"], 'recommendations': detail["recommendations"]}
        return False
    
    def disable_backup(self):
        VAULT_NAME = self.vault_name
        RESOURCE_GROUP_NAME = self.resource_group_name
        FABRIC_NAME = "Azure" 
        CONTAINER_NAME = self.container_name
        PROTECTED_ITEM_NAME = self.protected_item_name
        client = RecoveryServicesBkpClient().get_recoveryservice_backup_client(self.cloud,self.subscription_id)
        try:
            client.protected_items.delete(
                vault_name=VAULT_NAME,
                resource_group_name=RESOURCE_GROUP_NAME,
                fabric_name=FABRIC_NAME,
                container_name=CONTAINER_NAME,
                protected_item_name=PROTECTED_ITEM_NAME
            )
            logging.info(f"Backup disabled successfully for VM {self.vm_name} in vault {VAULT_NAME}.")
        except Exception as e:
            logging.error(f"Failed to disable backup for VM {self.vm_name}: {e}")
    
    def disk_cleanup(self):
        disk_cleanup_handler = AzVMDiskCleanup({
            "SubscriptionId": self.subscription_id,
            "ResourceGroupName": self.resource_group_name,
            "ResourceName": self.vm_name,
            "ResourceId": self.vm_id,
            "Zone": self.zone
        })
        try:
            asyncio.run(disk_cleanup_handler.cleanup())
            logging.info(f"Disk cleanup executed successfully for VM {self.vm_name}.")
        except Exception as e:
            logging.error(f"Disk cleanup failed for VM {self.vm_name}: {e}")

    def retry_backup(self):
        VAULT_NAME = self.vault_name
        RESOURCE_GROUP_NAME = self.resource_group_name
        FABRIC_NAME = "Azure" 
        CONTAINER_NAME = self.container_name
        PROTECTED_ITEM_NAME = self.protected_item_name
        client = RecoveryServicesBkpClient().get_recoveryservice_backup_client(self.cloud,self.subscription_id)
        try:
            operation = client.backups.trigger(
                vault_name=VAULT_NAME,
                resource_group_name=RESOURCE_GROUP_NAME,
                fabric_name=FABRIC_NAME,
                container_name=CONTAINER_NAME,
                protected_item_name=PROTECTED_ITEM_NAME
            )
            logging.info(f"Triggered resync for VM {self.vm_name} in vault {VAULT_NAME}.")
        except Exception as e:
            logging.error(f"Failed to trigger resync for VM {self.vm_name}: {e}")
    
    def restart_comsysapp(self):
        self.compute_client = ComputeClient().get_compute_client(self.subscription_id, self.cloud)
        command = {
                'command_id': 'RunPowerShellScript',
                'script': [
                    "net stop comsysapp",
                    "net start comsysapp"
                ]
            }
        poller = self.compute_client.virtual_machines.begin_run_command(
            self.resource_group_name, self.vm_name, command
        )
        result = poller.result()
        logging.info(result.value[0].message.strip())
        pass  

    def upgrade_vm_agent(self):
        self.compute_client = ComputeClient().get_compute_client(self.subscription_id, self.cloud)
        command = {
            'command_id': 'RunPowerShellScript',
            'script': [
                "sed -i 's/^AutoUpdate\.Enabled=N$/AutoUpdate.Enabled=Y/' /etc/waagent.conf",
                "waagent -upgrade"
            ]
        }
        poller = self.compute_client.virtual_machines.begin_run_command(
            self.resource_group_name, self.vm_name, command
        )
        result = poller.result()
        logging.info(result.value[0].message.strip())
    
    def restart_vss_service(self):
        self.compute_client = ComputeClient().get_compute_client(self.subscription_id, self.cloud)
        command = {
                'command_id': 'RunPowerShellScript',
                'script': [
                    "net stop vss",
                    "net start vss",
                    "net stop swprv",
                    "net start swprv"
                ]
            }
        poller = self.compute_client.virtual_machines.begin_run_command(
            self.resource_group_name, self.vm_name, command
        )
        result = poller.result()
        logging.info(result.value[0].message.strip())
    
    def remove_locks(self):
        self.lock_manager = LockManager(self.subscription_id,self.zone,self.resource_group_name,self.vm_name)
        try:
            self.lock_manager.remove_all_locks(scope=self.vm_id, lock_types=["ReadOnly","AzureBackupProtectionLock"])
            logging.info(f"Locks removed successfully from VM {self.vm_name}.")
        except Exception as e:
            logging.error(f"Failed to remove locks from VM {self.vm_name}: {e}")

    def handle_backup_failure(self):
        error = self.get_backup_health()
        if error:
            logging.info(f"Recommendations: {error['recommendations']}")
            match int(error['error_code']):
                case 400141 | 520025:
                    self.disable_backup()
                # case 510106:
                #     self.disk_cleanup()
                # case 400039:
                #     self.retry_backup()
                case 380022:
                    self.restart_comsysapp()
                    self.retry_backup()
                # case 400185:
                #     self.remove_locks()
                #     self.retry_backup()
                # case 400196:
                #     self.upgrade_vm_agent()
                # case 380036:
                #     self.restart_vss_service()
                #     self.retry_backup()
                case _:
                    logging.info(f"No action defined for error code {error['error_code']}.")