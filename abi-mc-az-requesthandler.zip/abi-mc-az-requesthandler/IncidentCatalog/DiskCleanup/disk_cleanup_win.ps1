param(
    [string[]]$UsersToRemove
)
function Remove-UserAndHomeDirectory {
    param([string]$Username)
    try {
        $profilePath = "C:\Users\$Username"
        if (-not (Test-Path $profilePath)) { return }
        $skip = @('ntuser.dat','ntuser.dat.log','ntuser.ini')
        Get-ChildItem $profilePath -Force -ErrorAction SilentlyContinue |
            ForEach-Object {
                if (-not $_.PSIsContainer) {
                    if ($skip -contains $_.Name.ToLower()) { return }
                }
                Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
            }
    }
    catch {}
}
try{
    $users = @()
    if ($UsersToRemove) {
        $users = $UsersToRemove |
            ForEach-Object { $_.ToString().Trim() } |
            Where-Object { $_ -ne "" }
    }
    if ($users.Count -gt 0) {
        $users | ForEach-Object { Remove-UserAndHomeDirectory $_ }
    }
    $threshold = (Get-Date).AddDays(-60)
    foreach ($username in $users) {
        $profilePath = "C:\Users\$username"
        if (-not (Test-Path $profilePath)) { continue }
        foreach ($folder in @('Downloads','Desktop')) {
            $targetPath = Join-Path $profilePath $folder
            if (-not (Test-Path $targetPath)) { continue }
            Get-ChildItem $targetPath -Force -Recurse -ErrorAction SilentlyContinue |
                Where-Object {
                    -not $_.PSIsContainer -and
                    $_.LastWriteTime -lt $threshold -and
                    $_.Extension.ToLower() -notin @('.lnk','.url')
                } |
                ForEach-Object {
                    Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue
                }
            Get-ChildItem $targetPath -Force -Recurse -ErrorAction SilentlyContinue |
                Where-Object { $_.PSIsContainer } |
                Sort-Object FullName -Descending |
                ForEach-Object {
                    $children = Get-ChildItem $_.FullName -Force -ErrorAction SilentlyContinue
                    if (-not $children -and $_.LastWriteTime -lt $threshold) {
                        Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
                    }
                }
        }
        $profilePath = "C:\Users\$username"
        if (-not (Test-Path $profilePath)) { continue }
        foreach ($rel in @(
            "AppData\Local\Temp","AppData\LocalLow\Temp","AppData\Local\Microsoft\Windows\INetCache"
        )) {
            $tempPath = Join-Path $profilePath $rel
            if (-not (Test-Path $tempPath)) { continue }

            Get-ChildItem $tempPath -Force -Recurse -ErrorAction SilentlyContinue |
                ForEach-Object {
                    Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
                }
        }
    }
    Stop-Service wuauserv -Force -ErrorAction SilentlyContinue
    $regPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches"
    $volumeCaches = @(
        "Active Setup Temp Folders","Content Indexer Cleaner","D3D Shader Cache","Diagnostic Data Viewer database files",
        "Downloaded Program Files","DownloadsFolder","Internet Cache Files","Offline Pages Files","Old ChkDsk Files",
        "Previous Installations","Recycle Bin","Setup Log Files","System error memory dump files","System error minidump files",
        "Temporary Files","Temporary Setup Files","Temporary Sync Files","Thumbnail Cache","Upgrade Discarded Files",
        "Windows Error Reporting Files","Windows ESD installation files","Windows Upgrade Log Files"
    )
    foreach ($cache in $volumeCaches) {
        $cachePath = Join-Path $regPath $cache
        if (Test-Path $cachePath) {
            Set-ItemProperty -Path $cachePath `
                -Name StateFlags0100 `
                -Value 2 `
                -Type DWord `
                -ErrorAction SilentlyContinue
        }
    }
    Start-Process cleanmgr.exe "/sagerun:100" -NoNewWindow -Wait
    $updateCache = "$env:WINDIR\SoftwareDistribution\Download"
    if (Test-Path $updateCache) {
        Get-ChildItem $updateCache -Recurse -Force -ErrorAction SilentlyContinue |
            Where-Object {
                -not $_.PSIsContainer -and
                $_.LastWriteTime -lt $threshold
            } |
            ForEach-Object {
                Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue
            }
        Get-ChildItem $updateCache -Recurse -Force -ErrorAction SilentlyContinue |
            Where-Object { $_.PSIsContainer } |
            Sort-Object FullName -Descending |
            ForEach-Object {
                $children = Get-ChildItem $_.FullName -Force -ErrorAction SilentlyContinue
                if (-not $children -and $_.LastWriteTime -lt $threshold) {
                    Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
                }
            }
    }
} catch {
} finally {
    Start-Service wuauserv -ErrorAction SilentlyContinue
}