import logging,json,os,base64,asyncio
from azure.mgmt.compute.models import VirtualMachineExtension
from shared_code.compute_client import ComputeClient
from shared_code.lock_manager import LockManager
from DAL.DbActivityManager import DbActivityManager

class AzVMDiskCleanup:
    def __init__(self,data):
        self.data = data
        self.subscription_id = data["SubscriptionId"]
        self.resource_group_name = data["ResourceGroupName"]
        self.vm_name = data["ResourceName"]
        self.vm_id = data["ResourceId"]
        self.volume = data["Volume"].replace(":","").upper()
        self.threshold = data["Threshold"]
        self.zone = data["Zone"].lower()
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.compute_client = ComputeClient().get_compute_client(self.subscription_id, self.cloud)
        self.lock_manager = LockManager(self.subscription_id, self.zone, self.resource_group_name,self.vm_name,self.vm_id)
        self.db_activity_manager = DbActivityManager()

    def is_vm_agent_available(self):
        response = self.compute_client.virtual_machines.instance_view(self.resource_group_name, self.vm_name)
        if response.vm_agent is None:
            return False
        if response.vm_agent.statuses[0].display_status == 'Ready':
            return True
        return False
    
    def get_vm_os_type_and_location(self):
        response = self.compute_client.virtual_machines.get(self.resource_group_name, self.vm_name,expand='instanceView')
        if response.storage_profile.os_disk.os_type == 'Windows':
            if hasattr(response.storage_profile, 'image_reference') and response.storage_profile.image_reference:
                sku = response.storage_profile.image_reference.sku
                if sku is not None and any(year in sku for year in ['2008', '2012','2016', '2019','2022','2025']):
                    return 'windows-old', response.location
            os_name = getattr(response.instance_view, 'os_name', '').lower()
            if 'windows' in os_name:
                if any(year in os_name for year in ['2008', '2012', '2016', '2019','2022','2025']):
                    return 'windows-old', response.location
                return 'windows', response.location        
        return 'linux', response.location

    def get_command(self,os_type):
        inactive_users = self.db_activity_manager.get_inactive_users(self.vm_name)
        if os_type == 'linux':
            with open(os.path.join('IncidentCatalog', 'DiskCleanup', 'disk_cleanup_linux.sh'), 'rb') as f:
                script = f.read().decode('utf-8')
            b64_script = base64.b64encode(script.encode('utf-8')).decode('utf-8')
            users_arg = ' '.join(f"{user}" for user in inactive_users)
            command = f""" bash -c "b64='{b64_script}'; printf '%s' \"$b64\" | base64 -d > /tmp/disk_cleanup_linux.sh; chmod +x /tmp/disk_cleanup_linux.sh; /bin/bash /tmp/disk_cleanup_linux.sh {users_arg}" """
            return command
        else:
            with open(os.path.join('IncidentCatalog', 'DiskCleanup', 'disk_cleanup_win.ps1'), 'rb') as f:
                ps_script = base64.b64encode(f.read()).decode('utf-8')
            command = f""" powershell.exe -Command \"$b64='{ps_script}'; $bytes=[Convert]::FromBase64String($b64); [IO.File]::WriteAllBytes('C:\\Windows\\Temp\\disk_cleanup_win.ps1', $bytes);\"; powershell.exe -ExecutionPolicy Unrestricted -File C:\\Windows\\Temp\\disk_cleanup_win.ps1 {'-UsersToRemove' if inactive_users else ''} {','.join(f"{user}" for user in inactive_users)}"
            """
            return command

    async def cleanup(self):
        if not self.is_vm_agent_available():
            logging.error(f'VM Agent is not available or VM is not running on {self.vm_name}')
            raise Exception(f'VM Agent is not available or VM is not running on {self.vm_name}')
        self.lock_manager.remove_all_locks()
        try:
            os_type,location = self.get_vm_os_type_and_location()
            if  os_type in ['windows','windows-old']:
                puslisher = 'Microsoft.Compute'
                type_properties_type = 'CustomScriptExtension'
                type_handler_version = '1.10'
            else:
                puslisher = 'Microsoft.Azure.Extensions'
                type_properties_type = 'CustomScript'
                type_handler_version = '2.1'
            response = self.compute_client.virtual_machine_extensions.list(resource_group_name=self.resource_group_name, vm_name=self.vm_name)
            if response.value:
                for ext in response.value:
                    if ext.publisher in ["Microsoft.Compute","Microsoft.Azure.Extensions"] and ext.type_properties_type in ["CustomScript","CustomScriptExtension"]:
                        response = self.compute_client.virtual_machine_extensions.begin_delete(resource_group_name=self.resource_group_name, vm_name=self.vm_name, vm_extension_name=ext.name)
                        result = response.result()
                        logging.info(f'Extension {ext.name} deleted successfully from VM {self.vm_name}')
                        break
            command = self.get_command(os_type)
            try: 
                response = self.compute_client.virtual_machine_extensions.begin_create_or_update(
                        resource_group_name=self.resource_group_name, 
                        vm_name=self.vm_name, 
                        vm_extension_name='Bewmation-VM-Disk-Cleanup', 
                        extension_parameters=VirtualMachineExtension(
                            location=location,
                            publisher=puslisher,
                            type_properties_type=type_properties_type, 
                            type_handler_version=type_handler_version, 
                            protected_settings= {
                                'commandToExecute': command,
                            }   
                    )
                )
                result = response.result()
            except Exception as e:
                logging.error(f'Error VM Disk Cleanup Extension {e}')
            logging.info(f'VM Disk Cleanup Extension created successfully {result.as_dict()}')
            response = self.compute_client.virtual_machine_extensions.get(
                resource_group_name=self.resource_group_name,
                vm_name=self.vm_name,
                vm_extension_name='Bewmation-VM-Disk-Cleanup',
                expand='instanceView'
            )

            logging.info(f'Disk Cleaned {response.as_dict()}')
            command_win = {
                'command_id': 'RunPowerShellScript',
                'script': [
                    f"[math]::Round(((Get-Volume -DriveLetter {self.volume}).Size - (Get-Volume -DriveLetter {self.volume}).SizeRemaining) / (Get-Volume -DriveLetter {self.volume}).Size * 100, 2)"
                ]
            }
            command_linux = {
                'command_id': 'RunShellScript',
                'script': [
                    "df / --output=pcent | tail -1 | tr -d ' %'"
                ]
            }
            poller = self.compute_client.virtual_machines.begin_run_command(
                self.resource_group_name, self.vm_name, command_win if os_type in ['windows','windows-old'] else command_linux
            )
            result = poller.result()
            used = int(float(result.value[0].message.strip()))
            if used >= int(self.threshold):
                logging.warning(f"Used OS disk space {used} GB is above the threshold of {self.threshold} GB")
                raise Exception(f"Used OS disk space {used} GB is above the threshold of {self.threshold} GB")
        except Exception as e:
            logging.error(f'Error while cleaning Disk {e}')
            raise e
        finally:
            response = self.compute_client.virtual_machine_extensions.begin_delete(
                resource_group_name=self.resource_group_name,
                vm_name=self.vm_name,
                vm_extension_name='Bewmation-VM-Disk-Cleanup'
            )
            result = response.result()
            logging.info(f'Removed VM Disk Cleanup Extension')
            self.lock_manager.restore_locks()