#!/usr/bin/env bash
set -euo pipefail
TMP_MAX_AGE_DAYS=7         # Remove files in /tmp and /var/tmp older than this
LOG_MAX_AGE_DAYS=30        # Remove rotated/compressed logs older than this
JOURNAL_VACUUM_SIZE="200M" # If journalctl present, shrink to this size (set empty to skip)
DRY_RUN=false              # Set to true to show what would be removed without deleting

# Helpers
echoinfo()   { printf '\033[1;34m[INFO]\033[0m %s\n' "$*"; }
echowarn()   { printf '\033[1;33m[WARN]\033[0m %s\n' "$*"; }
echoerror()  { printf '\033[1;31m[ERROR]\033[0m %s\n' "$*"; }

run_cmd() {
    if $DRY_RUN; then
        printf "DRYRUN: %s\n" "$*"
    else
        eval "$@"
    fi
}
require_root() {
    if [ "$(id -u)" -ne 0 ]; then
        echoerror "This script must be run as root. Use sudo."
        exit 2
    fi
}
detect_pkg_manager() {
    if command -v apt-get >/dev/null 2>&1; then echo "apt"; return; fi
    if command -v dnf >/dev/null 2>&1; then echo "dnf"; return; fi
    if command -v yum >/dev/null 2>&1; then echo "yum"; return; fi
    if command -v zypper >/dev/null 2>&1; then echo "zypper"; return; fi
    if command -v pacman >/dev/null 2>&1; then echo "pacman"; return; fi
    if command -v apk >/dev/null 2>&1; then echo "apk"; return; fi
    echo "unknown"
}

pkg_cleanup() {
    local pm="$1"
    echoinfo "Package manager detected: $pm — running cleanup"
    case "$pm" in
        apt)
            run_cmd "apt-get update -qq || true"
            run_cmd "DEBIAN_FRONTEND=noninteractive apt-get -y -o Dpkg::Options::='--force-confdef' -o Dpkg::Options::='--force-confold' autoremove"
            run_cmd "apt-get -y autoclean"
            run_cmd "apt-get -y clean"
            ;;
        dnf)
            run_cmd "dnf -y autoremove || true"
            run_cmd "dnf -y clean all"
            ;;
        yum)
            run_cmd "yum -y autoremove || true"
            run_cmd "yum -y clean all"
            ;;
        zypper)
            run_cmd "zypper --non-interactive clean --all"
            ;;
        pacman)
            # remove cached packages not in sync databases and clear unneeded cache
            run_cmd "pacman -Syu --noconfirm || true"
            run_cmd "pacman -Rns $(pacman -Qdtq 2>/dev/null || true) --noconfirm || true"
            run_cmd "yes | pacman -Scc || true"
            # keep recent packages (paccache requires pacman-contrib)
            if command -v paccache >/dev/null 2>&1; then
                run_cmd "paccache -ruk1 || true"
            fi
            ;;
        apk)
            run_cmd "apk cache clean || true"
            ;;
        *)
            echowarn "Unknown or unsupported package manager — skipping package cache cleanup"
            ;;
    esac
}

clean_tmp() {
    echoinfo "Cleaning temporary files older than ${TMP_MAX_AGE_DAYS} days in /tmp and /var/tmp"
    # Be conservative: remove regular files and empty dirs older than X days
    if [ -d /tmp ]; then
        if $DRY_RUN; then
            find /tmp -mindepth 1 -xdev -type f -mtime +"$TMP_MAX_AGE_DAYS" -print || true
            find /tmp -mindepth 1 -xdev -type d -empty -mtime +"$TMP_MAX_AGE_DAYS" -print || true
        else
            find /tmp -mindepth 1 -xdev -type f -mtime +"$TMP_MAX_AGE_DAYS" -delete || true
            find /tmp -mindepth 1 -xdev -type d -empty -mtime +"$TMP_MAX_AGE_DAYS" -delete || true
        fi
    fi
    if [ -d /var/tmp ]; then
        if $DRY_RUN; then
            find /var/tmp -mindepth 1 -xdev -type f -mtime +"$TMP_MAX_AGE_DAYS" -print || true
            find /var/tmp -mindepth 1 -xdev -type d -empty -mtime +"$TMP_MAX_AGE_DAYS" -print || true
        else
            find /var/tmp -mindepth 1 -xdev -type f -mtime +"$TMP_MAX_AGE_DAYS" -delete || true
            find /var/tmp -mindepth 1 -xdev -type d -empty -mtime +"$TMP_MAX_AGE_DAYS" -delete || true
        fi
    fi
}

clean_logs() {
    echoinfo "Cleaning rotated/compressed logs older than ${LOG_MAX_AGE_DAYS} days in /var/log"
    if [ -d /var/log ]; then
        if $DRY_RUN; then
            find /var/log -type f \( -name '*.gz' -o -name '*.1' -o -name '*.old' -o -name '*.xz' -o -name '*.lz4' \) -mtime +"$LOG_MAX_AGE_DAYS" -print || true
        else
            find /var/log -type f \( -name '*.gz' -o -name '*.1' -o -name '*.old' -o -name '*.xz' -o -name '*.lz4' \) -mtime +"$LOG_MAX_AGE_DAYS" -delete || true
        fi
    fi
}

vacuum_journal() {
    if command -v journalctl >/dev/null 2>&1; then
        echoinfo "systemd journal detected"
        if [ -n "$JOURNAL_VACUUM_SIZE" ]; then
            echoinfo "Vacuuming journal to keep <= $JOURNAL_VACUUM_SIZE"
            run_cmd "journalctl --vacuum-size=$JOURNAL_VACUUM_SIZE || true"
        else
            echoinfo "No journal vacuum size configured — skipping"
        fi
    else
        echoinfo "journalctl not present — skipping journal vacuum"
    fi
}

container_cleanup() {
    # If running in a container, package manager cleanup may be limited. Still try caches.
    if [ -f /.dockerenv ] || [ -f /run/.containerenv ]; then
        echoinfo "Container environment detected"
    fi
}
purge_user_homes() {
    if [ "$#" -eq 0 ]; then
        return
    fi

    echoinfo "Purging contents of home directories for users: $*"
    for user in "$@"; do
        home_dir="$(getent passwd "$user" | cut -d: -f6 || true)"
        if [ -z "$home_dir" ]; then
            echowarn "User '$user' not found — skipping"
            continue
        fi
        if command -v readlink >/dev/null 2>&1; then
            home_dir="$(readlink -f -- "$home_dir" 2>/dev/null || echo "$home_dir")"
        fi
        if [ -z "$home_dir" ] || [ "$home_dir" = "/" ]; then
            echoerror "Unsafe home dir '$home_dir' for user '$user' — skipping"
            continue
        fi
        if case "$home_dir" in /home/*|/home) true;; *) false;; esac; then
            :
        else
            echowarn "Home directory for '$user' is '$home_dir' which is outside /home"
            if [ "${ALLOW_ANY_HOME:-0}" != "1" ]; then
                echowarn "Skipping '$user'. Set ALLOW_ANY_HOME=1 to allow purging homes outside /home"
                continue
            fi
            echowarn "ALLOW_ANY_HOME=1 set; proceeding with caution for '$user'"
        fi

        if [ ! -d "$home_dir" ]; then
            echowarn "Home directory '$home_dir' for user '$user' does not exist — skipping"
            continue
        fi
        echoinfo "Removing contents of '$home_dir' for user '$user'"
        if $DRY_RUN; then
            find "$home_dir" -mindepth 1 -xdev -print || true
        else
            find "$home_dir" -mindepth 1 -xdev -exec rm -rf -- {} + || true
        fi
    done
}
summarize() {
    echoinfo "Disk usage before/after summary (root filesystem):"
    df -h / || true
}
main() {
    require_root
    echoinfo "Starting non-interactive disk cleanup"
    summarize

    container_cleanup

    PM="$(detect_pkg_manager)"
    pkg_cleanup "$PM"

    clean_tmp
    clean_logs
    vacuum_journal
    if [ "$PM" = "apt" ]; then
        echoinfo "Cleaning apt lists older than 30 days"
        if $DRY_RUN; then
            find /var/lib/apt/lists -type f -mtime +30 -print || true
        else
            find /var/lib/apt/lists -type f -mtime +30 -delete || true
        fi
    fi
    if command -v fstrim >/dev/null 2>&1; then
        echoinfo "Running fstrim on mounted filesystems supporting trim (may help on thin-provisioned storage)"
        run_cmd "fstrim -av || true"
    fi
    purge_user_homes "$@"

    echoinfo "Cleanup complete"
    summarize
}
main "$@"