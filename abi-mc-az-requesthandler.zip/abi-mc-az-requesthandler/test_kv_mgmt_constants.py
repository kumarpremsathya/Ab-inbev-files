"""
Verification script for FUNCTION_APP_PRINCIPAL_ID and KV Secrets Officer role ID
used in KeyVaultMgmt._grant_pim_kv_officer()
"""
from azure.identity import DefaultAzureCredential, InteractiveBrowserCredential
from azure.mgmt.authorization import AuthorizationManagementClient
from azure.mgmt.web import WebSiteManagementClient

ENVIRONMENTS = {
    "non-prod": {
        "subscription_id":      "73f88e6b-3a35-4612-b550-555157e7059f",
        "resource_group":       "config-mgmt-rg-gb-non-prod",
        "function_app_name":    "dev-abi-mc-az-requesthandler",
        "expected_principal_id": "e1a76d1c-d40f-4256-bf55-ef6d5710b878",
    },
    "prod": {
        "subscription_id":      "2db7c27b-2f9f-4088-981b-2bd88c5c1905",
        "resource_group":       "CONFIG-MGMT-RG-GB-PROD",
        "function_app_name":    "abi-mc-az-requesthandler",
        "expected_principal_id": "175069f8-dddf-4e77-ad30-4d87da8904c4",
    },
}

EXPECTED_ROLE_GUID = "b86a8fe4-44ce-4948-aee5-eccb2c155cd7"

try:
    credential = DefaultAzureCredential()
    credential.get_token("https://management.azure.com/.default")
except Exception:
    credential = InteractiveBrowserCredential()


def check_principal_id(env_name, env):
    web_client = WebSiteManagementClient(credential, env["subscription_id"])
    app = web_client.web_apps.get(env["resource_group"], env["function_app_name"])
    actual = app.identity.principal_id if app.identity else None
    expected = env["expected_principal_id"]
    if expected is None:
        print(f"[{env_name} Function App Principal ID]")
        print(f"  Actual   : {actual}")
        print(f"  Status   : DISCOVERED (update expected_principal_id if correct)")
        return True
    match = actual == expected
    print(f"[{env_name} Function App Principal ID]")
    print(f"  Expected : {expected}")
    print(f"  Actual   : {actual}")
    print(f"  Match    : {'PASS' if match else 'FAIL'}")
    return match


def check_role_definition(env_name, env):
    auth_client = AuthorizationManagementClient(credential, env["subscription_id"])
    roles = list(auth_client.role_definitions.list(
        scope=f"/subscriptions/{env['subscription_id']}",
        filter="roleName eq 'Key Vault Secrets Officer'"
    ))
    actual_guid = roles[0].name if roles else None
    match = actual_guid == EXPECTED_ROLE_GUID
    print(f"\n[{env_name} Key Vault Secrets Officer Role GUID]")
    print(f"  Expected : {EXPECTED_ROLE_GUID}")
    print(f"  Actual   : {actual_guid}")
    print(f"  Match    : {'PASS' if match else 'FAIL'}")
    return match


if __name__ == "__main__":
    all_pass = True
    for name, env in ENVIRONMENTS.items():
        print(f"\n{'='*40}")
        print(f"  Environment: {name}")
        print(f"{'='*40}")
        p = check_principal_id(name, env)
        r = check_role_definition(name, env)
        all_pass = all_pass and p and r
    print(f"\nOverall: {'ALL PASS' if all_pass else 'SOME CHECKS FAILED'}")
