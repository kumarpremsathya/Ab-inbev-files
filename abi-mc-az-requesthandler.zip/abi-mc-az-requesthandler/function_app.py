import azure.functions as func
import azure.durable_functions as df
import time,json,logging
from az_activity_blueprint import activity_blueprints
from Orchestration.OrchestrationClassifier import OrchestratorClassifier
from StatusMonitor.StatusMonitor import StatusMonitor

myApp = df.DFApp(http_auth_level=func.AuthLevel.FUNCTION)
myApp.register_functions(activity_blueprints)

# Service Bus Trigger function to start the orchestration
@myApp.service_bus_topic_trigger(arg_name="azservicebus", topic_name='request_handler',
                               connection="AzureWebJobsMyServiceBus",subscription_name='request_handler') 
@myApp.durable_client_input(client_name="client")
async def request_handler(azservicebus: func.ServiceBusMessage, client: df.DurableOrchestrationClient):
    data = json.loads(azservicebus.get_body().decode('utf-8'))
    status = await client.get_status(instance_id=data["ActivityId"])
    if status is not None:
        if status.runtime_status in [df.OrchestrationRuntimeStatus.Pending, df.OrchestrationRuntimeStatus.Running, df.OrchestrationRuntimeStatus.Completed]:
            logging.info(f"Orchestration with ID = '{data['ActivityId']}' already exists")
            return
        elif status.runtime_status in [df.OrchestrationRuntimeStatus.Failed, df.OrchestrationRuntimeStatus.Canceled]:
            await client.purge_instance_history(data["ActivityId"])
            logging.info(f"Orchestration with ID = '{data['ActivityId']}' purged")
    instance_id = await client.start_new("orchestrate_activity",instance_id=data["ActivityId"],client_input=data)
    logging.info(f"Started orchestration with ID = '{instance_id}'")

# Orchestrator function
@myApp.orchestration_trigger(context_name="context")
def orchestrate_activity(context: df.DurableOrchestrationContext):
    classifier = OrchestratorClassifier()
    yield from classifier.classify(context)

@myApp.orchestration_trigger(context_name="context")
def vmprovision_orchestrator(context: df.DurableOrchestrationContext):
    logging.info("Starting VM Provisioning")
    retry_options = df.RetryOptions(1800000,3)
    data = context.get_input()
    data = yield context.call_activity_with_retry("vmprovision_createvm", retry_options, data)
    data['DomainJoin'] = yield context.call_activity_with_retry("vmprovision_domainjoin", retry_options, data)
    data['Puppet'] = yield context.call_activity_with_retry("vmprovision_puppet", retry_options, data)
    post_vm_tasks = [
        context.call_activity_with_retry("vmprovision_vmbackup", retry_options, data),
        context.call_activity_with_retry("vmprovision_bginfo", retry_options, data),
        context.call_activity_with_retry("vmprovision_sam", retry_options, data),
        context.call_activity_with_retry("vmprovision_registersqlvm", retry_options, data)
    ]
    backup, bginfo, sam, sql_vm = yield context.task_all(post_vm_tasks)
    data.update({
        "VMBackup": backup,
        "BGInfo": bginfo,
        "Sam": sam,
        "SQLVM": sql_vm
    })
    return data

@myApp.orchestration_trigger(context_name="context")
def hoursofoperationinstance_orchestrator(context: df.DurableOrchestrationContext):
    retry_options = df.RetryOptions(300000, 2)
    data = context.get_input()
    result = yield context.call_activity_with_retry("hoursofoperationinstance", retry_options, data)
    return result

@myApp.timer_trigger(schedule="0 */5 * * * *", arg_name="myTimer", run_on_startup=False,
              use_monitor=True) 
@myApp.durable_client_input(client_name="client")
async def status_monitor_hoursofoperation(myTimer: func.TimerRequest, client: df.DurableOrchestrationClient):
    try:
        await StatusMonitor(client).update_status_hoursofoperationinstance()
    except Exception as e:
        logging.error(f"HoursOfOperation Status Monitor Error - {e}")
        raise e

@myApp.timer_trigger(schedule="0 */1 * * * *", arg_name="myTimer", run_on_startup=False,
              use_monitor=True) 
@myApp.durable_client_input(client_name="client")
async def status_monitor(myTimer: func.TimerRequest, client: df.DurableOrchestrationClient):
    try:
        await StatusMonitor(client).update_status()
    except Exception as e:
        logging.error(f"Status Monitor Error - {e}")
        raise e