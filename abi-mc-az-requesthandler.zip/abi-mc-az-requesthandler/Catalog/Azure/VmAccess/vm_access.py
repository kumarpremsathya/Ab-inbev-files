import logging,json,ldap3,os,time
from azure.mgmt.compute.models import VirtualMachineExtension
from shared_code.compute_client import ComputeClient
from shared_code.lock_manager import LockManager
from DAL.DbActivityManager import DbActivityManager
from shared_code.EmailNotification.NotifyUser import NotifyUser
from shared_code.akv_secrets import AkvSecrets

class AzVMAccess:
    def __init__(self,data):
        self.data = data
        self.subscription_id = data["SubscriptionId"]
        self.resource_group_name = data["ResourceGroupName"]
        self.vm_name = data["ResourceName"]
        self.vm_id = data["ResourceId"]
        self.access_level = data["Role"]
        self.action = data["Action"]
        self.users = [f'{self.get_domain_prefix(user["domain"])}\{user["id"]}' for user in json.loads(data["MemberIds"])]
        self.users_linux = [f'{self.get_domain_prefix(user["domain"])}\\\{user["id"].lower()}' for user in json.loads(data["MemberIds"])]
        self.zone = data['Zone'].lower()
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.compute_client = ComputeClient().get_compute_client(self.subscription_id, self.cloud)
        self.lock_manager = LockManager(self.subscription_id, self.zone, self.resource_group_name, self.vm_name, self.vm_id)
        self.secret = AkvSecrets(os.environ["KEYVAULT_URI"],'domain-join').get_tokens()

    def get_domain_prefix(self,domain):
        match domain.lower():
            case "one.ofc.loc":
                return "ONE"
            case "we.interbrew.net":
                return "WEINTERBREW"
            case "na.interbrew.net":
                return "NA1"
            case "beerdivision.africa.gcn.local":
                return "BEERSA"
            case "ob.co.kr":
                return "ob.co.kr"
            case "modelo.gmodelo.com.mx":
                return "MODELO"
            # TODO: Add more domain cases as needed
            case _:
                return domain.split(".")[0].upper()

    def is_vm_agent_available(self):
        response = self.compute_client.virtual_machines.instance_view(self.resource_group_name, self.vm_name)
        if response.vm_agent is None:
            return False
        if response.vm_agent.statuses[0].display_status == 'Ready':
            return True
        return False
    
    def get_vm_os_type_and_location(self):
        response = self.compute_client.virtual_machines.get(self.resource_group_name, self.vm_name)
        if response.storage_profile.os_disk.os_type == 'Windows':
            return 'windows', response.location
        elif response.storage_profile.os_disk.os_type == 'Linux':
            return 'linux', response.location
        else:
            raise Exception(f'Unknown OS type for VM {self.vm_name}')
    
    def get_vm_admin(self):
        if self.data.get('admin_username'):
            return self.data['admin_username']
        response = self.compute_client.virtual_machines.get(self.resource_group_name, self.vm_name)
        return response.os_profile.admin_username
    
    def is_vm_domain_joined(self):
        response = self.compute_client.virtual_machines.get(self.resource_group_name, self.vm_name)
        if response.os_profile.windows_configuration and response.os_profile.windows_configuration.domain_name:
            return True
        return False
    
    async def notify_user(self,vm_name,status,comments):
        event = {}
        objdb = DbActivityManager()
        dataset = objdb.get_event_info(self.data['EventId'])
        event['SnowItemId'] = dataset[0].SnowItemId
        requested_by = dataset[0].RequestedBy
        event['details']=[
            {
             'vm_name':vm_name,
             'status':status,
             'comments':comments
            }
        ]
        await NotifyUser().send_email_notification(event,requested_by)
    
    def get_command(self,os_type):
        if self.zone == 'europe':
            group_name = f"G-SWED-WE-{self.vm_name}-LocalAdmins" if self.access_level.lower() == "administrator" else f"G-SWED-WE-{self.vm_name}-LocalUsers"
            username = "WEINTERBREW\\azure.svc.we"
            server_name = 'WEAERDC001.we.interbrew.net'
            base_dn = 'OU=Server Admins,OU=Administrative Groups,OU=Groups,OU=ABI-IBS-EU-EuropeDC1 (Amsterdam),DC=we,DC=interbrew,DC=net'
            search_dn = "DC=we,DC=interbrew,DC=net"
            if os_type == 'windows':
                self.create_ad_group(username,server_name,base_dn,search_dn,group_name)
            self.users = [group_name]
            # self.users_linux = [f"WEINTERBREW\\\\{group_name}"] --- IGNORE ---
            if os_type == 'windows':
                return f"""powershell -Command "if ((systeminfo | Select-String 'Domain') -ne $null -and (systeminfo | Select-String 'Domain') -notmatch 'WORKGROUP') {{ {"".join([f"$exists = Get-LocalGroupMember -Group '{'Administrators' if self.access_level.lower() == 'administrator' else 'Remote Desktop Users'}' | Where-Object {{$_.Name -eq '{user}'}}; if (-not $exists) {{ Add-LocalGroupMember -Group '{'Administrators' if self.access_level.lower() == 'administrator' else 'Remote Desktop Users'}' -Member '{user}' -ErrorAction SilentlyContinue ; }}" for user in self.users]) } }} else {{ echo 'Error VM is not domain joined' "}}"""
            else:
                return f"""if wbinfo -p >/dev/null 2>&1; then {"".join([f"sudo usermod -aG sudousers {user};" if self.access_level.lower() == "administrator" else f"sudo usermod -aG sshusers {user};" for user in self.users_linux]) } else echo 'Error VM is not domain joined'; fi"""
        commands = {
            'windows': {
            'add':
            f"""
            powershell -Command "if ((systeminfo | Select-String 'Domain') -ne $null -and (systeminfo | Select-String 'Domain') -notmatch 'WORKGROUP') {{ {"".join([f"if ((net localgroup administrators | findstr /C:'{user}') -eq $null) {{ net localgroup administrators {user} /add; }};" if self.access_level.lower() == "administrator" else f"if ((net localgroup 'remote desktop users' | findstr /C:'{user}') -eq $null) {{ net localgroup 'remote desktop users' {user} /add; }};" for user in self.users]) } }} else {{ echo 'Error VM is not domain joined' "}}
            """,
            'remove': 
            f"""
            powershell -Command "if ((systeminfo | Select-String 'Domain') -ne $null -and (systeminfo | Select-String 'Domain') -notmatch 'WORKGROUP') {{ {"".join([f"if ((net localgroup administrators | findstr /C:'{user}') -ne $null) {{ net localgroup administrators {user} /remove; }};" if self.access_level.lower() == "administrator" else f"if ((net localgroup 'remote desktop users' | findstr /C:'{user}') -ne $null) {{ net localgroup 'remote desktop users' {user} /remove; }};" for user in self.users]) } }} else {{ echo 'Error VM is not domain joined' "}}
            """
            },
            'linux': {
                'add': 
                    f"""
                    if wbinfo -p >/dev/null 2>&1; then {"".join([f"sudo usermod -aG sudousers {user};" if self.access_level.lower() == "administrator" else f"sudo usermod -aG sshusers {user};" for user in self.users_linux]) } else echo 'Error VM is not domain joined'; fi
                    """,
                'remove': 
                    f"""
                    if wbinfo -p >/dev/null 2>&1; then {"".join([f"sudo usermod -G sudousers {user};" if self.access_level.lower() == "administrator" else f"sudo usermod -G sshusers {user};" for user in self.users_linux]) } else echo 'Error VM is not domain joined'; fi
                    """
            }
        }
        return commands.get(os_type,None).get(self.action.lower())
    
    def get_password(self,user):
        password = json.loads(self.secret.value).get(user)
        return password
    
    def create_ad_group(self,username,server_name,base_dn,search_dn,group_name):
        try:
            server = f"ldap://{server_name}"
            password = self.get_password(username.split('\\')[1])
            ldap_server = ldap3.Server(server, get_info=ldap3.ALL)
            conn = ldap3.Connection(ldap_server, user=username, password=password, auto_bind=True)
            group_dn = f'cn={group_name},' + base_dn
            users = [user.split('\\')[1] for user in self.users]
            users_dn = []
            if not conn.search(base_dn, f'(cn={group_name})', attributes=['member']):
                group = conn.add(group_dn, object_class=['top', 'group'], attributes={
                            'sAMAccountName': group_name,
                            'groupType': -2147483644  # DOMAIN_LOCAL_GROUP | SECURITY_ENABLED
                        })
                logging.info(f'Created Group {group_name}')
            for user in self.users:
                search_user = user.split('\\')[1]
                if user.split('\\')[0].lower() == 'one':
                    one_ldap = ldap3.Server('one.ofc.loc', get_info=ldap3.ALL)
                    one_conn = ldap3.Connection(one_ldap, user='ONE\\SRVGlobalJoin1', password=self.get_password('SRVGlobalJoin1'), auto_bind=True)
                    if  one_conn.search('DC=one,DC=ofc,DC=loc', f'(&(objectClass=user)(sAMAccountName=*{search_user}*))', attributes=['distinguishedName','objectSid']):
                        users_dn.append(f"cn={one_conn.entries[0]['objectSid'].value},CN=ForeignSecurityPrincipals,DC=we,DC=interbrew,DC=net")
                else:
                    conn.search(search_dn, f'(&(objectClass=user)(sAMAccountName=*{search_user}*))', attributes=['distinguishedName'])
                    users_dn.append(f"{conn.entries[0]['distinguishedName']}")
            conn.search(search_dn, f'(&(objectClass=group)(sAMAccountName={group_name}))', attributes=['distinguishedName'])
            group_dn = conn.entries[0]['distinguishedName']
            for dn in users_dn:
                if self.action.lower() == 'add':
                    if not conn.modify(group_dn.value, {'member': [(ldap3.MODIFY_ADD, [dn])]}):
                        logging.info(conn.result)
                        logging.info('Failed to add member to group')
                elif self.action.lower() == 'remove':
                    if not conn.modify(group_dn.value, {'member': [(ldap3.MODIFY_DELETE, [dn])]}):
                        logging.info('Failed to remove member to group')
        except Exception as e:
            logging.error(f"Failed to create group {group_name}: {e}")

    async def vm_access(self):
        if not self.is_vm_agent_available():
            logging.error(f'VM Agent is not available or VM is not running on {self.vm_name}')
            await self.notify_user(self.vm_name,'Failed',"VM is not running or VM Agent is not available")
            raise Exception(f'VM Agent is not available or VM is not running on {self.vm_name}')
        self.lock_manager.remove_all_locks()
        try: 
            os_type,location = self.get_vm_os_type_and_location()
            if  os_type == 'windows':
                puslisher = 'Microsoft.Compute'
                type_properties_type = 'CustomScriptExtension'
                type_handler_version = '1.10'
            else:
                puslisher = 'Microsoft.Azure.Extensions'
                type_properties_type = 'CustomScript'
                type_handler_version = '2.1'
            response = self.compute_client.virtual_machine_extensions.list(resource_group_name=self.resource_group_name, vm_name=self.vm_name)
            if response.value:
                for ext in response.value:
                    if ext.publisher in ["Microsoft.Compute","Microsoft.Azure.Extensions"] and ext.type_properties_type in ["CustomScript","CustomScriptExtension"]:
                        response = self.compute_client.virtual_machine_extensions.begin_delete (resource_group_name=self.resource_group_name, vm_name=self.vm_name, vm_extension_name=ext.name)
                        result = response.result()
                        logging.info(f'VM Access Extension deleted successfully')
                        break
            response = self.compute_client.virtual_machine_extensions.begin_create_or_update(
                    resource_group_name=self.resource_group_name, 
                    vm_name=self.vm_name, 
                    vm_extension_name='Bewmation-VM-Access', 
                    extension_parameters=VirtualMachineExtension(
                        location=location,
                        publisher=puslisher,
                        type_properties_type=type_properties_type, 
                        type_handler_version=type_handler_version, 
                        protected_settings= {
                             'commandToExecute': self.get_command(os_type)}
                        )
                )
            max_wait_seconds = 30 * 60
            start = time.time()
            interval = 5
            while not response.done() and (time.time() - start) < max_wait_seconds:
                time.sleep(interval)
                interval = min(interval * 2, 60)
            if not response.done():
                raise Exception('Timedout')
            result = response.result()
            logging.info(f'VM Access Extension created successfully {result.as_dict()}')
            response = self.compute_client.virtual_machine_extensions.get(
                resource_group_name=self.resource_group_name,
                vm_name=self.vm_name,
                vm_extension_name='Bewmation-VM-Access',
                expand='instanceView'
            )
            if os_type == 'windows' and response.instance_view.substatuses != None:
                if "Error VM is not domain joined" in response.instance_view.substatuses[0].message:
                    await self.notify_user(self.vm_name,'Failed',"Error VM is not domain joined")
                    logging.error(f'Error while adding VM Access {response.as_dict()}')
                    raise Exception(f'Error while adding VM Access {response.as_dict()}')
            else:
                if "Error VM is not domain joined" in response.instance_view.statuses[0].message:
                    await self.notify_user(self.vm_name,'Failed',"Error VM is not domain joined")
                    logging.error(f'Error while adding VM Access {response.as_dict()}')
                    raise Exception(f'Error while adding VM Access {response.as_dict()}')
            await self.notify_user(self.vm_name,'Successful',"VM Access Added Successfully")
            logging.info(f'VM Access Added successfully {response.as_dict()}')
        except Exception as e:
            logging.error(f'Error while adding VM Access {e}')
            raise e
        finally:
            response = self.compute_client.virtual_machine_extensions.begin_delete(
                resource_group_name=self.resource_group_name,
                vm_name=self.vm_name,
                vm_extension_name='Bewmation-VM-Access'
            )
            result = response.result()
            logging.info(f'Removed VM Access Extension')
            self.lock_manager.restore_locks()