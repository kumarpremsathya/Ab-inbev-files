import logging
import os
import uuid
from datetime import datetime, timezone
from shared_code.authorization_client import AuthorizationClient
from shared_code.lock_manager import LockManager
from shared_code.db import DB
from azure.mgmt.authorization.models import RoleEligibilityScheduleRequest, RequestType
from azure.core.exceptions import HttpResponseError
import re


class RbacInventoryReview:
    
    def __init__(self, json_data):
        self.data = json_data
        self.role_assignment_id = json_data['RoleAssignmentsId']
        self.subscription_id = json_data.get('SubscriptionId') or json_data['RoleAssignmentsId'].split('/')[2]
        self.scope = json_data.get('Scope') or f"/subscriptions/{self.subscription_id}"
        self.principal_id = json_data.get('AccountId')
        self.action = json_data.get('Action', '').upper() 
        self.zone = json_data['Zone'].lower()
        self.env = os.environ["Environment"].lower()
        self.azenvironment = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.auth_client = AuthorizationClient().get_auth_client(self.azenvironment, self.subscription_id)
        self.db = DB()
    
      
    async def remove_inventory_reviewed_role_assignment(self):
        try:
            logging.info(f"Attempting to delete role assignment {self.role_assignment_id} for subscription {self.subscription_id} and zone {self.zone}")
            logging.info(f"Current environment: {self.env}, Action: {self.action}")
    
            if self.action != "REVOKE":
                logging.info(f"Action is '{self.action}' - skipping deletion for {self.role_assignment_id}")
                return
    
            self._insert_activity_record()         

            if self.env == "production":

                self.auth_client.role_assignments.delete_by_id(self.role_assignment_id)
                logging.info(f"Successfully deleted role assignment {self.role_assignment_id}")
                # Update status to Success after deletion
                self._update_activity_status('Success', 'Implemented Successfully Role assignment removed via RBAC Inventory Review')
    
        except HttpResponseError as e:
            if e.error.code == "RoleAssignmentNotFound" or e.status_code == 404:
                logging.warning(f"Role assignment {self.role_assignment_id} not found - may already be deleted")
                self._update_activity_status('Success', 'Implemented Successfully Role assignment not found - may already be deleted')
            elif e.error.code == "CannotDeleteLastRbacAdminAssignment":
                uid = str(uuid.uuid4())
                parameters = RoleEligibilityScheduleRequest(
                    request_type=RequestType.ADMIN_REMOVE,
                    justification="RBAC Inventory Review - Auto Cleanup",
                    role_definition_id=self.auth_client.role_assignments.get_by_id(self.role_assignment_id).role_definition_id,
                    principal_id=self.principal_id,
                )
                self.auth_client.role_assignment_schedule_requests.create(
                    scope=self.scope,
                    role_assignment_schedule_request_name=uid,
                    parameters=parameters
                )
                logging.info(f"Created schedule request to remove {self.role_assignment_id}")
                self._update_activity_status('Success', 'Implemented Successfully Role assignment removed via schedule request')
            elif e.error.code == "ScopeLocked":
                lock_client = None
                try:
                    if self.env == "production":
                        locked_scope_match = re.search(r"following scope\(s\) are locked: '([^']+)'", str(e))
                        if locked_scope_match:
                            locked_scope = locked_scope_match.group(1)
                            logging.info(f"Scope lock detected on {locked_scope}. Attempting to remove locks.")
                            lock_client = LockManager(locked_scope.split('/')[2], self.zone, locked_scope.split('/')[4], locked_scope)
                            lock_client.remove_all_locks()
                            self.auth_client.role_assignments.delete_by_id(self.role_assignment_id)
                            self._update_activity_status('Success', 'Implemented Successfully Role assignment removed after lock removal')
                        else:
                            raise e       
                except HttpResponseError as e:
                    if e.error.code == "RoleAssignmentNotFound" or e.status_code == 404:
                            logging.warning(f"Role assignment {self.role_assignment_id} not found - may already been deleted along with resource")
                            self._update_activity_status('Success', 'Implemented Successfully Role assignment not found - resource may already be deleted')
                    elif e.error.code == "CannotDeleteLastRbacAdminAssignment":
                        uid = str(uuid.uuid4())
                        parameters = RoleEligibilityScheduleRequest(
                            request_type=RequestType.ADMIN_REMOVE,
                            justification="RBAC Inventory Review - Auto Cleanup",
                            role_definition_id=self.auth_client.role_assignments.get_by_id(self.role_assignment_id).role_definition_id,
                            principal_id=self.principal_id,
                        )
                        self.auth_client.role_assignment_schedule_requests.create(
                            scope=self.scope,
                            role_assignment_schedule_request_name=uid,
                            parameters=parameters
                        )
                        self._update_activity_status('Success', 'Implemented Successfully Role assignment removed via schedule request')
                    else:
                        logging.error(f"HTTP error occurred while deleting role assignment {self.role_assignment_id}: {str(e)}")
                        raise e
                finally:
                    if lock_client:
                        lock_client.restore_locks()
            else:
                logging.error(f"HTTP error occurred while deleting role assignment {self.role_assignment_id}: {str(e)}")
                raise e
                
        except Exception as e:
            logging.error(f"Failed to delete role assignment {self.role_assignment_id}: {str(e)}")
            raise e
    
    def _insert_activity_record(self):
        logging.info(f"Inserting activity record for {self.role_assignment_id}")
        try:
            sql_query = """
            MERGE INTO tblActivityAzInactiveRbac AS Target
            USING (
                SELECT
                    S.EventId,
                    R.PrincipalId,
                    CASE WHEN U.AccountType IS NULL OR U.AccountType = 'NULL' THEN 'UNKNOWN' ELSE U.AccountType END AS AccountType,
                    CASE WHEN U.UserId IS NULL OR U.UserId = 'NULL' THEN 'UNKNOWN' ELSE U.UserId END AS UserId,
                    CASE WHEN U.DisplayName IS NULL OR U.DisplayName = 'NULL' THEN 'UNKNOWN' ELSE U.DisplayName END AS DisplayName,
                    CASE WHEN U.ManagerEmail IS NULL OR U.ManagerEmail = 'NULL' THEN 'UNKNOWN' ELSE U.ManagerEmail END AS ManagerEmail,
                    CASE WHEN U.Email IS NULL OR U.Email = 'NULL' THEN 'UNKNOWN' ELSE U.Email END AS Email,
                    S.RoleAssignmentsId,
                    R.Scope, R.ScopeType, R.PrincipalType, R.RoleName, R.RoleType, R.RoleDescription,
                    S.SubscriptionId, R.SubscriptionName, R.ResourceName, R.ResourceType,
                    R.ResourceId, R.ManagementGroup, S.Cloud, R.Zone,
                    S.Status, S.Comments, S.RetryAttemptedAt, 'ActiveUser' AS UserStatus,
                    'REVOKE' AS CleanType,
                    S.Approvers
                FROM (SELECT ?, ?, ?, ?, ?, ?, ?, ?) AS S
                    (EventId, RoleAssignmentsId, SubscriptionId, Cloud,
                     Status, Comments, RetryAttemptedAt, Approvers)
                LEFT JOIN tblazureroleassignmentsreport R ON S.RoleAssignmentsId = R.RoleAssignmentsId
                LEFT JOIN tblazureusersreport U ON R.PrincipalId = U.userid
            ) AS Source
            ON Target.EventId = Source.EventId
            AND Target.RoleAssignmentsId = Source.RoleAssignmentsId
            WHEN NOT MATCHED THEN
                INSERT (ActivityId, EventId, PrincipalId, AccountType, UserId, DisplayName,
                        ManagerEmail, Email, RoleAssignmentsId, Scope, ScopeType, PrincipalType,
                        RoleName, RoleType, RoleDescription, SubscriptionId, SubscriptionName,
                        ResourceName, ResourceType, ResourceId, ManagementGroup, Cloud, Zone,
                        Status, Comments, RetryAttemptedAt, UserStatus, CleanType, Approvers)
                VALUES (NEWID(), Source.EventId, Source.PrincipalId, Source.AccountType,
                        Source.UserId, Source.DisplayName, Source.ManagerEmail, Source.Email,
                        Source.RoleAssignmentsId, Source.Scope, Source.ScopeType, Source.PrincipalType,
                        Source.RoleName, Source.RoleType, Source.RoleDescription, Source.SubscriptionId,
                        Source.SubscriptionName, Source.ResourceName, Source.ResourceType, Source.ResourceId,
                        Source.ManagementGroup, Source.Cloud, Source.Zone, Source.Status, Source.Comments,
                        Source.RetryAttemptedAt, Source.UserStatus, Source.CleanType, Source.Approvers);
            """
            values = (
                self.data.get('EventId'),
                self.data.get('RoleAssignmentsId'),
                self.subscription_id,
                'AZURE',
                'In-Progress',
                'Pending role assignment removal for RBACINVENTORYREVIEW',
                datetime.now(timezone.utc),
                self.data.get('Approver'),
            )
            self.db.executescalar(sql_query=sql_query, action="insert", values=values)
            logging.info(f"Inserted In-Progress record for {self.role_assignment_id}")
        except Exception as e:
            logging.error(f"Failed to insert activity record: {str(e)}")
            raise e
    

    def _update_activity_status(self, status, comments):
        logging.info(f"Updating activity status to '{status}' for {self.role_assignment_id}")
        
        try:
            sql_query = """
            UPDATE tblActivityAzInactiveRbac
            SET Status = ?, Comments = ?, RetryAttemptedAt = ?
            WHERE EventId = ? AND RoleAssignmentsId = ?
            """
            values = (
                status,
                comments,
                datetime.now(timezone.utc),
                self.data.get('EventId'),
                self.data.get('RoleAssignmentsId'),
            )
            self.db.executescalar(sql_query=sql_query, action="update", values=values)
            logging.info(f"Updated status to '{status}' for {self.role_assignment_id}")
        except Exception as e:
            logging.error(f"Failed to update activity status: {str(e)}")
            raise e

