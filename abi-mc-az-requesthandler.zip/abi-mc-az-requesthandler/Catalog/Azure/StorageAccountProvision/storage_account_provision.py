from shared_code.storage_client import StorageClient
from shared_code.networkmgmt_client import NetworkMgmtClient
from shared_code.private_endpoint_helper import PrivateEndpointHelper
import json,logging

class StorageAccountProvision:
    def __init__(self):
        pass
    def __init__(self,json_data):
        data = json.loads(json_data['Payload'])['payload']["data"]
        self.zone = json_data["Zone"].lower()
        self.tags = data["tags"]
        self.subscription_id = data["subscription_id"]
        self.resource_group_name = data["resource_group_name"]
        self.location = data["location"]
        self.environament = data["environment"]
        self.storage_account_name = data["storageaccount_name"]
        self.performance = data["performance"]
        self.redundancy = data["redundancy"]
        self.access_tier = data["access_tier"]
        self.hns = data["hns"]
        self.account_kind = data["account_kind"]
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.storage_client = StorageClient().get_storage_client(self.subscription_id,self.cloud)
        self.network_client = NetworkMgmtClient().get_network_mgmt_client(self.subscription_id,self.cloud)


    def create_storage_account(self):
        try:
            logging.info(f"Creating Storage Account {self.storage_account_name} in resource group {self.resource_group_name}")
            # Get subnet IDs for network rules
            subscription_to_network = {
                # ABI Global Prod
                "2db7c27b-2f9f-4088-981b-2bd88c5c1905": {
                    "vnet_name": "PVT-VNET-GB-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-GB-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # ABI Global Non-Prod
                "73f88e6b-3a35-4612-b550-555157e7059f": {
                    "vnet_name": "PVT-VNET-GB-NON-PROD",
                    "vnet_rg_name": "mgmtpvt-rg-gb-non-prod",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # ABI NAZ Non-Prod
                "25137c49-ffa8-4cef-a4db-f8aaf059d980": {
                    "vnet_name": "PVT-VNET-NAZ-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-NAZ-NON-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # ABI NAZ Prod
                "95c54dda-ae35-43c0-aeea-bcfc596674c1": {
                    "vnet_name": "PVT-VNET-NAZ-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-NAZ-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # ABI NAZ SAP R3
                "c8642ed5-9766-43fa-b6cc-47f19181fa40": {
                    "vnet_name": "SAP-INFRA-VNET-NAZ-PROD",
                    "vnet_rg_name": "SAP-RG-NAZ-PROD",
                    "subnet_name": "SAP-PR-APP-SUB",
                    "subnet_name1": "SAP-PR-DB-SUB"
                },
                # ABI MAZ Non-Prod
                "fe70970a-8778-4bc4-83c4-a85c57c1efd3": {
                    "vnet_name": "PVT-VNET-MEX-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-MEX-NON-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # ABI MAZ Prod
                "a6362b38-0f74-4c75-bcbb-719b38f04f75": {
                    "vnet_name": "PVT-VNET-MEX-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-MEX-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # ABI EU Non-Prod
                "3617a45e-beab-410a-9476-d6e000e1fb77": {
                    "vnet_name": "PVT-VNET-EU-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-EU-NON-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # ABI EU Prod
                "1c1db8ee-5d54-460b-bd71-fd031be2a7e5": {
                    "vnet_name": "PVT-VNET-EU-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-EU-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # ABI Africa Prod
                "77a7f337-8588-4076-b526-5f1ce0e55671": {
                    "vnet_name": "PVT-VNET-AFR-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-AFR-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # ABI Africa Non-Prod
                "15bcebd1-794e-49c6-9548-8a4a4357ee16": {
                    "vnet_name": "PVT-VNET-AFR-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-AFR-NON-PROD",
                    "subnet_name": "Webapp-1",
                    "subnet_name1": "Infra"
                },
                # ABI China Prod
                "30b7b23e-9325-4407-b613-610457afe869": {
                    "vnet_name": "PVT-E2-VNET-CN-PROD",
                    "vnet_rg_name": "MGMTPVT-E2-RG-CN-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # ABI China Non-Prod
                "08ba6e07-14eb-4984-9176-9261b8a2781d": {
                    "vnet_name": "PVT-E2-VNET-CN-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-E2-RG-CN-NON-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # ABI KR Non-Prod
                "b413c513-77a1-4416-84d4-4057920111c6": {
                    "vnet_name": "PVT-VNET-KR-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-KR-NON-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # ABI KR Prod
                "a831d6f9-cdd3-4d49-9dd5-9389dd3a1902": {
                    "vnet_name": "PVT-VNET-KR-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-KR-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                }
            }

            if self.subscription_id not in subscription_to_network:
                raise ValueError(f"Subscription ID {self.subscription_id} not found in network configuration")

            network_config = subscription_to_network[self.subscription_id]
            
            try:
                # Get subnets
                webapp_subnet = self.network_client.subnets.get(
                    resource_group_name=network_config["vnet_rg_name"],
                    virtual_network_name=network_config["vnet_name"],
                    subnet_name=network_config["subnet_name"]
                )

                infra_subnet = self.network_client.subnets.get(
                    resource_group_name=network_config["vnet_rg_name"], 
                    virtual_network_name=network_config["vnet_name"],
                    subnet_name=network_config["subnet_name1"]
                )
            except Exception as e:
                raise ValueError(f"Error getting subnet details: {str(e)}")

            subnet_ids = [webapp_subnet.id, infra_subnet.id]

            storage_account_params = {
                "location": self.location,
                "sku": {
                    "name": f"{self.performance}_{self.redundancy}",
                    "tier": self.performance
                },
                "kind": self.account_kind,
                "tags": self.tags,
                "properties": {
                    "isHnsEnabled": self.hns,
                    "accessTier": self.access_tier if self.access_tier in ["BlobStorage","StorageV2","FileStorage"] else None,
                    "supportsHttpsTrafficOnly": True,
                    "minimumTlsVersion": "TLS1_2",
                    "publicNetworkAccess": "Enabled",
                    "allowBlobPublicAccess": False,
                    "networkAcls": {
                        "defaultAction": "Deny",
                        "bypass": "AzureServices",
                        "virtualNetworkRules": [
                            {"id": subnet_id} for subnet_id in subnet_ids
                        ]
                    },
                    "infrastructureEncryption": self.performance == "Standard"
                }
            }   
            
            storage_account_result = self.storage_client.storage_accounts.begin_create(
                resource_group_name=self.resource_group_name,
                account_name=self.storage_account_name,
                parameters=storage_account_params
            ).result()
            logging.info(f"Storage Account {self.storage_account_name} created successfully")

            # Create private endpoint for blob
            pe_helper = PrivateEndpointHelper(self.subscription_id, self.zone, self.cloud)
            subnet_id = pe_helper.get_subnet_id(
                vnet_rg_name=network_config["vnet_rg_name"],
                vnet_name=network_config["vnet_name"],
                subnet_name=network_config["subnet_name"]
            )
            dns_zone_name = "privatelink.blob.core.chinacloudapi.cn" if self.zone == "china" else "privatelink.blob.core.windows.net"
            pe_helper.create_private_endpoint(
                resource_group_name=self.resource_group_name,
                resource_id=storage_account_result.id,
                resource_name=self.storage_account_name,
                location=self.location,
                subnet_id=subnet_id,
                group_ids=["blob"],
                dns_zone_name=dns_zone_name,
                private_endpoint_name=f"{self.storage_account_name}-pe-blob",
                tags=self.tags
            )

            return storage_account_result.id
        except Exception as e:
            logging.error(f"Error creating Storage Account: {e}")
            raise