from shared_code.resourcemgmt_client import ResourceMgmtClient
from azure.mgmt.resource.resources.models import TagsPatchResource
import logging,json
from shared_code.lock_manager import LockManager
from azure.core.exceptions import HttpResponseError

class HoursOfOperationUpdater:
    
    def __init__(self,data) -> None:
        self.subscription_id = data["SubscriptionId"]
        self.resource_group = data["ResourceGroupName"]
        self.resource_id = data["ResourceId"]
        self.hours_of_operation = data["HoursOfOperation"]
        self.zone = data['Zone'].lower()
        if self.zone == "china":
            self.cloud = "AzureChinaCloud"
        else:
            self.cloud = "AzurePublicCloud"        
        self.resource_client = ResourceMgmtClient().get_resource_client(self.cloud,self.subscription_id)
        self.lock_manager = LockManager(self.subscription_id, self.zone, self.resource_group)

    def update_hours_of_operation(self):
        tag_patch_resource = TagsPatchResource(
            operation="Merge",
            properties={
                "tags": 
                {
                    "HoursOfOperation": self.hours_of_operation
                }
            })
        try: 
            self.resource_client.tags.begin_update_at_scope(self.resource_id, tag_patch_resource)
            logging.info(f"HoursOfOperation tag {self.hours_of_operation} was added to resource")
            return True,None
        except HttpResponseError as e:
            if e.error.code == "ScopeLocked":
                try: 
                    self.lock_manager.remove_all_locks(lock_types=["ReadOnly"])
                    self.resource_client.tags.begin_update_at_scope(self.resource_id, tag_patch_resource)
                    logging.info(f"HoursOfOperation tag {self.hours_of_operation} was added to resource")
                    return True,None
                except Exception as e:
                     logging.error(f"Failed to update HoursOfOperation tag after removing locks: {e}")
                     raise
                finally:
                    self.lock_manager.restore_locks()
            logging.error(e)
            return False,e