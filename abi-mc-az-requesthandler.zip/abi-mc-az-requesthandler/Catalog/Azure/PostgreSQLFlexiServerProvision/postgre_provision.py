from shared_code.postgresql_client import PostgresqlClient
from shared_code.networkmgmt_client import NetworkMgmtClient
from shared_code.akv_secrets import AkvSecrets
from shared_code.private_endpoint_helper import PrivateEndpointHelper
import logging,json,os

class PostgreSQLProvision:
    def __init__(self,json_data):   
        data = json.loads(json_data['Payload'])['payload']["data"]
        self.subscription_id = data['subscription_id']
        self.subscription_name = data['subscription_name']
        self.zone = json_data["Zone"].lower()
        self.resource_group_name = data['resource_group_name']
        self.server_name = data['server_name']
        self.postgre_version = data['postgre_version']
        self.pricing_tier = data['pricing_tier']
        self.sku = data['sku_size'].split(' ')[0]
        self.storage_size = int(data['storage'])
        self.storage_auto_grow = "Enabled" if data['storage_auto_grow'].lower() == 'true' else "Disabled"
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.tags = data['tags']
        self.location = data['location']
        self.postgre_client = PostgresqlClient().get_sql_mgmt_client(self.subscription_id,self.cloud)
        self.network_client = NetworkMgmtClient().get_network_mgmt_client(self.subscription_id,self.cloud)
        self.secret = AkvSecrets(os.environ["KEYVAULT_URI"],'sql-creds-prov').get_tokens()


    def provision_server(self):
        try:
            # Get subnet details for private endpoint
            vnet_config = {
                # Abi Global Prod
                "2db7c27b-2f9f-4088-981b-2bd88c5c1905": {
                    "vnet_name": "PVT-VNET-GB-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-GB-PROD",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra", 
                    "subnet_name2": "DB1"
                },
                # ABI Global Non-Prod
                "73f88e6b-3a35-4612-b550-555157e7059f": {
                    "vnet_name": "PVT-VNET-GB-NON-PROD",
                    "vnet_rg_name": "mgmtpvt-rg-gb-non-prod",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB1"
                },
                # ABI NAZ Non-Prod
                "25137c49-ffa8-4cef-a4db-f8aaf059d980": {
                    "vnet_name": "PVT-VNET-NAZ-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-NAZ-NON-PROD",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB"
                },
                # ABI NAZ Prod
                "95c54dda-ae35-43c0-aeea-bcfc596674c1": {
                    "vnet_name": "PVT-VNET-NAZ-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-NAZ-PROD",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB"
                },
                # ABI NAZ SAP R3
                "c8642ed5-9766-43fa-b6cc-47f19181fa40": {
                    "vnet_name": "SAP-INFRA-VNET-NAZ-PROD",
                    "vnet_rg_name": "SAP-RG-NAZ-PROD",
                    "subnet_name": "SAP-PR-APP-SUB",
                    "subnet_name1": "SAP-PR-ANF-SUB",
                    "subnet_name2": "SAP-PR-DB-SUB"
                },
                # ABI MAZ Non-Prod
                "fe70970a-8778-4bc4-83c4-a85c57c1efd3": {
                    "vnet_name": "PAAS_INTEG_VNET-MEX_NO_PRD",
                    "vnet_rg_name": "Infraestructura",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "PE-postgreSQL_NP"
                },
                # ABI MAZ Prod
                "a6362b38-0f74-4c75-bcbb-719b38f04f75": {
                    "vnet_name": "PAAS_INTEG_VNET-MEX_PRD",
                    "vnet_rg_name": "Infraestructura",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "PE-postgreSQL"
                },
                # ABI EU Non-Prod
                "3617a45e-beab-410a-9476-d6e000e1fb77": {
                    "vnet_name": "PVT-VNET-EU-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-EU-NON-PROD",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB"
                },
                # ABI EU Prod
                "1c1db8ee-5d54-460b-bd71-fd031be2a7e5": {
                    "vnet_name": "PVT-VNET-EU-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-EU-PROD",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB"
                },
                # ABI Africa Prod
                "77a7f337-8588-4076-b526-5f1ce0e55671": {
                    "vnet_name": "PVT-VNET-AFR-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-AFR-PROD",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB"
                },
                # ABI Africa Non-Prod
                "15bcebd1-794e-49c6-9548-8a4a4357ee16": {
                    "vnet_name": "PVT-VNET-AFR-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-AFR-NON-PROD",
                    "subnet_name": "Webapp-1",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB"
                },
                # ABI China Prod
                "30b7b23e-9325-4407-b613-610457afe869": {
                    "vnet_name": "PVT-E2-VNET-CN-PROD",
                    "vnet_rg_name": "MGMTPVT-E2-RG-CN-PROD",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB"
                },
                # ABI China Non-Prod
                "08ba6e07-14eb-4984-9176-9261b8a2781d": {
                    "vnet_name": "PVT-E2-VNET-CN-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-E2-RG-CN-NON-PROD",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB"
                },
                # ABI KR Non-Prod
                "b413c513-77a1-4416-84d4-4057920111c6": {
                    "vnet_name": "PVT-VNET-KR-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-KR-NON-PROD",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB"
                },
                # ABI KR Prod
                "a831d6f9-cdd3-4d49-9dd5-9389dd3a1902": {
                    "vnet_name": "PVT-VNET-KR-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-KR-PROD",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB"
                }
            }

            # Get subnet details
            subnet = self.network_client.subnets.get(
                resource_group_name=vnet_config[self.subscription_id]["vnet_rg_name"],
                virtual_network_name=vnet_config[self.subscription_id]["vnet_name"],
                subnet_name=vnet_config[self.subscription_id]["subnet_name2"]
            )
            
            if self.zone == 'naz':
                login = "AADS_A_ABI NAZ SQL DB Admins"
                sid = "eacb2675-7fbc-4f91-a3eb-906c78bd0043"
            elif self.zone == 'china':
                login = "Cloudbolt"
                sid = "6a956c8e-0e11-4d70-84ef-4ea2c018964b"
            else:
                login = "AADS_A_ABI GlobalOps SQL DB Admins"
                sid = "c643a250-a7e8-44b2-bc5f-7ed4437e7cf9"
            tenant_id = "cef04b19-7776-4a94-b89b-375c77a8f936" if self.zone != 'china' else "c99b23b6-4fa8-4eee-a7cc-2f420106e730"
            # Create PostgreSQL server
            server_params = {
                "location": self.location,
                "sku": {
                    "name": self.sku,
                    "tier": self.pricing_tier,
                },
                "administrator_login": "ABISQLADMIN",
                "administrator_login_password": self.secret.value,
                "version": self.postgre_version,
                "storage": {
                    "storage_size_gb": min([32,64,128,256,512,1024,2048,4092,4096,8192,16384,32762], key=lambda x: abs(x - int(self.storage_size // 1024))),
                    "auto_grow": self.storage_auto_grow
                },
                "backup": {
                    "backup_retention_days": 7,
                    "geo_redundant_backup": "Enabled"
                },
                "auth_config":{
                    "active_directory_auth": "Enabled",
                    "password_auth" : "Enabled",
                    "tenant_id": tenant_id
                },
                "network": {
                    "publicNetworkAccess": "Disabled"
                },
                "ssl_enforcement": "Enabled",
                "minimal_tls_version": "TLS1_2",
                "public_network_access": "Disabled",
                "infrastructure_encryption": "Enabled",
                "tags": self.tags
            }

            # Create the server
            server = self.postgre_client.servers.begin_create(
                resource_group_name=self.resource_group_name,
                server_name=self.server_name,
                parameters=server_params
            ).result()

            auth = self.postgre_client.administrators.begin_create(
                resource_group_name=self.resource_group_name,
                server_name=self.server_name,
                object_id=sid,
                parameters={
                    "principal_type": "Group",
                    "principal_name": login,
                    "tenant_id": tenant_id
                }
            ).result()
            # Create private endpoint using shared helper
            pe_helper = PrivateEndpointHelper(self.subscription_id, self.zone, self.cloud)
            dns_zone_name = "postgres.database.azure.com" if self.zone != 'china' else "postgres.database.chinacloudapi.cn"
            pe_helper.create_private_endpoint(
                resource_group_name=self.resource_group_name,
                resource_id=server.id,
                resource_name=self.server_name,
                location=self.location,
                subnet_id=subnet.id,
                group_ids=["postgresqlServer"],
                dns_zone_name=dns_zone_name,
                tags=self.tags,
                create_dns_zone_if_not_exists=True
            )

            # Configure server settings
            configurations = [
                ("log_disconnections", "on"),
                ("log_checkpoints", "on"), 
                ("log_connections", "on"),
                ("log_duration", "on")
                ]

            for config_name, value in configurations:
                self.postgre_client.configurations.begin_put(
                    resource_group_name=self.resource_group_name,
                    server_name=self.server_name,
                    configuration_name=config_name,
                    parameters={
                        "value": value,
                        "source": "user-override"
                    }
                ).result()

            logging.info(f"PostgreSQL server {self.server_name} created successfully")
            return server.id
        except Exception as e:
            logging.error(f"Error provisioning database: {e}")
            raise e