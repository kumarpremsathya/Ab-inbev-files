import logging
from shared_code.graphservice_client import GraphClient
from msgraph.generated.groups.groups_request_builder import GroupsRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from msgraph.generated.models.o_data_errors.o_data_error import ODataError
import os


class RbacGroupMemberReview:

    def __init__(self, json_data):
        self.group_id = json_data['GroupId']
        self.group_name = json_data['GroupName']
        self.member_id = json_data['MemberId']
        self.member_name = json_data['MemberName']
        self.action = json_data['Action'].lower()
        self.zone = json_data['Zone'].lower()
        self.azenvironment = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.env = os.environ["Environment"].lower()
        self.graph_client_obj = GraphClient()

    async def remove_group_member(self):
        try:
            logging.info(f"Action: {self.action}, Member: {self.member_name} ({self.member_id}), Group: {self.group_name} ({self.group_id})")
            if self.action != "revoked":
                logging.info(f"Action is '{self.action}' — no operation performed")
                return

            graph_client = self.graph_client_obj.get_client_request_adapter(self.azenvironment)
            
            # check if group exists
            try:
                await graph_client.groups.by_group_id(self.group_id).get()
                logging.info(f"Group exists: {self.group_name}")
            except ODataError as e:
                if e.response_status_code == 404:
                    logging.info(f"Group does not exist: {self.group_id} ({self.group_name}) — already not present, skipping removal")
                    return
                raise e 

            # Check member exists in group
            query_params = GroupsRequestBuilder.GroupsRequestBuilderGetQueryParameters(
                filter=f"id eq '{self.member_id}'",
            )
            request_configuration = RequestConfiguration(query_parameters=query_params)
            request_configuration.headers.add("ConsistencyLevel", "eventual")
            member_count = await graph_client.groups.by_group_id(self.group_id).members.count.get(
                request_configuration=request_configuration
            )
            if member_count == 0:
                logging.info(f"Member {self.member_name} is not in group — skipping removal")
                return
            logging.info(f"Member {self.member_name} is in group — proceeding with removal")
            
            # Remove member from group
            if self.env == "production":
                await graph_client.groups.by_group_id(self.group_id).members.by_directory_object_id(
                    self.member_id
                ).ref.delete()
                logging.info(f"Successfully removed member {self.member_name} ({self.member_id}) from group {self.group_name}")
        
        except Exception as e:
            logging.error(f"Failed to remove member {self.member_name} from group {self.group_name}: {e}")
            raise e