from shared_code.resourcemgmt_client import ResourceMgmtClient
from shared_code.compute_client import ComputeClient
from shared_code.lock_manager import LockManager
from azure.servicebus import ServiceBusMessage
from shared_code.servicebus_client import ServiceBusClientAbstract
from shared_code.cab_calendar import CabCalendar
from DAL.DbActivityManager import DbActivityManager
from shared_code.snow_client import SNOWClient
import logging, json, asyncio, re
from datetime import datetime, timezone
from azure.core.exceptions import HttpResponseError,ResourceExistsError
from Catalog.Azure.Decommission.backup_recovery_service_vault import BackupRecoveryServiceVault


class AzDecommission:
    
    def __init__(self,json_data) -> None:
        self.json_data = json_data
        self.payload = json.loads(json_data['Payload'])['payload']['data'] if json.loads(json_data['Payload']).get('payload') else json.loads(json_data['Payload'])['data']
        self.subscription_id = json_data['SubscriptionId']
        self.subscription_name = json_data['SubscriptionName']
        self.zone = json_data['Zone'].lower()
        self.resource_group_name = json_data['ResourceGroupName']
        self.decomm_type = json_data['DecommissionType']
        self.decomm_preactivity = json_data['IsDecommissionPreActivity']
        self.azenvironment = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.event_id = json_data['EventId']
        self.resource_mgmt_client = ResourceMgmtClient().get_resource_client(self.azenvironment,self.subscription_id)
        self.compute_client = ComputeClient().get_compute_client(self.subscription_id,self.azenvironment)
    
    def delete_resource_group(self,resource_group_name):
        self.resource_mgmt_client.resource_groups.begin_delete(resource_group_name).result()
        logging.info(f"Resource group {resource_group_name} has been decommissioned successfully.")

    def delete_from_supported(self,resource_id,e:HttpResponseError):
        try:
            if e.error.code == "ResourceNotFound":
                logging.warning(f"Resource {resource_id} not found, it may have already been deleted.")
                return
            if e.error.code == "ScopeLocked":
                locked_scope_match = re.search(r"following scope\(s\) are locked: '([^']+)'", str(e))
                if locked_scope_match:
                    locked_scope = locked_scope_match.group(1)
                    logging.info(f"Scope lock detected on {locked_scope}. Attempting to remove locks.")
                    lock_client = LockManager(locked_scope.split('/')[2], self.zone, locked_scope.split('/')[4], locked_scope)
                    lock_client.remove_all_locks()
                    self.resource_mgmt_client.resources.begin_delete_by_id(resource_id, "2021-04-01").result()
                    lock_client.restore_locks()
                    return
            if e.error.code == "NoRegisteredProviderFound":
                pattern = r"supported api-versions are '([^']+)'"
                match = re.search(pattern, e.error.message)
                if match:
                    supported_versions = match.group(1)
                    supported_versions_list = supported_versions.split(', ')
                    supported_versions_list = sorted(supported_versions_list,reverse=True)
                    self.resource_mgmt_client.resources.begin_delete_by_id(resource_id,supported_versions_list[0]).result()
                    logging.info(f"{resource_id} has been decommissioned successfully.")
                    return
                raise e
        except HttpResponseError as e:
            logging.error(e)
            if type(e) is ResourceExistsError:
                return
            if e.error.code == "NoRegisteredProviderFound":
                pattern = r"supported api-versions are '([^']+)'"
                match = re.search(pattern, e.error.message)
                if match:
                    supported_versions = match.group(1)
                    supported_versions_list = supported_versions.split(', ')
                    supported_versions_list = sorted(supported_versions_list,reverse=True)
                    self.resource_mgmt_client.resources.begin_delete_by_id(resource_id,supported_versions_list[1]).result()
                    logging.info(f"{resource_id} has been decommissioned successfully.")
                    return
                raise e
            if e.error.code == "ScopeLocked":
                locked_scope_match = re.search(r"following scope\(s\) are locked: '([^']+)'", str(e))
                if locked_scope_match:
                    locked_scope = locked_scope_match.group(1)
                    logging.info(f"Scope lock detected on {locked_scope}. Attempting to remove locks.")
                    lock_client = LockManager(locked_scope.split('/')[2], self.zone, locked_scope.split('/')[4], locked_scope)
                    lock_client.remove_all_locks()
                    self.resource_mgmt_client.resources.begin_delete_by_id(resource_id, "2021-04-01").result()
                    lock_client.restore_locks()
                    return
    
    def delete_resource(self,resource_id):
        resource_type = resource_id.split('/')[-2]
        try:
            resource = self.resource_mgmt_client.resources.get_by_id(resource_id, "2021-04-01")
        except HttpResponseError as e:
            if e.error.code == "ResourceNotFound":
                logging.warning(f"Resource {resource_id} not found, it may have already been deleted.")
                return
            if e.error.code == "NoRegisteredProviderFound":
                pattern = r"supported api-versions are '([^']+)'"
                match = re.search(pattern, e.error.message)
                try:
                    if match:
                        supported_versions = match.group(1)
                        supported_versions_list = supported_versions.split(', ')
                        supported_versions_list = sorted(supported_versions_list,reverse=True)
                        if len(supported_versions_list) == 1:
                            resource = self.resource_mgmt_client.resources.get_by_id(resource_id,supported_versions_list[0])
                            return
                        resource = self.resource_mgmt_client.resources.get_by_id(resource_id,supported_versions_list[1])
                except HttpResponseError as e:
                    if e.error.code == "ResourceNotFound":
                        logging.warning(f"Resource {resource_id} not found, it may have already been deleted.")
                        return

        if resource_type.lower() == 'serverfarms':
            # Get all sites associated with the server farm
            sites = self.resource_mgmt_client.resources.list_by_resource_group(
                self.resource_group_name,
                filter=f"resourceType eq 'Microsoft.Web/sites'",
            )
            for site in sites:
                try:
                    try:
                        api_version = "2022-03-01"
                        res = self.resource_mgmt_client.resources.get_by_id(site.id, api_version=api_version)
                    except HttpResponseError as e:
                        if e.error.code == "ResourceNotFound":
                            logging.warning(f"Resource {resource_id} not found, it may have already been deleted.")
                            continue
                        if e.error.code == "NoRegisteredProviderFound":
                            pattern = r"supported api-versions are '([^']+)'"
                            match = re.search(pattern, e.error.message)
                            if match:
                                supported_versions = match.group(1)
                                supported_versions_list = supported_versions.split(', ')
                                supported_versions_list = sorted(supported_versions_list,reverse=True)
                                res = self.resource_mgmt_client.resources.get_by_id(site.id,supported_versions_list[1])
                                api_version = supported_versions_list[1]
                    if res.properties and res.properties['serverFarmId'].lower() == resource_id.lower():
                        self.resource_mgmt_client.resources.begin_delete_by_id(res.id, api_version).result()
                        logging.info(f"Site {site.id} has been decommissioned successfully.")
                except HttpResponseError as e:
                    logging.error(f"Error deleting site {res.id}: {e}")
                    self.delete_from_supported(res.id, e)
        elif resource_type.lower() == 'networksecuritygroups':
            # Get all subnets associated with the NSG
            subnets = resource.properties.get('subnets', [])
            for subnet in subnets:
                try:
                    try:
                        api_version = "2021-04-01"
                        subnet_resource = self.resource_mgmt_client.resources.get_by_id(subnet['id'], api_version=api_version)
                        logging.info(f"NSG association removed from subnet")
                    except HttpResponseError as e:
                        if e.error.code == "ResourceNotFound":
                            logging.warning(f"Resource {subnet['id']} not found, it may have already been deleted.")
                            continue
                        if e.error.code == "NoRegisteredProviderFound":
                            pattern = r"supported api-versions are '([^']+)'"
                            match = re.search(pattern, e.error.message)
                            if match:
                                supported_versions = match.group(1)
                                supported_versions_list = supported_versions.split(', ')
                                supported_versions_list = sorted(supported_versions_list,reverse=True)
                                subnet_resource = self.resource_mgmt_client.resources.get_by_id(subnet['id'],supported_versions_list[1])
                                api_version = supported_versions_list[1]
                    subnet_properties = subnet_resource.properties
                    subnet_properties["networkSecurityGroup"] = None
                    self.resource_mgmt_client.resources.begin_create_or_update_by_id(
                        subnet['id'],
                        api_version,
                        subnet_resource
                    ).result()
                
                except HttpResponseError as e:
                    logging.error(f"Error removing NSG from subnet {e}")
                    self.delete_from_supported(subnet['id'], e)
            nics = resource.properties.get('networkInterfaces', [])
            for nic in nics:
                try:
                    try:
                        api_version = "2021-04-01"
                        nic_resource = self.resource_mgmt_client.resources.get_by_id(nic['id'], api_version=api_version)
                    except HttpResponseError as e:
                        if e.error.code == "ResourceNotFound":
                            logging.warning(f"Resource {nic['id']} not found, it may have already been deleted.")
                            continue
                        if e.error.code == "NoRegisteredProviderFound":
                            pattern = r"supported api-versions are '([^']+)'"
                            match = re.search(pattern, e.error.message)
                            if match:
                                supported_versions = match.group(1)
                                supported_versions_list = supported_versions.split(', ')
                                supported_versions_list = sorted(supported_versions_list,reverse=True)
                                nic_resource = self.resource_mgmt_client.resources.get_by_id(nic['id'],supported_versions_list[1])
                                api_version = supported_versions_list[1]
                    nic_properties = nic_resource.properties
                    nic_properties["networkSecurityGroup"] = None
                    self.resource_mgmt_client.resources.begin_create_or_update_by_id(
                        nic['id'],
                        api_version,
                        nic_resource
                    ).result()
                    logging.info(f"NSG association removed from NIC ")
                except HttpResponseError as e:
                    logging.error(f"Error removing NSG from NIC: {e}")
                    self.delete_from_supported(nic['id'], e)
        elif resource_type.lower() == 'networkinterfaces':
            try:
                try:
                    api_version = "2021-04-01"
                    nic = self.resource_mgmt_client.resources.get_by_id(resource_id, api_version=api_version)
                except HttpResponseError as e:
                    if e.error.code == "ResourceNotFound":
                        logging.warning(f"Resource {resource_id} not found, it may have already been deleted.")
                        return
                    if e.error.code == "NoRegisteredProviderFound":
                        pattern = r"supported api-versions are '([^']+)'"
                        match = re.search(pattern, e.error.message)
                        if match:
                            supported_versions = match.group(1)
                            supported_versions_list = supported_versions.split(', ')
                            supported_versions_list = sorted(supported_versions_list,reverse=True)
                            nic = self.resource_mgmt_client.resources.get_by_id(resource_id,supported_versions_list[1])
                            api_version = supported_versions_list[1]
                if "privateEndpoint" in nic.properties and nic.properties["privateEndpoint"]:
                    pe_id = nic.properties["privateEndpoint"]["id"]
                    if pe_id:
                        logging.info(f"NIC {resource_id} is in use with Private Endpoint {pe_id}. Deleting Private Endpoint first.")
                        self.resource_mgmt_client.resources.begin_delete_by_id(pe_id, "2021-05-01").result()
            except HttpResponseError as e:
                logging.error(f"Error deleting Private Endpoint {pe_id}: {e}")
                self.delete_from_supported(pe_id, e)
        elif resource_type.lower() == 'virtualnetworks':
            try:
                try:
                    api_version = "2021-04-01"
                    vnets = self.resource_mgmt_client.resources.get_by_id(resource_id, api_version=api_version)
                except HttpResponseError as e:
                    if e.error.code == "ResourceNotFound":
                        logging.warning(f"Resource {resource_id} not found, it may have already been deleted.")
                        return
                    if e.error.code == "NoRegisteredProviderFound":
                        pattern = r"supported api-versions are '([^']+)'"
                        match = re.search(pattern, e.error.message)
                        if match:
                            supported_versions = match.group(1)
                            supported_versions_list = supported_versions.split(', ')
                            supported_versions_list = sorted(supported_versions_list,reverse=True)
                            vnets = self.resource_mgmt_client.resources.get_by_id(resource_id,supported_versions_list[1])
                            api_version = supported_versions_list[1]
                subnets = vnets.properties.get('subnets', [])
                for subnet in subnets:
                    subnet_id = subnet["id"]
                    try:
                        subnet_resource = self.resource_mgmt_client.resources.get_by_id(subnet_id, api_version)
                    except HttpResponseError as e:
                        if e.error.code == "ResourceNotFound":
                            logging.warning(f"Subnet {subnet_id} not found, it may have already been deleted.")
                            continue
                        if e.error.code == "NoRegisteredProviderFound":
                            pattern = r"supported api-versions are '([^']+)'"
                            match = re.search(pattern, e.error.message)
                            if match:
                                supported_versions = match.group(1)
                                supported_versions_list = supported_versions.split(', ')
                                supported_versions_list = sorted(supported_versions_list,reverse=True)
                                subnet_resource = self.resource_mgmt_client.resources.get_by_id(subnet_id,supported_versions_list[1])
                                api_version = supported_versions_list[1]
                    subnet_properties = subnet_resource.properties
                    private_endpoints = subnet_properties.get("privateEndpoints", [])
                    for pe in private_endpoints:
                        pe_id = pe.get("id")
                        if pe_id:
                            try:
                                logging.info(f"Deleting Private Endpoint {pe_id} in subnet {subnet_id} before deleting subnet.")
                                private_resource = self.resource_mgmt_client.resources.get_by_id(f"{pe_id}/privateDnsZoneGroups", "2021-05-01")
                            except HttpResponseError as e:
                                if e.error.code == "NoRegisteredProviderFound":
                                    pattern = r"supported api-versions are '([^']+)'"
                                    match = re.search(pattern, e.error.message)
                                    if match:
                                        supported_versions = match.group(1)
                                        supported_versions_list = supported_versions.split(', ')
                                        supported_versions_list = sorted(supported_versions_list,reverse=True)
                                        private_resource = self.resource_mgmt_client.resources.get_by_id(f"{pe_id}/privateDnsZoneGroups",supported_versions_list[1])
                                        api_version = supported_versions_list[1]
                            dns_zone_groups = private_resource.additional_properties.get("value")
                            for dns_zone_group in dns_zone_groups:
                                dns_zone_group_id = dns_zone_group.get("id")
                                if dns_zone_group_id:
                                    try:
                                        logging.info(f"Deleting Private DNS Zone Group {dns_zone_group_id} associated with Private Endpoint {pe_id}.")
                                        self.resource_mgmt_client.resources.begin_delete_by_id(dns_zone_group_id, "2021-05-01").result()
                                    except HttpResponseError as e:
                                        logging.error(f"Error deleting Private DNS Zone Group {dns_zone_group_id}: {e}")
                                        self.delete_from_supported(dns_zone_group_id, e)
                            try:
                                self.resource_mgmt_client.resources.begin_delete_by_id(pe_id, "2021-05-01").result()
                                logging.info(f"Private Endpoint {pe_id} has been deleted successfully.")
                            except HttpResponseError as e:
                                logging.error(f"Error deleting Virtual Network {pe_id}: {e}")
                                self.delete_from_supported(pe_id, e)
                    try:
                        self.resource_mgmt_client.resources.begin_delete_by_id(subnet_id, api_version).result()
                        logging.info(f"Subnet {subnet_id} has been deleted successfully.")
                    except HttpResponseError as e:
                        logging.error(f"Error deleting Virtual Network {subnet_id}: {e}")
                        self.delete_from_supported(subnet_id, e)        
            except HttpResponseError as e:
                logging.error(f"Error deleting Virtual Network {resource_id}: {e}")
                self.delete_from_supported(resource_id, e)

        elif resource_type.lower() == 'vaults':
            BackupRecoveryServiceVault(self.subscription_id, self.zone, self.resource_group_name, resource_id).cleanup()
        try:
            self.resource_mgmt_client.resources.begin_delete_by_id(resource_id,"2021-04-01").result()
            logging.info(f"{resource_id} has been decommissioned successfully.")
        except HttpResponseError as e:
            logging.error(e)
            self.delete_from_supported(resource_id,e)

    def delete_vm(self,vm_id):
        try:
            self.resource_mgmt_client.resources.begin_delete_by_id(vm_id,"2021-04-01").result()
            logging.info(f"VM {vm_id} has been decommissioned successfully.")
        except HttpResponseError as e:
            if e.error.code == "NoRegisteredProviderFound":
                pattern = r"supported api-versions are '([^']+)'"
                match = re.search(pattern, e.error.message)
                if match:
                    supported_versions = match.group(1)
                    supported_versions_list = supported_versions.split(', ')
                    self.resource_mgmt_client.resources.begin_delete_by_id(vm_id,supported_versions_list[0]).result()
                    logging.info(f"{vm_id} has been decommissioned successfully.")
                    return
                raise e

    def stop_vm(self,vm):
        vm_stop = self.compute_client.virtual_machines.begin_deallocate(self.resource_group_name, vm)
        vm_stop.wait()
        logging.info(f"VM {vm} has been stopped successfully.")
    
    def is_vm_running(self,vm):
        try:
            vm_details = self.compute_client.virtual_machines.get(self.resource_group_name, vm, expand='instanceView')
            if vm_details.instance_view.statuses[1].code == "PowerState/running":
                return True
            return False
        except HttpResponseError as e:
            if e.error.code == "ResourceNotFound":
                return False
            raise e
    
    def snaptshot_vm(self,vm):
        current_date = datetime.now(timezone.utc).strftime("%Y%m%d")
        snapshot_name = f"{vm}-osdisk-snapshot-{current_date}-brewmation"
        vm_details = self.compute_client.virtual_machines.get(self.resource_group_name, vm)
        os_disk_id = vm_details.storage_profile.os_disk.managed_disk.id
        snapshot = self.compute_client.snapshots.begin_create_or_update(
            self.resource_group_name,
            snapshot_name,
            {
                "location": vm_details.location,
                "creation_data": {
                    "create_option": "Copy",
                    "source_uri": os_disk_id
                }
            }
        )
        snapshot.wait()
        logging.info(f"Snapshot of VM {vm} has been taken successfully.")
    
    async def publish_message(self,payload):
        await self.publish_api(payload)
    
    def create_ctask(self):
        if self.zone not in ['africa','europe']:
            return
        if self.decomm_type in ['resource_with_vm','resource_group_with_vm']:
            objdal = DbActivityManager()
            snow_client = SNOWClient()
            event = objdal.get_event_info(self.event_id)
            vms = []
            for resource in self.payload:
                if '/providers/microsoft.compute/virtualmachines/' in resource['resource_id'].lower():
                    vms.append(resource['resource_name'])
            match self.zone:
                case 'africa':
                    assignment_group = "cbc0b2e21b2f0c104aae202a2d4bcb5d"  # AFR Asset & Configuration Management
                    business_service = "dd45becc37358e00ad52148543990e2c"
                case 'europe':
                    assignment_group = "a3c43bdc879c55108fbe53d83cbb357f" # GL CMDB Team
                    business_service = "1f7a415fdb35dc10faa711494b96195f"
            if event[0].ActivityType == 'Change':
                payload = {
                    "short_description": "CMDB Update",
                    "description": "CMDB update",
                    "change_request": event[0].SnowItemId,
                    "assignment_group": assignment_group,
                    "change_task_type": "cmdb",
                }
                snow_client.create_ctask(payload)
            else:
                data = {
                    "assignment_group": assignment_group,
                    "short_description": "CMDB Update",
                    "description": "CMDB update",
                }
                snow_client.create_ritm_on_existing_request(event[0].SnowItemId,data)

    async def publish_api(self,payload):
        servicebus_client = ServiceBusClientAbstract().get_servicebus_client()
        unique_key = ServiceBusClientAbstract().generate_unique_key(payload)
        try:
            sender = servicebus_client.get_topic_sender(topic_name='request_receiver')
            async with sender:
                message = ServiceBusMessage(json.dumps(payload, sort_keys=True),message_id=unique_key)
                await sender.send_messages(message)
        except Exception as e:
            logging.error(e)
            raise 
    
    def make_receiver_payload(self):
        receiver_payload = json.loads(self.json_data['Payload'])
        if receiver_payload['ActivityType'] == 'Change':
            cab = CabCalendar(self.zone,receiver_payload['payload']['cooling_period'])
            receiver_payload['payload']['chg_cab_calender'] = cab.get_cab_date(receiver_payload['payload']['chg_cab_calender'])
            receiver_payload['payload']['chg_start_datetime'] = cab.get_start_date(receiver_payload['payload']['chg_cab_calender'])
            receiver_payload['payload']['chg_end_datetime'] = cab.get_end_date(receiver_payload['payload']['chg_cab_calender'])
        receiver_payload['message_id'] = ServiceBusClientAbstract().generate_unique_key(receiver_payload)
        return receiver_payload


    def decommission(self):
        self.payload = sorted(self.payload, key=lambda rid: -len(rid['resource_id'].strip("/").split("/"))) if self.decomm_type != 'resource_group_only' else self.payload
        try:
            if self.decomm_type in ['resource_group_only','resource_group_without_vm']:
                self.lock_client = LockManager(self.subscription_id, self.zone, self.resource_group_name)
                self.lock_client.remove_all_locks()
                self.delete_resource_group(self.resource_group_name)
            elif self.decomm_type in ['resource_with_vm','resource_without_vm']:
                for resource in self.payload:
                    if '/providers/microsoft.compute/virtualmachines/' in resource['resource_id'].lower() and self.is_vm_running(resource['resource_name']):
                        raise Exception(f'Failed to decommission resource. Found a Running VM - {resource["resource_name"]}')
                for resource in self.payload:
                    self.lock_client = LockManager(self.subscription_id, self.zone, self.resource_group_name,resource['resource_name'], resource['resource_id'])
                    self.lock_client.remove_all_locks()
                    self.lock_client.remove_all_locks(scope=resource['resource_id'])
                    self.delete_resource(resource['resource_id'])
                    self.lock_client.restore_locks_at_rg()
                if self.decomm_type == 'resource_with_vm':
                    self.create_ctask()
            elif self.decomm_type == 'resource_group_with_vm':
                for resource in self.payload:
                    if '/providers/microsoft.compute/virtualmachines/' in resource['resource_id'].lower() and self.is_vm_running(resource['resource_name']):
                        raise Exception(f'Failed to decommission resource. Found a Running VM - {resource["resource_name"]}')
                self.lock_client = LockManager(self.subscription_id, self.zone, self.resource_group_name)
                self.lock_client.remove_all_locks()
                self.delete_resource_group(self.resource_group_name)
                self.create_ctask()
        except Exception as e:
            logging.error(f"Error in decommissioning: {e}")
            raise e
    
    async def decommission_preactivity(self):
        try:
            if self.decomm_type == 'resource_group_with_vm':
                self.lock_client = LockManager(self.subscription_id, self.zone, self.resource_group_name)
                self.lock_client.remove_all_locks()
                for resource in self.payload:
                    if '/providers/microsoft.compute/virtualmachines/' in resource['resource_id'].lower():
                        self.stop_vm(resource['resource_name'])
                lock_scope = f"/subscriptions/{self.subscription_id}/resourceGroups/{self.resource_group_name}"
                self.lock_client.add_locks(scope=lock_scope,lock_type="ReadOnly",notes="Added By Brewmation for Decommissioning")
                self.lock_client.add_locks(scope=lock_scope,lock_type="CanNotDelete",notes="Added By Brewmation for Decommissioning")
            elif self.decomm_type == 'resource_with_vm':
                for resource in self.payload:
                    if '/providers/microsoft.compute/virtualmachines/' in resource['resource_id'].lower():
                        self.lock_client = LockManager(self.subscription_id, self.zone, self.resource_group_name,resource['resource_name'], resource['resource_id'])
                        self.lock_client.remove_all_locks()
                        self.stop_vm(resource['resource_name'])                       
                        lock_scope = resource['resource_id']
                        self.lock_client.add_locks(scope=lock_scope,lock_type="ReadOnly",notes="Added By Brewmation for Decommissioning")
                        self.lock_client.add_locks(scope=lock_scope,lock_type="CanNotDelete",notes="Added By Brewmation for Decommissioning")
                        self.lock_client.restore_locks_at_rg()
            payload = self.make_receiver_payload()
            await self.publish_message(payload)
        except Exception as e:
            raise e