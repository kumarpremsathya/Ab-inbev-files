from shared_code.recoveryservices_client import RecoveryServicesBkpClient, RecoveryServiceClient
from shared_code.networkmgmt_client import NetworkMgmtClient
from azure.mgmt.recoveryservicesbackup.models import (
    BackupResourceVaultConfigResource, BackupResourceVaultConfig,
    ProtectedItemResource, ProtectedItem
)

from azure.core.exceptions import HttpResponseError
import logging, requests
from azure.mgmt.recoveryservicessiterecovery import SiteRecoveryManagementClient
from shared_code.client_secret_auth import ClientSecretAuth
import os


class BackupRecoveryServiceVault:

    def __init__(self, subscription_id, zone, resource_group_name, vault_resource_id):
        self.subscription_id = subscription_id
        self.zone = zone
        self.resource_group_name = resource_group_name
        self.vault_resource_id = vault_resource_id
        self.vault_name = vault_resource_id.split('/')[-1]
        self.azenvironment = "AzureChinaCloud" if zone == "china" else "AzurePublicCloud"
        self.backup_client = RecoveryServicesBkpClient().get_recoveryservice_backup_client(self.azenvironment, subscription_id)
        self.rs_client = RecoveryServiceClient().get_recoveryservice_client(self.azenvironment, subscription_id)
        self.network_client = NetworkMgmtClient().get_network_mgmt_client(subscription_id, self.azenvironment)

    def _get_credentials(self):
       
        spn_secret_name = os.environ["SPN_SECRET_CHINA"] if self.zone == "china" else os.environ["SPN_SECRET_PUBLIC"]
        return ClientSecretAuth().client_credential(spn_secret_name)

    def disable_soft_delete(self):
        try:
            self.backup_client.backup_resource_vault_configs.update(
                self.vault_name,
                self.resource_group_name,
                BackupResourceVaultConfigResource(
                    properties=BackupResourceVaultConfig(soft_delete_feature_state="Disabled")
                )
            )
            logging.info(f"Soft delete disabled for vault {self.vault_name}")
        except HttpResponseError as e:
            if "ResourceGuard" in str(e) or "MUA" in str(e):
                logging.error(f"MUA is enabled on vault {self.vault_name}. "
                              "Request approval from the Resource Guard owner before retrying.")
                raise
            else:
                logging.error(f"Error disabling soft delete: {e}")

    def disable_hybrid_backup_security(self):
        
        try:
            credentials = self._get_credentials()
            base_url = "https://management.chinacloudapi.cn" if self.zone == "china" else "https://management.azure.com"
            token = credentials.get_token(f"{base_url}/.default").token
            url = f"{base_url}{self.vault_resource_id}/backupconfig/vaultconfig?api-version=2024-04-01"
            body = {"properties": {"enhancedSecurityState": "Disabled"}}
            response = requests.patch(url, json=body, headers={"Authorization": f"Bearer {token}"})
            response.raise_for_status()
            logging.info(f"Hybrid backup security disabled for vault {self.vault_name}")
        except Exception as e:
            logging.error(f"Error disabling hybrid security: {e}")

    def undelete_soft_deleted_items(self):
        try:
            items = list(self.backup_client.backup_protected_items.list(self.vault_name, self.resource_group_name))
        except HttpResponseError as e:
            logging.error(f"Error listing items for undelete: {e}")
            return
        for item in items:
            try:
                if getattr(item.properties, 'is_scheduled_for_deferred_delete', False):
                    parts = item.id.split('/')
                    fabric_name = parts[parts.index('backupFabrics') + 1]
                    container_name = parts[parts.index('protectionContainers') + 1]
                    item_name = parts[parts.index('protectedItems') + 1]
                    self.backup_client.protected_items.begin_create_or_update(
                        self.vault_name, self.resource_group_name,
                        fabric_name, container_name, item_name,
                        ProtectedItemResource(
                            properties=ProtectedItem(is_rehydrate=True)
                        )
                    ).result()
                    logging.info(f"Undeleted soft-deleted item: {item_name}")
            except HttpResponseError as e:
                logging.error(f"Error undeleting item {item.id}: {e}")

    def delete_all_backup_items(self):
        try:
            items = list(self.backup_client.backup_protected_items.list(self.vault_name, self.resource_group_name))
            for item in items:
                try:
                    parts = item.id.split('/')
                    fabric_name = parts[parts.index('backupFabrics') + 1]
                    container_name = parts[parts.index('protectionContainers') + 1]
                    item_name = parts[parts.index('protectedItems') + 1]
                    self.backup_client.protected_items.delete(
                        self.vault_name, self.resource_group_name,
                        fabric_name, container_name, item_name
                    )
                    logging.info(f"Deleted backup item: {item_name}")
                except HttpResponseError as e:
                    logging.error(f"Error deleting backup item {item.id}: {e}")
        except HttpResponseError as e:
            logging.error(f"Error listing backup items: {e}")

    def disable_sql_auto_protection(self):
        try:
            intents = list(self.backup_client.backup_protection_intent.list(
                self.vault_name, self.resource_group_name))
            for intent in intents:
                try:
                    parts = intent.id.split('/')
                    fabric_name = parts[parts.index('backupFabrics') + 1]
                    intent_name = parts[-1]
                    self.backup_client.protection_intent.delete(
                        self.vault_name, self.resource_group_name,
                        fabric_name, intent_name
                    )
                    logging.info(f"Removed auto-protection intent: {intent_name}")
                except HttpResponseError as e:
                    logging.error(f"Error removing protection intent {intent.id}: {e}")
        except HttpResponseError as e:
            logging.error(f"Error listing protection intents: {e}")
    
    def unregister_containers(self):
        # Covers Storage, SQL, SAP HANA, MARS containers
        filter_types = [
            "backupManagementType eq 'AzureStorage'",
            "backupManagementType eq 'AzureWorkload'",
            "backupManagementType eq 'MAB'",
        ]
        for filter_expr in filter_types:
            try:
                containers = list(self.backup_client.backup_protection_containers.list(
                    self.vault_name, self.resource_group_name, filter=filter_expr
                ))
                for container in containers:
                    try:
                        parts = container.id.split('/')
                        fabric_name = parts[parts.index('backupFabrics') + 1]
                        container_name = parts[parts.index('protectionContainers') + 1]
                        self.backup_client.protection_containers.unregister(
                            self.vault_name, self.resource_group_name, fabric_name, container_name
                        )
                        logging.info(f"Unregistered container: {container_name}")
                    except HttpResponseError as e:
                        logging.error(f"Error unregistering container {container.id}: {e}")
            except HttpResponseError as e:
                logging.error(f"Error listing containers for filter '{filter_expr}': {e}")

    def unregister_management_servers(self):
        # Covers MABS and DPM servers
        try:
            servers = list(self.backup_client.backup_engines.list(self.vault_name, self.resource_group_name))
            for server in servers:
                try:
                    server_name = server.id.split('/')[-1]
                    # backup_engines has no delete — unregister via registered_identities
                    self.rs_client.registered_identities.delete(
                                    self.resource_group_name, self.vault_name, server_name)
                    logging.info(f"Unregistered management server: {server_name}")
                except HttpResponseError as e:
                    logging.error(f"Error unregistering server {server.id}: {e}")
        except HttpResponseError as e:
            logging.error(f"Error listing management servers: {e}")

    def cleanup_asr(self):
        try:
            credentials = self._get_credentials()
            if self.zone == "china":
                from msrestazure.azure_cloud import AZURE_CHINA_CLOUD as CHINA
                asr_client = SiteRecoveryManagementClient(
                    credentials, self.subscription_id,
                    base_url=CHINA.endpoints.resource_manager,
                    credential_scopes=[CHINA.endpoints.resource_manager + "/.default"]
                )
            else:
                asr_client = SiteRecoveryManagementClient(credentials, self.subscription_id)
    
            fabrics = list(asr_client.replication_fabrics.list(self.resource_group_name, self.vault_name))
            for fabric in fabrics:
                containers = list(asr_client.replication_protection_containers.list_by_replication_fabrics(
                    self.resource_group_name, self.vault_name, fabric.name))
                for container in containers:
                    items = list(asr_client.replication_protected_items.list_by_replication_protection_containers(
                        self.resource_group_name, self.vault_name, fabric.name, container.name))
                    for item in items:
                        asr_client.replication_protected_items.begin_purge(
                            self.resource_group_name, self.vault_name, fabric.name, container.name, item.name).result()
                        logging.info(f"Purged ASR protected item: {item.name}")
                    mappings = list(asr_client.replication_protection_container_mappings.list_by_replication_protection_containers(
                        self.resource_group_name, self.vault_name, fabric.name, container.name))
                    for mapping in mappings:
                        asr_client.replication_protection_container_mappings.begin_purge(
                            self.resource_group_name, self.vault_name, fabric.name, container.name, mapping.name).result()
                        logging.info(f"Removed ASR container mapping: {mapping.name}")
    
                networks = list(asr_client.replication_networks.list_by_replication_fabrics(
                    self.resource_group_name, self.vault_name, fabric.name))
                for network in networks:
                    net_mappings = list(asr_client.replication_network_mappings.list_by_replication_networks(
                        self.resource_group_name, self.vault_name, fabric.name, network.name))
                    for net_mapping in net_mappings:
                        asr_client.replication_network_mappings.begin_delete(
                            self.resource_group_name, self.vault_name,
                            fabric.name, network.name, net_mapping.name).result()
                        logging.info(f"Removed ASR network mapping: {net_mapping.name}")
    
                asr_client.replication_fabrics.begin_purge(
                    self.resource_group_name, self.vault_name, fabric.name).result()
                logging.info(f"Removed ASR fabric: {fabric.name}")
        except HttpResponseError as e:
            logging.error(f"Error during ASR cleanup: {e}")

    def remove_private_endpoints(self):
        try:
            vault = self.rs_client.vaults.get(self.resource_group_name, self.vault_name)
            for pe_conn in (vault.properties.private_endpoint_connections or []):
                pe_id = pe_conn.properties.private_endpoint.id
                pe_name = pe_id.split('/')[-1]
                pe_rg = pe_id.split('/resourceGroups/')[1].split('/')[0]
                self.network_client.private_endpoints.begin_delete(pe_rg, pe_name).result()
                logging.info(f"Deleted private endpoint: {pe_name}")
        except HttpResponseError as e:
            logging.error(f"Error removing private endpoints: {e}")
                
    def verify_cleanup(self):
        issues = []
        try:
            items = list(self.backup_client.backup_protected_items.list(
                self.vault_name, self.resource_group_name))
            if items:
                issues.append(f"{len(items)} backup items still present")
        except HttpResponseError:
            pass

        for filter_expr in [
            "backupManagementType eq 'AzureStorage'",
            "backupManagementType eq 'AzureWorkload'",
            "backupManagementType eq 'MAB'",
        ]:
            try:
                containers = list(self.backup_client.backup_protection_containers.list(
                    self.vault_name, self.resource_group_name, filter=filter_expr))
                if containers:
                    issues.append(f"{len(containers)} containers still registered ({filter_expr})")
            except HttpResponseError:
                pass

        try:
            servers = list(self.backup_client.backup_engines.list(
                self.vault_name, self.resource_group_name))
            if servers:
                issues.append(f"{len(servers)} management servers still registered")
        except HttpResponseError:
            pass

        try:
            vault = self.rs_client.vaults.get(self.resource_group_name, self.vault_name)
            pe_conns = vault.properties.private_endpoint_connections or []
            if pe_conns:
                issues.append(f"{len(pe_conns)} private endpoints still linked")
        except HttpResponseError:
            pass

        try:
            credentials = self._get_credentials()
            if self.zone == "china":
                from msrestazure.azure_cloud import AZURE_CHINA_CLOUD as CHINA
                asr_client = SiteRecoveryManagementClient(
                    credentials, self.subscription_id,
                    base_url=CHINA.endpoints.resource_manager,
                    credential_scopes=[CHINA.endpoints.resource_manager + "/.default"]
                )
            else:
                asr_client = SiteRecoveryManagementClient(credentials, self.subscription_id)
            fabrics = list(asr_client.replication_fabrics.list(self.resource_group_name, self.vault_name))
            if fabrics:
                issues.append(f"{len(fabrics)} ASR fabrics still present")
        except HttpResponseError:
            pass

        for issue in issues:
            logging.warning(f"Vault cleanup incomplete: {issue}")
        if not issues:
            logging.info(f"All dependencies removed for vault {self.vault_name}")
        return issues

    def cleanup(self):
        logging.info(f"Starting cleanup for Recovery Services Vault: {self.vault_name}")
        self.disable_soft_delete()
        self.disable_hybrid_backup_security()
        self.undelete_soft_deleted_items()
        self.delete_all_backup_items()
        self.disable_sql_auto_protection()
        self.unregister_containers()
        self.unregister_management_servers()
        self.cleanup_asr()                 
        self.remove_private_endpoints()
        self.verify_cleanup() 
        logging.info(f"Cleanup complete for vault: {self.vault_name}")