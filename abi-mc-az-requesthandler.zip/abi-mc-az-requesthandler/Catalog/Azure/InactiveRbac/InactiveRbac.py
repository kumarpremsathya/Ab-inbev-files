import logging
import json,os,uuid
from shared_code.authorization_client import AuthorizationClient
from azure.mgmt.authorization.models import RoleEligibilityScheduleRequest, RequestType, RoleAssignmentScheduleRequest
from azure.core.exceptions import HttpResponseError,ResourceNotFoundError
from shared_code.lock_manager import LockManager

class InactiveRbac:
    def __init__(self, json_data):
        data = json_data
        self.role_assignment_id = data['RoleAssignmentsId']
        self.subscription_id = data['SubscriptionId'] if data['SubscriptionId'] else "73f88e6b-3a35-4612-b550-555157e7059f"
        self.scope = data['Scope']
        self.principal_id = data['PrincipalId']
        self.zone = data['Zone'].lower() if data['Zone'] else "ghq"
        self.env = os.environ["Environment"].lower()
        self.azenvironment = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        # self.scope_type = data['ScopeType']

    async def delete_inactive_users_roles(self):
        try:
            logging.info(f"Attempting to delete role assignment {self.role_assignment_id} for subscription {self.subscription_id} and zone {self.zone}")
            logging.info(f"Current environment: {self.env}")
            if  self.env == "production":
                auth_client = AuthorizationClient().get_auth_client(self.azenvironment, self.subscription_id)
                if 'roleeligibilityscheduleinstances' in self.role_assignment_id.lower():
                    role_instance = auth_client.role_eligibility_schedule_instances.get(self.scope,self.role_assignment_id.split("/")[-1])
                    role_definition_id = role_instance.expanded_properties.role_definition.id
                    uid = str(uuid.uuid4())
                    parameters= RoleEligibilityScheduleRequest(
                        request_type = RequestType.ADMIN_REMOVE,
                        justification = "Brewmation Auto Cleanup",
                        role_definition_id = role_definition_id,
                        principal_id = self.principal_id                            
                    )
                    auth_client.role_eligibility_schedule_requests.create(
                        scope=self.scope,
                        role_eligibility_schedule_request_name= uid,
                        parameters=parameters
                    )
                else:
                    auth_client.role_assignments.delete_by_id(self.role_assignment_id)
                logging.info(f"Successfully deleted role assignment {self.role_assignment_id}")
        except ResourceNotFoundError as e:
            logging.warning(f"Role assignment {self.role_assignment_id} not found. It may have already been deleted.")
        except HttpResponseError as e:
            if e.error.code in ["ResourceNotFoundError","ResourceGroupNotFound"]:
                logging.warning(f"Role assignment {self.role_assignment_id} not found. It may have already been deleted.")
            elif e.error.code == "CannotDeleteLastRbacAdminAssignment":
                role_definition_id = auth_client.role_assignments.get_by_id(self.role_assignment_id).role_definition_id
                uid = str(uuid.uuid4())
                parameters= RoleAssignmentScheduleRequest(
                    request_type = RequestType.ADMIN_REMOVE,
                    justification = "Brewmation Auto Cleanup",
                    role_definition_id = role_definition_id,
                    principal_id = self.principal_id,
                )
                auth_client.role_assignment_schedule_requests.create(
                    scope=self.scope,
                    role_assignment_schedule_request_name= uid,
                    parameters=parameters
                )
            elif e.error.code == "ScopeLocked":
                self.lock_manager = LockManager(self.subscription_id, self.zone, resource_group_name=self.scope.split("/")[4])
                self.lock_manager.remove_all_locks(scope=self.scope,lock_types=["CanNotDelete","ReadOnly"])
                try:
                    if  self.env == "production":
                        auth_client = AuthorizationClient().get_auth_client(self.azenvironment, self.subscription_id)
                        auth_client.role_assignments.delete_by_id(self.role_assignment_id)
                        logging.info(f"Successfully deleted role assignment {self.role_assignment_id}")
                except HttpResponseError as e:
                    if e.error.code == "CannotDeleteLastRbacAdminAssignment":
                        role_definition_id = auth_client.role_assignments.get_by_id(self.role_assignment_id).role_definition_id
                        uid = str(uuid.uuid4())
                        parameters= RoleAssignmentScheduleRequest(
                            request_type = RequestType.ADMIN_REMOVE,
                            justification = "Brewmation Auto Cleanup",
                            role_definition_id = role_definition_id,
                            principal_id = self.principal_id,
                        )
                        auth_client.role_assignment_schedule_requests.create(
                            scope=self.scope,
                            role_assignment_schedule_request_name= uid,
                            parameters=parameters
                        )
                    else:
                        logging.error(f"HTTP error occurred while deleting role assignment {self.role_assignment_id}: {str(e)}")
                        raise e
                finally:
                    self.lock_manager.restore_locks()
            else:
                logging.error(f"HTTP error occurred while deleting role assignment {self.role_assignment_id}: {str(e)}")
                raise e
        except Exception as e:
            logging.error(f"Failed to delete role assignment {self.role_assignment_id}: {str(e)}")
            raise e