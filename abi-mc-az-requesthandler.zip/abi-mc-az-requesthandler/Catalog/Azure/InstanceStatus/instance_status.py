from shared_code.compute_client import ComputeClient
from shared_code.lock_manager import LockManager
from shared_code.vm_run_command import execute_run_command
from shared_code.EmailNotification.NotifyUser import NotifyUser
import logging


class AzVmStatus:
    def __init__(self, data):
        self.zone = data["Zone"]
        self.subscription_id = data["SubscriptionId"]
        self.subscription_name = data.get("SubscriptionName")
        self.resource_group_name = data["ResourceGroupName"]
        self.resource_name = data["ResourceName"]
        self.resource_id = data["ResourceId"]
        self.pre_stop_config = data.get("PreStopConfig")
        self.post_start_config = data.get("PostStartConfig")
        self.event_id = data.get("EventId")
        self.email_notifications = data.get("EmailNotifications")
        if self.zone.lower() == "china":
            self.compute_client = ComputeClient().get_compute_client(self.subscription_id, "AzureChinaCloud")
        else:
            self.compute_client = ComputeClient().get_compute_client(self.subscription_id, "AzurePublicCloud")
        self.lock_client = LockManager(self.subscription_id, self.zone, self.resource_group_name, self.resource_name, self.resource_id)

    async def vm_start_stop_restart(self, action):
        script_failure = None
        vm_status = "Success"
        error_details = None
        
        try:
            self.lock_client.remove_all_locks(lock_types=['ReadOnly'])
            if action == "stop":
                if self.pre_stop_config:
                    success = execute_run_command(
                        self.compute_client,
                        self.resource_group_name,
                        self.resource_name,
                        self.pre_stop_config,
                        "PreStopConfig",
                        required=True
                    )
                    if not success:
                        script_failure = "PreStopConfig script failed"
                        raise Exception("PreStopConfig script failed - VM stop aborted")
                
                logging.info(f"Stopping the VM {self.resource_name}.")
                async_vm_stop = self.compute_client.virtual_machines.begin_deallocate(
                    self.resource_group_name, self.resource_name
                )
                async_vm_stop.wait()
                logging.info(f"VM {self.resource_name} has been stopped successfully.")
            elif action == "start":
                logging.info(f"Starting the VM {self.resource_name}.")
                async_vm_start = self.compute_client.virtual_machines.begin_start(
                    self.resource_group_name, self.resource_name
                )
                async_vm_start.wait()
                logging.info(f"VM {self.resource_name} has been started successfully.")
                
                if self.post_start_config:
                    success = execute_run_command(
                        self.compute_client,
                        self.resource_group_name,
                        self.resource_name,
                        self.post_start_config,
                        "PostStartConfig",
                        required=False
                    )
                    if not success:
                        script_failure = "PostStartConfig script failed (non-blocking)"
            elif action == "restart":
                logging.info(f"Restarting the VM {self.resource_name}.")
                async_vm_restart = self.compute_client.virtual_machines.begin_restart(
                    self.resource_group_name, self.resource_name
                )
                async_vm_restart.wait()
                logging.info(
                    f"VM {self.resource_name} has been restarted successfully."
                )
            
            await NotifyUser().send_vm_operation_notification(
                vm_name=self.resource_name,
                resource_group=self.resource_group_name,
                subscription_id=self.subscription_id,
                subscription_name=self.subscription_name,
                operation=action,
                status=vm_status,
                error_details=script_failure,
                event_id=self.event_id,
                email_notifications=self.email_notifications
            )
            return f"VM {self.resource_name} has been {action}ed successfully."
            
        except Exception as e:
            logging.error(f"An error occurred: {e}")
            vm_status = "Failed"
            error_details = str(e)
            await NotifyUser().send_vm_operation_notification(
                vm_name=self.resource_name,
                resource_group=self.resource_group_name,
                subscription_id=self.subscription_id,
                subscription_name=self.subscription_name,
                operation=action,
                status=vm_status,
                error_details=error_details,
                event_id=self.event_id,
                email_notifications=self.email_notifications
            )
            raise e
        finally:
            self.lock_client.restore_locks()