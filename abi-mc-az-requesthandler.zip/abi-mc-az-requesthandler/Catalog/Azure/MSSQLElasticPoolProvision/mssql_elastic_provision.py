from shared_code.sqlmgmt_client import SqlMgmtClient
from azure.mgmt.sql.models import ServerAzureADAdministrator,AdministratorType
from shared_code.akv_secrets import AkvSecrets
from shared_code.lock_manager import LockManager
from shared_code.storage_client import StorageClient
from shared_code.networkmgmt_client import NetworkMgmtClient
from shared_code.private_endpoint_helper import PrivateEndpointHelper
import pyodbc,logging,os,struct,json

class MSSQLElasticPoolProvision:
    def __init__(self,json_data):   
        data = json.loads(json_data['Payload'])['payload']["data"]
        self.subscription_id = data['subscription_id']
        self.subscription_name = data['subscription_name']
        self.zone = json_data['Zone'].lower()
        self.resource_group_name = data['resource_group_name']
        self.new_server = data['server_type']
        self.sql_server_name = data['new_server_name'] if self.new_server.lower() == 'new' else data['existing_server']
        self.azenvironment = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.elastic_pool = data['new_elastic_pool']
        self.tags = data['tags']
        self.location = data['location']
        self.sku_tier = data['elastic_pool_tier']
        self.sku = data['elastic_pool_sku_name']
        self.sql_mgmt_client = SqlMgmtClient().get_sql_mgmt_client(self.subscription_id,self.azenvironment)
        self.lock_client = LockManager(self.subscription_id,self.zone,self.resource_group_name,self.sql_server_name)
        self.network_client = NetworkMgmtClient().get_network_mgmt_client(self.subscription_id,self.azenvironment)
        self.storage_client = StorageClient().get_storage_client(self.subscription_id,self.azenvironment)
        self.secret = AkvSecrets(os.environ["KEYVAULT_URI"],'sql-creds-prov').get_tokens()

    def provision_db(self):
        try:
            self.lock_client.remove_all_locks()

            if self.new_server == 'New':
                subscription_config = {
                # Abi Global Prod
                "2db7c27b-2f9f-4088-981b-2bd88c5c1905": {
                    "storage_account_name": "mgmtgbpsecuritystorage",
                    "storage_account_rg_name": "mgmtoms-rg-gb-prod",
                    "vnet_name": "PVT-VNET-GB-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-GB-PROD",
                    "log_analytics_workspace_name": "mgmtomsgbprod",
                    "log_analytics_workspace_rg_name": "mgmtoms-rg-gb-prod",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB1",
                    "ad_gp": "AADS_A_ABI GlobalOps SQL DB Admins"
                },
                # ABI Global Non-Prod
                "73f88e6b-3a35-4612-b550-555157e7059f": {
                    "storage_account_name": "mgmtgbnpsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-RG-GB-NON-PROD",
                    "vnet_name": "PVT-VNET-GB-NON-PROD",
                    "vnet_rg_name": "mgmtpvt-rg-gb-non-prod",
                    "log_analytics_workspace_name": "mgmtomsgbnonprod",
                    "log_analytics_workspace_rg_name": "mgmtoms-rg-gb-non-prod",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB1",
                    "ad_gp": "AADS_A_ABI GlobalOps SQL DB Admins"
                },
                # ABI NAZ Non-Prod
                "25137c49-ffa8-4cef-a4db-f8aaf059d980": {
                    "storage_account_name": "mgmtnaznpsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-RG-NAZ-NON-PROD",
                    "vnet_name": "PVT-VNET-NAZ-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-NAZ-NON-PROD",
                    "log_analytics_workspace_name": "mgmtomsnaznonprod",
                    "log_analytics_workspace_rg_name": "mgmtoms-rg-naz-non-prod",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB",
                    "ad_gp": "AADS_A_ABI NAZ SQL Admins"
                },
                # ABI NAZ Prod
                "95c54dda-ae35-43c0-aeea-bcfc596674c1": {
                    "storage_account_name": "mgmtnazpsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-RG-NAZ-PROD",
                    "vnet_name": "PVT-VNET-NAZ-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-NAZ-PROD",
                    "log_analytics_workspace_name": "mgmtomsnazprod",
                    "log_analytics_workspace_rg_name": "mgmtoms-rg-naz-prod",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB",
                    "ad_gp": "AADS_A_ABI NAZ SQL Admins"
                },
                # ABI NAZ SAP R3
                "c8642ed5-9766-43fa-b6cc-47f19181fa40": {
                    "storage_account_name": "mgmtnazsapr3bootdiag",
                    "storage_account_rg_name": "MGMTOMS-RG-NAZ-SAP-R3",
                    "vnet_name": "SAP-INFRA-VNET-NAZ-PROD",
                    "vnet_rg_name": "SAP-RG-NAZ-PROD",
                    "log_analytics_workspace_name": "mgmtomsnazsap",
                    "log_analytics_workspace_rg_name": "MGMTOMS-RG-NAZ-SAP-R3",
                    "subnet_name": "SAP-PR-DB-SUB",
                    "subnet_name1": "SAP-PR-ANF-SUB",
                    "subnet_name2": "SAP-PR-DB-SUB",
                    "ad_gp": "AADS_A_ABI NAZ SQL Admins"
                },
                # ABI MAZ Non-Prod
                "fe70970a-8778-4bc4-83c4-a85c57c1efd3": {
                    "storage_account_name": "mgmtmaznpsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-RG-MEX-NON-PROD",
                    "vnet_name": "PVT-VNET-MEX-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-MEX-NON-PROD",
                    "log_analytics_workspace_name": "mgmtomsmexnonprod",
                    "log_analytics_workspace_rg_name": "mgmtoms-rg-mex-non-prod",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB",
                    "ad_gp": "AADS_A_ABI GlobalOps SQL DB Admins"
                },
                # ABI MAZ Prod
                "a6362b38-0f74-4c75-bcbb-719b38f04f75": {
                    "storage_account_name": "mgmtmazpsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-RG-MEX-PROD",
                    "vnet_name": "PVT-VNET-MEX-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-MEX-PROD",
                    "log_analytics_workspace_name": "mgmtomsmexprod",
                    "log_analytics_workspace_rg_name": "mgmtoms-rg-mex-prod",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB",
                    "ad_gp": "AADS_A_ABI GlobalOps SQL DB Admins"
                },
                # ABI EU Non-Prod
                "3617a45e-beab-410a-9476-d6e000e1fb77": {
                    "storage_account_name": "mgmteunpsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-RG-EU-NON-PROD",
                    "vnet_name": "PVT-VNET-EU-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-EU-NON-PROD",
                    "log_analytics_workspace_name": "mgmtomseunonprod",
                    "log_analytics_workspace_rg_name": "mgmtoms-rg-eu-non-prod",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB",
                    "ad_gp": "AADS_A_ABI GlobalOps SQL DB Admins"
                },
                # ABI EU Prod
                "1c1db8ee-5d54-460b-bd71-fd031be2a7e5": {
                    "storage_account_name": "mgmteupsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-RG-EU-PROD",
                    "vnet_name": "PVT-VNET-EU-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-EU-PROD",
                    "log_analytics_workspace_name": "mgmtomseuprod",
                    "log_analytics_workspace_rg_name": "MGMTOMS-RG-EU-PROD",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB",
                    "ad_gp": "AADS_A_ABI GlobalOps SQL DB Admins"
                },
                # ABI Africa Prod
                "77a7f337-8588-4076-b526-5f1ce0e55671": {
                    "storage_account_name": "mgmtafpsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-RG-AFR-PROD",
                    "vnet_name": "PVT-VNET-AFR-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-AFR-PROD",
                    "log_analytics_workspace_name": "mgmtomsafrprod",
                    "log_analytics_workspace_rg_name": "mgmtoms-rg-afr-prod",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB",
                    "ad_gp": "AADS_A_ABI GlobalOps SQL DB Admins"
                },
                # ABI Africa Non-Prod
                "15bcebd1-794e-49c6-9548-8a4a4357ee16": {
                    "storage_account_name": "mgmtafnpsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-RG-AFR-NON-PROD",
                    "vnet_name": "PVT-VNET-AFR-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-AFR-NON-PROD",
                    "log_analytics_workspace_name": "mgmtomsafrnonprod",
                    "log_analytics_workspace_rg_name": "mgmtoms-rg-afr-non-prod",
                    "subnet_name": "Webapp-1",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB",
                    "ad_gp": "AADS_A_ABI GlobalOps SQL DB Admins"
                },
                # ABI China Prod
                "30b7b23e-9325-4407-b613-610457afe869": {
                    "storage_account_name": "mgmtcnpsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-E2-RG-CN-PROD",
                    "vnet_name": "PVT-E2-VNET-CN-PROD",
                    "vnet_rg_name": "MGMTPVT-E2-RG-CN-PROD",
                    "log_analytics_workspace_name": "mgmtomschinaprod",
                    "log_analytics_workspace_rg_name": "mgmtoms-e2-rg-cn-prod",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB",
                    "ad_gp": "SONEG-Admin-Global-Azure-Operations"
                },
                # ABI China Non-Prod
                "08ba6e07-14eb-4984-9176-9261b8a2781d": {
                    "storage_account_name": "mgmtcnnonprodbootdiag",
                    "storage_account_rg_name": "MGMTOMS-E2-RG-CN-NON-PROD",
                    "vnet_name": "PVT-E2-VNET-CN-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-E2-RG-CN-NON-PROD",
                    "log_analytics_workspace_name": "mgmtomschinanonprod",
                    "log_analytics_workspace_rg_name": "mgmtoms-e2-rg-cn-non-prod",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB",
                    "ad_gp": "SONEG-Admin-Global-Azure-Operations"
                },
                # ABI KR Non-Prod
                "b413c513-77a1-4416-84d4-4057920111c6": {
                    "storage_account_name": "mgmtkrnpsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-RG-KR-NON-PROD",
                    "vnet_name": "PVT-VNET-KR-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-KR-NON-PROD",
                    "log_analytics_workspace_name": "mgmtomskrnonprod",
                    "log_analytics_workspace_rg_name": "mgmtoms-rg-kr-non-prod",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB",
                    "ad_gp": "AADS_A_ABI GlobalOps SQL DB Admins"
                },
                # ABI KR Prod
                "a831d6f9-cdd3-4d49-9dd5-9389dd3a1902": {
                    "storage_account_name": "mgmtkrpsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-RG-KR-PROD",
                    "vnet_name": "PVT-VNET-KR-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-KR-PROD",
                    "log_analytics_workspace_name": "mgmtomskrprod",
                    "log_analytics_workspace_rg_name": "mgmtoms-rg-kr-prod",
                    "subnet_name": "Webapp",
                    "subnet_name1": "Infra",
                    "subnet_name2": "DB",
                    "ad_gp": "AADS_A_ABI GlobalOps SQL DB Admins"
                }
                }

                if self.subscription_id not in subscription_config:
                    raise ValueError(f"Subscription ID {self.subscription_id} not found in configuration")
                
                config = subscription_config[self.subscription_id]
                storage_account_name = config['storage_account_name']
                storage_account_rg = config['storage_account_rg_name']
                subnet_name = config['subnet_name2']
                ad_group = config['ad_gp']
                
                # Create SQL Server
                server = self.sql_mgmt_client.servers.begin_create_or_update(
                    self.resource_group_name,
                    self.sql_server_name,
                    {
                        "location": self.location,
                        "version": "12.0",
                        "administrator_login": "ABISQLADMIN",
                        "administrator_login_password": self.secret.value,
                        "minimal_tls_version": "1.2",
                        "public_network_access": "Disabled",
                        "tags": self.tags
                    }
                ).result()
                
                logging.info(f"SQL Server '{self.sql_server_name}' created successfully")

                if self.zone == 'naz':
                    login = "AADS_A_ABI NAZ SQL DB Admins"
                    sid = "eacb2675-7fbc-4f91-a3eb-906c78bd0043"
                elif self.zone == 'china':
                    login = "Cloudbolt"
                    sid = "6a956c8e-0e11-4d70-84ef-4ea2c018964b"
                else:
                    login = "AADS_A_ABI GlobalOps SQL DB Admins"
                    sid = "c643a250-a7e8-44b2-bc5f-7ed4437e7cf9"
                tenant_id = "cef04b19-7776-4a94-b89b-375c77a8f936" if self.zone != 'china' else "c99b23b6-4fa8-4eee-a7cc-2f420106e730"
                self.sql_mgmt_client.server_azure_ad_administrators.begin_create_or_update(self.resource_group_name,self.sql_server_name,"ActiveDirectory", 
                    ServerAzureADAdministrator(     
                        administrator_type=AdministratorType("ActiveDirectory"),
                        login=login,
                        sid=sid,
                        tenant_id=tenant_id,
                        azure_ad_only_authentication = False
                        )
                )
                logging.info(f"AD Administrator added to SQL Server '{self.sql_server_name}'")

                pe_helper = PrivateEndpointHelper(self.subscription_id, self.zone, self.azenvironment)
                subnet_id = pe_helper.get_subnet_id(
                    vnet_rg_name=config["vnet_rg_name"],
                    vnet_name=config["vnet_name"],
                    subnet_name=config["subnet_name2"]
                )
                private_dns_zone_name = "privatelink.sql.cn" if self.zone == "china" else "privatelink.database.windows.net"
                pe_helper.create_private_endpoint(
                    resource_group_name=self.resource_group_name,
                    resource_id=server.id,
                    resource_name=self.sql_server_name,
                    location=self.location,
                    subnet_id=subnet_id,
                    group_ids=["sqlServer"],
                    dns_zone_name=private_dns_zone_name,
                    tags=self.tags,
                    create_dns_zone_if_not_exists=True
                )

                storage_account = self.storage_client.storage_accounts.list_keys(storage_account_rg, storage_account_name)
                
                self.sql_mgmt_client.extended_server_blob_auditing_policies.begin_create_or_update(
                    self.resource_group_name,
                    self.sql_server_name,
                    {
                        "storage_endpoint": f"https://{storage_account_name}.blob.core.windows.net" if self.zone != "china" else f"https://{storage_account_name}.blob.core.chinacloudapi.cn",
                        "storage_account_access_key": storage_account.keys[0].value,
                        "storage_account_access_key_is_secondary": False,
                        "retention_days": 91,
                        "state": "Enabled",
                    }
                )
                logging.info(f"Extended auditing enabled for SQL Server '{self.sql_server_name}'")

                # Enable Security Alert Policy
                self.sql_mgmt_client.server_security_alert_policies.begin_create_or_update(
                    self.resource_group_name,
                    self.sql_server_name,
                    "Default",
                    {
                        "state": "Enabled"
                    }
                )
                logging.info(f"Security alert policy enabled for SQL Server '{self.sql_server_name}'")

                # Enable Vulnerability Assessment
                self.sql_mgmt_client.server_vulnerability_assessments.create_or_update(
                    self.resource_group_name,
                    self.sql_server_name,
                    "default",
                    {
                        "storage_container_path": f"https://{storage_account_name}.blob.core.windows.net/{self.sql_server_name}/",
                        "storage_account_access_key": storage_account.keys[0].value,
                        "recurring_scans": {
                            "is_enabled": True,
                        }
                    }
                )
                logging.info(f"Vulnerability assessment enabled for SQL Server '{self.sql_server_name}'")   

            #create pool
            elastic_pool = self.sql_mgmt_client.elastic_pools.begin_create_or_update(
                self.resource_group_name,
                self.sql_server_name,
                self.elastic_pool,
                {
                    "location": self.location,
                    "sku": {
                        "name": self.sku.split('-')[0],
                        "tier": self.sku_tier,
                        "capacity": self.sku.split('-')[-2] if self.sku_tier.lower() in ['standard','premium','basic'] else None
                    },
                    "tags": self.tags
                }
            )

            return elastic_pool.result().id
        except Exception as e:
            logging.error(f"Error provisioning database: {e}")
            raise e
        finally:
            self.lock_client.restore_locks()