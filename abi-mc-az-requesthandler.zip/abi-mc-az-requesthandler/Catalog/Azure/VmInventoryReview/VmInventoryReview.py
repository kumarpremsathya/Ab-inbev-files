import logging
import json, os
from datetime import datetime, timezone
from shared_code.db import DB
from shared_code.lock_manager import LockManager
from shared_code.vm_run_command import execute_run_command
from shared_code.compute_client import ComputeClient


class VmInventoryReview:
    def __init__(self, json_data):
        data = json_data
        self.event_id = data.get('EventId', None)
        self.activity_id = data.get('ActivityId', None)
        self.account_name = data.get('AccountName', None)
        self.account_id = data.get('AccountId', None)
        self.account_enabled = data.get('AccountEnabled', None)
        self.action = data.get('Action', None)
        self.node = data.get('Node', None)
        self.ipaddress = data.get('Ipaddress', None)
        self.privileged_access = data.get('PrivilegedAccess', None)
        self.approver = data.get('Approver', None)
        self.zone = data.get('Zone', None)
        self.unique_id = data.get('UniqueId', None)
        self.application_uid = data.get('ApplicationUID', None)
        self.project_name = data.get('ProjectName', None)
        self.env = os.environ.get("Environment", '').lower()
        self.azenvironment = "AzureChinaCloud" if self.zone and self.zone.lower() == "china" else "AzurePublicCloud"
        self.objdb = DB()

    def _get_user_details_from_report(self):
        user_query = """
            SELECT TOP 1 UserId, DisplayName, Email, UserPrincipalName, AccountType, ManagerEmail, OnPremisesDomain
            FROM tblAzureUsersReport
            WHERE SamAccountName = ?
        """
        vm_query = """
            SELECT TOP 1 Kernel, VmId
            FROM tblFactsReport
            WHERE Node = ?
        """
        user_result = self.objdb.executescalar(sql_query=user_query, action="select", values=(self.account_name,))
        vm_result = self.objdb.executescalar(sql_query=vm_query, action="select", values=(self.node,))

        if not user_result:
            logging.warning(f"No record found in tblAzureUsersReport for SamAccountName: {self.account_name}")
            return None
        if not vm_result:
            logging.warning(f"No record found in tblFactsReport for Node: {self.node}")
            return None

        user = user_result[0]
        vm = vm_result[0]

        vmid = vm.VmId
        parts = vmid.split('/') if vmid else []
        subscription_id = parts[2] if len(parts) > 2 else None
        resource_group = parts[4] if len(parts) > 4 else None
        resource = f"/subscriptions/{subscription_id}/resourceGroups/{resource_group}" if subscription_id and resource_group else None

        subscription_name = None
        if subscription_id:
            sub_result = self.objdb.executescalar(
                sql_query="SELECT TOP 1 SubscriptionName FROM tblAzureSubscriptionsListReport WHERE SubscriptionId = ?",
                action="select",
                values=(subscription_id,)
            )
            if sub_result:
                subscription_name = sub_result[0].SubscriptionName

        return {
            "Kernel": vm.Kernel,
            "Email": user.Email,
            "UserPrincipalName": user.UserPrincipalName,
            "DisplayName": user.DisplayName,
            "Domain": user.OnPremisesDomain,
            "UserId": user.UserId,
            "Vmid": vmid,
            "SubscriptionId": subscription_id,
            "SubscriptionName": subscription_name,
            "ResourceGroupName": resource_group,
            "Resource": resource,
            "AccountType": user.AccountType
        }

    def _insert_into_inactive_vm_accounts(self, user_details):
        sql_query = """
            MERGE INTO tblActivityAzInactiveVmAccounts AS Target
            USING (
                SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
            ) AS Source
            (EventId, Node, Kernel, UserId, Email, UserPrincipalName, DisplayName, ManagerEmail,
             AccountName, AccountType, Domain, Vmid, PrivilegedAccess, SubscriptionId, SubscriptionName,
             ResourceGroupName, Resource, Cloud, Zone, Status, Comments, RetryAttemptedAt, AccountStatus, CleanType)
            ON Target.EventId = Source.EventId
            AND Target.UserPrincipalName = Source.UserPrincipalName
            AND Target.Vmid = Source.Vmid
            WHEN MATCHED THEN
                UPDATE SET
                    Target.ManagerEmail = Source.ManagerEmail,
                    Target.AccountStatus = Source.AccountStatus,
                    Target.RetryAttemptedAt = Source.RetryAttemptedAt
            WHEN NOT MATCHED THEN
                INSERT (
                    EventId, Node, Kernel, UserId, Email, UserPrincipalName, DisplayName, ManagerEmail,
                    AccountName, AccountType, Domain, Vmid, PrivilegedAccess, SubscriptionId, SubscriptionName,
                    ResourceGroupName, Resource, Cloud, Zone, Status, Comments, RetryAttemptedAt, AccountStatus, CleanType
                )
                VALUES (
                    Source.EventId, Source.Node, Source.Kernel, Source.UserId, Source.Email,
                    Source.UserPrincipalName, Source.DisplayName, Source.ManagerEmail, Source.AccountName,
                    Source.AccountType, Source.Domain, Source.Vmid, Source.PrivilegedAccess, Source.SubscriptionId,
                    Source.SubscriptionName, Source.ResourceGroupName, Source.Resource, Source.Cloud, Source.Zone,
                    Source.Status, Source.Comments, Source.RetryAttemptedAt, Source.AccountStatus, Source.CleanType
                );
        """
        values = (
            self.event_id,
            self.node,
            user_details.get("Kernel"),
            user_details.get("UserId"),
            user_details.get("Email"),
            user_details.get("UserPrincipalName"),
            user_details.get("DisplayName"),
            self.approver,
            self.account_name,
            user_details.get("AccountType"),
            user_details.get("Domain"),
            user_details.get("Vmid"),
            self.privileged_access,
            user_details.get("SubscriptionId"),
            user_details.get("SubscriptionName"),
            user_details.get("ResourceGroupName"),
            user_details.get("Resource"),
            "Azure",
            self.zone,
            "In-Progress",
            f"Revoked by approver: {self.approver}",
            datetime.now(timezone.utc),
            "Inactive User",
            "Revoked"
        )
        self.objdb.executescalar(sql_query=sql_query, action="insert", values=values)

    def _update_status(self, user_details, status, comments):
        sql_query = """
            UPDATE tblActivityAzInactiveVmAccounts SET Status = ?, Comments = ?
            WHERE EventId = ? AND UserPrincipalName = ? AND Vmid = ?
        """
        self.objdb.executescalar(
            sql_query=sql_query,
            action="update",
            values=(status, comments, self.event_id, user_details.get("UserPrincipalName"), user_details.get("Vmid"))
        )

    def _execute_remove_command(self, user_details):
        subscription_id = user_details.get("SubscriptionId")
        resource_group_name = user_details.get("ResourceGroupName")
        vmid = user_details.get("Vmid")
        kernel = user_details.get("Kernel")

        if not subscription_id or not resource_group_name or not vmid:
            raise Exception(f"Missing VM details for run command execution. SubscriptionId: {subscription_id}, ResourceGroupName: {resource_group_name}, Vmid: {vmid}")

        lock_manager = LockManager(subscription_id, self.zone.lower(), resource_group_name=resource_group_name, resource_id=vmid)
        compute_client = ComputeClient().get_compute_client(subscription_id, self.azenvironment)
        lock_manager.remove_all_locks(scope=user_details.get("Resource"), lock_types=["ReadOnly"])

        is_privileged = self.privileged_access and self.privileged_access.lower() == "yes"

        if kernel and kernel.lower() == "linux":
            script_json = {
                "kernel": "Linux",
                "scripts": [
                    f"gpasswd -d {self.account_name} sudousers > /dev/null 2>&1 || true",
                    f"gpasswd -d {self.account_name} sshusers > /dev/null 2>&1 || true",
                ]
            }
        else:
            group_name = "Administrators" if is_privileged else "Remote Desktop Users"
            script_json = {
                "kernel": "Windows",
                "scripts": [
                    f"Remove-LocalGroupMember -Group \"{group_name}\" -Member \"{self.account_name}\" -ErrorAction SilentlyContinue"
                ]
            }

        vm_name = self.node.split('.')[0] if '.' in self.node else self.node
        try:
            execute_run_command(compute_client, resource_group_name, vm_name, json.dumps(script_json), "VM Inventory Review - Account Revocation", required=True)
            logging.info(f"Removed account {self.account_name} from VM {self.node}")
        finally:
            lock_manager.restore_locks(lock_types=["ReadOnly"])

    def process_vm_inventory_review(self):
        try:
            if not (self.action and self.action.lower() == "revoked"):
                logging.info(f"Action '{self.action}' does not require processing for VMINVREVIEW. Skipping.")
                return

            user_details = self._get_user_details_from_report()
            if not user_details:
                raise Exception(f"No user details found in tblAzureUsersReport for AccountName: {self.account_name}, Node: {self.node}")

            self._insert_into_inactive_vm_accounts(user_details)

            if self.env == "production" and user_details.get("Vmid"):
                self._execute_remove_command(user_details)
                self._update_status(user_details, "Success", "Account revoked successfully")

        except Exception as e:
            logging.exception(f"Error processing VMINVREVIEW for {self.account_name} on {self.node}: {e}")
            raise e

