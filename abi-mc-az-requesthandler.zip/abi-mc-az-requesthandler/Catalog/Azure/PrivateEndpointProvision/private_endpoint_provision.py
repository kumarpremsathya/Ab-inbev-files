from shared_code.networkmgmt_client import NetworkMgmtClient
from shared_code.privatedns_client import PrivateDNSClient
from shared_code.resourcemgmt_client import ResourceMgmtClient
from shared_code.dns_zone_helper import DnsZoneHelper
from azure.mgmt.core.tools import parse_resource_id
import json,logging

class PrivateEndpointProvision:
    def __init__(self):
        pass
    PRIVATE_DNS_ZONES = {
        "blob": "privatelink.blob.core.windows.net",
        "file": "privatelink.file.core.windows.net",
        "queue": "privatelink.queue.core.windows.net",
        "table": "privatelink.table.core.windows.net",
        "dfs": "privatelink.dfs.core.windows.net",
        "web": "privatelink.web.core.windows.net",
        "sites": "privatelink.azurewebsites.net",
        "vault": "privatelink.vaultcore.azure.net",
        "Sql": "privatelink.documents.azure.com",
        "MongoDB": "privatelink.mongo.cosmos.azure.com",
        "Cassandra": "privatelink.cassandra.cosmos.azure.com",
        "Gremlin": "privatelink.gremlin.cosmos.azure.com",
        "Table": "privatelink.table.cosmos.azure.com",
        "sqlServer": "privatelink.database.windows.net",
        "postgresqlServer": "privatelink.postgres.database.azure.com",
        "namespace": "privatelink.servicebus.windows.net",
        "redisCache": "privatelink.redis.cache.windows.net",
        "registry": "privatelink.azurecr.io",
        "databricks": "privatelink.azuredatabricks.net",
        "dataFactory": "privatelink.datafactory.azure.net",
    }

    # China cloud DNS zones
    PRIVATE_DNS_ZONES_CHINA = {
        "blob": "privatelink.blob.core.chinacloudapi.cn",
        "file": "privatelink.file.core.chinacloudapi.cn",
        "queue": "privatelink.queue.core.chinacloudapi.cn",
        "table": "privatelink.table.core.chinacloudapi.cn",
        "dfs": "privatelink.dfs.core.chinacloudapi.cn",
        "web": "privatelink.web.core.chinacloudapi.cn",
        "sites": "privatelink.chinacloudsites.cn",
        "vault": "privatelink.vaultcore.azure.cn",
        "Sql": "privatelink.documents.azure.cn",
        "sqlServer": "privatelink.database.chinacloudapi.cn",
        "postgresqlServer": "privatelink.postgres.database.chinacloudapi.cn",
        "namespace": "privatelink.servicebus.chinacloudapi.cn",
        "redisCache": "privatelink.redis.cache.chinacloudapi.cn",
        "registry": "privatelink.azurecr.cn",
        "databricks": "privatelink.azuredatabricks.cn",
        "dataFactory": "privatelink.datafactory.azure.cn",
    }

    def __init__(self,json_data):
        data = json.loads(json_data['Payload'])['payload']["data"]
        self.zone = json_data["Zone"].lower()
        self.tags = data.get("tags", {})
        self.subscription_id = data["subscription_id"]
        self.resource_group_name = data["resource_group_name"]
        self.private_endpoint_name = data["private_endpoint_name"]
        self.target_resource_id = data["target_resource_id"]
        self.group_id = data["group_id"]
        self.subnet_id = data["subnet_id"]
        self.create_dns_zone_group = data.get("create_dns_zone_group", True)
        self.dns_zone_id = data.get("dns_zone_id")
        self.private_ip_address = data.get("private_ip_address")
        self.member_name = data.get("member_name")
        self.network_interface_name = data.get("network_interface_name")
        self.public_network_access = data.get("public_network_access")
        
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.network_client = NetworkMgmtClient().get_network_mgmt_client(self.subscription_id, self.cloud)
        self.dns_client = PrivateDNSClient().get_dns_client(self.subscription_id, self.cloud)
        self.resource_client = ResourceMgmtClient().get_resource_client(self.cloud, self.subscription_id)
        self.location = data.get("location") or self._get_location()

    def _get_location(self):
        rg = self.resource_client.resource_groups.get(self.resource_group_name)
        return rg.location

    def _update_public_network_access(self):
        """Update publicNetworkAccess on the target resource."""
        try:
            parsed = parse_resource_id(self.target_resource_id)
            provider = parsed["namespace"]
            resource_type = parsed["type"]
            logging.info(f"Updating publicNetworkAccess to '{self.public_network_access}' on {self.target_resource_id}")
            
            api_version = self._get_api_version(provider, resource_type)
            
            resource = self.resource_client.resources.get_by_id(
                self.target_resource_id,
                api_version=api_version
            )

            if "publicNetworkAccess" not in (resource.properties or {}):
                logging.warning(f"Resource '{self.target_resource_id}' does not support publicNetworkAccess. Skipping.")
                return

            resource.properties["publicNetworkAccess"] = self.public_network_access
            
            self.resource_client.resources.begin_create_or_update_by_id(
                self.target_resource_id,
                api_version=api_version,
                parameters=resource
            ).result()
            
            logging.info(f"publicNetworkAccess updated to '{self.public_network_access}' successfully")
            
        except Exception as e:
            logging.error(f"Error updating publicNetworkAccess: {str(e)}")
            raise e

    def _get_api_version(self, resource_provider, resource_type):
        """Get the latest API version for a given resource provider and type."""
        provider = self.resource_client.providers.get(resource_provider)
        resource_types = next(
            (rt for rt in provider.resource_types if rt.resource_type.lower() == resource_type.lower()),
            None
        )
        if resource_types and resource_types.api_versions:
            return resource_types.api_versions[0]
        raise ValueError(f"Could not find API version for {resource_provider}/{resource_type}")

    def _parse_subnet_id(self, subnet_id):
        parts = subnet_id.split('/')
        return {
            "subscription_id": parts[2],
            "resource_group": parts[4],
            "vnet_name": parts[8],
            "subnet_name": parts[10]
        }

    def _get_subnet(self):
        return {"id": self.subnet_id}

    def _get_private_dns_zone_name(self):
        dns_zones = self.PRIVATE_DNS_ZONES_CHINA if self.zone == "china" else self.PRIVATE_DNS_ZONES
        return dns_zones.get(self.group_id)

    def _get_dns_zone(self):
        if self.dns_zone_id:
            return self.dns_zone_id
        
        dns_zone_name = self._get_private_dns_zone_name()
        
        if not dns_zone_name:
            logging.warning(f"No DNS zone mapping found for group_id: {self.group_id}")
            return None
        
        try:
            dns_client, dns_rg = DnsZoneHelper.get_dns_client_for_zone(self.subscription_id, self.zone, self.cloud)
            private_dns_zone = dns_client.private_zones.get(
                resource_group_name=dns_rg,
                private_zone_name=dns_zone_name
            )
            return private_dns_zone.id
        except Exception as e:
            logging.warning(f"Could not find DNS zone {dns_zone_name}: {e}")
            return None

    def create_private_endpoint(self):
        try:
            logging.info(f"Creating Private Endpoint {self.private_endpoint_name} for resource {self.target_resource_id}")
            
            subnet = self._get_subnet()
            
            private_endpoint_params = {
                "location": self.location,
                "subnet": subnet,
                "privateLinkServiceConnections": [{
                    "name": f"{self.private_endpoint_name}-connection",
                    "properties": {
                        "privateLinkServiceId": self.target_resource_id,
                        "groupIds": [self.group_id],
                        "requestMessage": None
                    }
                }],
                "tags": self.tags
            }
            
            if self.network_interface_name:
                private_endpoint_params["customNetworkInterfaceName"] = self.network_interface_name
                logging.info(f"Using custom NIC name: {self.network_interface_name}")
            
            if self.private_ip_address:
                member_name = self.member_name if self.member_name else self.group_id
                private_endpoint_params["ipConfigurations"] = [{
                    "name": f"{self.private_endpoint_name}-ipconfig",
                    "properties": {
                        "privateIPAddress": self.private_ip_address,
                        "groupId": self.group_id,
                        "memberName": member_name
                    }
                }]
                logging.info(f"Using static IP address: {self.private_ip_address}")
            
            private_endpoint = self.network_client.private_endpoints.begin_create_or_update(
                resource_group_name=self.resource_group_name,
                private_endpoint_name=self.private_endpoint_name,
                parameters=private_endpoint_params
            ).result()
            
            logging.info(f"Private Endpoint {self.private_endpoint_name} created successfully")
            
            # Create DNS Zone Group if requested
            if self.create_dns_zone_group:
                dns_zone_id = self._get_dns_zone()
                if dns_zone_id:
                    self._create_dns_zone_group(dns_zone_id)
                else:
                    logging.warning(f"Skipping DNS zone group creation - no DNS zone found for group_id: {self.group_id}")
            
            if self.public_network_access:
                self._update_public_network_access()
            
            return private_endpoint.id
            
        except Exception as e:
            logging.error(f"Error creating Private Endpoint: {str(e)}")
            raise e

    def _create_dns_zone_group(self, dns_zone_id):
        try:
            dns_zone_name = self._get_private_dns_zone_name()
            dns_config_name = f"{self.private_endpoint_name}-dnsconfig"
            
            private_dns_zone_group_params = {
                "privateDnsZoneConfigs": [{
                    "name": dns_config_name,
                    "properties": {
                        "privateDnsZoneId": dns_zone_id
                    }
                }]
            }
            
            private_dns_zone_group = self.network_client.private_dns_zone_groups.begin_create_or_update(
                self.resource_group_name,
                self.private_endpoint_name,
                "default",
                private_dns_zone_group_params
            ).result()
            
            logging.info(f"DNS Zone Group created for Private Endpoint {self.private_endpoint_name}")
            return private_dns_zone_group
            
        except Exception as e:
            logging.error(f"Error creating DNS Zone Group: {str(e)}")
            raise e

    def delete_private_endpoint(self):
        try:
            logging.info(f"Deleting Private Endpoint {self.private_endpoint_name}")
            
            self.network_client.private_endpoints.begin_delete(
                resource_group_name=self.resource_group_name,
                private_endpoint_name=self.private_endpoint_name
            ).result()
            
            logging.info(f"Private Endpoint {self.private_endpoint_name} deleted successfully")
            return True
            
        except Exception as e:
            logging.error(f"Error deleting Private Endpoint: {str(e)}")
            raise e

    def get_private_endpoint(self):
        try:
            private_endpoint = self.network_client.private_endpoints.get(
                resource_group_name=self.resource_group_name,
                private_endpoint_name=self.private_endpoint_name
            )
            return private_endpoint.as_dict()
            
        except Exception as e:
            logging.error(f"Error getting Private Endpoint details: {str(e)}")
            raise e