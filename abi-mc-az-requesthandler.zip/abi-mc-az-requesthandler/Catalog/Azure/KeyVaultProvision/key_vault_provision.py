from shared_code.keyvault_client import KeyVaultClient
from azure.mgmt.keyvault.models import VaultCreateOrUpdateParameters, Sku, SkuName, NetworkRuleSet, VirtualNetworkRule
from shared_code.networkmgmt_client import NetworkMgmtClient
from shared_code.private_endpoint_helper import PrivateEndpointHelper
import json,logging

class KVProvision:
    def __init__(self,json_data):
        data = json.loads(json_data['Payload'])['payload']["data"]
        self.zone = json_data["Zone"].lower()
        self.tags = data["tags"]
        self.subscription_id = data["subscription_id"]
        self.resource_group_name = data["resource_group_name"]
        self.kv_name = data["key_vault_name"]
        self.sku = data["sku"]
        self.location = data["key_vault_location"]
        self.environament = data["environment"]
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.tenant = "c99b23b6-4fa8-4eee-a7cc-2f420106e730" if self.zone == "china" else "cef04b19-7776-4a94-b89b-375c77a8f936"
        self.kv_client = KeyVaultClient().get_kv_client(self.subscription_id,self.cloud)
        self.network_client = NetworkMgmtClient().get_network_mgmt_client(self.subscription_id,self.cloud)

    def create_kv(self):
        try:
            logging.info(f"Creating Key Vault {self.kv_name} in resource group {self.resource_group_name}")

            # Get subnet details based on subscription
            subscription_to_network = {
                # Global Prod
                "2db7c27b-2f9f-4088-981b-2bd88c5c1905": {
                    "vnet_name": "PVT-VNET-GB-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-GB-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # Global Non-Prod
                "73f88e6b-3a35-4612-b550-555157e7059f": {
                    "vnet_name": "PVT-VNET-GB-NON-PROD", 
                    "vnet_rg_name": "mgmtpvt-rg-gb-non-prod",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # NAZ Non-Prod
                "25137c49-ffa8-4cef-a4db-f8aaf059d980": {
                    "vnet_name": "PVT-VNET-NAZ-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-NAZ-NON-PROD", 
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # NAZ Prod
                "95c54dda-ae35-43c0-aeea-bcfc596674c1": {
                    "vnet_name": "PVT-VNET-NAZ-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-NAZ-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # NAZ SAP R3
                "c8642ed5-9766-43fa-b6cc-47f19181fa40": {
                    "vnet_name": "SAP-INFRA-VNET-NAZ-PROD",
                    "vnet_rg_name": "SAP-RG-NAZ-PROD",
                    "subnet_name": "SAP-PR-APP-SUB",
                    "subnet_name1": "SAP-PR-DB-SUB"
                },
                # MAZ Non-Prod
                "fe70970a-8778-4bc4-83c4-a85c57c1efd3": {
                    "vnet_name": "PVT-VNET-MEX-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-MEX-NON-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # MAZ Prod
                "a6362b38-0f74-4c75-bcbb-719b38f04f75": {
                    "vnet_name": "PVT-VNET-MEX-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-MEX-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # EU Non-Prod
                "3617a45e-beab-410a-9476-d6e000e1fb77": {
                    "vnet_name": "PVT-VNET-EU-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-EU-NON-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # EU Prod
                "1c1db8ee-5d54-460b-bd71-fd031be2a7e5": {
                    "vnet_name": "PVT-VNET-EU-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-EU-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # Africa Prod
                "77a7f337-8588-4076-b526-5f1ce0e55671": {
                    "vnet_name": "PVT-VNET-AFR-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-AFR-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # Africa Non-Prod
                "15bcebd1-794e-49c6-9548-8a4a4357ee16": {
                    "vnet_name": "PVT-VNET-AFR-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-AFR-NON-PROD",
                    "subnet_name": "Webapp-1",
                    "subnet_name1": "Infra"
                },
                # China Prod
                "30b7b23e-9325-4407-b613-610457afe869": {
                    "vnet_name": "PVT-E2-VNET-CN-PROD",
                    "vnet_rg_name": "MGMTPVT-E2-RG-CN-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # China Non-Prod
                "08ba6e07-14eb-4984-9176-9261b8a2781d": {
                    "vnet_name": "PVT-E2-VNET-CN-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-E2-RG-CN-NON-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # KR Non-Prod
                "b413c513-77a1-4416-84d4-4057920111c6": {
                    "vnet_name": "PVT-VNET-KR-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-KR-NON-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # KR Prod
                "a831d6f9-cdd3-4d49-9dd5-9389dd3a1902": {
                    "vnet_name": "PVT-VNET-KR-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-KR-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                }
            }

            # Validate subscription exists in network config
            if self.subscription_id not in subscription_to_network:
                raise ValueError(f"Subscription ID {self.subscription_id} not found in network configuration")

            network_config = subscription_to_network[self.subscription_id]
            
            try:
                # Get subnets
                webapp_subnet = self.network_client.subnets.get(
                    resource_group_name=network_config["vnet_rg_name"],
                    virtual_network_name=network_config["vnet_name"],
                    subnet_name=network_config["subnet_name"]
                )

                infra_subnet = self.network_client.subnets.get(
                    resource_group_name=network_config["vnet_rg_name"], 
                    virtual_network_name=network_config["vnet_name"],
                    subnet_name=network_config["subnet_name1"]
                )
            except Exception as e:
                raise ValueError(f"Error getting subnet details: {str(e)}")

            self.subnet_ids = [webapp_subnet.id, infra_subnet.id]

            network_rule_set = NetworkRuleSet(
                default_action="Deny",
                bypass="AzureServices",
                virtual_network_rules=[
                    VirtualNetworkRule(id=subnet_id) for subnet_id in self.subnet_ids
                ]
            )
            kv_params = VaultCreateOrUpdateParameters(
                location=self.location,
                properties={
                    "tenant_id": self.tenant,
                    "sku": Sku(name=SkuName.PREMIUM if self.sku.lower() == "premium" else SkuName.STANDARD),
                    "enabled_for_disk_encryption": True,
                    "enabled_for_deployment": True,
                    "enabled_for_template_deployment": True,
                    "enable_purge_protection": True,
                    "vault_uri": f"https://{self.kv_name}.vault.azure.net/"  if self.zone != 'china' else f"https://{self.kv_name}.vault.azure.cn/",
                    "network_acls": network_rule_set,
                    "enable_rbac_authorization": True,
                    "access_policies": []
                },
                tags=self.tags
            )

            kv_result = self.kv_client.vaults.begin_create_or_update(
                resource_group_name=self.resource_group_name,
                vault_name=self.kv_name,
                parameters=kv_params
            ).result()
            logging.info(f"Key Vault {self.kv_name} created successfully")

            # Create private endpoint
            pe_helper = PrivateEndpointHelper(self.subscription_id, self.zone, self.cloud)
            subnet_id = pe_helper.get_subnet_id(
                vnet_rg_name=network_config["vnet_rg_name"],
                vnet_name=network_config["vnet_name"],
                subnet_name=network_config["subnet_name"]
            )
            dns_zone_name = "privatelink.vaultcore.azure.cn" if self.zone == "china" else "privatelink.vaultcore.azure.net"
            pe_helper.create_private_endpoint(
                resource_group_name=self.resource_group_name,
                resource_id=kv_result.id,
                resource_name=self.kv_name,
                location=self.location,
                subnet_id=subnet_id,
                group_ids=["vault"],
                dns_zone_name=dns_zone_name,
                private_endpoint_name=f"{self.kv_name}-pe-vault",
                tags=self.tags
            )

            return kv_result.id
        except Exception as e:
            logging.error(f"Error creating Key Vault: {e}")
            raise