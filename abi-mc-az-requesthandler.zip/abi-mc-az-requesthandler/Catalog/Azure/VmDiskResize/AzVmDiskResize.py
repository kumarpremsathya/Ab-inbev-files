import logging
import re
import time
from datetime import datetime, timezone
from azure.mgmt.compute.models import RunCommandInput
from shared_code.compute_client import ComputeClient
from shared_code.lock_manager import LockManager
from Catalog.Azure.InstanceStatus.instance_status import AzVmStatus


class AzVmDiskResize:
    def __init__(
        self,
        subscription_id,
        zone,
        resource_group_name,
        resource_name,
        disk_name,
        resource_id,
        
    ):
        self.subscription_id = subscription_id
        self.zone = zone.lower()
        self.resource_group_name = resource_group_name
        self.resource_name = resource_name
        self.disk_name = disk_name
        self.resource_id = resource_id
        self.azenvironment = (
            "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        )

        self.compute_client = ComputeClient().get_compute_client(
            self.subscription_id, self.azenvironment
        )
        data = {
            "Zone": self.zone,
            "SubscriptionId": self.subscription_id,
            "ResourceGroupName": self.resource_group_name,
            "ResourceName": self.resource_name,
            "ResourceId": self.resource_id,
        }
        self.vm_status_manager = AzVmStatus(data)

        self.lock_manager = LockManager(
            self.subscription_id,
            self.zone,
            self.resource_group_name,
            self.resource_name,
            self.resource_id,
        )

    def construct_disk_resource_id(self, disk_name):
        return f"/subscriptions/{self.subscription_id}/resourceGroups/{self.resource_group_name}/providers/Microsoft.Compute/disks/{disk_name}"

    def get_disk_details(self, disk_id):
        try:
            disk_details = self.compute_client.disks.get(
                self.resource_group_name, disk_id.split("/")[-1]
            )
            return disk_details
        except Exception as e:
            logging.error(f"Error fetching disk details for {disk_id}: {e}")
            raise

    def check_disk_type(self, disk_details):
        if disk_details.os_type:
            return "OS Disk"
        else:
            return "Data Disk"

    def get_snapshot_name(self):
        current_date = datetime.now(timezone.utc).strftime("%Y%m%d")
        suffix = f"-snapshot-{current_date}-BeforeResize"
        max_disk_name_len = 80 - len(suffix)
        truncated_disk_name = self.disk_name[:max_disk_name_len]
        return f"{truncated_disk_name}{suffix}"

    def create_disk_snapshot(self):
        try:
            disk = self.compute_client.disks.get(
                self.resource_group_name, self.disk_name
            )
            snapshot_name = self.get_snapshot_name()

            snapshot_params = {
                "location": disk.location,
                "creation_data": {
                    "create_option": "Copy",
                    "source_resource_id": disk.id,
                },
            }

            async_snapshot_creation = (
                self.compute_client.snapshots.begin_create_or_update(
                    self.resource_group_name, snapshot_name, snapshot_params
                )
            )
            async_snapshot_creation.result()

            logging.info(f"Created disk snapshot: {snapshot_name}")
            return True
        except Exception as e:
            logging.error(f"Error creating disk snapshot: {e}")
            raise

    def extract_size(self, new_size_gb):
        match = re.search(r"-(\d+)-GiB", new_size_gb)
        if match:
            return int(match.group(1))  # Extract and convert to integer
        else:
            raise ValueError(f"Invalid size format: {new_size_gb}")

    def resize_disk(self, new_size_gb):
        try:
            disk = self.compute_client.disks.get(
                self.resource_group_name, self.disk_name
            )
            new_size_gb = self.extract_size(new_size_gb)
            if disk.disk_size_gb >= new_size_gb:
                raise ValueError("New disk size must be greater than the current size.")

            disk.disk_size_gb = new_size_gb
            async_disk_update = self.compute_client.disks.begin_create_or_update(
                self.resource_group_name, self.disk_name, disk
            )
            async_disk_update.result()
            logging.info(
                f"Disk '{self.disk_name}' resized successfully to {new_size_gb}GB."
            )
        except Exception as e:
            logging.error(f"Error resizing disk: {e}")
            raise

    def get_vm_os_type(self):
        try:
            vm = self.compute_client.virtual_machines.get(
                self.resource_group_name, self.resource_name, expand="instanceView"
            )
            os_type = vm.storage_profile.os_disk.os_type
            logging.info(f"VM '{self.resource_name}' OS type: {os_type}")
            return str(os_type).lower()
        except Exception as e:
            logging.error(f"Error getting VM OS type: {e}")
            return None

    def extend_windows_partition(self, disk_number=None):
        try:
            script = [
                "$disks = Get-Disk | Where-Object { $_.PartitionStyle -ne 'RAW' }",
                "foreach ($disk in $disks) {",
                "  $partitions = Get-Partition -DiskNumber $disk.Number | Where-Object { $_.Type -ne 'Reserved' -and $_.Type -ne 'System' -and $_.DriveLetter }",
                "  foreach ($partition in $partitions) {",
                "    $maxSize = (Get-PartitionSupportedSize -DiskNumber $disk.Number -PartitionNumber $partition.PartitionNumber).SizeMax",
                "    if ($partition.Size -lt $maxSize) {",
                "      Write-Output \"Extending partition $($partition.DriveLetter): on Disk $($disk.Number) from $([math]::Round($partition.Size/1GB,2))GB to $([math]::Round($maxSize/1GB,2))GB\"",
                "      Resize-Partition -DiskNumber $disk.Number -PartitionNumber $partition.PartitionNumber -Size $maxSize",
                "    }",
                "  }",
                "}",
            ]

            command = RunCommandInput(command_id="RunPowerShellScript", script=script)
            poller = self.compute_client.virtual_machines.begin_run_command(
                resource_group_name=self.resource_group_name,
                vm_name=self.resource_name,
                parameters=command,
            )
            result = poller.result()

            if result and hasattr(result, "value"):
                for output in result.value:
                    if output.message:
                        logging.info(f"Partition extend output: {output.message}")

            logging.info(f"Windows partition extend completed for VM '{self.resource_name}'.")
            return True
        except Exception as e:
            logging.warning(f"Failed to extend Windows partition (non-blocking): {e}")
            return False

    async def resize_with_snapshot(self, new_size_gb):
        try:
            logging.info("Starting disk resize operation with snapshot creation...")
            removed_locks = self.lock_manager.remove_all_locks()
            if removed_locks:
                logging.info(f"Removed locks: {removed_locks}")

            try:
                # Use the actual disk name passed to the class
                disk_id = self.construct_disk_resource_id(self.disk_name)
                disk_details = self.get_disk_details(disk_id)

                # Check if it's an OS disk or data disk
                if self.check_disk_type(disk_details) == "OS Disk":
                    logging.info(
                        "OS Disk identified. Stopping VM before OS disk resize..."
                    )
                    await self.vm_status_manager.vm_start_stop_restart("stop")

                    if self.create_disk_snapshot():
                        logging.info(
                            f"Snapshot created. Proceeding with resize to {new_size_gb}GB."
                        )
                        self.resize_disk(new_size_gb)

                        logging.info("Resizing completed. Starting VM...")
                        await self.vm_status_manager.vm_start_stop_restart("start")

                        if self.get_vm_os_type() == "windows":
                            logging.info("Windows OS detected. Extending partition inside VM...")
                            self.extend_windows_partition()
                    else:
                        logging.error(
                            "Snapshot creation failed. Resize operation skipped."
                        )

                else:
                    logging.info(
                        "Data Disk identified. Proceeding with data disk resize..."
                    )
                    if self.create_disk_snapshot():
                        logging.info(
                            f"Snapshot created. Proceeding with resize to {new_size_gb}GB."
                        )
                        self.resize_disk(new_size_gb)
                        logging.info("Resizing completed successfully!")

                        if self.get_vm_os_type() == "windows":
                            logging.info("Windows OS detected. Extending data disk partition inside VM...")
                            self.extend_windows_partition()
                    else:
                        logging.error(
                            "Snapshot creation failed. Data disk resize operation skipped."
                        )

                return True

            finally:
                self.lock_manager.restore_locks()

        except Exception as e:
            logging.error(f"Error during disk resize operation: {e}")
            raise
