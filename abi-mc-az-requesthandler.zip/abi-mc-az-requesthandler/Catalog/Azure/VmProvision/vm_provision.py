from shared_code.networkmgmt_client import NetworkMgmtClient
from shared_code.compute_client import ComputeClient
from azure.mgmt.compute.models import (HardwareProfile, NetworkProfile, OSProfile,
                                    StorageProfile, VirtualMachine,
                                    OSDisk, DiskCreateOption, VirtualHardDisk, ManagedDiskParameters, NetworkInterfaceReference, AvailabilitySet, SubResource)
from shared_code.recoveryservices_client import RecoveryServicesBkpClient
from Catalog.Azure.VmDomainJoin.vm_domain_join import AzVMDomainJoin
from Catalog.Azure.PuppetInstall.puppet_install import PuppetInstall
from shared_code.akv_secrets import AkvSecrets
from DAL.DbActivityManager import DbActivityManager
from shared_code.EmailNotification.NotifySAM import NotifySAM
from shared_code.sqlvm_client import SqlVMClient
from azure.mgmt.sqlvirtualmachine.models import SqlVirtualMachine
import re,logging,json,os,time 


class AzVMProvision:
    def __init__(self, json_data):
        data = json.loads(json_data['Payload'])['payload']["data"]
        self.json_data = json_data
        self.zone = json_data["Zone"].lower()
        #tags
        self.tags = data["tags"]
        self.tags.update({"EnablePrivateNetworkGC":"TRUE"})
        #Resource Detail
        self.subscription_id = data["subscription_id"]
        self.resource_group_name = data["resource_group_name"]
        #data disk details
        self.disk_quantity = data["disk_quantity"]
        self.data_disks = data["disk"]
        self.disk_type = data["disk_type"]
        #Network Details
        self.subnet_id = data["subnet_id"]
        #VM Details
        self.image = data["vm_image"].split("|")
        self.hostname = data["vm_hostname"]
        self.hostname_suffix = data.get("hostname_suffix",None)
        self.location = data["vm_location"]
        self.vm_size = data["vm_size"]
        self.os_type = data["vm_os"].lower()
        self.admin_username = "AbiCloudAdmin"
        self.availability_set = data["availability_set"]
        self.availability_zone = data.get("availability_zone",'1')
        self.availability_set_id = json_data.get("AvailablitySetId",None)
        #backup details
        self.recovery_services_vault_id = data["recovery_service_vault_id"]
        self.vault_name = data["recovery_service_vault_name"]
        self.policy_name = data["recovery_vault_backup_policy"]
        #sam details
        self.licensed_software = data['licensed_software']
        self.software_publisher = data['software_publisher']
        self.db_on_vm = data['db_on_vm']
        self.db_to_installed = data['db_to_installed']
        self.software_ritm = data['software_ritm']
        self.software_ritm_number = data['software_ritm_number']
        self.software_evidence = data['software_evidence']
        #extensions
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.compute_client = ComputeClient().get_compute_client(self.subscription_id, self.cloud)
        self.network_client = NetworkMgmtClient().get_network_mgmt_client(self.subscription_id, self.cloud)
        self.backup_client = RecoveryServicesBkpClient().get_recoveryservice_backup_client(self.cloud,self.subscription_id)
    
    def domain_details(self, zone):
        switch = {
            "africa" : "beerdivision.africa.gcn.local",
            "brewdat" : "one.ofc.loc",
            "china" : "ap1.ofc.loc",
            "eu" : "we.interbrew.net",
            "ghq" : "one.ofc.loc",
            "kr" : "ob.co.kr",
            "maz" : "modelo.gmodelo.com.mx",
            "naz" : "one.ofc.loc"
        }
        return switch.get(zone, "Invalid choice")

    def get_admin_password(self):
        creds = AkvSecrets(os.environ["KEYVAULT_URI"],'vm-admin-password').get_tokens()
        password = json.loads(creds.value).get('value')
        return password
    
    def get_highest_vm_number(self, hostname):
        numbers = [
            int(match.group(1))
            for vm in self.compute_client.virtual_machines.list_all()
            if (match := re.match(rf"{hostname}(\d+)", vm.name))
        ]
        return max(numbers, default=0)
    
    def create_nic(self, nic_name):
        nic = self.network_client.network_interfaces.begin_create_or_update(
            self.resource_group_name,
            nic_name,
            {
                "location": self.location,
                "ip_configurations": [{
                    "name": nic_name + "-ip-config",
                    "subnet": {"id": self.subnet_id},
                    "enable_accelerated_networking": True
                }]
            }
        ) 
        nic.wait()
        return nic.result().id
    
    def create_or_get_availability_set(self):
        if self.availability_set_id:
            return self.availability_set_id
        
        if self.availability_set:
            for set in self.compute_client.availability_sets.list_by_subscription():
                if set.name.lower() == self.availability_set.lower():
                    return set.id
            set = self.compute_client.availability_sets.create_or_update(
                self.resource_group_name,
                self.availability_set,
                {
                    'location': self.location,
                    'sku': {'name': 'Aligned'},
                    "properties": {"platformFaultDomainCount": 3, "platformUpdateDomainCount": 5},
                }
            )
            return set.id
        return None
    
    def vm_preprovision(self):
        if not self.hostname_suffix:
            vm_name = self.hostname + str(self.get_highest_vm_number(self.hostname) + int(self.json_data['VMNumber']) +1)
        elif self.hostname_suffix.isdigit():
            vm_name = f"{self.hostname}{int(self.hostname_suffix)+int(self.json_data['VMNumber']):0{len(self.hostname_suffix)}d}"
        elif self.hostname_suffix.isalpha():
            vm_name = f"{self.hostname}{chr(ord(self.hostname_suffix[-1])+int(self.json_data['VMNumber']))}"
        self.nic_name = vm_name + "-nic"
        self.json_data["VMName"] = vm_name
        self.json_data["NIC"] = self.create_nic(self.nic_name)
        self.json_data["AvailablitySetId"] = self.create_or_get_availability_set()
        return self.json_data
    
    def create_vm(self, vm_name, nic_id):
        network_profile = NetworkProfile(
            network_interfaces=[
                NetworkInterfaceReference(id=nic_id, primary=True)
            ]
        )

        # Create hardware profile
        hardware_profile = HardwareProfile(vm_size=self.vm_size)

        # Create OS profile
        os_profile = OSProfile(
            computer_name=vm_name,
            admin_username=self.admin_username,
            admin_password=self.get_admin_password(),
        )

        # Create OS disk configuration
        os_disk = OSDisk(
            caching='ReadWrite',
            create_option=DiskCreateOption.FROM_IMAGE,
            managed_disk=ManagedDiskParameters(
                storage_account_type=self.disk_type,
            ),
            disk_size_gb=128,
            name=vm_name + '_osdisk',
            os_type=self.os_type,            
        )

        # Create data disks array
        data_disks = []
        if self.data_disks:
            for i, disk in enumerate(self.data_disks.split(',')):
                data_disks.append({
                    'lun': i,
                    'disk_size_gb': int(disk),
                    'managed_disk': ManagedDiskParameters(
                        storage_account_type=self.disk_type
                    ),
                    'create_option': DiskCreateOption.EMPTY
                })

        # Create storage profile
        storage_profile = StorageProfile(
            os_disk=os_disk,
            image_reference={
                "publisher": self.image[0],
                "offer": self.image[1],
                "sku": self.image[2],
                "version": self.image[3]
            },
            data_disks=[
                {
                    'lun': disk['lun'],
                    'disk_size_gb': disk['disk_size_gb'],
                    'managed_disk': disk['managed_disk'],
                    'create_option': disk['create_option']
                }
                for disk in data_disks
            ]
        )

        # Create diagnostics profile
        diagnostics_profile = {
            'boot_diagnostics': {
                'enabled': True
            }
        }
        if self.json_data["AvailablitySetId"]:
            availability_set = SubResource(id=self.json_data["AvailablitySetId"])
        else:
            availability_set = None
        if self.availability_zone:
            availability_zone = [self.availability_zone]
        else:
            availability_zone = None
        # Create VM parameters
        vm_parameters = VirtualMachine(
            location=self.location,
            tags=self.tags,
            os_profile=os_profile,
            hardware_profile=hardware_profile,
            network_profile=network_profile,
            storage_profile=storage_profile,
            diagnostics_profile=diagnostics_profile,
            zones=availability_zone,   
            availability_set=availability_set  
        )

        try:
            # Create the VM
            vm = self.compute_client.virtual_machines.begin_create_or_update(
                self.resource_group_name, 
                vm_name, 
                vm_parameters
            )
            vm.wait()
            self.json_data["VMID"] = vm.result().id
            time.sleep(120)
            return self.json_data
            
        except Exception as e:
            logging.error(f"Failed to create VM: {str(e)}")
            raise Exception(f"Failed to create VM: {str(e)}")
    
    def enable_backup(self,vm_name):
        try:
            vault_resource_group = self.recovery_services_vault_id.split("/")[4]
            vault_name = self.recovery_services_vault_id.split("/")[8]
            policy = self.backup_client.protection_policies.get(
                vault_name,
                vault_resource_group,
                self.policy_name
            )

            container_name = f"iaasvmcontainer;iaasvmcontainerv2;{self.resource_group_name};{vm_name}"
            item_name = f"vm;iaasvmcontainerv2;{self.resource_group_name};{vm_name}"

            protected_item = {
                "properties": {
                    "protectedItemType": "Microsoft.Compute/virtualMachines",
                    "sourceResourceId": self.json_data["VMID"],
                    "policyId": policy.id
                }
            }

            item = self.backup_client.protected_items.create_or_update(
                vault_name,
                vault_resource_group,
                "Azure",
                container_name,
                item_name,
                protected_item
            )
            logging.info(f"Enabled Backup for the VM {vm_name} - {item}")
            return item

        except Exception as e:
            logging.error(f"Failed to enable backup: {str(e)}")
            raise Exception(f"Failed to enable backup: {str(e)}")
    
    def bginfo_extension(self,vm_name):
        try:
            if self.os_type == "linux":
                return
            bginfo_extension = {
                'location': self.location,
                'properties': {
                    'publisher': 'Microsoft.Compute',
                    'type': 'BGInfo',
                    'typeHandlerVersion': '2.1',
                    'autoUpgradeMinorVersion': True,
                }
            }

            poller = self.compute_client.virtual_machine_extensions.begin_create_or_update(
                self.resource_group_name,
                vm_name,
                'BGInfo',
                bginfo_extension
            )
            
            extension_result = poller.result()
            logging.info(f"Enabled BGinfo for the VM {vm_name} - {extension_result}")
            return extension_result.id
        except Exception as e:
            logging.error(f"Failed to enable BGInfo extension: {str(e)}")
            raise Exception(f"Failed to enable BGInfo extension: {str(e)}")
    
    def domain_join_extension(self,vm_name):
        if "sql" in self.image[0]:
            os_version = self.image[1].split('-')[0]
        else:
            os_version = self.image[2].split('-')[0]   
        if os_version.startswith("sql"):
            os_version = os_version.replace("sql","")
        if self.os_type == "windows" and os_version in ["2019","2022","2025"]:
            return AzVMDomainJoin(self.json_data).windows_extension(os_version,vm_name)
        return True
    
    def register_sql_vm(self,vm_name):
        if "microsoftsqlserver" in self.image[0].lower():
            sqlvm_client = SqlVMClient().get_sqlvm_client(self.subscription_id,self.cloud)
            sqlvm_client.sql_virtual_machines.create_or_update(
                resource_group_name=self.resource_group_name,
                sql_virtual_machine_name=vm_name,
                parameters=SqlVirtualMachine(
                location=self.location,
                virtual_machine_resource_id=self.json_data["VMID"]
                )
            )
            return True
        return False
    
    def puppet_extension(self,vm_name):
        if self.os_type == "linux":
            return PuppetInstall(self.json_data).linux_extension(vm_name)
        else:
            return PuppetInstall(self.json_data).windows_extension(vm_name)

    async def notify_sam(self,eventid):
        sam_qa = {}
        dalobj = DbActivityManager()
        event = dalobj.get_event_info(eventid)
        sam_qa['SnowItemId'] = event[0].SnowItemId
        sam_qa['SnowId'] = event[0].SnowId
        sam_qa['VMName'] = self.json_data["VMName"]
        requested_by = event[0].RequestedBy
        temp = []
        temp.append({
            "name": "Is there a Licensed Software to be deployed in VM ?",
            "value": self.licensed_software
        })
        if self.licensed_software.lower() == "yes":
            if self.software_publisher:
                temp.append({
                    "name": "Software Publisher",
                    "value": self.software_publisher
                })
            if self.db_on_vm.lower() == "yes":
                temp.append({
                    "name": "Is there a DB to be installed on VM ?",
                    "value": self.db_on_vm
                })
                if self.db_to_installed:
                    temp.append({
                        "name": "DB to be installed",
                        "value": self.db_to_installed
                    })
            if self.software_ritm.lower() == "yes":
                temp.append({
                    "name": "Is there a Software Provisioning Service Now RITM in place ?",
                    "value": self.software_ritm
                })
                if self.software_ritm_number:
                    temp.append({
                        "name": "RITM in SNOW",
                        "value": self.software_ritm_number
                    })
            if self.software_evidence:
                temp.append({
                    "name": "Software Evidence",
                    "value": self.software_evidence
                })
        sam_qa['sam'] = temp
        await NotifySAM().send_email_notification(self.zone,sam_qa,requested_by)
        return True