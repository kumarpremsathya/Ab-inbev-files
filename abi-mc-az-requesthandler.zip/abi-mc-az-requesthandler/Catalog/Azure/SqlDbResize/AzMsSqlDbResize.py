import logging
from datetime import datetime, timezone
from shared_code.lock_manager import LockManager
from shared_code.sqlmgmt_client import SqlMgmtClient


class AzMsSqlDbResize:
    def __init__(
        self,
        subscription_id,
        zone,
        resource_group_name,
        db_server_name,
        db_name,
        target_sku_size,
        db_id,
    ):
        self.subscription_id = subscription_id
        self.zone = zone.lower()
        self.resource_group_name = resource_group_name
        self.db_server_name = db_server_name
        self.db_name = db_name
        self.target_sku_size = target_sku_size
        self.db_id = db_id
        self.azenvironment = (
            "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        )

        self.sql_mgmt_client = SqlMgmtClient().get_sql_mgmt_client(
            self.subscription_id, self.azenvironment
        )

        self.lock_manager = LockManager(
            subscription_id=self.subscription_id,
            zone=self.zone,
            resource_group_name=self.resource_group_name,
            resource_name=self.db_server_name,
            resource_id=self.db_id,
        )

    def parse_sku_details(self, target_sku_size):
        """
        Expected formats:
        - 'name-tier-family-capacity-unit'
        - 'name-tier-capacity-unit'
        """
        sku_parts = target_sku_size.split("-")

        # Extract numeric value from capacity (e.g., "2-VCores" -> 2)
        def extract_numeric_value(value):
            numeric_value = "".join(filter(str.isdigit, value))
            return int(numeric_value) if numeric_value else None

        if len(sku_parts) == 5:  # Format: 'name-tier-family-capacity-unit'
            return {
                "name": sku_parts[0],
                "tier": sku_parts[1],
                "family": sku_parts[2],
                "capacity": extract_numeric_value(sku_parts[3]),
            }
        elif len(sku_parts) == 4:  # Format: 'name-tier-capacity-unit'
            return {
                "name": sku_parts[0],
                "tier": sku_parts[1],
                "capacity": extract_numeric_value(sku_parts[2]),
            }
        else:
            raise ValueError(f"Invalid sku format: {target_sku_size}")

    def resize_database(self):
        try:

            server_id = f"/subscriptions/{self.subscription_id}/resourceGroups/{self.resource_group_name}/providers/Microsoft.Sql/servers/{self.db_server_name}"

            logging.info(f"Removing locks for SQL Server: {server_id}")
            self.lock_manager.remove_all_locks(scope=server_id)

            logging.info(f"Removing locks for Database: {self.db_id}")
            self.lock_manager.remove_all_locks(scope=self.db_id)

            logging.info("Locks removed successfully")

            sku_details = self.parse_sku_details(self.target_sku_size)

            database = self.sql_mgmt_client.databases.get(
                resource_group_name=self.resource_group_name,
                server_name=self.db_server_name,
                database_name=self.db_name,
            )

            database.sku.name = sku_details.get("name")
            database.sku.tier = sku_details.get("tier")

            if "family" in sku_details:
                database.sku.family = sku_details.get("family")

            database.sku.capacity = sku_details.get("capacity")

            update_result = self.sql_mgmt_client.databases.begin_update(
                resource_group_name=self.resource_group_name,
                server_name=self.db_server_name,
                database_name=self.db_name,
                parameters=database,
            )

            result = update_result.result()
            logging.info(f"Database resize completed: {result.name}")

            self.lock_manager.restore_locks()
            logging.info("Locks restored successfully")

            return True, "Database resized successfully"

        except Exception as e:
            logging.error(f"Database resize failed: {e}")
            # Attempt to restore locks even if resize fails
            try:
                self.lock_manager.restore_locks()
            except Exception as restore_error:
                logging.error(f"Failed to restore locks: {restore_error}")

            return False, str(e)
