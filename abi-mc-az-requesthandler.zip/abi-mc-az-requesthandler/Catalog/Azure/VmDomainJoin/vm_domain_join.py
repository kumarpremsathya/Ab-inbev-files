import logging,json,os
from azure.mgmt.compute.models import VirtualMachineExtension
from shared_code.compute_client import ComputeClient
from shared_code.akv_secrets import AkvSecrets

class AzVMDomainJoin:
    def __init__(self,json_data):
        data = json.loads(json_data['Payload'])['payload']["data"]
        self.subscription_id = data["subscription_id"]
        self.resource_group_name = data["resource_group_name"]
        self.zone = json_data["Zone"].lower()
        self.location = data["vm_location"]
        self.str_users = data["member_ids"]
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.compute_client = ComputeClient().get_compute_client(self.subscription_id, self.cloud)
        self.secret = AkvSecrets(os.environ["KEYVAULT_URI"],'domain-join').get_tokens()

    def get_domain_join_details(self):
        switch = {
            "naz": [
            {
                "domain": "one.ofc.loc",
                "os_version": "2019",
                "domain_username": "ONE\srvAzureNAZComputerM",
                "ou_path": "OU=Windows 2019,OU=Azure,OU=Servers,OU=Zone-North America,DC=one,DC=ofc,DC=loc"
            },
            {
                "domain": "one.ofc.loc",
                "os_version": "2022",
                "domain_username": "ONE\srvAzureNAZComputerM",
                "ou_path": "OU=Windows 2022,OU=Azure,OU=Servers,OU=Zone-North America,DC=one,DC=ofc,DC=loc"
            },
            {
                "domain": "one.ofc.loc",
                "os_version": "2025",
                "domain_username": "ONE\srvAzureNAZComputerM",
                "ou_path": "OU=Windows 2025,OU=Azure,OU=Servers,OU=Zone-North America,DC=one,DC=ofc,DC=loc"
            }
            ],
            "ghq": [
            {
                "domain": "one.ofc.loc",
                "os_version": "2019",
                "domain_username": "ONE\SRVGlobalJoin1",
                "ou_path": "OU=Azure,OU=Windows 2019,OU=Servers,OU= Zone-ABI Global,DC=one,DC=ofc,DC=loc"
            },
            {
                "domain": "one.ofc.loc",
                "os_version": "2022",
                "domain_username": "ONE\SRVGlobalJoin1",
                "ou_path": "OU=Azure,OU=Windows 2022,OU=Servers,OU= Zone-ABI Global,DC=one,DC=ofc,DC=loc"
            },
            {
                "domain": "one.ofc.loc",
                "os_version": "2025",
                "domain_username": "ONE\SRVGlobalJoin1",
                "ou_path": "OU=Azure,OU=Windows 2025,OU=Servers,OU= Zone-ABI Global,DC=one,DC=ofc,DC=loc"
            }
            ],
            "brewdat": [
            {
                "domain": "one.ofc.loc",
                "os_version": "2019",
                "domain_username": "ONE\SRVGlobalJoin1",
                "ou_path": "OU=BrewDat,OU=Azure,OU=Windows 2019,OU=Servers,OU= Zone-ABI Global,DC=one,DC=ofc,DC=loc"
            },
            {
                "domain": "one.ofc.loc",
                "os_version": "2022",
                "domain_username": "ONE\SRVGlobalJoin1",
                "ou_path": "OU=BrewDat,OU=Azure,OU=Windows 2022,OU=Servers,OU= Zone-ABI Global,DC=one,DC=ofc,DC=loc"
            },
            {
                "domain": "one.ofc.loc",
                "os_version": "2025",
                "domain_username": "ONE\SRVGlobalJoin1",
                "ou_path": "OU=BrewDat,OU=Azure,OU=Windows 2025,OU=Servers,OU= Zone-ABI Global,DC=one,DC=ofc,DC=loc"
            }
            ],
            "africa": [
            {
                "domain": "beerdivision.africa.gcn.local",
                "os_version": "ALL",
                "domain_username": "BEERSA\SVC_AZBEERSA_AUTO",
                "ou_path": "OU=Azure,OU=Servers,OU=Data Centre,DC=beerdivision,DC=africa,DC=gcn,DC=local"
            }
            ],
            "china": [
            {
                "domain": "AP1.OFC.LOC",
                "os_version": "ALL",
                "domain_username": "AP1.OFC.LOC\srvLZOps",
                "ou_path": "OU=Azure,OU=Servers,OU=APAC Resources,DC=AP1,DC=OFC,DC=LOC"
            }
            ],
            "korea": [
            {
                "domain": "ob.co.kr",
                "os_version": "ALL",
                "domain_username": "ob.co.kr\GCCOPSdesk",
                "ou_path": "OU=AzureVM,OU=Servers,OU=OB,DC=ob,DC=co,DC=kr"
            }
            ],
            "europe": [
            {
                "domain": "we.interbrew.net",
                "os_version": "2019",
                "domain_username": "WEINTERBREW\\azure.svc.we",
                "ou_path": "OU=Application Servers,OU=Windows 2019,OU=Servers,OU=ABI-IBS-EU-AZURE-LZ,DC=we,DC=interbrew,DC=net"
            },
            {
                "domain": "we.interbrew.net",
                "os_version": "2022",
                "domain_username": "WEINTERBREW\\azure.svc.we",
                "ou_path": "OU=Application Servers,OU=Windows 2022,OU=Servers,OU=ABI-IBS-EU-AZURE-LZ,DC=we,DC=interbrew,DC=net"
            },
            {
                "domain": "we.interbrew.net",
                "os_version": "2025",
                "domain_username": "WEINTERBREW\\azure.svc.we",
                "ou_path": "OU=Application Servers,OU=Windows 2025,OU=Servers,OU=ABI-IBS-EU-AZURE-LZ,DC=we,DC=interbrew,DC=net"
            }
            ],
            "maz": [
            {
                "domain": "modelo.gmodelo.com.mx",
                "os_version": "2019",
                "domain_username": "MODELO\hwin1195s",
                "ou_path": "OU=Servidores 2019,OU=Diblo,OU=Servidores,OU=Corporativo,DC=modelo,DC=gmodelo,DC=com,DC=mx"
            },
            {
                "domain": "modelo.gmodelo.com.mx",
                "os_version": "2022",
                "domain_username": "MODELO\hwin1195s",
                "ou_path": "OU=Servidores 2022,OU=Diblo,OU=Servidores,OU=Corporativo,DC=modelo,DC=gmodelo,DC=com,DC=mx"
            },
            {
                "domain": "modelo.gmodelo.com.mx",
                "os_version": "2025",
                "domain_username": "MODELO\hwin1195s",
                "ou_path": "OU=Servidores 2025,OU=Diblo,OU=Servidores,OU=Corporativo,DC=modelo,DC=gmodelo,DC=com,DC=mx"
            }
            ]
        }
        default = [
            {
                "domain": "one.ofc.loc",
                "os_version": "2019",
                "domain_username": "ONE\SRVGlobalJoin1",
                "ou_path": "OU=Azure,OU=Windows 2019,OU=Servers,OU= Zone-ABI Global,DC=one,DC=ofc,DC=loc"
            },
            {
                "domain": "one.ofc.loc", 
                "os_version": "2022",
                "domain_username": "ONE\SRVGlobalJoin1",
                "ou_path": "OU=Azure,OU=Windows 2022,OU=Servers,OU= Zone-ABI Global,DC=one,DC=ofc,DC=loc"
            },
            {
                "domain": "one.ofc.loc",
                "os_version": "2025",
                "domain_username": "ONE\SRVGlobalJoin1",
                "ou_path": "OU=Azure,OU=Windows 2025,OU=Servers,OU= Zone-ABI Global,DC=one,DC=ofc,DC=loc"
            }]
        return switch.get(self.zone, default)
    
    def get_password(self,user):
        password = json.loads(self.secret.value).get(user)
        return password

    def windows_extension(self,os_version, vm_name):
        try: 
            domain_details = self.get_domain_join_details()
            domain = next((domain for domain in domain_details if domain["os_version"] in [os_version,'ALL']), None)
            windows_domain_extension_parameters = VirtualMachineExtension(
                location=self.location,
                publisher='Microsoft.Compute',
                type_properties_type= 'JsonADDomainExtension',
                type_handler_version= '1.3',
                settings= {
                    "Name": domain["domain"],
                    "User": domain["domain_username"].split('\\')[1] + '@' + domain["domain"] if os_version == '2025' else domain["domain_username"],
                    "OUPath": domain["ou_path"],
                    "Restart": "false",
                    "Options": "3",
                    "NumberOfRetries": "2",
                    "UnjoinDomainUser": domain["domain_username"].split('\\')[1] + '@' + domain["domain"] if os_version == '2025' else domain["domain_username"],
                },
                # TODO: Add the password to the protected settings
                protected_settings= {
                    "Password": self.get_password(domain["domain_username"].split('\\')[1]),
                    "UnjoinDomainPassword": self.get_password(domain["domain_username"].split('\\')[1]),
                }
            )
            async_extension_creation_domain = self.compute_client.virtual_machine_extensions.begin_create_or_update(
                self.resource_group_name,
                vm_name,
                vm_name + '_domain',
                windows_domain_extension_parameters
            )
            result = async_extension_creation_domain.result()
            logging.info(f"Domain Extension created for VM: {vm_name} - {result}")
            return result.id
        except Exception as e :
            logging.error(e)
            raise e