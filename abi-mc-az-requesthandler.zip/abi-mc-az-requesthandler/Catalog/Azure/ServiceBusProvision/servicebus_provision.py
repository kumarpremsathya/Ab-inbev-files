from shared_code.storage_client import StorageClient
from shared_code.servicebusmgmt_client import ServicebusClient
from shared_code.networkmgmt_client import NetworkMgmtClient
from shared_code.private_endpoint_helper import PrivateEndpointHelper
from azure.mgmt.servicebus.models import SBNamespace,SBNamespaceProperties
import json,logging

class ServiceBusProvision:
    def __init__(self,json_data):
        data = json.loads(json_data['Payload'])['payload']["data"]
        self.zone = json_data["Zone"].lower()
        self.tags = data["tags"]
        self.subscription_id = data["subscription_id"]
        self.resource_group_name = data["resource_group_name"]
        self.location = data["location"]
        self.servicebus_sku = data["service_bus_sku"]
        self.servicebus_capacity = data.get("capacity")
        self.zone_redundant = data.get("zone_redundant")
        self.service_bus_name = data["servicebus_name"]
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.storage_client = StorageClient().get_storage_client(self.subscription_id,self.cloud)
        self.servicebus_client = ServicebusClient().get_servicebus_client(self.subscription_id,self.cloud)
        self.network_client = NetworkMgmtClient().get_network_mgmt_client(self.subscription_id,self.cloud)

    def create_servicebus(self):
        try:
            # 1. Prepare Service Bus Namespace parameters
            # namespace_params = {
            #     "location": self.location,
            #     "sku": {
            #         "name": self.servicebus_sku,
            #         "tier": self.servicebus_sku,
            #         "capacity": self.servicebus_capacity if self.servicebus_sku.lower() == "premium" else 0
            #     },
            #     "zone_redundant": self.zone_redundant if self.servicebus_sku.lower() == "premium" else None,
            #     "tags": self.tags,
            #     "minimum_tls_version": "1.2",
            #     "public_network_access": "Disabled",
            #     "properties": {
            #         "minimumTlsVersion": "1.2",
            #         "disableLocalAuth": False,
            #         "publicNetworkAccess": "Disabled"
            #     },
            # }
            namespace_params = SBNamespace(
                location=self.location,
                properties=SBNamespaceProperties(
                    minimum_tls_version="1.2",
                    disable_local_auth=False,
                    public_network_access="Disabled",
                    zone_redundant= True if self.servicebus_sku.lower() == "premium" else None
                ),
                sku={
                    "name": self.servicebus_sku,
                    "tier": self.servicebus_sku,
                    "capacity": self.servicebus_capacity if self.servicebus_sku.lower() == "premium" else 0
                },
                tags=self.tags
            )

            # 2. Create or update Service Bus Namespace
            namespace_poller = self.servicebus_client.namespaces.begin_create_or_update(
                self.resource_group_name,
                self.service_bus_name,
                namespace_params
            )
            namespace_result = namespace_poller.result()
            namespace_id = namespace_result.id
            logging.info(f"Service Bus Namespace created: {namespace_id}")

            # 3. If Premium, create Private Endpoint and DNS
            subscription_vnet_map = {
                "2db7c27b-2f9f-4088-981b-2bd88c5c1905": {
                    "vnet_name": "PVT-VNET-GB-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-GB-PROD",
                    "subnet_name": "Webapp"
                },
                "73f88e6b-3a35-4612-b550-555157e7059f": {
                    "vnet_name": "PVT-VNET-GB-NON-PROD",
                    "vnet_rg_name": "mgmtpvt-rg-gb-non-prod",
                    "subnet_name": "Webapp"
                },
                "25137c49-ffa8-4cef-a4db-f8aaf059d980": {
                    "vnet_name": "PVT-VNET-NAZ-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-NAZ-NON-PROD",
                    "subnet_name": "Webapp"
                },
                "95c54dda-ae35-43c0-aeea-bcfc596674c1": {
                    "vnet_name": "PVT-VNET-NAZ-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-NAZ-PROD",
                    "subnet_name": "Webapp"
                },
                "c8642ed5-9766-43fa-b6cc-47f19181fa40": {
                    "vnet_name": "SAP-INFRA-VNET-NAZ-PROD",
                    "vnet_rg_name": "SAP-RG-NAZ-PROD",
                    "subnet_name": "SAP-PR-APP-SUB"
                },
                "fe70970a-8778-4bc4-83c4-a85c57c1efd3": {
                    "vnet_name": "PVT-VNET-MEX-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-MEX-NON-PROD",
                    "subnet_name": "Webapp"
                },
                "a6362b38-0f74-4c75-bcbb-719b38f04f75": {
                    "vnet_name": "PVT-VNET-MEX-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-MEX-PROD",
                    "subnet_name": "Webapp"
                },
                "3617a45e-beab-410a-9476-d6e000e1fb77": {
                    "vnet_name": "PVT-VNET-EU-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-EU-NON-PROD",
                    "subnet_name": "Webapp"
                },
                "1c1db8ee-5d54-460b-bd71-fd031be2a7e5": {
                    "vnet_name": "PVT-VNET-EU-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-EU-PROD",
                    "subnet_name": "Webapp"
                },
                "77a7f337-8588-4076-b526-5f1ce0e55671": {
                    "vnet_name": "PVT-VNET-AFR-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-AFR-PROD",
                    "subnet_name": "Webapp"
                },
                "15bcebd1-794e-49c6-9548-8a4a4357ee16": {
                    "vnet_name": "PVT-VNET-AFR-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-AFR-NON-PROD",
                    "subnet_name": "Webapp-1"
                },
                "30b7b23e-9325-4407-b613-610457afe869": {
                    "vnet_name": "PVT-E2-VNET-CN-PROD",
                    "vnet_rg_name": "MGMTPVT-E2-RG-CN-PROD",
                    "subnet_name": "Webapp"
                },
                "08ba6e07-14eb-4984-9176-9261b8a2781d": {
                    "vnet_name": "PVT-E2-VNET-CN-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-E2-RG-CN-NON-PROD",
                    "subnet_name": "Webapp"
                },
                "b413c513-77a1-4416-84d4-4057920111c6": {
                    "vnet_name": "PVT-VNET-KR-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-KR-NON-PROD",
                    "subnet_name": "Webapp"
                },
                "a831d6f9-cdd3-4d49-9dd5-9389dd3a1902": {
                    "vnet_name": "PVT-VNET-KR-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-KR-PROD",
                    "subnet_name": "Webapp"
                }
            }
            sub_map = subscription_vnet_map.get(self.subscription_id)
            if not sub_map:
                raise Exception(f"Subscription {self.subscription_id} not mapped for VNet/subnet.")

            # Get subnet resource
            subnet = self.network_client.subnets.get(
                sub_map["vnet_rg_name"],
                sub_map["vnet_name"],
                sub_map["subnet_name"]
            )
            subnet_id = subnet.id

            # Determine DNS zone name
            if self.subscription_id in ["30b7b23e-9325-4407-b613-610457afe869", "08ba6e07-14eb-4984-9176-9261b8a2781d"]:
                dns_zone_name = "privatelink.servicebus.chinacloudapi.cn"
            else:
                dns_zone_name = "privatelink.servicebus.windows.net"

            if self.servicebus_sku.lower() == "premium":
                logging.info("Provisioning Private Endpoint for Premium Service Bus Namespace")

                pe_helper = PrivateEndpointHelper(self.subscription_id, self.zone, self.cloud)
                pe_name = f"{self.service_bus_name}-pe-webapp"
                pe_helper.create_private_endpoint(
                    resource_group_name=self.resource_group_name,
                    resource_id=namespace_id,
                    resource_name=self.service_bus_name,
                    location=self.location,
                    subnet_id=subnet_id,
                    group_ids=["namespace"],
                    dns_zone_name=dns_zone_name,
                    private_endpoint_name=pe_name,
                    tags=self.tags
                )
                pe_id = None
                
                network = self.servicebus_client.namespaces.create_or_update_network_rule_set(
                    self.resource_group_name,
                    self.service_bus_name,
                    {
                        "default_action": "Deny",
                        "virtual_network_rules": [
                            {
                                "subnet": {"id": subnet_id},
                                "ignore_missing_vnet_service_endpoint": True
                            }
                        ],
                        "ip_rules": [],
                        "trusted_service_access_enabled": True,
                        "public_network_access": "Disabled"
                    }
                )
                logging.info(f"Network rules updated for Service Bus Namespace: {network.id}")
            return {
                "servicebus_namespace_id": namespace_id,
                "private_endpoint_id": pe_id if self.servicebus_sku.lower() == "premium" else None
            }
        except Exception as e:
            logging.error(f"Failed to provision Service Bus: {e}")
            raise