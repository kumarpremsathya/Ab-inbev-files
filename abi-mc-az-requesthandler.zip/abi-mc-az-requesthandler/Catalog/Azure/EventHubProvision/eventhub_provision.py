from shared_code.storage_client import StorageClient
from shared_code.eventhubmgmt_client import EventhubClient
from shared_code.networkmgmt_client import NetworkMgmtClient
from shared_code.private_endpoint_helper import PrivateEndpointHelper
import json,logging

class EventHubProvision:
    def __init__(self,json_data):
        data = json.loads(json_data['Payload'])['payload']["data"]
        self.zone = json_data["Zone"].lower()
        self.tags = data["tags"]
        self.subscription_id = data["subscription_id"]
        self.resource_group_name = data["resource_group_name"]
        self.location = data["location"]
        self.eventhub_namespace_name = data["namespace_name"]
        self.eventhub_name = data["eventhub_name"]
        self.sku = data["sku"]
        self.processing_units = data.get("processing_units", None)
        self.throughput_units = data.get("throughput_units", None)
        self.message_retention = data.get("retention_time", None)
        self.partition_count = data.get("partition_count")
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.storage_client = StorageClient().get_storage_client(self.subscription_id,self.cloud)
        self.eventhub_client = EventhubClient().get_eventhub_client(self.subscription_id,self.cloud)
        self.network_client = NetworkMgmtClient().get_network_mgmt_client(self.subscription_id,self.cloud)

    def create_eventhub(self):
        try:

            # Map subscription_id to vnet/subnet/log analytics info
            subscription_map = {
                "2db7c27b-2f9f-4088-981b-2bd88c5c1905": {
                    "log_analytics_name": "mgmtomsgbprod",
                    "log_analytics_rg_name": "mgmtoms-rg-gb-prod",
                    "vnet_name": "PVT-VNET-GB-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-GB-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                "73f88e6b-3a35-4612-b550-555157e7059f": {
                    "log_analytics_name": "mgmtomsgbnonprod",
                    "log_analytics_rg_name": "mgmtoms-rg-gb-non-prod",
                    "vnet_name": "PVT-VNET-GB-NON-PROD",
                    "vnet_rg_name": "mgmtpvt-rg-gb-non-prod",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                "25137c49-ffa8-4cef-a4db-f8aaf059d980": {
                    "log_analytics_name": "mgmtomsnaznonprod",
                    "log_analytics_rg_name": "MGMTOMS-RG-NAZ-NON-PROD",
                    "vnet_name": "PVT-VNET-NAZ-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-NAZ-NON-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                "95c54dda-ae35-43c0-aeea-bcfc596674c1": {
                    "log_analytics_name": "mgmtomsnazprod",
                    "log_analytics_rg_name": "mgmtoms-rg-naz-prod",
                    "vnet_name": "PVT-VNET-NAZ-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-NAZ-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                "c8642ed5-9766-43fa-b6cc-47f19181fa40": {
                    "log_analytics_name": "mgmtomsnazsap",
                    "log_analytics_rg_name": "mgmtoms-rg-naz-sap-r3",
                    "vnet_name": "SAP-INFRA-VNET-NAZ-PROD",
                    "vnet_rg_name": "SAP-RG-NAZ-PROD",
                    "subnet_name": "SAP-PR-APP-SUB",
                    "subnet_name1": "SAP-PR-DB-SUB"
                },
                "fe70970a-8778-4bc4-83c4-a85c57c1efd3": {
                    "log_analytics_name": "mgmtomsmexnonprod",
                    "log_analytics_rg_name": "mgmtoms-rg-mex-non-prod",
                    "vnet_name": "PVT-VNET-MEX-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-MEX-NON-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                "a6362b38-0f74-4c75-bcbb-719b38f04f75": {
                    "log_analytics_name": "mgmtomsmexprod",
                    "log_analytics_rg_name": "mgmtoms-rg-mex-prod",
                    "vnet_name": "PVT-VNET-MEX-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-MEX-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                "3617a45e-beab-410a-9476-d6e000e1fb77": {
                    "log_analytics_name": "mgmtomseunonprod",
                    "log_analytics_rg_name": "mgmtoms-rg-eu-non-prod",
                    "vnet_name": "PVT-VNET-EU-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-EU-NON-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                "1c1db8ee-5d54-460b-bd71-fd031be2a7e5": {
                    "log_analytics_name": "mgmtomseuprod",
                    "log_analytics_rg_name": "mgmtoms-rg-eu-prod",
                    "vnet_name": "PVT-VNET-EU-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-EU-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                "77a7f337-8588-4076-b526-5f1ce0e55671": {
                    "log_analytics_name": "mgmtomsafrprod",
                    "log_analytics_rg_name": "mgmtoms-rg-afr-prod",
                    "vnet_name": "PVT-VNET-AFR-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-AFR-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                "15bcebd1-794e-49c6-9548-8a4a4357ee16": {
                    "log_analytics_name": "mgmtomsafrnonprod",
                    "log_analytics_rg_name": "mgmtoms-rg-afr-non-prod",
                    "vnet_name": "PVT-VNET-AFR-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-AFR-NON-PROD",
                    "subnet_name": "Webapp-1",
                    "subnet_name1": "Infra"
                },
                "30b7b23e-9325-4407-b613-610457afe869": {
                    "log_analytics_name": "mgmtomschinaprod",
                    "log_analytics_rg_name": "mgmtoms-e2-rg-cn-prod",
                    "vnet_name": "PVT-E2-VNET-CN-PROD",
                    "vnet_rg_name": "MGMTPVT-E2-RG-CN-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                "08ba6e07-14eb-4984-9176-9261b8a2781d": {
                    "log_analytics_name": "mgmtomschinanonprod",
                    "log_analytics_rg_name": "mgmtoms-e2-rg-cn-non-prod",
                    "vnet_name": "PVT-E2-VNET-CN-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-E2-RG-CN-NON-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                "b413c513-77a1-4416-84d4-4057920111c6": {
                    "log_analytics_name": "mgmtomskrnonprod",
                    "log_analytics_rg_name": "mgmtoms-rg-kr-non-prod",
                    "vnet_name": "PVT-VNET-KR-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-KR-NON-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                "a831d6f9-cdd3-4d49-9dd5-9389dd3a1902": {
                    "log_analytics_name": "mgmtomskrprod",
                    "log_analytics_rg_name": "mgmtoms-rg-kr-prod",
                    "vnet_name": "PVT-VNET-KR-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-KR-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                "1d3c55b6-f2e9-469b-8e3b-f2ed41ef0887":{
                    "log_analytics_name": "cloud-governance-nprod",
                    "log_analytics_rg_name": "ABI-GHQ-03553-CRS-CUS-NPRD-RG",
                    "vnet_name": "ghq-03553-cus-nprd-vnet",
                    "vnet_rg_name": "ABI-GHQ-03553-CRS-CUS-NPRD-RG",
                    "subnet_name": "ghq-04906-cus-nprd-vnet-pesnet",
                    "subnet_name1": "Infra"
                }
            }


            # Get the current subscription's mapping, if available
            subscription_info = subscription_map.get(self.subscription_id)
            subnet = self.network_client.subnets.get(
                subscription_info["vnet_rg_name"],
                subscription_info["vnet_name"],
                subscription_info["subnet_name"]
            )
            subnet_id = subnet.id

            # 1. Create EventHub Namespace
            namespace_params = {
                "location": self.location,
                "sku": {
                    "name": self.sku,
                    "tier": self.sku,
                    "capacity": str(self.processing_units) if self.sku.lower() not in ["standard", "basic"] else None
                },
                "tags": self.tags,
                "is_auto_inflate_enabled": False,
                "maximum_throughput_units": int(self.throughput_units) if self.throughput_units else None,
            }
            # Create or update the namespace
            eventhub_id = None
            try:
                eventhub_id = self.eventhub_client.namespaces.get(
                    self.resource_group_name,
                    self.eventhub_namespace_name
                )
                namespace_result = eventhub_id
            except Exception as e:
                logging.error(f"Failed to get EventHub Namespace: {e}")
                
            if not eventhub_id:
                poller = self.eventhub_client.namespaces.begin_create_or_update(
                    self.resource_group_name,
                    self.eventhub_namespace_name,
                    namespace_params
                )
                namespace_result = poller.result()
                logging.info(f"EventHub Namespace created: {namespace_result.id}")

            # 2. Create EventHub
            # Set EventHub parameters based on SKU
            eventhub_params = {
                "partition_count": self.partition_count if self.partition_count else None,
            }
            # For Premium SKU, message_retention_in_days must be an integer (days)
            if self.sku.lower() == "premium":
                if self.message_retention:
                    # If retention is given in hours, convert to days (rounded up)
                    retention_days = int(-(-self.message_retention // 24))  # ceil division
                    eventhub_params["message_retention_in_days"] = retention_days
            else:
                # For Standard/Basic, message_retention_in_days can be float (in days)
                if self.message_retention:
                    eventhub_params["message_retention_in_days"] = self.message_retention / 24
            eventhub_result = self.eventhub_client.event_hubs.create_or_update(
                self.resource_group_name,
                self.eventhub_namespace_name,
                self.eventhub_name,
                eventhub_params
            )
            logging.info(f"EventHub created: {eventhub_result.id}")
            if self.sku.lower() == "premium":
                # Create private endpoint
                pe_helper = PrivateEndpointHelper(self.subscription_id, self.zone, self.cloud)
                dns_zone_name = "privatelink.servicebus.chinacloudapi.cn" if self.zone == "china" else "privatelink.servicebus.windows.net"
                pe_helper.create_private_endpoint(
                    resource_group_name=self.resource_group_name,
                    resource_id=namespace_result.id,
                    resource_name=self.eventhub_namespace_name,
                    location=self.location,
                    subnet_id=subnet_id,
                    group_ids=["namespace"],
                    dns_zone_name=dns_zone_name,
                    private_endpoint_name=f"{self.eventhub_namespace_name}-pe-namespace",
                    tags=self.tags
                )

                network = self.eventhub_client.namespaces.create_or_update_network_rule_set(
                    self.resource_group_name,
                    self.eventhub_namespace_name,
                    {
                        "default_action": "Deny",
                        "virtual_network_rules": [
                            {
                                "subnet": {"id": subnet_id},
                                "ignore_missing_vnet_service_endpoint": True
                            }
                        ],
                        "ip_rules": [],
                        "trusted_service_access_enabled": True,
                        "public_network_access_enabled": True
                    }
                )
                logging.info(f"Network rules updated for EventHub Namespace: {network.id}")

            return {
                "namespace_id": namespace_result.id,
                "eventhub_id": eventhub_result.id
            }
        except Exception as e:
            logging.error(f"Failed to provision EventHub: {e}")
            raise