import logging
import json,os
from azure.core.exceptions import HttpResponseError
from shared_code.lock_manager import LockManager
from shared_code.vm_run_command import execute_run_command
from shared_code.compute_client import ComputeClient


class InactiveVMAccounts:
    def __init__(self, json_data):
        data = json_data
        self.vmid = data.get('Vmid', None)
        self.subscription_id = data.get('SubscriptionId', None)
        self.account_name = data.get('AccountName', None)
        self.account_status = data.get('AccountStatus', None)
        self.account_type = data.get('AccountType', None)
        self.display_name = data.get('DisplayName', None)
        self.domain = data.get('Domain', None)
        self.email = data.get('Email', None)
        self.kernel = data.get('Kernel', None)
        self.node = data.get('Node', None)
        self.privileged_access = data.get('PrivilegedAccess', None)
        self.resource = data.get('Resource', None)
        self.resource_group_name = data.get('ResourceGroupName', None)
        self.subscription_name = data.get('SubscriptionName', None)
        self.user_id = data.get('UserId', None)
        self.zone = data.get('Zone', None).lower()
        self.env = os.environ.get("Environment", '').lower()
        self.azenvironment = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
    
    def remove_inactive_vm_accounts(self):
        try:
            logging.info(f"Attempting to remove inactive account {self.account_name} for subscription {self.subscription_id} and zone {self.zone}")
            logging.info(f"Current environment: {self.env}")
            if  self.env == "production" and self.vmid:
                self.lock_manager = LockManager(self.subscription_id, self.zone, resource_group_name=self.resource_group_name, resource_id=self.vmid)
                self.compute_client = ComputeClient().get_compute_client(self.subscription_id,self.azenvironment)
                self.lock_manager.remove_all_locks(scope=self.resource,lock_types=["ReadOnly"])
                if self.kernel.lower() == "linux":
                    script_json = {
                        "kernel": "Linux", "scripts": [
                            f"gpasswd -d {self.account_name} sudousers > /dev/null 2>&1 || true",
                            f"gpasswd -d {self.account_name} sshusers > /dev/null 2>&1 || true",
                        ]
                    }
                else:
                    script_json = {
                        "kernel": "Windows", "scripts": [
                            f"Get-LocalGroup | ForEach-Object {{ if (Get-LocalGroupMember -Group $_ -Member \"{self.account_name}\" -ErrorAction SilentlyContinue) {{ Remove-LocalGroupMember -Group $_ -Member \"{self.account_name}\" }} }}"
                        ]
                    }
                execute_run_command(self.compute_client,self.resource_group_name,self.node,script_json,"VM Account Removal",required=True)
                logging.info(f"Successfully removed inactive account {self.account_name} from VM {self.node}")
        except Exception as e:
            logging.error(f"Error removing inactive account {self.account_name}: {e}")
            raise e
