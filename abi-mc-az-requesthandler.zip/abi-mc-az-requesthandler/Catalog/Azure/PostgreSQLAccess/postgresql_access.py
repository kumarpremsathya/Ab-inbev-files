from shared_code.postgresql_client import PostgresqlClient
from shared_code.client_secret_auth import ClientSecretAuth
from shared_code.lock_manager import LockManager
from shared_code.graphservice_client import GraphClient
from shared_code.policy_client import AzPolicyClient
from azure.core.exceptions import HttpResponseError
from azure.mgmt.postgresqlflexibleservers.models import ServerForUpdate, AuthConfig
from shared_code.spn_token import SpnToken
from datetime import datetime,timedelta
import logging,os,json,uuid,time
import re
import psycopg2

class AzPostgreSQLAccess:
    def __init__(self,json_data):
        self.subscription_id = json_data['SubscriptionId']
        self.subscription_name = json_data['SubscriptionName']
        self.zone = json_data['Zone'].lower()
        self.resource_group_name = json_data['ResourceGroupName']
        self.postgre_server_name = json_data['PostgreServerName']
        self.postgre_db_names = json_data['PostgreDbName'].split(",")
        self.members_ids = json.loads(json_data['MemberIds'])
        self.db_role = json_data['PostgreDbRole']
        self.azenvironment = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.postgre_mgmt_client = PostgresqlClient().get_sql_mgmt_client(self.subscription_id,self.azenvironment)
        self.is_public_access_enabled_by_brewmation = None
        self.lock_client = LockManager(self.subscription_id,self.zone,self.resource_group_name,self.postgre_server_name)

    def apply_firewall_rules(self):
        self.postgre_mgmt_client.firewall_rules.begin_create_or_update(
            self.resource_group_name,
            self.postgre_server_name,
            "Brewmation",
            {
                "start_ip_address": '0.0.0.0',
                "end_ip_address": '255.255.255.255'
            }
        ).result()
        logging.info(f"Firewall rule 'Brewmation' created for PostgreSQL Server '{self.postgre_server_name}'")

    def enable_public_network_access(self):
        server = self.postgre_mgmt_client.servers.get(self.resource_group_name, self.postgre_server_name)
        if server.network and server.network.public_network_access == "Enabled":
            logging.info(f"Public network access already enabled for PostgreSQL Server '{self.postgre_server_name}'")
            return
        self.postgre_mgmt_client.servers.begin_update(
            self.resource_group_name,
            self.postgre_server_name,
            {
                "network": {
                    "public_network_access": "Enabled"
                }
            }
        ).result()
        self.is_public_access_enabled_by_brewmation = True
        logging.info(f"Public network access enabled for PostgreSQL Server '{self.postgre_server_name}'")
    
    def disable_public_network_access(self):
        if not self.is_public_access_enabled_by_brewmation:
            logging.info(f"Public network access not enabled by Brewmation for PostgreSQL Server '{self.postgre_server_name}'")
            return
        self.postgre_mgmt_client.servers.begin_update(
            self.resource_group_name,
            self.postgre_server_name,
            {
                "network": {
                    "public_network_access": "Disabled"
                }
            }
        ).result()
        logging.info(f"Public network access disabled for PostgreSQL Server '{self.postgre_server_name}'")

    def remove_firewall_rules(self):
        self.postgre_mgmt_client.firewall_rules.begin_delete(
            self.resource_group_name,
            self.postgre_server_name,
            "Brewmation"
        ).result()
        logging.info(f"Firewall rule 'Brewmation' deleted for PostgreSQL Server '{self.postgre_server_name}'")

    def enable_aad_authentication(self):
        server = self.postgre_mgmt_client.servers.get(self.resource_group_name, self.postgre_server_name)
        if server.auth_config and server.auth_config.active_directory_auth == "Enabled":
            logging.info(f"Microsoft Entra authentication already enabled for PostgreSQL Server '{self.postgre_server_name}'")
            return
        self.postgre_mgmt_client.servers.begin_update(
            self.resource_group_name,
            self.postgre_server_name,
            ServerForUpdate(
                auth_config=AuthConfig(active_directory_auth="Enabled")
            )
        ).result()
        logging.info(f"Microsoft Entra authentication enabled for PostgreSQL Server '{self.postgre_server_name}'")

    def add_aad_administrator(self):
        if self.zone == 'naz':
            self.aad_admin_name = "AADS_A_ABI NAZ SQL DB Admins"
            principal_id = "eacb2675-7fbc-4f91-a3eb-906c78bd0043"
        elif self.zone == 'china':
            self.aad_admin_name = "Cloudbolt"
            principal_id = "6a956c8e-0e11-4d70-84ef-4ea2c018964b"
        else:
            self.aad_admin_name = "AADS_A_ABI GlobalOps SQL DB Admins"
            principal_id = "c643a250-a7e8-44b2-bc5f-7ed4437e7cf9"
        tenant_id = "cef04b19-7776-4a94-b89b-375c77a8f936" if self.zone != 'china' else "c99b23b6-4fa8-4eee-a7cc-2f420106e730"

        self.postgre_mgmt_client.administrators.begin_create(
            self.resource_group_name,
            self.postgre_server_name,
            principal_id,
            {
                "principal_type": "Group",
                "principal_name": self.aad_admin_name,
                "tenant_id": tenant_id
            }
        ).result()
        logging.info(f"AAD Administrator group added for PostgreSQL Server '{self.postgre_server_name}'")

    def execute_query(self, database, query, token):
        host = f"{self.postgre_server_name}.postgres.database.azure.com"
        try:
            conn = psycopg2.connect(
                host=host,
                database=database,
                user=self.aad_admin_name,
                password=token.token,
                sslmode='require'
            )
            conn.autocommit = True
            cursor = conn.cursor()
            cursor.execute(query)
            cursor.close()
            conn.close()
        except Exception as e:
            logging.error(f"Error executing query on database '{database}': {str(e)}")
            raise e

    def _build_grant_queries(self, user, db):
        """Build granular GRANT queries as a workaround for Azure PostgreSQL
        Flexible Server which does not support granting predefined roles
        (pg_read_all_data, pg_write_all_data, pg_database_owner) directly.

        Mapping:
          pg_read_all_data  → SELECT on public schema
          pg_write_all_data → ALL PRIVILEGES on public schema
          pg_database_owner → ALL PRIVILEGES on ALL user schemas
        """
        role_lower = self.db_role.lower()

        if role_lower == 'pg_read_all_data':
            return f"""
            GRANT CONNECT ON DATABASE "{db}" TO "{user}";
            GRANT USAGE ON SCHEMA public TO "{user}";
            GRANT SELECT ON ALL TABLES IN SCHEMA public TO "{user}";
            GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO "{user}";
            GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO "{user}";
            DO $$
            DECLARE
                r TEXT;
            BEGIN
                FOR r IN
                    SELECT DISTINCT tableowner
                    FROM   pg_catalog.pg_tables
                    WHERE  schemaname = 'public'
                LOOP
                    BEGIN
                        EXECUTE format(
                            'ALTER DEFAULT PRIVILEGES FOR ROLE %I IN SCHEMA public '
                            'GRANT SELECT ON TABLES TO "{user}"', r);
                        EXECUTE format(
                            'ALTER DEFAULT PRIVILEGES FOR ROLE %I IN SCHEMA public '
                            'GRANT USAGE, SELECT ON SEQUENCES TO "{user}"', r);
                        EXECUTE format(
                            'ALTER DEFAULT PRIVILEGES FOR ROLE %I IN SCHEMA public '
                            'GRANT EXECUTE ON FUNCTIONS TO "{user}"', r);
                    EXCEPTION WHEN insufficient_privilege THEN
                        NULL;
                    END;
                END LOOP;
                ALTER DEFAULT PRIVILEGES IN SCHEMA public
                    GRANT SELECT ON TABLES TO "{user}";
                ALTER DEFAULT PRIVILEGES IN SCHEMA public
                    GRANT USAGE, SELECT ON SEQUENCES TO "{user}";
                ALTER DEFAULT PRIVILEGES IN SCHEMA public
                    GRANT EXECUTE ON FUNCTIONS TO "{user}";
            END
            $$;
            """

        elif role_lower == 'pg_write_all_data':
            return f"""
            GRANT CREATE, CONNECT, TEMPORARY ON DATABASE "{db}" TO "{user}";
            GRANT ALL PRIVILEGES ON SCHEMA public TO "{user}";
            GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO "{user}";
            GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO "{user}";
            GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA public TO "{user}";
            DO $$
            DECLARE
                r TEXT;
            BEGIN
                -- Cover future tables created by ANY existing non-system role.
                -- ALTER DEFAULT PRIVILEGES FOR ROLE only works when the executor
                -- is a member of that role, so we skip roles we can't impersonate.
                FOR r IN
                    SELECT DISTINCT tableowner
                    FROM   pg_catalog.pg_tables
                    WHERE  schemaname = 'public'
                LOOP
                    BEGIN
                        EXECUTE format(
                            'ALTER DEFAULT PRIVILEGES FOR ROLE %I IN SCHEMA public '
                            'GRANT ALL PRIVILEGES ON TABLES TO "{user}"', r);
                        EXECUTE format(
                            'ALTER DEFAULT PRIVILEGES FOR ROLE %I IN SCHEMA public '
                            'GRANT ALL PRIVILEGES ON SEQUENCES TO "{user}"', r);
                        EXECUTE format(
                            'ALTER DEFAULT PRIVILEGES FOR ROLE %I IN SCHEMA public '
                            'GRANT ALL PRIVILEGES ON FUNCTIONS TO "{user}"', r);
                    EXCEPTION WHEN insufficient_privilege THEN
                        -- Skip roles we are not a member of; current-role defaults
                        -- below still cover tables created by this session.
                        NULL;
                    END;
                END LOOP;
                -- Default privileges for objects created by the current role
                ALTER DEFAULT PRIVILEGES IN SCHEMA public
                    GRANT ALL PRIVILEGES ON TABLES TO "{user}";
                ALTER DEFAULT PRIVILEGES IN SCHEMA public
                    GRANT ALL PRIVILEGES ON SEQUENCES TO "{user}";
                ALTER DEFAULT PRIVILEGES IN SCHEMA public
                    GRANT ALL PRIVILEGES ON FUNCTIONS TO "{user}";
            END
            $$;
            """

        elif role_lower == 'pg_database_owner':
            return f"""
            GRANT ALL PRIVILEGES ON DATABASE "{db}" TO "{user}";
            DO $$
            DECLARE
                sch TEXT;
            BEGIN
                FOR sch IN
                    SELECT nspname FROM pg_catalog.pg_namespace
                    WHERE nspname NOT LIKE 'pg_%'
                      AND nspname <> 'information_schema'
                LOOP
                    EXECUTE format('GRANT ALL PRIVILEGES ON SCHEMA %I TO %I', sch, '{user}');
                    EXECUTE format('GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA %I TO %I', sch, '{user}');
                    EXECUTE format('GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA %I TO %I', sch, '{user}');
                    EXECUTE format('GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA %I TO %I', sch, '{user}');
                    EXECUTE format('ALTER DEFAULT PRIVILEGES IN SCHEMA %I GRANT ALL PRIVILEGES ON TABLES TO %I', sch, '{user}');
                    EXECUTE format('ALTER DEFAULT PRIVILEGES IN SCHEMA %I GRANT ALL PRIVILEGES ON SEQUENCES TO %I', sch, '{user}');
                    EXECUTE format('ALTER DEFAULT PRIVILEGES IN SCHEMA %I GRANT ALL PRIVILEGES ON FUNCTIONS TO %I', sch, '{user}');
                END LOOP;
            END
            $$;
            """
        else:
            raise ValueError(f"Unsupported db_role: {self.db_role}")

    def _get_aad_principal_params(self):
        """Returns (isAdmin, isMfa) based on the db_role."""
        return 'false', 'true'

    def provide_access_to_user(self, user):
        spn = os.environ["SPN_SECRET_PUBLIC"] if self.zone != 'china' else os.environ["SPN_SECRET_CHINA"]
        token = ClientSecretAuth().client_credential(spn).get_token("https://ossrdbms-aad.database.windows.net/.default")
        is_admin, is_mfa = self._get_aad_principal_params()

        create_query = f"""
        DO $$
        BEGIN
            IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = '{user}') THEN
                PERFORM pg_catalog.pgaadauth_create_principal('{user}'::text, {is_admin}::boolean, {is_mfa}::boolean);
            END IF;
            -- Strip any pre-existing cluster-wide admin membership unconditionally.
            BEGIN
                EXECUTE format('REVOKE azure_pg_admin FROM %I', '{user}');
            EXCEPTION WHEN undefined_object OR insufficient_privilege OR undefined_table THEN
                NULL;  -- role didn't have it or azure_pg_admin doesn't exist
            END;
        END
        $$;
        """
        self.execute_query('postgres', create_query, token)
        logging.info(f"AAD principal ensured for user '{user}'")

        for db in self.postgre_db_names:
            if self.if_db_exists(db):
                grant_query = self._build_grant_queries(user, db)
                self.execute_query(db, grant_query, token)
                logging.info(f"Granted '{self.db_role}' equivalent permissions to '{user}' on database '{db}'")
        
    def if_db_exists(self, db_name):
        try:
            self.postgre_mgmt_client.databases.get(self.resource_group_name, self.postgre_server_name, db_name)
            return True
        except Exception as e:
            logging.info(f"Database '{db_name}' does not exist")
            return False
        
    def exempt_policy(self, id):
        policy_client = AzPolicyClient().get_policy_client(self.subscription_id, self.azenvironment)
        try:
            response = policy_client.policy_exemptions.create_or_update(
                scope=f"/subscriptions/{self.subscription_id}/resourceGroups/{self.resource_group_name}/providers/Microsoft.DBforPostgreSQL/flexibleServers/{self.postgre_server_name}",
                policy_exemption_name=f"{self.postgre_server_name}-Brewmation-{str(uuid.uuid4()).split('-')[0]}",
                parameters={
                    "properties": {
                        "policyAssignmentId": id,
                        "exemptionCategory": "Waiver",
                        "expiresOn": datetime.now() + timedelta(hours=3),
                    }
                },
            )
            logging.info(f"Policy exemption created: {response}")
            time.sleep(180)
        except Exception as e:
            logging.error(f"Error creating policy exemption: {str(e)}")
            raise e

    async def get_user_principal_name(self, user_id):
        graph_client = GraphClient().get_graph_client(self.azenvironment)
        try:
            user = await graph_client.directory_objects.by_directory_object_id(user_id).get()
            if user.odata_type == "#microsoft.graph.user":
                return user.user_principal_name
            elif user.odata_type == "#microsoft.graph.servicePrincipal":
                return user.display_name
            elif user.odata_type == "#microsoft.graph.group":
                return user.display_name
            else:
                raise Exception(f"Unsupported object type: {user.odata_type}")
        except Exception as e:
            logging.error(f"Error fetching user principal name for user ID '{user_id}': {str(e)}")
            raise e 

    async def grant_access(self):
        try:
            self.lock_client.remove_all_locks()
            self.enable_aad_authentication()
            self.add_aad_administrator()
            self.enable_public_network_access()
            self.apply_firewall_rules()
            for member in self.members_ids:
                member_principal_name = await self.get_user_principal_name(member["OID"])
                self.provide_access_to_user(member_principal_name)
        except HttpResponseError as e:
            if hasattr(e, 'error') and e.error and hasattr(e.error, 'code') and "RequestDisallowedByPolicy" in e.error.code:
                logging.warning("Access grant was blocked by policy, attempting to exempt policy and retry")
                match = re.search(r'"policyAssignment":\{"name":".+?","id":"(.*?)"', e.error.message)
                id = match.group(1) if match else None
                try:
                    self.exempt_policy(id)
                    self.enable_aad_authentication()
                    self.enable_public_network_access()
                    self.apply_firewall_rules()
                    for member in self.members_ids:
                        member_principal_name = await self.get_user_principal_name(member["OID"])
                        self.provide_access_to_user(member_principal_name)
                except Exception as ex:
                    logging.error(f"Retry after policy exemption failed: {str(ex)}")
                    raise ex
                logging.error(f"Error granting access: {str(e)}")
            else:
                raise e
        finally:
            try:
                self.remove_firewall_rules()
            except Exception as e:
                logging.error(f"Error removing firewall rules for '{self.postgre_server_name}': {str(e)}")
            try:
                self.disable_public_network_access()
            except Exception as e:
                logging.error(f"Error disabling public network access for '{self.postgre_server_name}': {str(e)}")
            try:
                self.lock_client.restore_locks()
            except Exception as e:
                logging.error(f"Error restoring locks for '{self.postgre_server_name}': {str(e)}")
