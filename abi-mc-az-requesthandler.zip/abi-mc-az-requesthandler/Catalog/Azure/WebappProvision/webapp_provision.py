from shared_code.resourcemgmt_client import ResourceMgmtClient
from shared_code.website_client import WebSiteClient
from shared_code.storage_client import StorageClient
from shared_code.networkmgmt_client import NetworkMgmtClient
from shared_code.privatedns_client import PrivateDNSClient
import json,logging

class WebAppProvision:
    def __init__(self):
        pass
    def __init__(self,json_data):
        data = json.loads(json_data['Payload'])['payload']["data"]
        self.zone = json_data["Zone"].lower()
        self.tags = data["tags"]
        self.subscription_id = data["subscription_id"]
        self.resource_group_name = data["resource_group_name"]
        self.location = data["webapp_location"]
        self.environament = data["environment"]
        self.webapp_name = data["webapp_name"]
        self.publish_type = data["webapp_publish_type"]
        self.os_type = data["webapp_os_type"]
        self.runtime_stack = data["webapp_runtime_stack"]
        self.app_service_plan_type = data["app_service_plan_type"]
        self.app_service_plan_name = data["app_service_plan_name"]
        self.app_service_plan_id = data["app_service_plan_id"]
        self.app_service_plan_sku_name = data["app_service_plan_sku"].split(':')[0].strip()
        self.app_service_plan_sku_tier = data["app_service_plan_sku_tier"]
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.web_client = WebSiteClient().get_web_client(self.subscription_id,self.cloud)
        self.storage_client = StorageClient().get_storage_client(self.subscription_id,self.cloud)
        self.network_client = NetworkMgmtClient().get_network_mgmt_client(self.subscription_id,self.cloud)
        self.dns_client = PrivateDNSClient().get_dns_client(self.subscription_id,self.cloud)

    def create_webapp(self):
        try:
            # Define subscription details dictionary
            self.subscriptions = {
                "2db7c27b-2f9f-4088-981b-2bd88c5c1905": {
                    "storage_account_name": "mgmtgbpsecuritystorage",
                    "storage_account_rg_name": "mgmtoms-rg-gb-prod",
                    "vnet_name": "PVT-VNET-GB-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-GB-PROD",
                    "subnet_name": "Webapp"
                },
                "73f88e6b-3a35-4612-b550-555157e7059f": {
                    "storage_account_name": "mgmtgbnpsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-RG-GB-NON-PROD",
                    "vnet_name": "PVT-VNET-GB-NON-PROD",
                    "vnet_rg_name": "mgmtpvt-rg-gb-non-prod",
                    "subnet_name": "Webapp"
                },
                "25137c49-ffa8-4cef-a4db-f8aaf059d980": {
                    "storage_account_name": "mgmtnaznpsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-RG-NAZ-NON-PROD",
                    "vnet_name": "PVT-VNET-NAZ-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-NAZ-NON-PROD",
                    "subnet_name": "Webapp"
                },
                "95c54dda-ae35-43c0-aeea-bcfc596674c1": {
                    "storage_account_name": "mgmtnazpsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-RG-NAZ-PROD",
                    "vnet_name": "PVT-VNET-NAZ-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-NAZ-PROD",
                    "subnet_name": "Webapp"
                },
                "c8642ed5-9766-43fa-b6cc-47f19181fa40": {
                    "storage_account_name": "mgmtnazsapr3bootdiag",
                    "storage_account_rg_name": "MGMTOMS-RG-NAZ-SAP-R3",
                    "vnet_name": "SAP-INFRA-VNET-NAZ-PROD",
                    "vnet_rg_name": "SAP-RG-NAZ-PROD",
                    "subnet_name": "SAP-PR-APP-SUB"
                },
                "fe70970a-8778-4bc4-83c4-a85c57c1efd3": {
                    "storage_account_name": "mgmtmaznpsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-RG-MEX-NON-PROD",
                    "vnet_name": "PVT-VNET-MEX-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-MEX-NON-PROD",
                    "subnet_name": "Webapp"
                },
                "a6362b38-0f74-4c75-bcbb-719b38f04f75": {
                    "storage_account_name": "mgmtmazpsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-RG-MEX-PROD",
                    "vnet_name": "PVT-VNET-MEX-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-MEX-PROD",
                    "subnet_name": "Webapp"
                },
                "3617a45e-beab-410a-9476-d6e000e1fb77": {
                    "storage_account_name": "mgmteunpsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-RG-EU-NON-PROD",
                    "vnet_name": "PVT-VNET-EU-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-EU-NON-PROD",
                    "subnet_name": "Webapp"
                },
                "1c1db8ee-5d54-460b-bd71-fd031be2a7e5": {
                    "storage_account_name": "mgmteupsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-RG-EU-PROD",
                    "vnet_name": "PVT-VNET-EU-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-EU-PROD",
                    "subnet_name": "Webapp"
                },
                "77a7f337-8588-4076-b526-5f1ce0e55671": {
                    "storage_account_name": "mgmtafpsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-RG-AFR-PROD",
                    "vnet_name": "PVT-VNET-AFR-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-AFR-PROD",
                    "subnet_name": "Webapp"
                },
                "15bcebd1-794e-49c6-9548-8a4a4357ee16": {
                    "storage_account_name": "mgmtafnpsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-RG-AFR-NON-PROD",
                    "vnet_name": "PVT-VNET-AFR-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-AFR-NON-PROD",
                    "subnet_name": "Webapp-1"
                },
                "30b7b23e-9325-4407-b613-610457afe869": {
                    "storage_account_name": "mgmtcnpsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-E2-RG-CN-PROD",
                    "vnet_name": "PVT-E2-VNET-CN-PROD",
                    "vnet_rg_name": "MGMTPVT-E2-RG-CN-PROD",
                    "subnet_name": "Webapp"
                },
                "08ba6e07-14eb-4984-9176-9261b8a2781d": {
                    "storage_account_name": "mgmtcnnonprodbootdiag",
                    "storage_account_rg_name": "MGMTOMS-E2-RG-CN-NON-PROD",
                    "vnet_name": "PVT-E2-VNET-CN-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-E2-RG-CN-NON-PROD",
                    "subnet_name": "Webapp"
                },
                "b413c513-77a1-4416-84d4-4057920111c6": {
                    "storage_account_name": "mgmtkrnpsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-RG-KR-NON-PROD",
                    "vnet_name": "PVT-VNET-KR-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-KR-NON-PROD",
                    "subnet_name": "Webapp"
                },
                "a831d6f9-cdd3-4d49-9dd5-9389dd3a1902": {
                    "storage_account_name": "mgmtkrpsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-RG-KR-PROD",
                    "vnet_name": "PVT-VNET-KR-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-KR-PROD",
                    "subnet_name": "Webapp"
                },
                "1920c23f-e3e5-47b3-98cd-c904cc2b9671": {
                    "storage_account_name": "mgmtusnpsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-RG-US-NON-PROD",
                    "vnet_name": "ghq-digisol-weu-nprd-vnet",
                    "vnet_rg_name": "abi-ghq-DigitalSolutions-weu-nprd-rg",
                    "subnet_name": "ghq-04397-weu-dev-vnet-pesnet"
                },
                "d6eacf7e-2814-4fe3-966f-f0575f66f88e": {
                    "storage_account_name": "mgmtusppsecuritystorage",
                    "storage_account_rg_name": "MGMTOMS-RG-US-PROD",
                    "vnet_name": "ghq-digitalsol-weu-prod-vnet",
                    "vnet_rg_name": "abi-ghq-digitalsol-weu-prod-rg",
                    "subnet_name": "ghq-04397-weu-prd-vnet-pesnet"
                }
            }
            logging.info(f"Creating Web App {self.webapp_name} in resource group {self.resource_group_name}")
                
            # Create or get app service plan ID
            if self.app_service_plan_type.lower() == "new":
                if not self.app_service_plan_name:
                    raise ValueError("App service plan name is required for new plan")
                app_service_plan_id = self.create_app_service_plan()
            else:
                if not self.app_service_plan_name:
                    raise ValueError("Existing app service plan ID is required")
                app_service_plan_id = self.app_service_plan_name

            webapp_params = {
                "location": self.location,
                "server_farm_id": app_service_plan_id,
                "kind": f"app,{self.os_type.lower()}",
                "properties": {
                    "publicNetworkAccess": "Disabled",  # Disable public network access
                    "httpsOnly": True 
                },
                "site_config": {
                    "app_settings": [
                        {
                            "name": "WEBSITE_RUN_FROM_PACKAGE",
                            "value": "1"
                        }
                    ] if self.publish_type.lower() == "code" else [
                        {
                            "name": "DOCKER_REGISTRY_SERVER_URL",
                            "value": "https://mcr.microsoft.com"
                        },
                        {
                            "name": "WEBSITES_ENABLE_APP_SERVICE_STORAGE",
                            "value": "false"
                        }
                    ],
                    "linux_fx_version": self.runtime_stack if self.os_type.lower() == 'linux' and self.publish_type.lower() == "code" else  'DOCKER|mcr.microsoft.com/latest' if self.os_type.lower() == 'linux' and self.publish_type.lower() == "container" else None,
                    "appCommandLine": "" if self.os_type.lower() == 'linux' and self.publish_type.lower() == "code" else None,
                    "http20_enabled": True,
                    "ftps_state": "FtpsOnly",
                    "min_tls_version": "1.2",
                    "remote_debugging_enabled": False,
                    "https_only": True,
                },
                "identity": {
                    "type": "SystemAssigned"
                },
                "tags": self.tags
            }

            webapp_result = self.web_client.web_apps.begin_create_or_update(
                resource_group_name=self.resource_group_name,
                name=self.webapp_name,
                site_envelope=webapp_params
            )
            
            # Get subnet details for private endpoint
            subnet_name = self.subscriptions[self.subscription_id]["subnet_name"]
            vnet_name = self.subscriptions[self.subscription_id]["vnet_name"]
            vnet_rg = self.subscriptions[self.subscription_id]["vnet_rg_name"]
            
            # Get private DNS zone name based on subscription
            dns_zone_name = "privatelink.chinacloudsites.cn" if self.subscription_id in ["30b7b23e-9325-4407-b613-610457afe869", "08ba6e07-14eb-4984-9176-9261b8a2781d"] else "privatelink.azurewebsites.net"
            
            # Get subnet for private endpoint
            subnet = self.network_client.subnets.get(
                vnet_rg,
                vnet_name,
                subnet_name
            )
            
            # Get private DNS zone
            try:
                dns_zone = self.dns_client.private_zones.get(
                    vnet_rg,
                    dns_zone_name
                )
            except Exception as e:
                if "ResourceNotFound" in str(e):
                    dns_zone = self.dns_client.private_zones.begin_create_or_update(
                        resource_group_name=vnet_rg,
                        private_zone_name=dns_zone_name,
                        parameters={
                            "location": "global",
                            "properties": {
                            "max_number_of_record_sets": 25000,
                            "max_number_of_virtual_network_links": 1000,
                            "max_number_of_virtual_network_links_with_registration": 100,
                            }
                        }
                    ).result()
            
            # Create private endpoint
            private_endpoint_params = {
                "location": self.location,
                "subnet": {
                    "id": subnet.id
                },
                "privateLinkServiceConnections": [{
                    "name": f"{self.webapp_name}-pe-webapp-connection",
                    "properties": {
                        "privateLinkServiceId": webapp_result.result().id,
                        "groupIds": ["sites"],
                        "requestMessage": None
                    }
                }]
            }
            
            private_endpoint = self.network_client.private_endpoints.begin_create_or_update(
                self.resource_group_name,
                f"{self.webapp_name}-pe-webapp",
                private_endpoint_params
            )
            private_endpoint.result()
            # Create private DNS zone group
            private_dns_zone_group_params = {
                "privateDnsZoneConfigs": [{
                    "name": dns_zone.name,
                    "properties": {
                        "privateDnsZoneId": dns_zone.id
                    }
                }]
            }
            
            private_dns_zone_group = self.network_client.private_dns_zone_groups.begin_create_or_update(
                self.resource_group_name,
                f"{self.webapp_name}-pe-webapp",
                "default",
                private_dns_zone_group_params
            )
            private_dns_zone_group.result()
            
            logging.info(f"Private endpoint created for Web App {self.webapp_name}")
            logging.info(f"Web App {self.webapp_name} created successfully")
            return webapp_result.result().id
        except Exception as e:
            logging.error(f"Error creating Web App: {e}")
            raise

    def create_app_service_plan(self):
        try:
            logging.info(f"Creating App Service Plan {self.app_service_plan_name} in resource group {self.resource_group_name}")
            
            # Validate app service plan parameters
            if not self.app_service_plan_sku_name or not self.app_service_plan_sku_tier:
                raise ValueError("App service plan SKU name and tier are required")
                
            app_service_plan_params = {
                "location": self.location,
                "sku": {
                    "name": self.app_service_plan_sku_name.upper(),
                    "tier": self.app_service_plan_sku_tier,
                    "capacity": 1
                },
                "kind": "app",
                "reserved": True if self.os_type.lower() == "linux" else False,
                "tags": self.tags
            }
            
            app_service_plan_result = self.web_client.app_service_plans.begin_create_or_update(
                resource_group_name=self.resource_group_name,
                name=self.app_service_plan_name,
                app_service_plan=app_service_plan_params
            )
            logging.info(f"App Service Plan {self.app_service_plan_name} created successfully")
            return app_service_plan_result.result().id
        except Exception as e:
            logging.error(f"Error creating App Service Plan: {e}")
            raise