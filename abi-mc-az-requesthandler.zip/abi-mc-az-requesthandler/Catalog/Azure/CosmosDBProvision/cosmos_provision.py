from shared_code.cosmos_client import CosmosClient
from shared_code.private_endpoint_helper import PrivateEndpointHelper
from azure.mgmt.cosmosdb.models import DatabaseAccountCreateUpdateParameters, ConsistencyPolicy, Location, DatabaseAccountKind
import logging,json

class CosmosDBProvision:
    def __init__(self,json_data):   
        data = json.loads(json_data['Payload'])['payload']["data"]
        self.subscription_id = data['subscription_id']
        self.subscription_name = data['subscription_name']
        self.zone = json_data["Zone"].lower()
        self.resource_group_name = data['resource_group_name']
        self.database_name = data['cosmos_db_name']
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.tags = data['tags']
        self.location = data['location']
        self.offer_type = data['offer_type']
        self.consistency_level = data['consistency_policy']['consistency_level'] if data['consistency_policy']['consistency_level'] != '' else None
        self.max_interval_in_seconds = data['consistency_policy']['max_interval_in_seconds'] if data['consistency_policy']['max_interval_in_seconds'] != '' else None
        self.max_staleness_prefix = data['consistency_policy'].get('max_staleness_prefix') if data['consistency_policy'].get('max_staleness_prefix') != '' else None
        self.cosmos_client = CosmosClient().get_cosmos_mgmt_client(self.subscription_id,self.cloud)


    def provision_db(self):
        try:
            # Create consistency policy
            consistency_policy = ConsistencyPolicy(
                default_consistency_level=self.consistency_level,
                max_interval_in_seconds=self.max_interval_in_seconds,
                max_staleness_prefix=self.max_staleness_prefix
            )

            # Create location object for the primary region
            location = Location(
                location_name=self.location,
                failover_priority=0,
                is_zone_redundant=False
            )

            # Create database account parameters
            database_account = DatabaseAccountCreateUpdateParameters(
                location=self.location,
                tags=self.tags,
                kind=DatabaseAccountKind.GLOBAL_DOCUMENT_DB,
                consistency_policy=consistency_policy,
                locations=[location],
                database_account_offer_type=self.offer_type,
                is_virtual_network_filter_enabled=True,
                enable_automatic_failover=False,
                enable_multiple_write_locations=False,
                disable_key_based_metadata_write_access=True,
                public_network_access="Disabled"  # Disable public network access
            )

            # Create the Cosmos DB account
            cosmosdb = self.cosmos_client.database_accounts.begin_create_or_update(
                resource_group_name=self.resource_group_name,
                account_name=self.database_name,
                create_update_parameters=database_account
            ).result()

            subscriptions= {
                "2db7c27b-2f9f-4088-981b-2bd88c5c1905": {
                    "vnet_name": "PVT-VNET-GB-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-GB-PROD",
                    "subnet_name": "DB1"
                },
                "73f88e6b-3a35-4612-b550-555157e7059f": {
                    "vnet_name": "PVT-VNET-GB-NON-PROD",
                    "vnet_rg_name": "mgmtpvt-rg-gb-non-prod",
                    "subnet_name": "DB1"
                },
                "25137c49-ffa8-4cef-a4db-f8aaf059d980": {
                    "vnet_name": "PVT-VNET-NAZ-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-NAZ-NON-PROD",
                    "subnet_name": "DB"
                },
                "95c54dda-ae35-43c0-aeea-bcfc596674c1": {
                    "vnet_name": "PVT-VNET-NAZ-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-NAZ-PROD",
                    "subnet_name": "DB"
                },
                "c8642ed5-9766-43fa-b6cc-47f19181fa40": {
                    "vnet_name": "SAP-INFRA-VNET-NAZ-PROD",
                    "vnet_rg_name": "SAP-RG-NAZ-PROD",
                    "subnet_name": "SAP-PR-DB-SUB"
                },
                "fe70970a-8778-4bc4-83c4-a85c57c1efd3": {
                    "vnet_name": "PVT-VNET-MEX-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-MEX-NON-PROD",
                    "subnet_name": "DB"
                },
                "a6362b38-0f74-4c75-bcbb-719b38f04f75": {
                    "vnet_name": "PVT-VNET-MEX-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-MEX-PROD",
                    "subnet_name": "DB"
                },
                "3617a45e-beab-410a-9476-d6e000e1fb77": {
                    "vnet_name": "PVT-VNET-EU-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-EU-NON-PROD",
                    "subnet_name": "DB"
                },
                "1c1db8ee-5d54-460b-bd71-fd031be2a7e5": {
                    "vnet_name": "PVT-VNET-EU-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-EU-PROD",
                    "subnet_name": "DB"
                },
                "77a7f337-8588-4076-b526-5f1ce0e55671": {
                    "vnet_name": "PVT-VNET-AFR-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-AFR-PROD",
                    "subnet_name": "DB"
                },
                "15bcebd1-794e-49c6-9548-8a4a4357ee16": {
                    "vnet_name": "PVT-VNET-AFR-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-AFR-NON-PROD",
                    "subnet_name": "DB"
                },
                "30b7b23e-9325-4407-b613-610457afe869": {
                    "vnet_name": "PVT-E2-VNET-CN-PROD",
                    "vnet_rg_name": "MGMTPVT-E2-RG-CN-PROD",
                    "subnet_name": "DB"
                },
                "08ba6e07-14eb-4984-9176-9261b8a2781d": {
                    "vnet_name": "PVT-E2-VNET-CN-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-E2-RG-CN-NON-PROD",
                    "subnet_name": "DB"
                },
                "b413c513-77a1-4416-84d4-4057920111c6": {
                    "vnet_name": "PVT-VNET-KR-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-KR-NON-PROD",
                    "subnet_name": "DB"
                },
                "a831d6f9-cdd3-4d49-9dd5-9389dd3a1902": {
                    "vnet_name": "PVT-VNET-KR-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-KR-PROD",
                    "subnet_name": "DB"
                }
            }
            
            pe_helper = PrivateEndpointHelper(self.subscription_id, self.zone, self.cloud)
            sub_config = subscriptions[self.subscription_id]
            subnet_id = pe_helper.get_subnet_id(
                vnet_rg_name=sub_config['vnet_rg_name'],
                vnet_name=sub_config['vnet_name'],
                subnet_name=sub_config['subnet_name']
            )
            dns_zone_name = "privatelink.documents.azure.cn" if self.zone == "china" else "privatelink.documents.azure.com"
            pe_helper.create_private_endpoint(
                resource_group_name=self.resource_group_name,
                resource_id=cosmosdb.id,
                resource_name=self.database_name,
                location=self.location,
                subnet_id=subnet_id,
                group_ids=['SQL'],
                dns_zone_name=dns_zone_name,
                tags=self.tags
            )

            return cosmosdb.id
        except Exception as e:
            logging.error(f"Error provisioning database: {e}")
            raise e