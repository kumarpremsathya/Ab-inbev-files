from azure.mgmt.compute import ComputeManagementClient
from azure.mgmt.network import NetworkManagementClient
from azure.mgmt.compute.models import HardwareProfile, NetworkProfile, OSProfile, StorageProfile, VirtualMachine, VirtualMachineExtension, OSDisk, DiskCreateOption, VirtualHardDisk, NetworkInterfaceReference
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.resource.resources.models import ResourceGroup
from shared_code.client_secret_auth import ClientSecretAuth
from azure.mgmt.recoveryservices import RecoveryServicesClient
from azure.mgmt.recoveryservicesbackup.activestamp import RecoveryServicesBackupClient
from azure.mgmt.recoveryservicesbackup.activestamp.models import ProtectedItemResource
import os,logging,re,base64


 
class AzureVMCreation():
 
    def __init__(self, data):
        self.subscription_id = data.get('subscription_id')
        self.resource_group_name = data.get('resource_group_name')
        self.location = data.get('location')
        self.admin_username = data.get('admin_username')
        self.admin_password = data.get('admin_password')
        self.vm_size = data.get('vm_size')
        self.vm_count = data.get('vm_count')
        self.image_details = data.get('image_details')
        self.subnet_id = data.get('subnet_id')
        self.domain = data.get('domain')
        if self.image_details in ("WINDOWS2012R2", "WINDOWS2016", "WINDOWS2019", "WINDOWS2022"):
            self.domain_username = data.get('domain_username')
            self.domain_password = data.get('domain_password')
            self.os_type = 'Windows'
        else:
            self.os_type = 'Linux'
        if data.get('add_nic'):
            self.nic_count = data.get('extra_nic') + 1
        else:
            self.nic_count = 1
        if data.get('add_additional_disk'):
            self.data_disk_size2 = data.get('data_disk_size2')
            self.data_disk_size3 = data.get('data_disk_size3')
        self.apptier = data.get('apptier')
        if self.apptier == 'production':
            self.storage_account_type = 'Premium_LRS'
        else:
            self.storage_account_type = 'Standard_LRS'
        self.datacenter = data.get('datacenter')
        self.application = data.get('application')
        self.masterserver = data.get('masterserver')
        self.role = data.get('role')
        self.service = data.get('service')
        self.credential = ClientSecretAuth().client_credential(os.environ["SPN_SECRET_PUBLIC"])
        self.recovery_vault_rg_name = data.get('recovery_vault_rg_name')
        self.recovery_vault_name = data.get('recovery_vault_name')
        self.backup_policy_name = data.get('backup_policy_name')
        self.BusinessOwnerEmail = data.get('BusinessOwnerEmail')
        self.DevOwnerEmail = data.get('DevOwnerEmail')
        self.costcenter = data.get('costcenter')
        self.capeximpact = data.get('capeximpact')
        self.opeximpact = data.get('opeximpact')
        self.projectname = data.get('projectname')
        self.department = data.get('department')
        self.criticaity = data.get('criticaity')
        self.applicationuid = data.get('applicationuid')
        self.additional_users = data.get('domain_users')
        self.provisioner = data.get('provisioner')

    def hostname_prefix(self, domain):
        switch = {
            "AFRICA-NP" : "AAZVAPP",
            "ABI-AFRICA-PROD" : "AAZVAPP",
            "EU-NP" : "ONEAZAP3",
            "EU" : "ONEAZAP3",
            "GHQ-NP" : "ONEAZAP3",
            "GHQ" : "ONEAZAP3",
        }
        return switch.get(domain, "Invalid choice")
            
    
    def domain_details(self, domain):
        switch = {
            "AFRICA-NP" : "beerdivision.africa.gcn.local",
            "ABI-AFRICA-PROD" : "beerdivision.africa.gcn.local",
            "BREWDAT" : "one.ofc.loc",
            "CHINA" : "ap1.ofc.loc",
            "EU-NP" : "we.interbrew.net",
            "EU" : "we.interbrew.net",
            "GHQ-NP" : "one.ofc.loc",
            "GHQ" : "one.ofc.loc",
            "KR-NP" : "ob.co.kr",
            "KR" : "ob.co.kr",
            "MAZ" : "modelo.gmodelo.com.mx",
            "NAZ-NP" : "one.ofc.loc",
            "NAZ" : "one.ofc.loc",
            "SAP-AFRICA" : "one.ofc.loc",
            "SAP-GLOBAL" : "one.ofc.loc",
            "SAP-IPA" : "one.ofc.loc",
            "SAP-STOUT" : "one.ofc.loc"
        }
        return switch.get(domain, "Invalid choice")

    def image_reference(self, image_details):
        switch = {
            "CENTOS7" : {
                "publisher" : "OpenLogic",
                "offer" : "CentOS",
                "sku" : "7.5",
                "version" : "latest"
            },
            "CENTOS8" : {
                "publisher" : "OpenLogic",
                "offer" : "CentOS",
                "sku" : "8_2-gen2",
                "version" : "latest"
            },
            "RHEL7" : {
                "publisher" : "RedHat",
                "offer" : "RHEL",
                "sku" : "7.4",
                "version" : "latest"
            },
            "RHEL8" : {
                "publisher" : "RedHat",
                "offer" : "RHEL",
                "sku" : "82gen2",
                "version" : "latest"
            },
            "SUSE12" : {
                "publisher" : "SUSE",
                "offer" : "sles-sap-12-sp5",
                "sku" : "gen2",
                "version" : "latest"
            },
            "SUSE15" : {
                "publisher" : "SUSE",
                "offer" : "sles-sap-15-sp5",
                "sku" : "gen2",
                "version" : "latest"
            },
            "UBUNTU16" : {
                "publisher" : "Canonical",
                "offer" : "UbuntuServer",
                "sku" : "16.04-LTS",
                "version" : "latest"
            },
            "UBUNTU18" : {
                "publisher" : "Canonical",
                "offer" : "UbuntuServer",
                "sku" : "18.04-LTS",
                "version" : "18.04.202105120"
            },
            "UBUNTU20" : {
                "publisher" : "Canonical",
                "offer" : "0001-com-ubuntu-server-focal",
                "sku" : "20_04-LTS",
                "version" : "latest"
            },
            "UBUNTU22" : {
                "publisher" : "Canonical",
                "offer" : "0001-com-ubuntu-server-jammy",
                "sku" : "22_04-lts-gen2",
                "version" : "latest"
            },
            "WINDOWS2012R2" : {
                "publisher" : "MicrosoftWindowsServer",
                "offer" : "WindowsServer",
                "sku" : "2012-R2-Datacenter",
                "version" : "latest"
            },
            "WINDOWS2016" : {
                "publisher" : "MicrosoftWindowsServer",
                "offer" : "WindowsServer",
                "sku" : "2016-Datacenter",
                "version" : "latest"
            },
            "WINDOWS2019" : {
                "publisher" : "MicrosoftWindowsServer",
                "offer" : "WindowsServer",
                "sku" : "2019-Datacenter",
                "version" : "latest"
            },
            "WINDOWS2022" : {
                "publisher" : "MicrosoftWindowsServer",
                "offer" : "WindowsServer",
                "sku" : "2022-Datacenter",
                "version" : "latest"
            }
        }
        return switch.get(image_details, "Invalid choice")
        
        
    def resource_group(self):
        resource_client = ResourceManagementClient(self.credential, self.subscription_id)
        try:
            resource_group = resource_client.resource_groups.get(self.resource_group_name)
            logging.info("Resource group '{}' already exists.".format(self.resource_group_name))
            return resource_group
        except Exception as e:
            logging.info("Resource group '{}' not found. Creating...".format(self.resource_group_name))
            resource_group_params = ResourceGroup(location=self.location)
            resource_group_params.tags = {'CostCenter': self.costcenter}
            resource_group = resource_client.resource_groups.create_or_update(
                self.resource_group_name, resource_group_params)
            logging.info("Resource group '{}' created successfully.".format(self.resource_group_name))
            return resource_group
        
    def windows_extension(self, compute_client, vm_name, str_users):
        windows_domain_extension_parameters = VirtualMachineExtension(
            location=self.location,
            publisher='Microsoft.Compute',
            type_properties_type= 'JsonADDomainExtension',
            type_handler_version= '1.3',
            settings= {
                "Name": self.domain_details(self.domain),
                "User": 'ONE\\'+self.domain_username,
                "OUPath": "OU=Windows,OU=SAPHana,OU=Servers,OU=Zone-ABI Global,DC=ONE,DC=OFC,DC=LOC",
                "Restart": "false",
                "Options": "3",
                "NumberOfRetries": "2",
                "UnjoinDomainUser": 'ONE\\'+self.domain_username
            },
            protected_settings= {
                "Password": self.domain_password,
                "UnjoinDomainPassword": self.domain_password
            }
        )

        encoded_bytes = base64.b64encode(str_users.encode('utf-8'))
        encoded_str = encoded_bytes.decode('utf-8')
        command = f"powershell.exe -ExecutionPolicy Unrestricted -File abicloud-puppet-agent-win.ps1 -environment {self.apptier} -zone {self.datacenter} -application {self.application} -master {self.masterserver} -role {self.role} -service {self.service} -provisioner {self.provisioner} -user {encoded_str}"

        windows_puppet_extension_parameters = VirtualMachineExtension(
            location=self.location,
            publisher='Microsoft.Compute',
            type_properties_type= 'CustomScriptExtension',
            type_handler_version= '1.9',
            settings= {
                'fileUris': ["https://devopsstoragegbprod.blob.core.windows.net/vm-scripts/abicloud-puppet-agent-win.ps1?sp=r&st=2024-07-25T07:39:54Z&se=2026-07-25T15:39:54Z&spr=https&sv=2022-11-02&sr=b&sig=tGwi3jivO0kiXx9ZZr9nQ9gGJAfmXpfKM3wwr7Pkdsk%3D"]
            },
            protected_settings= {
                'commandToExecute': command
            },
            auto_upgrade_minor_version= True
        )

        async_extension_creation_domain = compute_client.virtual_machine_extensions.begin_create_or_update(
            self.resource_group_name,
            vm_name,
            vm_name + '_domain',
            windows_domain_extension_parameters
        )
        async_extension_creation_domain.wait()
        async_extension_creation_puppet = compute_client.virtual_machine_extensions.begin_create_or_update(
            self.resource_group_name,
            vm_name,
            vm_name + '_config',
            windows_puppet_extension_parameters
        )
        async_extension_creation_puppet.wait()

    def linux_extension(self, compute_client, vm_name, str_users):
        script = f"""
                    Users="{str_users}"
                    echo "Users Value"
                    echo $Users
                    domain="{self.domain_details(self.domain)}"
                    apptier="{self.apptier}"
                    datacenter="{self.datacenter}"
                    platform="{self.provisioner}"
                    application="{self.application}"
                    role="{self.role}"
                    service="{self.service}" 
                    masterserver="{self.masterserver}"
                    hostsFile="/etc/hosts"
                    ip="$(hostname -I)"
                    host_name="$(hostname | cut -f1 -d.)"
                    domain_name=$domain
                    fqdn="$host_name.$domain_name"
                    host_entry="$ip $fqdn $host_name"
                    if [ -n "$(grep -P "$fqdn" $hostsFile)" ]; then
                        echo "$host_entry, already exists:";
                    else
                        echo "Adding $host_entry...";
                        echo "$host_entry" >> "$hostsFile"
                    fi
                    curl -k https://$masterserver:8140/packages/current/install.bash | sudo bash -s \
                      extension_requests:pp_environment=new \
                      extension_requests:1.3.6.1.4.1.34380.1.2.1=true \
                      extension_requests:pp_apptier=$apptier \
                      extension_requests:pp_datacenter=$datacenter \
                      extension_requests:pp_application=$application \
                      extension_requests:pp_role=$role \
                      extension_requests:pp_service=$service \
                      extension_requests:pp_provisioner=$platform \
                      extension_requests:pp_created_by="$Users"
                 """
        encoded_script = base64.b64encode(script.encode('utf-8')).decode('utf-8')

        linux_puppet_extension_parameters = VirtualMachineExtension(
            location=self.location,
            publisher='Microsoft.Azure.Extensions',
            type_properties_type= 'CustomScript',
            type_handler_version= '2.1',
            settings={
            'script': encoded_script
            },
            protected_settings={},
            auto_upgrade_minor_version= True
        )

        async_extension_creation = compute_client.virtual_machine_extensions.begin_create_or_update(
                self.resource_group_name,
                vm_name,
                vm_name + '_config',
                linux_puppet_extension_parameters
            )
        async_extension_creation.wait()


    def create_backup(self, vm_name):
        recovery_services_backup_client = RecoveryServicesBackupClient(self.credential, self.subscription_id)
        vm_id = '/subscriptions/{}/resourceGroups/{}/providers/Microsoft.Compute/virtualMachines/{}'.format(self.subscription_id, self.resource_group_name, vm_name)
        policy_id = '/subscriptions/{}/resourceGroups/{}/providers/Microsoft.RecoveryServices/vaults/{}/backupPolicies/{}'.format(self.subscription_id, self.recovery_vault_rg_name, self.recovery_vault_name, self.backup_policy_name)
        protected_item_type = 'Microsoft.Compute/virtualMachines'
        protected_item_config = ProtectedItemResource(
            properties={
                "policy_id": policy_id,
                "source_resource_id": vm_id,
                "protected_item_type": protected_item_type
            }
        )

        recovery_services_backup_client.protected_items.create_or_update(
            vault_name=self.recovery_vault_name,
            resource_group_name=self.recovery_vault_rg_name,
            fabric_name='Azure',
            container_name="IaasVMContainer;iaasvmcontainerv2;"+self.resource_group_name+";"+vm_name,
            protected_item_name="vm;iaasvmcontainerv2;"+self.resource_group_name+";"+vm_name,
            parameters=protected_item_config
        )    
        logging.info("VM '{}' backup policy created '{}'".format(vm_name, self.backup_policy_name))
    
    def get_highest_vm_number(self, compute_client, hostname):
        vms = compute_client.virtual_machines.list_all()
        max_number = 0
        for vm in vms:
            name = vm.name
            match = re.match(rf"{hostname}(\d+)", name)
            if match:
                number = int(match.group(1))
                if number > max_number:
                    max_number = number
        # logging.info(max_number)
        return max_number
        
    def create_vm(self):
        self.resource_group()
        compute_client = ComputeManagementClient(self.credential, self.subscription_id)
        network_client = NetworkManagementClient(self.credential, self.subscription_id)
        nic_ids = []
        for i in range(1,self.vm_count+1):
            suffix = self.get_highest_vm_number(compute_client,self.hostname_prefix(self.domain))+1
            vm_name = f'{self.hostname_prefix(self.domain)}{suffix:03}'
            nic_ids = []
            for j in range(1,self.nic_count+1):
                async_nic_creation = network_client.network_interfaces.begin_create_or_update(
                    self.resource_group_name,
                    vm_name + '_nic' + str(j),
                    {
                        'location': self.location,
                        'ip_configurations': [{
                            'name': vm_name + '_ip_config' + str(j),
                            'subnet': {'id': self.subnet_id},
                            'enable_accelerated_networking': True
                        }]
                    }
                )
                network_interface = async_nic_creation.result()
                nic_ids.append(network_interface.id)

            network_profile = NetworkProfile(
                network_interfaces=[
                    NetworkInterfaceReference(id=nic_id, primary=(index == 0)) 
                    for index, nic_id in enumerate(nic_ids)
                ]
            )

            hardware_profile = HardwareProfile(vm_size=self.vm_size)

            os_profile = OSProfile(
                computer_name=vm_name,
                admin_username=self.admin_username,
                admin_password=self.admin_password
            )

            os_disk = OSDisk(
                caching='ReadWrite',
                create_option=DiskCreateOption.from_image,
                managed_disk=VirtualHardDisk(
                    storage_account_type=self.storage_account_type
                ),
                disk_size_gb=128,
                name=vm_name + '_osdisk',
                os_type=self.os_type
            )
            
            data_disks = []

            if self.data_disk_size2:
                data_disks.append({
                    'lun': 0,
                    'disk_size_gb': int(self.data_disk_size2),
                    'managed_disk': {
                        'storage_account_type': self.storage_account_type
                    },
                    'create_option': DiskCreateOption.empty
                })

            if self.data_disk_size3:
                data_disks.append({
                    'lun': 1,
                    'disk_size_gb': int(self.data_disk_size3),
                    'managed_disk': {
                        'storage_account_type': self.storage_account_type
                    },
                    'create_option': DiskCreateOption.empty
                })

            
            storage_profile = StorageProfile(
                os_disk=os_disk,
                image_reference=self.image_reference(self.image_details),
                data_disks=[
                    {
                        'lun': disk['lun'],
                        'disk_size_gb': disk['disk_size_gb'],
                        'managed_disk': {
                            'storage_account_type': disk['managed_disk']['storage_account_type']
                        },
                        'create_option': disk['create_option']
                    }
                    for disk in data_disks
                ]
            )
            
            tags = {
                'BusinessOwnerEmail': self.BusinessOwnerEmail,
                'DevOwnerEmail': self.DevOwnerEmail,
                'CostCenter' : self.costcenter,
                'CapexImpact' : self.capeximpact,
                'OpexImpact' : self.opeximpact,
                'ProjectName' : self.projectname,
                'Department' : self.department,
                'Criticality' : self.criticaity,
                'ApplicationUID' : self.applicationuid,
            }

            vm_parameters = VirtualMachine(
                location=self.location,
                tags=tags,
                os_profile=os_profile,
                hardware_profile=hardware_profile,
                network_profile=network_profile,
                storage_profile=storage_profile
            )

            
            async_vm_creation = compute_client.virtual_machines.begin_create_or_update(self.resource_group_name, vm_name, vm_parameters)
            async_vm_creation.wait()
            Users = self.additional_users
            str_user = ', '.join(Users)
            # print(str_user)
            str_user = str_user.replace(" ' ", " ")
            str_user = str_user.replace("\\\\", "\\")
            str_users = str(str_user)
            logging.info(str_users)
            if self.image_details in ("CENTOS7", "CENTOS8", "RHEL7", "RHEL8", "SUSE12", "SUSE15", "UBUNTU16", "UBUNTU18", "UBUNTU20", "UBUNTU22"):
                self.linux_extension(compute_client, vm_name, str_users)
                logging.info("VM '{}' created with NIC '{}'".format(vm_name, vm_name + '_nic'))
            elif self.image_details in ("WINDOWS2012R2", "WINDOWS2016", "WINDOWS2019", "WINDOWS2022"):
                self.windows_extension(compute_client, vm_name, str_users)
                logging.info("VM '{}' created with NIC '{}'".format(vm_name, vm_name + '_nic'))
            else:
                logging.info('wrong image details')

            self.create_backup(vm_name)
            
            








