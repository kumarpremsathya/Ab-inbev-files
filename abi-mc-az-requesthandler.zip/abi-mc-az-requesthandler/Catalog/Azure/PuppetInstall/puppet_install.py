import logging,base64,json,os,ldap3
from azure.mgmt.compute.models import VirtualMachineExtension
from shared_code.compute_client import ComputeClient
from shared_code.akv_secrets import AkvSecrets


class PuppetInstall:
    def __init__(self,json_data):
        data = json.loads(json_data['Payload'])['payload']["data"]
        self.subscription_id = data["subscription_id"]
        self.resource_group_name = data["resource_group_name"]
        self.zone = json_data["Zone"].lower()
        self.envrionment = data["environment"].lower()
        self.location = data["vm_location"]
        self.domain = data["vm_hostname"]
        self.members = data["member_ids"]
        self.str_users = ",".join([f"{self.get_domain_prefix(user['domain'])}\\{user['id']}" for user in data["member_ids"]])
        self.application = data.get('puppet_role','')
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.compute_client = ComputeClient().get_compute_client(self.subscription_id, self.cloud)
        self.secret = AkvSecrets(os.environ["KEYVAULT_URI"],'domain-join').get_tokens()


    def get_domain_prefix(self,domain):
        match domain.lower():
            case "one.ofc.loc":
                return "ONE"
            case "we.interbrew.net":
                return "WEINTERBREW"
            case "na.interbrew.net":
                return "NA1"
            case "beerdivision.africa.gcn.local":
                return "BEERSA"
            case "ob.co.kr":
                return "ob.co.kr"
            case "modelo.gmodelo.com.mx":
                return "MODELO"
            # TODO: Add more domain cases as needed
            case _:
                return domain.split(".")[0].upper()
    
    def get_puppet_details(self):
        switch = {
            "naz": [{
            "Zone": "NAZ",
            "apptier": "production",
            "domain": "one.ofc.loc",
            "master_domain": "glazlxpepmp01.one.ofc.loc",
            "masterserver": "peadmin.ab-inbev.com",
            "ip":"172.18.210.55",
            },
           {
            "Zone": "NAZ-NP",
            "apptier": "development",
            "domain": "one.ofc.loc",
            "master_domain": "glazlxpepmp01.one.ofc.loc",
            "masterserver": "peadmin.ab-inbev.com",
            "ip":"172.18.210.55",
            }],
            "ghq": [{
            "Zone": "GHQ",
            "apptier": "production",
            "domain": "one.ofc.loc",
            "master_domain": "glazlxpepmp01.one.ofc.loc",
            "masterserver": "peadmin.ab-inbev.com",
            "ip":"172.18.210.55",
            },
            {
            "Zone": "GHQ-NP",
            "apptier": "development",
            "domain": "one.ofc.loc",
            "master_domain": "glazlxpepmp01.one.ofc.loc",
            "masterserver": "peadmin.ab-inbev.com",
            "ip":"172.18.210.55",
            }],
            "brewdat": [{
            "Zone": "BREWDAT",
            "apptier": "production",
            "domain": "one.ofc.loc",
            "master_domain": "glazlxpepmp01.one.ofc.loc",
            "masterserver": "peadmin.ab-inbev.com",
            "ip":" 172.18.210.55",
            },
            {
            "Zone": "BREWDAT",
            "apptier": "development",
            "domain": "one.ofc.loc",
            "master_domain": "glazlxpepmp01.one.ofc.loc",
            "masterserver": "peadmin.ab-inbev.com",
            "ip":"172.18.210.55",
            }],
            "europe": [{
            "Zone": "EU-PRD",
            "apptier": "production",
            "domain": "we.interbrew.net",
            "master_domain": "glazlxpepmp01.one.ofc.loc",
            "masterserver": "peadmin.ab-inbev.com",
            "ip":"172.18.210.55",
            },
            {
            "Zone": "EU-NP",
            "apptier": "development",
            "domain": "we.interbrew.net",
            "master_domain": "glazlxpepmp01.one.ofc.loc",
            "masterserver": "peadmin.ab-inbev.com",
            "ip":"172.18.210.55",
            }],
            "africa": [{
            "Zone": "ABI-AFRICA-PROD",
            "apptier": "production",
            "domain": "beerdivision.africa.gcn.local",
            "master_domain": "glazlxpepmp01.one.ofc.loc",
            "masterserver": "peadmin.ab-inbev.com",
            "ip":"172.18.210.55",
            },
            {
            "Zone": "AFRICA-NP",
            "apptier": "development",
            "domain": "beerdivision.africa.gcn.local",
            "master_domain": "glazlxpepmp01.one.ofc.loc",
            "masterserver": "peadmin.ab-inbev.com",
            "ip":"172.18.210.55",
            }],
            "korea": [{
            "Zone": "KR-Prod",
            "apptier": "production",
            "domain": "ob.co.kr",
            "master_domain": "glazlxpepmp01.one.ofc.loc",
            "masterserver": "peadmin.ab-inbev.com",
            "ip":"172.18.210.55",
            },
            {
            "Zone": "KR-NP",
            "apptier": "development",
            "domain": "ob.co.kr",
            "master_domain": "glazlxpepmp01.one.ofc.loc",
            "masterserver": "peadmin.ab-inbev.com",
            "ip":"172.18.210.55",
            }],
            "china": [{
            "Zone": "CHINA",
            "apptier": "production",
            "domain": "api.ofc.loc",
            "master_domain": "puppetcnp001.ap1.ofc.loc",
            "masterserver": "puppet.ab-inbev.cn",
            "ip":"172.18.250.211",
            },
            {
            "Zone": "CHINA",
            "apptier": "development",
            "domain": "api.ofc.loc",
            "master_domain": "puppetcnp001.ap1.ofc.loc",
            "masterserver": "puppet.ab-inbev.cn",
            "ip":"172.18.250.211",
            }],
            "maz": [{
            "Zone": "MAZ",
            "apptier": "production",
            "domain": "modelo.gmodelo.com.mx",
            "master_domain": "azupmap001.modelo.gmodelo.com.mx",
            "masterserver": "puppet.modelo.gmodelo.com.mx",
            "ip":"172.18.218.166",
            },
            {
            "Zone": "MAZ",
            "apptier": "development",
            "domain": "modelo.gmodelo.com.mx",
            "master_domain": "azupmap001.modelo.gmodelo.com.mx",
            "masterserver": "puppet.modelo.gmodelo.com.mx",
            "ip":"172.18.218.166",
            }]
        }
        for puppet_detail in switch[self.zone]:
            if puppet_detail["apptier"] == self.envrionment.lower():
                self.puppet_zone = puppet_detail["Zone"]
                self.apptier = puppet_detail["apptier"]
                self.domain = puppet_detail["domain"]
                self.masterserver = puppet_detail["masterserver"]
                self.masterdomain = puppet_detail["master_domain"]
                self.ip = puppet_detail["ip"]
                break
    
    def get_password(self,user):
        password = json.loads(self.secret.value).get(user)
        return password
    
    def create_ad_group(self,vm_name):
        if self.zone.lower() == "europe":
            try:
                username = "WEINTERBREW\\azure.svc.we"
                server_name = 'weaerdc001.we.interbrew.net'
                base_dn = 'OU=Server Admins,OU=Administrative Groups,OU=Groups,OU=ABI-IBS-EU-EuropeDC1 (Amsterdam),DC=we,DC=interbrew,DC=net'
                server = f"ldap://{server_name}"
                password = self.get_password(username.split('\\')[1])
                group_name = f"G-SWED-WE-{vm_name}-LocalAdmins"
                ldap_server = ldap3.Server(server, get_info=ldap3.ALL)
                conn = ldap3.Connection(ldap_server, user=username, password=password, auto_bind=True)
                group_dn = f'cn={group_name},' + base_dn
                #users = [user.split('\\\\')[1] for user in self.str_users.split(',')]
                users_dn = []
                #for user in users:
                for user in self.members:
                    if user['domain'].lower() == 'we.interbrew.net' and conn.search("DC=we,DC=interbrew,DC=net", f'(&(objectClass=user)(sAMAccountName=*{user["id"]}*))', attributes=['distinguishedName']):
                        users_dn.append(f"{conn.entries[0]['distinguishedName']}")
                    if user['domain'].lower() == 'one.ofc.loc' and conn.search("OU=Zone-ABI Global,OU=Managed Objects,OU=Managed Users,OU=Active Users,OU=Employee,DC=one,DC=ofc,DC=loc", f'(&(objectClass=user)(sAMAccountName=*{user["id"]}*))', attributes=['distinguishedName']):
                        users_dn.append(f"{conn.entries[0]['distinguishedName']}")
                if not conn.search(base_dn, f'(cn={group_name})', attributes=['member']):
                    group = conn.add(
                        group_dn,
                        object_class=['top', 'group'],
                        attributes={
                            'sAMAccountName': group_name,
                            'groupType': -2147483644  # DOMAIN_LOCAL_GROUP | SECURITY_ENABLED
                        }
                    )
                for dn in users_dn:
                    if not conn.modify(group_dn, {'member': [(ldap3.MODIFY_ADD, [dn])]}):
                        continue
                self.str_users = f"WEINTERBREW\\{group_name}"
            except Exception as e:
                logging.error(f"Failed to create group {group_name}: {e}")

    def windows_extension(self,vm_name):
        self.get_puppet_details()
        self.create_ad_group(vm_name)
        try: 
            str_users = base64.b64encode(self.str_users.encode('utf-8')).decode('utf-8')
            with open(os.path.join('Catalog','Azure','PuppetInstall','puppet_install.ps1'), 'rb') as f:
                ps_script = base64.b64encode(f.read()).decode('utf-8')
            command = (
                "powershell.exe -Command \""
                f"$b64='{ps_script}'; $bytes=[Convert]::FromBase64String($b64); "
                "[IO.File]::WriteAllBytes('C:\\Windows\\Temp\\puppet_install.ps1', $bytes); "
                f"powershell.exe -ExecutionPolicy Bypass -File C:\\Windows\\Temp\\puppet_install.ps1 "
                f"-environment 'new' -zone '{self.puppet_zone}'  {'-application ' + self.application if self.application else ''} "
                f"-master '{self.masterserver}' -apptier {self.apptier} {'-user ' + str_users if str_users else ''} -provisioner BREWMATION\""
            )
            windows_puppet_extension_parameters = VirtualMachineExtension(
                location=self.location,
                publisher='Microsoft.Compute',
                type_properties_type='CustomScriptExtension',
                type_handler_version='1.9',
                protected_settings={
                    'commandToExecute': command
                },
                auto_upgrade_minor_version=True
            )

            async_extension_creation_puppet = self.compute_client.virtual_machine_extensions.begin_create_or_update(
                self.resource_group_name,
                vm_name,
                vm_name + '_puppet',
                windows_puppet_extension_parameters
            )
            result = async_extension_creation_puppet.result()
            logging.info(f"Puppet Extension created for VM: {vm_name} - {result}")
            return result.id
        except Exception as e:
            logging.error(e)
            raise e

    def linux_extension(self,vm_name):
        self.get_puppet_details()
        try:
            script = f"""
                        Users="{self.str_users}"
                        echo "Users Value"
                        echo $Users
                        domain="{self.domain}"
                        apptier="{self.apptier}"
                        datacenter="{self.puppet_zone}"
                        platform="BREWMATION"
                        application="{self.application}"
                        masterserver="{self.masterserver}"
                        masterdomain="{self.masterdomain}"
                        role=""
                        puppet_ip="{self.ip}"
                        hostsFile="/etc/hosts"
                        ip="$(hostname -I)"
                        host_name="$(hostname | cut -f1 -d.)"
                        domain_name=$domain
                        fqdn="$host_name.$domain_name"
                        host_entry="$ip $fqdn $host_name"
                        if [ -n "$(grep -P "$fqdn" $hostsFile)" ]; then
                            echo "$host_entry, already exists:";
                        else
                            echo "Adding $host_entry...";
                            echo "$host_entry" >> "$hostsFile"
                        fi
                        host_entry="$puppet_ip $masterserver $masterdomain"
                        if [ -n "$(grep -P "$masterserver" $hostsFile)" ]; then
                            echo "$host_entry, already exists:";
                        else
                            echo "Adding $host_entry...";
                            echo "$host_entry" >> "$hostsFile"
                        fi
                        curl -k https://$masterserver:8140/packages/current/install.bash | sudo bash -s \
                        extension_requests:pp_environment=new \
                        extension_requests:1.3.6.1.4.1.34380.1.2.1=true \
                        extension_requests:pp_apptier=$apptier \
                        extension_requests:pp_datacenter=$datacenter \
                        extension_requests:pp_application=$application \
                        extension_requests:pp_provisioner=$platform \
                        extension_requests:pp_created_by="$Users"
                    """
            encoded_script = base64.b64encode(script.encode('utf-8')).decode('utf-8')

            linux_puppet_extension_parameters = VirtualMachineExtension(
                location=self.location,
                publisher='Microsoft.Azure.Extensions',
                type_properties_type= 'CustomScript',
                type_handler_version= '2.1',
                settings={
                'script': encoded_script
                },
                protected_settings={},
                auto_upgrade_minor_version= True
            )

            async_extension_creation = self.compute_client.virtual_machine_extensions.begin_create_or_update(
                    self.resource_group_name,
                    vm_name,
                    vm_name + '_puppet',
                    linux_puppet_extension_parameters
                )
            result = async_extension_creation.result()
            logging.info(f"Puppet Extension created for VM: {vm_name} - {result}")
            return result.id
        except Exception as e:
            logging.error(e)
            raise e