Param(
    [Parameter(Mandatory=$true)]
    [string]$zone,
    [Parameter(Mandatory=$true)]
    [string]$environment,
    [Parameter()]
    [string]$application,
    [Parameter(Mandatory=$true)]
    [string]$master,
    [Parameter(Mandatory=$true)]
    [string]$apptier,
    [Parameter()]
    [string]$role,
    [Parameter()]
    [string]$service,
    [Parameter(Mandatory=$true)]
    [string]$provisioner,
    [Parameter()]
    [string]$user
)
$env:SEE_MASK_NOZONECHECKS=1
Write-Host "Setting TLS protocol version"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Write-Host "Disabling TLS certificate validation"
[Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}
Write-Host "Downloading the install script"
$webClient = New-Object System.Net.WebClient
$webClient.DownloadFile("https://$($master):8140/packages/current/install.ps1", 'C:\Windows\Temp\install.ps1')
$decodedBytes = [Convert]::FromBase64String($user)
$decodedString = [System.Text.Encoding]::UTF8.GetString($decodedBytes)
Write-Host "Executing the install script..."
powershell.exe -ExecutionPolicy Unrestricted -File C:\Windows\Temp\install.ps1 -v extension_requests:pp_environment=$environment extension_requests:1.3.6.1.4.1.34380.1.2.1=true extension_requests:pp_apptier=$apptier extension_requests:pp_datacenter=$zone extension_requests:pp_application=$application extension_requests:pp_role=$role extension_requests:pp_service=$service extension_requests:pp_provisioner=$provisioner extension_requests:pp_created_by=$decodedString
Write-Host "Adding users to the Administrators group"
if ($user -ne $null -and $user -ne "") {
    $decodedBytes = [Convert]::FromBase64String($user)
    $decodedString = [System.Text.Encoding]::UTF8.GetString($decodedBytes)
    $userList = $decodedString -split ","
    foreach ($u in $userList) {
        $trimmedUser = $u.Trim()
        Write-Host "Adding user $trimmedUser to Administrators group"
        Add-LocalGroupMember -Group "Administrators" -Member $trimmedUser
    }
} else {
    Write-Host "No users provided to add to the Administrators group"
}