from shared_code.datafactorymgmt_client import DatafactoryClient
from shared_code.networkmgmt_client import NetworkMgmtClient
from shared_code.privatedns_client import PrivateDNSClient
from shared_code.dns_zone_helper import DnsZoneHelper
import json,logging

class DatafactoryProvision:
    def __init__(self,json_data):
        data = json.loads(json_data['Payload'])['payload']["data"]
        self.zone = json_data["Zone"].lower()
        self.tags = data["tags"]
        self.subscription_id = data["subscription_id"]
        self.resource_group_name = data["resource_group_name"]
        self.location = data["location"]
        self.datafactory_name = data["datafactory_name"]
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.redis_client = DatafactoryClient().get_datafactory_client(self.subscription_id,self.cloud)
        self.network_client = NetworkMgmtClient().get_network_mgmt_client(self.subscription_id,self.cloud)
        self.dns_client = PrivateDNSClient().get_dns_client(self.subscription_id,self.cloud)

    def create_datafactory(self):
        try:
            # Map subscription_id to vnet/subnet info
            subscription_map = {
                "2db7c27b-2f9f-4088-981b-2bd88c5c1905": {
                    "vnet_name": "PVT-VNET-GB-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-GB-PROD",
                    "subnet_name": "DB1"
                },
                "73f88e6b-3a35-4612-b550-555157e7059f": {
                    "vnet_name": "PVT-VNET-GB-NON-PROD",
                    "vnet_rg_name": "mgmtpvt-rg-gb-non-prod",
                    "subnet_name": "DB1"
                },
                "25137c49-ffa8-4cef-a4db-f8aaf059d980": {
                    "vnet_name": "PVT-VNET-NAZ-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-NAZ-NON-PROD",
                    "subnet_name": "DB"
                },
                "95c54dda-ae35-43c0-aeea-bcfc596674c1": {
                    "vnet_name": "PVT-VNET-NAZ-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-NAZ-PROD",
                    "subnet_name": "DB"
                },
                "c8642ed5-9766-43fa-b6cc-47f19181fa40": {
                    "vnet_name": "SAP-INFRA-VNET-NAZ-PROD",
                    "vnet_rg_name": "SAP-RG-NAZ-PROD",
                    "subnet_name": "SAP-PR-DB-SUB"
                },
                "fe70970a-8778-4bc4-83c4-a85c57c1efd3": {
                    "vnet_name": "PVT-VNET-MEX-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-MEX-NON-PROD",
                    "subnet_name": "DB"
                },
                "a6362b38-0f74-4c75-bcbb-719b38f04f75": {
                    "vnet_name": "PVT-VNET-MEX-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-MEX-PROD",
                    "subnet_name": "DB"
                },
                "3617a45e-beab-410a-9476-d6e000e1fb77": {
                    "vnet_name": "PVT-VNET-EU-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-EU-NON-PROD",
                    "subnet_name": "DB"
                },
                "1c1db8ee-5d54-460b-bd71-fd031be2a7e5": {
                    "vnet_name": "PVT-VNET-EU-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-EU-PROD",
                    "subnet_name": "DB"
                },
                "77a7f337-8588-4076-b526-5f1ce0e55671": {
                    "vnet_name": "PVT-VNET-AFR-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-AFR-PROD",
                    "subnet_name": "DB"
                },
                "15bcebd1-794e-49c6-9548-8a4a4357ee16": {
                    "vnet_name": "PVT-VNET-AFR-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-AFR-NON-PROD",
                    "subnet_name": "DB"
                },
                "30b7b23e-9325-4407-b613-610457afe869": {
                    "vnet_name": "PVT-E2-VNET-CN-PROD",
                    "vnet_rg_name": "MGMTPVT-E2-RG-CN-PROD",
                    "subnet_name": "DB"
                },
                "08ba6e07-14eb-4984-9176-9261b8a2781d": {
                    "vnet_name": "PVT-E2-VNET-CN-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-E2-RG-CN-NON-PROD",
                    "subnet_name": "DB"
                },
                "b413c513-77a1-4416-84d4-4057920111c6": {
                    "vnet_name": "PVT-VNET-KR-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-KR-NON-PROD",
                    "subnet_name": "DB"
                },
                "a831d6f9-cdd3-4d49-9dd5-9389dd3a1902": {
                    "vnet_name": "PVT-VNET-KR-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-KR-PROD",
                    "subnet_name": "DB"
                }
            }

            sub_map = subscription_map.get(self.subscription_id)
            if not sub_map:
                raise Exception(f"Subscription {self.subscription_id} not mapped for Data Factory provisioning.")

            # 1. Create Data Factory
            df_params = {
                "location": self.location,
                "identity": {"type": "SystemAssigned"},
                "tags": self.tags,
                "version": "V2",
                "properties": {
                    "publicNetworkAccess": "Disabled"
                }
            }
            df_poller = self.redis_client.factories.create_or_update(
                self.resource_group_name,
                self.datafactory_name,
                df_params
            )
            df_id = df_poller.id
            logging.info(f"Data Factory created: {df_id}")

            # 2. Get Subnet Resource
            subnet = self.network_client.subnets.get(
                sub_map["vnet_rg_name"],
                sub_map["vnet_name"],
                sub_map["subnet_name"]
            )
            subnet_id = subnet.id

            # 3. Get Private DNS Zone for Data Factory
            if self.subscription_id in ["30b7b23e-9325-4407-b613-610457afe869", "08ba6e07-14eb-4984-9176-9261b8a2781d"]:
                dns_zone_name = "privatelink.datafactory.azure.cn"
                dns_zone_portal_name = "privatelink.adf.azure.cn"
            else:
                dns_zone_name = "privatelink.datafactory.azure.net"
                dns_zone_portal_name = "privatelink.adf.azure.com"

            dns_client, dns_rg = DnsZoneHelper.get_dns_client_for_zone(self.subscription_id, self.zone, self.cloud)
            dns_zone = dns_client.private_zones.get(
                dns_rg,
                dns_zone_name
            )
            dns_zone_portal = dns_client.private_zones.get(
                dns_rg,
                dns_zone_portal_name
            )

            # 4. Create Private Endpoint for Data Factory
            pe_name = f"{self.datafactory_name}-pe-datafactory"
            pe_params = {
                "location": self.location,
                "subnet": {"id": subnet_id},
                "private_link_service_connections": [{
                    "name": f"{self.datafactory_name}-pe-datafactory-connection",
                    "private_link_service_id": df_id,
                    "group_ids": ["dataFactory"]
                }],
                "private_dns_zone_groups": [{
                    "name": f"{self.datafactory_name}-private-dns-zone-group",
                    "private_dns_zone_ids": [dns_zone.id]
                }],
                "tags": self.tags
            }
            pe_poller = self.network_client.private_endpoints.begin_create_or_update(
                self.resource_group_name,
                pe_name,
                pe_params
            )
            pe_result = pe_poller.result()
            pe_id = pe_result.id
            logging.info(f"Private Endpoint for Data Factory created: {pe_id}")

            # 5. Create Private Endpoint for Data Factory Portal
            pe_portal_name = f"{self.datafactory_name}-pe-datafactory-portal"
            pe_portal_params = {
                "location": self.location,
                "subnet": {"id": subnet_id},
                "private_link_service_connections": [{
                    "name": f"{self.datafactory_name}-pe-datafactory-portal-connection",
                    "private_link_service_id": df_id,
                    "group_ids": ["portal"]
                }],
                "private_dns_zone_groups": [{
                    "name": f"{self.datafactory_name}-private-dns-zone-group",
                    "private_dns_zone_ids": [dns_zone_portal.id]
                }],
                "tags": self.tags
            }
            pe_portal_poller = self.network_client.private_endpoints.begin_create_or_update(
                self.resource_group_name,
                pe_portal_name,
                pe_portal_params
            )
            pe_portal_result = pe_portal_poller.result()
            pe_portal_id = pe_portal_result.id
            logging.info(f"Private Endpoint for Data Factory Portal created: {pe_portal_id}")

            return {
                "datafactory_id": df_id,
                "private_endpoint_datafactory_id": pe_id,
                "private_endpoint_datafactory_portal_id": pe_portal_id
            }
        except Exception as e:
            logging.error(f"Failed to provision Data Factory: {e}")
            raise