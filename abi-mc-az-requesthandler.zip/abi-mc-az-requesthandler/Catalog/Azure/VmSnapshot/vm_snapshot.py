import logging,datetime
from shared_code.compute_client import ComputeClient
from shared_code.resourcemgmt_client import ResourceMgmtClient
from shared_code.lock_manager import LockManager

class AzVMSnapshot:
    def __init__(self,data):
        self.data = data
        self.subscription_id = data["SubscriptionId"]
        self.resource_group_name = data["ResourceGroupName"]
        self.resource_name = data["ResourceName"]
        self.resource_id = data["ResourceId"]
        self.zone = data['Zone'].lower()
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.compute_client = ComputeClient().get_compute_client(self.subscription_id, self.cloud)
        self.resource_client = ResourceMgmtClient().get_resource_client(self.cloud,self.subscription_id)
        self.lock_client = LockManager(self.subscription_id, self.zone, self.resource_group_name)
    
    def create_snaphot(self):
        try:
            self.lock_client.remove_all_locks(lock_types=["ReadOnly"])
            location = self.resource_client.resource_groups.get(self.resource_group_name).location
            os_disk = self.compute_client.virtual_machines.get(self.resource_group_name, self.resource_name).storage_profile.os_disk
            os_disk_id = os_disk.managed_disk.id
            logging.info(f"Creating snapshot for {self.resource_name}")
            snapshot = self.compute_client.snapshots.begin_create_or_update(
                self.resource_group_name,
                f"{self.resource_name}_OsDisk_Snapshot_{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}_Brewmation",
                {
                    "location": location,
                    "creation_data": {
                            "create_option": "Copy",
                            "source_uri": os_disk_id
                    },
                    "sku": {
                        "name": "Standard_LRS",
                        "tier": "Standard" 
                    }
                }
            )
            snapshot.wait()
            logging.info(f"Snapshot created successfully")
            return snapshot.result().id
        except Exception as e:
            logging.error(f"Error creating snapshot: {e}")
            raise e
        finally:
            self.lock_client.restore_locks()