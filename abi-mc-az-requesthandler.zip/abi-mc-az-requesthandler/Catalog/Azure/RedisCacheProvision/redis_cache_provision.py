from shared_code.storage_client import StorageClient
from shared_code.rediscachemgmt_client import RedisClient
from shared_code.networkmgmt_client import NetworkMgmtClient
from shared_code.privatedns_client import PrivateDNSClient
from shared_code.dns_zone_helper import DnsZoneHelper
import json,logging

class RedisCacheProvision:
    def __init__(self,json_data):
        data = json.loads(json_data['Payload'])['payload']["data"]
        self.zone = json_data["Zone"].lower()
        self.tags = data["tags"]
        self.subscription_id = data["subscription_id"]
        self.resource_group_name = data["resource_group_name"]
        self.location = data["location"]
        self.redis_cache_name = data["redis_cache_name"]
        self.redis_family = data["redis_family"]
        self.redis_cache_sku = data["redis_cache_sku"]
        self.shard_count = data.get("shard_count", 1)
        self.replicas_per_master = data.get("replicas_per_master", 1)
        self.capacity = data["capacity"]
        self.enable_non_ssl_port = data["enable_non_ssl_port"]
        self.enable_backup = data["enable_backup"]
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.storage_client = StorageClient().get_storage_client(self.subscription_id,self.cloud)
        self.redis_client = RedisClient().get_redis_client(self.subscription_id,self.cloud)
        self.network_client = NetworkMgmtClient().get_network_mgmt_client(self.subscription_id,self.cloud)
        self.dns_client = PrivateDNSClient().get_dns_client(self.subscription_id,self.cloud)

    def create_redis_cache(self):
        try:
            redis_params = {
                "location": self.location,
                "sku": {
                    "name": self.redis_cache_sku,
                    "family": self.redis_family,
                    "capacity": self.capacity
                },
                "enable_non_ssl_port": self.enable_non_ssl_port,
                "minimum_tls_version": "1.2",
                "public_network_access": "Disabled",
                "tags": self.tags
            }

            # Only set Premium-specific properties if SKU is Premium
            if self.redis_cache_sku.lower() == "premium":
                redis_params["replicas_per_master"] = self.replicas_per_master
                redis_params["shard_count"] = self.shard_count

                # Redis configuration for backup
                redis_configuration = {}
                if self.enable_backup:
                    # Lookup storage account info for this subscription
                    subscription_map = {
                        "2db7c27b-2f9f-4088-981b-2bd88c5c1905": {
                            "storage_account_name": "mgmtgbpsecuritystorage",
                            "storage_account_rg_name": "mgmtoms-rg-gb-prod"
                        },
                        "73f88e6b-3a35-4612-b550-555157e7059f": {
                            "storage_account_name": "mgmtgbnpsecuritystorage",
                            "storage_account_rg_name": "MGMTOMS-RG-GB-NON-PROD"
                        },
                        "25137c49-ffa8-4cef-a4db-f8aaf059d980": {
                            "storage_account_name": "mgmtnaznpsecuritystorage",
                            "storage_account_rg_name": "MGMTOMS-RG-NAZ-NON-PROD"
                        },
                        "95c54dda-ae35-43c0-aeea-bcfc596674c1": {
                            "storage_account_name": "mgmtnazpsecuritystorage",
                            "storage_account_rg_name": "MGMTOMS-RG-NAZ-PROD"
                        },
                        "c8642ed5-9766-43fa-b6cc-47f19181fa40": {
                            "storage_account_name": "mgmtnazsapr3bootdiag",
                            "storage_account_rg_name": "MGMTOMS-RG-NAZ-SAP-R3"
                        },
                        "fe70970a-8778-4bc4-83c4-a85c57c1efd3": {
                            "storage_account_name": "mgmtmaznpsecuritystorage",
                            "storage_account_rg_name": "MGMTOMS-RG-MEX-NON-PROD"
                        },
                        "a6362b38-0f74-4c75-bcbb-719b38f04f75": {
                            "storage_account_name": "mgmtmazpsecuritystorage",
                            "storage_account_rg_name": "MGMTOMS-RG-MEX-PROD"
                        },
                        "3617a45e-beab-410a-9476-d6e000e1fb77": {
                            "storage_account_name": "mgmteunpsecuritystorage",
                            "storage_account_rg_name": "MGMTOMS-RG-EU-NON-PROD"
                        },
                        "1c1db8ee-5d54-460b-bd71-fd031be2a7e5": {
                            "storage_account_name": "mgmteupsecuritystorage",
                            "storage_account_rg_name": "MGMTOMS-RG-EU-PROD"
                        },
                        "77a7f337-8588-4076-b526-5f1ce0e55671": {
                            "storage_account_name": "mgmtafpsecuritystorage",
                            "storage_account_rg_name": "MGMTOMS-RG-AFR-PROD"
                        },
                        "15bcebd1-794e-49c6-9548-8a4a4357ee16": {
                            "storage_account_name": "mgmtafnpsecuritystorage",
                            "storage_account_rg_name": "MGMTOMS-RG-AFR-NON-PROD"
                        },
                        "30b7b23e-9325-4407-b613-610457afe869": {
                            "storage_account_name": "mgmtcnpsecuritystorage",
                            "storage_account_rg_name": "MGMTOMS-E2-RG-CN-PROD"
                        },
                        "08ba6e07-14eb-4984-9176-9261b8a2781d": {
                            "storage_account_name": "mgmtcnnonprodbootdiag",
                            "storage_account_rg_name": "MGMTOMS-E2-RG-CN-NON-PROD"
                        },
                        "b413c513-77a1-4416-84d4-4057920111c6": {
                            "storage_account_name": "mgmtkrnpsecuritystorage",
                            "storage_account_rg_name": "MGMTOMS-RG-KR-NON-PROD"
                        },
                        "a831d6f9-cdd3-4d49-9dd5-9389dd3a1902": {
                            "storage_account_name": "mgmtkrpsecuritystorage",
                            "storage_account_rg_name": "MGMTOMS-RG-KR-PROD"
                        }
                    }
                    sub_map = subscription_map.get(self.subscription_id)
                    if sub_map:
                        storage_account_name = sub_map["storage_account_name"]
                        storage_account_rg = sub_map["storage_account_rg_name"]
                        # Get storage account keys
                        storage_account = self.storage_client.storage_accounts.get_properties(
                            storage_account_rg, storage_account_name
                        )
                        keys = self.storage_client.storage_accounts.list_keys(
                            storage_account_rg, storage_account_name
                        )
                        connection_string = (
                            f"DefaultEndpointsProtocol=https;"
                            f"AccountName={storage_account_name};"
                            f"AccountKey={keys.keys[0].value};"
                            f"EndpointSuffix=core.windows.net;"
                        )
                        redis_configuration["rdb_backup_enabled"] = True
                        redis_configuration["rdb_storage_connection_string"] = connection_string
                        redis_configuration["rdb_backup_frequency"] = "60" 
                if redis_configuration:
                    redis_params["redis_configuration"] = redis_configuration

            # Create or update Redis Cache
            poller = self.redis_client.redis.begin_create(
                self.resource_group_name,
                self.redis_cache_name,
                redis_params
            )
            redis_resource = poller.result()

            vnet_map = {
                "2db7c27b-2f9f-4088-981b-2bd88c5c1905": {
                    "vnet_name": "PVT-VNET-GB-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-GB-PROD",
                    "subnet_name": "Webapp"
                },
                "73f88e6b-3a35-4612-b550-555157e7059f": {
                    "vnet_name": "PVT-VNET-GB-NON-PROD",
                    "vnet_rg_name": "mgmtpvt-rg-gb-non-prod",
                    "subnet_name": "Webapp"
                },
                "25137c49-ffa8-4cef-a4db-f8aaf059d980": {
                    "vnet_name": "PVT-VNET-NAZ-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-NAZ-NON-PROD",
                    "subnet_name": "Webapp"
                },
                "95c54dda-ae35-43c0-aeea-bcfc596674c1": {
                    "vnet_name": "PVT-VNET-NAZ-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-NAZ-PROD",
                    "subnet_name": "Webapp"
                },
                "c8642ed5-9766-43fa-b6cc-47f19181fa40": {
                    "vnet_name": "SAP-INFRA-VNET-NAZ-PROD",
                    "vnet_rg_name": "SAP-RG-NAZ-PROD",
                    "subnet_name": "SAP-PR-DB-SUB"
                },
                "fe70970a-8778-4bc4-83c4-a85c57c1efd3": {
                    "vnet_name": "PVT-VNET-MEX-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-MEX-NON-PROD",
                    "subnet_name": "Webapp"
                },
                "a6362b38-0f74-4c75-bcbb-719b38f04f75": {
                    "vnet_name": "PVT-VNET-MEX-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-MEX-PROD",
                    "subnet_name": "Webapp"
                },
                "3617a45e-beab-410a-9476-d6e000e1fb77": {
                    "vnet_name": "PVT-VNET-EU-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-EU-NON-PROD",
                    "subnet_name": "Webapp"
                },
                "1c1db8ee-5d54-460b-bd71-fd031be2a7e5": {
                    "vnet_name": "PVT-VNET-EU-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-EU-PROD",
                    "subnet_name": "Webapp"
                },
                "77a7f337-8588-4076-b526-5f1ce0e55671": {
                    "vnet_name": "PVT-VNET-AFR-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-AFR-PROD",
                    "subnet_name": "Webapp"
                },
                "15bcebd1-794e-49c6-9548-8a4a4357ee16": {
                    "vnet_name": "PVT-VNET-AFR-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-AFR-NON-PROD",
                    "subnet_name": "Webapp-1"
                },
                "30b7b23e-9325-4407-b613-610457afe869": {
                    "vnet_name": "PVT-E2-VNET-CN-PROD",
                    "vnet_rg_name": "MGMTPVT-E2-RG-CN-PROD",
                    "subnet_name": "Webapp"
                },
                "08ba6e07-14eb-4984-9176-9261b8a2781d": {
                    "vnet_name": "PVT-E2-VNET-CN-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-E2-RG-CN-NON-PROD",
                    "subnet_name": "Webapp"
                },
                "b413c513-77a1-4416-84d4-4057920111c6": {
                    "vnet_name": "PVT-VNET-KR-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-KR-NON-PROD",
                    "subnet_name": "Webapp"
                },
                "a831d6f9-cdd3-4d49-9dd5-9389dd3a1902": {
                    "vnet_name": "PVT-VNET-KR-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-KR-PROD",
                    "subnet_name": "Webapp"
                }
            }
            vnet_info = vnet_map.get(self.subscription_id)
            if not vnet_info:
                raise Exception(f"VNet info not found for subscription {self.subscription_id}")

            subnet = self.network_client.subnets.get(
                vnet_info["vnet_rg_name"],
                vnet_info["vnet_name"],
                vnet_info["subnet_name"]
            )
            subnet_id = subnet.id

            # Determine DNS zone name
            if self.subscription_id in ["30b7b23e-9325-4407-b613-610457afe869", "08ba6e07-14eb-4984-9176-9261b8a2781d"]:
                dns_zone_name = "privatelink.redis.cache.chinacloudapi.cn"
            else:
                dns_zone_name = "privatelink.redis.cache.windows.net"

            dns_client, dns_rg = DnsZoneHelper.get_dns_client_for_zone(self.subscription_id, self.zone, self.cloud)
            try:
                dns_zone = dns_client.private_zones.get(
                    resource_group_name=dns_rg,
                    private_zone_name=dns_zone_name
                )
            except Exception as e:
                if "ResourceNotFound" in str(e):
                    dns_zone = dns_client.private_zones.begin_create_or_update(
                        resource_group_name=dns_rg,
                        private_zone_name=dns_zone_name,
                        parameters={
                            "location": "global",
                            "properties": {
                                "max_number_of_record_sets": 25000,
                                "max_number_of_virtual_network_links": 1000,
                                "max_number_of_virtual_network_links_with_registration": 100,
                            }
                        }
                    ).result()
                else:
                    raise

            pe_name = f"{self.redis_cache_name}-pe-webapp"
            pe_params = {
                "location": self.location,
                "subnet": {"id": subnet_id},
                "private_link_service_connections": [
                    {
                        "name": f"{self.redis_cache_name}-pe-webapp-connection",
                        "private_link_service_id": redis_resource.id,
                        "group_ids": ["redisCache"]
                    }
                ],
                "custom_dns_configs": [],
                "manual_private_link_service_connections": None
            }

            # Add DNS zone group
            pe_params["private_dns_zone_groups"] = [
                {
                    "name": f"{self.redis_cache_name}-private-dns-zone-group",
                    "private_dns_zone_configs": [
                        {
                            "name": dns_zone_name,
                            "private_dns_zone_id": dns_zone.id
                        }
                    ]
                }
            ]

            pe_poller = self.network_client.private_endpoints.begin_create_or_update(
                self.resource_group_name,
                pe_name,
                pe_params
            )
            pe_result = pe_poller.result()
            return redis_resource.id
        except Exception as e:
            logging.error(f"Error creating Redis Cache: {e}")
            raise e