from shared_code.storage_client import StorageClient
from shared_code.website_client import WebSiteClient
from shared_code.networkmgmt_client import NetworkMgmtClient
from shared_code.privatedns_client import PrivateDNSClient
from azure.mgmt.web.models import AzureStorageType
import json,logging,uuid,ipaddress
from azure.mgmt.resource.resources.models import DeploymentMode
from shared_code.resourcemgmt_client import ResourceMgmtClient

class FunctionAppProvision:
    def __init__(self):
        pass
    def __init__(self,json_data):
        data = json.loads(json_data['Payload'])['payload']["data"]
        self.zone = json_data["Zone"].lower()
        self.tags = data["tags"]
        self.subscription_id = data["subscription_id"]
        self.resource_group_name = data["resource_group_name"]
        self.location = data["location"]
        self.publish_type = data["functionapp_publish_type"]
        self.environament = data["environment"]
        self.function_app_name = data["function_name"]
        self.os_type = data["functionapp_os_type"]
        self.runtime_stack = data["functionapp_runtime_stack"]
        self.runtime_version = data["functionapp_runtime_stack"].split('|')[-1]
        self.storage_type = data["storage_type"]
        self.storage_id = data["storage_account_plan_id"]
        self.storage_account_name = data["storage_account_name"]
        self.app_service_plan_type = data["app_service_plan_type"]
        self.app_service_plan_name = data["app_service_plan_name"]
        self.app_service_plan_id = data["app_service_plan_id"]
        self.app_service_plan_sku_name = data["app_service_plan_sku"].split(':')[0].strip()
        self.app_service_plan_sku_tier = data["app_service_plan_sku_tier"]
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.storage_client = StorageClient().get_storage_client(self.subscription_id,self.cloud)
        self.web_client = WebSiteClient().get_web_client(self.subscription_id,self.cloud)
        self.network_client = NetworkMgmtClient().get_network_mgmt_client(self.subscription_id,self.cloud)
        self.dns_client = PrivateDNSClient().get_dns_client(self.subscription_id,self.cloud)
        self.resource_client = ResourceMgmtClient().get_resource_client(self.cloud,self.subscription_id,)

    def get_subnet_address_prefix(self,vnet_rg_name,vnet_name,subscription_id):
        client = NetworkMgmtClient().get_network_mgmt_client(subscription_id,self.cloud)
        vnet =client.virtual_networks.get(resource_group_name=vnet_rg_name,virtual_network_name=vnet_name)
        existing_subnets = vnet.subnets or []
        vnet_address_spaces = vnet.address_space.address_prefixes
        vnet_network = ipaddress.ip_network(vnet_address_spaces[0])
        used_subnets = [ipaddress.ip_network(subnet.address_prefix) for subnet in existing_subnets]
        def find_available_subnet(vnet_network, used_subnets, new_prefix=28):
            # Generate all possible subnets with the desired prefix length inside the VNet
            for subnet in vnet_network.subnets(new_prefix=new_prefix):
                # Check if this subnet overlaps any existing subnet
                if any(subnet.overlaps(used) for used in used_subnets):
                    continue
                return subnet
            return None
        available_subnet = find_available_subnet(vnet_network, used_subnets)
        if available_subnet is None:
            raise Exception("No available subnet range found in the VNet.")
        return str(available_subnet)

    def create_function_app(self):
        try:
            logging.info(f"Creating Function App in resource group {self.resource_group_name}")
            subscription_to_network = {
                # ABI Global Prod
                "2db7c27b-2f9f-4088-981b-2bd88c5c1905": {
                    "vnet_name": "PVT-VNET-GB-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-GB-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # ABI Global Non-Prod
                "73f88e6b-3a35-4612-b550-555157e7059f": {
                    "vnet_name": "PVT-VNET-GB-NON-PROD",
                    "vnet_rg_name": "mgmtpvt-rg-gb-non-prod",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # ABI NAZ Non-Prod
                "25137c49-ffa8-4cef-a4db-f8aaf059d980": {
                    "vnet_name": "PVT-VNET-NAZ-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-NAZ-NON-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # ABI NAZ Prod
                "95c54dda-ae35-43c0-aeea-bcfc596674c1": {
                    "vnet_name": "PVT-VNET-NAZ-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-NAZ-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # ABI NAZ SAP R3
                "c8642ed5-9766-43fa-b6cc-47f19181fa40": {
                    "vnet_name": "SAP-INFRA-VNET-NAZ-PROD",
                    "vnet_rg_name": "SAP-RG-NAZ-PROD",
                    "subnet_name": "SAP-PR-APP-SUB",
                    "subnet_name1": "SAP-PR-DB-SUB"
                },
                # ABI MAZ Non-Prod
                "fe70970a-8778-4bc4-83c4-a85c57c1efd3": {
                    "vnet_name": "PVT-VNET-MEX-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-MEX-NON-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra",
                    "pe_vnet_name": "PAAS_INTEG_VNET-MEX_NO_PRD",
                    "pe_vnet_rg_name": "Infraestructura",
                    "pe_subnet_storageaccount": "StorageAccount",
                    "pe_subnet_keyvault": "KeyVaults",
                    "pe_subnet_db": "Data",
                    "pe_subnet_services": "Services",
                    "pe_subnet_logicapp": "LogicApps",
                    "pe_subnet_functionapp": "DATA"
                },
                # ABI MAZ Prod
                "a6362b38-0f74-4c75-bcbb-719b38f04f75": {
                    "vnet_name": "PVT-VNET-MEX-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-MEX-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra",
                    "pe_vnet_name": "PAAS_INTEG_VNET-MEX_PRD",
                    "pe_vnet_rg_name": "Infraestructura",
                    "pe_subnet_storageaccount": "DATA",
                    "pe_subnet_keyvault": "KeyVaults",
                    "pe_subnet_db": "Data",
                    "pe_subnet_services": "Services",
                    "pe_subnet_logicapp": "LogicApps",
                    "pe_subnet_functionapp": "Functions"
                    
                },
                # ABI EU Non-Prod
                "3617a45e-beab-410a-9476-d6e000e1fb77": {
                    "vnet_name": "PVT-VNET-EU-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-EU-NON-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # ABI EU Prod
                "1c1db8ee-5d54-460b-bd71-fd031be2a7e5": {
                    "vnet_name": "PVT-VNET-EU-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-EU-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # ABI Africa Prod
                "77a7f337-8588-4076-b526-5f1ce0e55671": {
                    "vnet_name": "PVT-VNET-AFR-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-AFR-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # ABI Africa Non-Prod
                "15bcebd1-794e-49c6-9548-8a4a4357ee16": {
                    "vnet_name": "PVT-VNET-AFR-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-AFR-NON-PROD",
                    "subnet_name": "Webapp-1",
                    "subnet_name1": "Infra"
                },
                # ABI China Prod
                "30b7b23e-9325-4407-b613-610457afe869": {
                    "vnet_name": "PVT-E2-VNET-CN-PROD",
                    "vnet_rg_name": "MGMTPVT-E2-RG-CN-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # ABI China Non-Prod
                "08ba6e07-14eb-4984-9176-9261b8a2781d": {
                    "vnet_name": "PVT-E2-VNET-CN-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-E2-RG-CN-NON-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # ABI KR Non-Prod
                "b413c513-77a1-4416-84d4-4057920111c6": {
                    "vnet_name": "PVT-VNET-KR-NON-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-KR-NON-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                },
                # ABI KR Prod
                "a831d6f9-cdd3-4d49-9dd5-9389dd3a1902": {
                    "vnet_name": "PVT-VNET-KR-PROD",
                    "vnet_rg_name": "MGMTPVT-RG-KR-PROD",
                    "subnet_name": "WebApp",
                    "subnet_name1": "Infra"
                }
            }

            if self.subscription_id not in subscription_to_network:
                raise ValueError(f"Subscription ID {self.subscription_id} not found in network configuration")

            network_config = subscription_to_network[self.subscription_id]
            webapp_subnet = self.network_client.subnets.get(
                resource_group_name=network_config["vnet_rg_name"],
                virtual_network_name=network_config["vnet_name"],
                subnet_name=network_config["subnet_name"]
            )
            infra_subnet = self.network_client.subnets.get(
                resource_group_name=network_config["vnet_rg_name"], 
                virtual_network_name=network_config["vnet_name"],
                subnet_name=network_config["subnet_name1"]
            )
            subnet_ids = [webapp_subnet.id, infra_subnet.id]

            if self.storage_type.lower() == "new":

                storage_account = self.storage_client.storage_accounts.begin_create(
                    resource_group_name=self.resource_group_name,
                    account_name=self.storage_account_name,
                    parameters={
                        "sku": {
                            "name": "Standard_LRS"
                        },
                        "kind": "StorageV2",
                        "location": self.location,
                        "tags": self.tags,
                        "properties": {
                            "supportsHttpsTrafficOnly": True,
                            "minimumTlsVersion": "TLS1_2",
                            "allowBlobPublicAccess": False,  # Set blob service public access level to Private
                            "networkAcls": {
                                "defaultAction": "Deny",
                                "bypass": "AzureServices",
                                "virtualNetworkRules": [
                                    {"id": subnet_id} for subnet_id in subnet_ids
                                ],
                                "ipRules": []
                            }
                        }
                    }
                ).result()
                if self.subscription_id in ('fe70970a-8778-4bc4-83c4-a85c57c1efd3','a6362b38-0f74-4c75-bcbb-719b38f04f75'):
                    maz_subnet = self.network_client.subnets.get(
                        resource_group_name=network_config["pe_vnet_rg_name"], 
                        virtual_network_name=network_config["pe_vnet_name"],
                        subnet_name=network_config["pe_subnet_storageaccount"]
                    )
                    dns_client = PrivateDNSClient().get_dns_client("a6362b38-0f74-4c75-bcbb-719b38f04f75",self.cloud)
                    private_endpoint = self.network_client.private_endpoints.begin_create_or_update(
                        resource_group_name=self.resource_group_name,
                        private_endpoint_name=f"{self.storage_account_name}-pe-blob",
                        parameters={
                            "location": self.location,
                            "subnet": {
                                "id": maz_subnet.id
                            },
                            "privateLinkServiceConnections": [{
                                "name": f"{self.storage_account_name}-pe-blob-connection",
                                "properties": {
                                    "privateLinkServiceId": storage_account.id,
                                    "groupIds": ["blob"],
                                    "requestMessage": None
                                }
                            }],
                            "tags": self.tags
                        }
                    ).result()
                    private_dns_zone = dns_client.private_zones.get(
                        resource_group_name="MGMTPVT-RG-MEX-PROD",
                        private_zone_name="privatelink.blob.core.windows.net"
                    )
                    private_dns_zone_group_params = {
                    "privateDnsZoneConfigs": [{
                        "name": f"{self.storage_account_name}-pe-blob-dnsconfig",
                        "properties": {
                            "privateDnsZoneId": private_dns_zone.id
                            }
                        }]
                    } 
                    private_dns_zone_group = self.network_client.private_dns_zone_groups.begin_create_or_update(
                        self.resource_group_name,
                        f"{self.storage_account_name}-pe-blob",
                        "default",
                        private_dns_zone_group_params
                    )
                    private_dns_zone_group.result()

                    private_endpoint = self.network_client.private_endpoints.begin_create_or_update(
                        resource_group_name=self.resource_group_name,
                        private_endpoint_name=f"{self.storage_account_name}-pe-file",
                        parameters={
                            "location": self.location,
                            "subnet": {
                                "id": maz_subnet.id
                            },
                            "privateLinkServiceConnections": [{
                                "name": f"{self.storage_account_name}-pe-file-connection",
                                "properties": {
                                    "privateLinkServiceId": storage_account.id,
                                    "groupIds": ["file"],
                                    "requestMessage": None
                                }
                            }],
                            "tags": self.tags
                        }
                    ).result()
                    private_dns_zone = dns_client.private_zones.get(
                        resource_group_name="MGMTPVT-RG-MEX-PROD",
                        private_zone_name="privatelink.file.core.windows.net"
                    )
                    private_dns_zone_group_params = {
                    "privateDnsZoneConfigs": [{
                        "name": f"{self.storage_account_name}-pe-file-dnsconfig",
                        "properties": {
                            "privateDnsZoneId": private_dns_zone.id
                            }
                        }]
                    } 
                    private_dns_zone_group = self.network_client.private_dns_zone_groups.begin_create_or_update(
                        self.resource_group_name,
                        f"{self.storage_account_name}-pe-file",
                        "default",
                        private_dns_zone_group_params
                    )
                    private_dns_zone_group.result()
                    private_endpoint = self.network_client.private_endpoints.begin_create_or_update(
                        resource_group_name=self.resource_group_name,
                        private_endpoint_name=f"{self.storage_account_name}-pe-queue",
                        parameters={
                            "location": self.location,
                            "subnet": {
                                "id": maz_subnet.id
                            },
                            "privateLinkServiceConnections": [{
                                "name": f"{self.storage_account_name}-pe-queue-connection",
                                "properties": {
                                    "privateLinkServiceId": storage_account.id,
                                    "groupIds": ["queue"],
                                    "requestMessage": None
                                }
                            }],
                            "tags": self.tags
                        }
                    ).result()
                    private_dns_zone = dns_client.private_zones.get(
                        resource_group_name="MGMTPVT-RG-MEX-PROD",
                        private_zone_name="privatelink.queue.core.windows.net"
                    )
                    private_dns_zone_group_params = {
                        "privateDnsZoneConfigs": [{
                            "name": f"{self.storage_account_name}-pe-queue-dnsconfig",
                            "properties": {
                                "privateDnsZoneId": private_dns_zone.id
                            }
                        }]
                    }
                    private_dns_zone_group = self.network_client.private_dns_zone_groups.begin_create_or_update(
                        self.resource_group_name,
                        f"{self.storage_account_name}-pe-queue",
                        "default",
                        private_dns_zone_group_params
                    )
                    private_dns_zone_group.result()
                    private_endpoint = self.network_client.private_endpoints.begin_create_or_update(
                        resource_group_name=self.resource_group_name,
                        private_endpoint_name=f"{self.storage_account_name}-pe-table",
                        parameters={
                            "location": self.location,
                            "subnet": {
                                "id": maz_subnet.id
                            },
                            "privateLinkServiceConnections": [{
                                "name": f"{self.storage_account_name}-pe-table-connection",
                                "properties": {
                                    "privateLinkServiceId": storage_account.id,
                                    "groupIds": ["table"],
                                    "requestMessage": None
                                }
                            }],
                            "tags": self.tags
                        }
                    ).result()
                    private_dns_zone = dns_client.private_zones.get(
                        resource_group_name="MGMTPVT-RG-MEX-PROD",
                        private_zone_name="privatelink.table.core.windows.net"
                    )
                    private_dns_zone_group_params = {
                        "privateDnsZoneConfigs": [{
                            "name": f"{self.storage_account_name}-pe-table-dnsconfig",
                            "properties": {
                                "privateDnsZoneId": private_dns_zone.id
                            }
                        }]
                    }
                    private_dns_zone_group = self.network_client.private_dns_zone_groups.begin_create_or_update(
                        self.resource_group_name,
                        f"{self.storage_account_name}-pe-table",
                        "default",
                        private_dns_zone_group_params
                    )
                    private_dns_zone_group.result()


                storage_account_id = storage_account.id
            else:
                storage_account_id = self.storage_id
            
            # Get storage account key
            storage_keys = self.storage_client.storage_accounts.list_keys(
                resource_group_name=storage_account_id.split("/")[4],
                account_name=self.storage_account_name
            )
            storage_key = storage_keys.keys[0].value
            storage_account_kind = self.storage_client.storage_accounts.get_properties(
                resource_group_name=storage_account_id.split("/")[4],
                account_name=self.storage_account_name
            ).kind

            # Create function app
            # Create app service plan
            if self.app_service_plan_type.lower() == "new":
                try:
                    app_service_plan = self.web_client.app_service_plans.begin_create_or_update(
                        resource_group_name=self.resource_group_name,
                        name=self.app_service_plan_name,
                        app_service_plan={
                            "location": self.location,
                            "sku": {
                                "name": self.app_service_plan_sku_name,
                                "tier": self.app_service_plan_sku_tier,
                                "capacity": 1
                            },
                            "kind": "elastic" if "premium" in self.app_service_plan_sku_tier.lower() else "app",
                            "tags": self.tags,
                            "properties": {
                                "elasticScaleEnabled": True if "premium" in self.app_service_plan_sku_tier.lower() else False,
                                "maximumElasticWorkerCount": 20 if "premium" in self.app_service_plan_sku_tier.lower() else None,
                                "reserved": True if self.publish_type.lower() == "container" or self.os_type.lower() == "linux" else False
                            }
                        }
                    ).result()
                except Exception as e:
                        logging.error(f"App Service Plan creation failed: {e}")
                        raise e
                app_service_plan_id = app_service_plan.id
            else :
                app_service_plan = self.web_client.app_service_plans.get(
                    resource_group_name=self.app_service_plan_id.split("/")[4],
                    name=self.app_service_plan_id.split("/")[-1]
                )
                app_service_plan_id = app_service_plan.id

            # Create function app
            if storage_account_kind in ["BlobStorage", "BlockBlobStorage"]:
                site_envelope = {
                    "location": self.location,
                    "tags": self.tags,
                    "kind": "functionapp",
                    "identity": {
                        "type": "SystemAssigned"
                    },
                    "properties": {
                    "serverFarmId": app_service_plan_id,
                    "publicNetworkAccess": "Disabled",  # Disable public network access
                    "httpsOnly": True,  # Enforce HTTPS only
                    "siteConfig": {
                        "appSettings": [
                            {
                                "name": "AzureWebJobsStorage",
                                "value": f"DefaultEndpointsProtocol=https;AccountName={self.storage_account_name};AccountKey={storage_key};EndpointSuffix=core.windows.net"
                            },
                            {
                                "name": "FUNCTIONS_EXTENSION_VERSION", 
                                "value": "~4"
                            },
                            {
                                "name": "FUNCTIONS_WORKER_RUNTIME",
                                "value": self.runtime_stack.split("|")[0]
                            },
                            {
                                "name": "WEBSITE_RUN_FROM_PACKAGE" if self.publish_type.lower() == "code" else "DOCKER_REGISTRY_SERVER_URL",
                                "value": "1" if self.publish_type.lower() == "code" else "https://mcr.microsoft.com"
                            },
                        ],
                        "http20Enabled": True,
                        "linuxFxVersion": f"{self.runtime_stack}" if self.os_type.lower() == "linux" and self.publish_type.lower() == "code" else "DOCKER|mcr.microsoft.com/azure-functions/dotnet:4-dotnet8.0-appservice" if self.publish_type.lower() == "container" else None,
                        "pythonVersion": self.runtime_version if self.runtime_stack.lower().startswith("python") and self.os_type.lower() == "windows" and self.publish_type.lower() == "code" else None,
                        "nodeVersion": self.runtime_version if self.runtime_stack.lower().startswith("node") and self.os_type.lower() == "windows" and self.publish_type.lower() == "code" else None,
                        "javaVersion": self.runtime_version if self.runtime_stack.lower().startswith("java") and self.os_type.lower() == "windows" and self.publish_type.lower() == "code" else None,
                        "powerShellVersion": self.runtime_version if self.runtime_stack.lower().startswith("powershell") and self.os_type.lower() == "windows" and self.publish_type.lower() == "code" else None,
                        }
                    }
                }
                function_app = self.web_client.web_apps.begin_create_or_update(
                    resource_group_name=self.resource_group_name,
                    name=self.function_app_name,
                    site_envelope=site_envelope
                ).result()
            else:
                content_share_base = ''.join(ch for ch in self.function_app_name.lower() if ch.isalnum())
                if not content_share_base:
                    content_share_base = "func"
                content_share = f"{content_share_base[:58]}{uuid.uuid4().hex.lower()[0:5]}"
                arm_template = {
                    "$schema": "https://schema.management.azure.com/schemas/2015-01-01/deploymentTemplate.json#",
                    "contentVersion": "1.0.0.0",
                    # Build resources list and filter out None values to avoid invalid ARM template
                    "resources": list(filter(
                        None,
                        [
                            {
                                "name": self.function_app_name,
                                "apiVersion": "2022-03-01",
                                "type": "Microsoft.Web/sites",
                                "location": self.location,
                                "tags": self.tags,
                                "kind": "functionapp",
                                "identity": {
                                    "type": "SystemAssigned"
                                },
                                "properties": {
                                    "name": self.function_app_name,
                                    "serverFarmId": app_service_plan_id,
                                    "clientAffinityEnabled": False,
                                    "virtualNetworkSubnetId": None,
                                    "functionsRuntimeAdminIsolationEnabled": False,
                                    "vnetContentShareEnabled": True,
                                    "publicNetworkAccess": "Disabled",  # Disable public network access
                                    "httpsOnly": True,  # Enforce HTTPS only
                                    "siteConfig": {
                                        "appSettings": list(filter(
                                            lambda s: s["name"] is not None and s["value"] is not None,
                                            [
                                                {
                                                    "name": "AzureWebJobsStorage",
                                                    "value": f"[concat('DefaultEndpointsProtocol=https;AccountName=','{storage_account_id.split('/')[-1]}',';AccountKey=',listKeys(resourceId('{storage_account_id.split('/')[2]}','{storage_account_id.split('/')[4]}','Microsoft.Storage/storageAccounts', '{storage_account_id.split('/')[-1]}'), '2022-05-01').keys[0].value,';EndpointSuffix=','core.windows.net')]"
                                                },
                                                {
                                                    "name": "FUNCTIONS_EXTENSION_VERSION", 
                                                    "value": "~4"
                                                },
                                                {
                                                    "name": "FUNCTIONS_WORKER_RUNTIME",
                                                    "value": self.runtime_stack.split("|")[0] if self.publish_type.lower() == "code" else 'dotnet'
                                                },
                                                {
                                                    "name": "WEBSITE_RUN_FROM_PACKAGE" if self.publish_type.lower() == "code" else "DOCKER_REGISTRY_SERVER_URL",
                                                    "value": "1" if self.publish_type.lower() == "code" else "https://mcr.microsoft.com"
                                                },
                                                {
                                                    "name":"WEBSITE_DNS_SERVER" if self.subscription_id in ('fe70970a-8778-4bc4-83c4-a85c57c1efd3','a6362b38-0f74-4c75-bcbb-719b38f04f75') else None,
                                                    "value":"172.18.218.84" if self.subscription_id in ('fe70970a-8778-4bc4-83c4-a85c57c1efd3','a6362b38-0f74-4c75-bcbb-719b38f04f75') else None
                                                },
                                                {
                                                    "name": "WEBSTITE_CONTENOVERVNET" if self.subscription_id in ('fe70970a-8778-4bc4-83c4-a85c57c1efd3','a6362b38-0f74-4c75-bcbb-719b38f04f75') else None,
                                                    "value": "1" if self.subscription_id in ('fe70970a-8778-4bc4-83c4-a85c57c1efd3','a6362b38-0f74-4c75-bcbb-719b38f04f75') else None
                                                },
                                                {
                                                    "name": "WEBSITE_CONTENTAZUREFILECONNECTIONSTRING" if "elastic" in app_service_plan.kind and storage_account_kind in ("StorageV2", "FileStorage","Storage") else None,
                                                    "value": f"[concat('DefaultEndpointsProtocol=https;AccountName=','{storage_account_id.split('/')[-1]}',';AccountKey=',listKeys(resourceId('{storage_account_id.split('/')[2]}','{storage_account_id.split('/')[4]}','Microsoft.Storage/storageAccounts', '{storage_account_id.split('/')[-1]}'), '2022-05-01').keys[0].value,';EndpointSuffix=','core.windows.net')]" if "elastic" in app_service_plan.kind and storage_account_kind in ("StorageV2", "FileStorage","Storage") else None
                                                },
                                                {
                                                    "name": "WEBSITE_CONTENTSHARE" if "elastic" in app_service_plan.kind and storage_account_kind in ("StorageV2", "FileStorage","Storage") else None,
                                                    "value": f"{content_share}"  if "elastic" in app_service_plan.kind and storage_account_kind in ("StorageV2", "FileStorage","Storage") else None
                                                },
                                            ]
                                        )),
                                        "http20Enabled": True,
                                        "linuxFxVersion": f"{self.runtime_stack}" if self.os_type.lower() == "linux" and self.publish_type.lower() == "code" else "DOCKER|mcr.microsoft.com/azure-functions/dotnet:4-dotnet8.0-appservice" if self.publish_type.lower() == "container" else None,
                                        "pythonVersion": self.runtime_version if self.runtime_stack.lower().startswith("python") and self.os_type.lower() == "windows" and self.publish_type.lower() == "code" else None,
                                        "nodeVersion": self.runtime_version if self.runtime_stack.lower().startswith("node") and self.os_type.lower() == "windows" and self.publish_type.lower() == "code" else None,
                                        "javaVersion": self.runtime_version if self.runtime_stack.lower().startswith("java") and self.os_type.lower() == "windows" and self.publish_type.lower() == "code" else None,
                                        "powerShellVersion": self.runtime_version if self.runtime_stack.lower().startswith("powershell") and self.os_type.lower() == "windows" and self.publish_type.lower() == "code" else None,
                                    }
                                }
                            },
                            (
                                {
                                    "type": "Microsoft.Resources/deployments",
                                    "apiVersion": "2021-04-01",
                                    "name": "StorageContentShareTemplate",
                                    "resourceGroup": storage_account_id.split("/")[4],
                                    "subscriptionId": storage_account_id.split("/")[2],
                                    "properties": {
                                        "mode": "Incremental",
                                        "template": {
                                            "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
                                            "contentVersion": "1.0.0.1",
                                            "parameters": {},
                                            "variables": {},
                                            "resources": [
                                                {
                                                    "name": f"{storage_account_id.split('/')[-1]}/default/{content_share}",
                                                    "type": "Microsoft.Storage/storageAccounts/fileServices/shares",
                                                    "apiVersion": "2022-05-01",
                                                    "dependsOn": []
                                                }
                                            ]
                                        }
                                    }
                                }
                                if storage_account_kind in ("StorageV2", "FileStorage","Storage") else None
                            )
                        ]
                    ))
                }

                deployment_properties = {
                    "properties": {
                        "mode": DeploymentMode.INCREMENTAL,
                        "template": arm_template,
                        "parameters": {}
                    }
                }

                deployment_name = f"{self.function_app_name}{content_share}"
                deployment_async_operation = self.resource_client.deployments.begin_create_or_update(
                    self.resource_group_name,
                    deployment_name,
                    deployment_properties
                )
                deployment_async_operation.result()
                function_app = self.web_client.web_apps.get(
                    self.resource_group_name,
                    self.function_app_name
                )


            if self.subscription_id in ('fe70970a-8778-4bc4-83c4-a85c57c1efd3','a6362b38-0f74-4c75-bcbb-719b38f04f75'):
                subnet = self.network_client.subnets.get(
                    resource_group_name=network_config["pe_vnet_rg_name"], 
                    virtual_network_name=network_config["pe_vnet_name"],
                    subnet_name=network_config["pe_subnet_functionapp"]
                )
            else:
                subnet = self.network_client.subnets.get(
                resource_group_name=network_config["vnet_rg_name"],
                virtual_network_name=network_config["vnet_name"],
                subnet_name=network_config["subnet_name"]
                )

            # Create private endpoint
            private_endpoint_name = f"{self.function_app_name}-pe-webapp"
            private_endpoint = self.network_client.private_endpoints.begin_create_or_update(
                resource_group_name=self.resource_group_name,
                private_endpoint_name=private_endpoint_name,
                parameters={
                    "location": self.location,
                    "subnet": {
                        "id": subnet.id
                    },
                    "privateLinkServiceConnections": [{
                        "name": f"{private_endpoint_name}-connection",
                        "properties": {
                            "privateLinkServiceId": function_app.id,
                            "groupIds": ["sites"],
                            "requestMessage": None
                        }
                    }],
                    "tags": self.tags
                }
            ).result()
            if self.subscription_id in ('fe70970a-8778-4bc4-83c4-a85c57c1efd3','a6362b38-0f74-4c75-bcbb-719b38f04f75'):
                    maz_subnets = self.network_client.subnets.list(
                        resource_group_name=network_config["pe_vnet_rg_name"],
                        virtual_network_name=network_config["pe_vnet_name"],
                    )
                    maz_subnet = None
                    maz_subnet = [subnet for subnet in maz_subnets if subnet.name == f"{self.function_app_name.replace('-','_')}"]
                    if maz_subnet:
                        maz_subnet = maz_subnet[0]
                    else:
                        maz_subnet = self.network_client.subnets.begin_create_or_update(
                            resource_group_name=network_config["pe_vnet_rg_name"],
                            virtual_network_name=network_config["pe_vnet_name"],
                            subnet_name=f"{self.function_app_name.replace('-','_')}",
                            subnet_parameters={
                                "properties": {
                                    "addressPrefix": self.get_subnet_address_prefix(network_config["pe_vnet_rg_name"], network_config["pe_vnet_name"],self.subscription_id),
                                    "serviceEndpoints": [
                                        {"service": "Microsoft.Storage"},
                                        {"service": "Microsoft.Keyvault"},
                                        {"service": "Microsoft.ServiceBus"},
                                    ],
                                    "routeTable": { 
                                        "id": "/subscriptions/fe70970a-8778-4bc4-83c4-a85c57c1efd3/resourceGroups/MGMTPA-RG-MEX-NON-PROD/providers/Microsoft.Network/routeTables/trust-routetable" if self.subscription_id == 'fe70970a-8778-4bc4-83c4-a85c57c1efd3' else "/subscriptions/a6362b38-0f74-4c75-bcbb-719b38f04f75/resourceGroups/MGMTPVT-RG-MEX-PROD/providers/Microsoft.Network/routeTables/RouteTable-PaaS"
                                    },
                                    "delegations": [
                                        {
                                            "name": "serverfarms",
                                            "properties": {
                                                "serviceName": "Microsoft.Web/serverFarms",
                                                "actions": [
                                                    "Microsoft.Network/virtualNetworks/subnets/join/action"
                                                ]
                                            }
                                        }
                                    ]
                                }
                            }
                        ).result()
                    app = self.web_client.web_apps.begin_create_or_update(
                        resource_group_name=self.resource_group_name,
                        name=self.function_app_name,
                        site_envelope={
                            "location": self.location,
                            "properties": {
                                "publicNetworkAccess": "Disabled",
                                "virtualNetworkSubnetId": maz_subnet.id,
                                "vnetRouteAllEnabled": True,
                                "httpsOnly": True,
                            }
                        }
                    ).result()
                    services_subnet = self.network_client.subnets.get(
                        resource_group_name=network_config["pe_vnet_rg_name"],
                        virtual_network_name=network_config["pe_vnet_name"],
                        subnet_name=network_config["pe_subnet_services"]
                    )
                    storage = self.storage_client.storage_accounts.get_properties(
                        resource_group_name=storage_account_id.split("/")[4],
                        account_name=self.storage_account_name
                    )
                    storage_dict = storage.as_dict()
                    existing_vnet_rules = storage_dict.get("network_rule_set", {}).get("virtual_network_rules", [])
                    existing_vnet = []
                    for rule in existing_vnet_rules:
                        if rule.get("virtual_network_resource_id") == services_subnet.id or rule.get("virtual_network_resource_id") == maz_subnet.id:
                            continue
                        temp = {}
                        temp['id'] = rule.get("virtual_network_resource_id")
                        temp['action'] = rule.get("action")
                        existing_vnet.append(temp)
                    self.storage_client.storage_accounts.update(
                        resource_group_name=storage_account_id.split("/")[4],
                        account_name=self.storage_account_name,
                        parameters={
                            "networkAcls": {
                                "bypass": "AzureServices",
                                "defaultAction": "Deny",
                                "virtualNetworkRules": existing_vnet + [
                                    {
                                        "id": services_subnet.id,
                                    },
                                    {
                                        "id": maz_subnet.id,
                                    }
                                ],
                            }
                        }
                    )             
            # Get private DNS zone
            private_dns_zone_name = "privatelink.chinacloudsites.cn" if self.zone == "china" else "privatelink.azurewebsites.net"
            try:
                private_dns_zone = self.dns_client.private_zones.get(
                    resource_group_name=network_config["vnet_rg_name"],
                    private_zone_name=private_dns_zone_name
                )
                if self.subscription_id in ('fe70970a-8778-4bc4-83c4-a85c57c1efd3'):
                    dns_client = PrivateDNSClient().get_dns_client("a6362b38-0f74-4c75-bcbb-719b38f04f75",self.cloud)
                    private_dns_zone = dns_client.private_zones.get(
                        resource_group_name="MGMTPVT-RG-MEX-PROD",
                        private_zone_name=private_dns_zone_name
                    )
                    private_dns_zone_group_params = {
                    "privateDnsZoneConfigs": [{
                        "name": f"{self.function_app_name}-dnsconfig",
                        "properties": {
                            "privateDnsZoneId": private_dns_zone.id
                            }
                        }]
                    } 
                    private_dns_zone_group = self.network_client.private_dns_zone_groups.begin_create_or_update(
                    self.resource_group_name,
                    private_endpoint_name,
                    "default",
                    private_dns_zone_group_params
                    )
                    private_dns_zone_group.result()
                else:
                    private_dns_zone_group_params = {
                    "privateDnsZoneConfigs": [{
                        "name": private_dns_zone.name,
                        "properties": {
                            "privateDnsZoneId": private_dns_zone.id
                            }
                        }]
                    } 
                    private_dns_zone_group = self.network_client.private_dns_zone_groups.begin_create_or_update(
                    self.resource_group_name,
                    private_endpoint_name,
                    "default",
                    private_dns_zone_group_params
                    )
                    private_dns_zone_group.result()
            except Exception as e:
                pass
            logging.info(f"Private endpoint {private_endpoint_name} created successfully")
            logging.info(f"Function App {self.function_app_name} created successfully")
            return function_app.id
        except Exception as e:
            logging.error(f"Error creating Function App: {str(e)}")
            raise e