# KeyVaultMgmt - Secret Operation Flow

```
                    ┌──────────────────┐
                    │ Incoming Request │
                    └────────┬─────────┘
                             ▼
                  ┌──────────────────────┐
                  │ 1. Is KV public?     │
                  │ (networkAcls check)  │
                  └──────┬───────┬───────┘
                    Yes  │       │  No (defaultAction=Deny)
                    skip │       ▼
                         │  ┌──────────────────┐
                         │  │ Try add IP rule   │
                         │  │ (0.0.0.0/0)      │
                         │  └──┬───────┬───────┘
                         │     │ OK    │ Policy blocks
                         │     │       ▼
                         │     │  ┌─────────────────┐
                         │     │  │ Exempt policy    │
                         │     │  │ → Retry IP rule  │
                         │     │  └──┬──────┬───────┘
                         │     │     │ OK   │ Fail
                         │     │     │      ▼
                         │     │     │  ┌──────────────┐
                         │     │     │  │ Create PE    │
                         │     │     │  └──────────────┘
                         ▼     ▼     ▼
                  ┌──────────────────────┐
                  │ 2. Grant PIM         │
                  │ KV Secrets Officer   │
                  │ (principal: 5c18fa7a)│
                  │ Duration: 1 hour     │
                  └──────────┬───────────┘
                             ▼
                  ┌──────────────────────┐
                  │ 3. Decrypt secret    │
                  │ AES-GCM-256          │
                  │ Key: secrets-aes-key │
                  │ from puppet-secrets  │
                  │ (create/update only) │
                  └──────────┬───────────┘
                             ▼
                  ┌──────────────────────┐
                  │ 4. Perform KV op     │
                  │ DefaultAzureCredential│
                  │ - Create: set_secret │
                  │ - Update: set_secret │
                  │ - Delete: delete     │
                  └──────────┬───────────┘
                             ▼
                  ┌──────────────────────┐
                  │ FINALLY: Cleanup     │
                  │ - Remove IP 0.0.0.0/0│
                  │   (if added)         │
                  │ - Delete PE          │
                  │   (if created)       │
                  └──────────────────────┘
```

## Methods Mapping

| Step | Method | Description |
|------|--------|-------------|
| 1 | `_ensure_network_access()` | Checks public/private, routes to IP or PE |
| 1a | `_add_ip_rule()` | Adds 0.0.0.0/0 to KV firewall |
| 1b | `_exempt_policy()` | Creates policy exemption (3hr) if IP blocked by policy |
| 1c | `_create_private_endpoint()` | Fallback: creates PE + DNS zone group |
| 2 | `_grant_pim_kv_officer()` | PIM activation of KV Secrets Officer role |
| 3 | `_decrypt_secret_value()` | AES-GCM-256 decryption using key from puppet-secrets KV |
| 4 | `_create_or_update_secret()` / `_delete_secret()` | Actual KV operation via DefaultAzureCredential |
| 5 | `_remove_ip_rule()` | Removes temporary IP rule |
| 5 | `_delete_private_endpoint()` | Removes temporary PE + DNS |

## Step-by-Step Verification

### Step 1: `_ensure_network_access()`
- Calls `_get_vault()` to fetch KV properties
- Checks `_is_public_network()` → if `defaultAction == "Allow"` or no ACLs → skip (vault already reachable)
- If private (`defaultAction == "Deny"`):
  - Tries `_add_ip_rule()` to add `0.0.0.0/0`
  - If blocked by Azure Policy (`RequestDisallowedByPolicy`):
    - Extracts policy assignment ID from error message
    - Calls `_exempt_policy()` (creates 3hr waiver)
    - Retries `_add_ip_rule()`
  - If policy ID can't be extracted or other error → falls back to `_create_private_endpoint()`

### Step 1a: `_add_ip_rule()`
- Fetches current IP rules from vault's `network_acls`
- Appends `{"value": "0.0.0.0/0"}`
- Calls `kv_mgmt_client.vaults.update()` to apply
- Sets `self.is_ip_added = True` (for cleanup tracking)

### Step 1b: `_exempt_policy()`
- Creates policy exemption scoped to the Key Vault resource
- Category: `Waiver`
- Expires: 3 hours from now (UTC)
- Waits 180s (`time.sleep(180)`) for exemption to propagate

### Step 1c: `_create_private_endpoint()`
- Gets vault and extracts subnet from `virtual_network_rules[0].id`
- Uses `PrivateEndpointHelper` to create PE with `group_ids=["vault"]`
- DNS zone: `privatelink.vaultcore.azure.net` (or `.azure.cn` for China)
- Sets `self.is_pe_created = True` (for cleanup tracking)

### Step 2: `_grant_pim_kv_officer()`
- Scope: KV resource (`/subscriptions/.../Microsoft.KeyVault/vaults/{name}`)
- Role: Key Vault Secrets Officer (`b86a8fe4-44ce-4948-aee5-eccb2c155cd7`)
- Principal: Function App identity (`175069f8-dddf-4e77-ad30-4d87da8904c4`)
- Request type: `ADMIN_ASSIGN`
- Duration: `PT1H` (1 hour auto-expire)
- Handles `RoleAssignmentExists` gracefully (already active = OK)
- Waits 30s for role propagation

### Step 3: `_decrypt_secret_value()`
- Fetches AES key from puppet-secrets KV: `AkvSecrets(KEYVAULT_URI, 'secrets-aes-key')`
- Base64-decodes: key, IV (nonce), ciphertext, tag
- Decrypts using AES-GCM-256: `AESGCM(key).decrypt(nonce, ciphertext + tag, None)`
- Returns plaintext UTF-8 string
- **Only called for create/update** — delete doesn't need the secret value

### Step 4: KV Operation
- `_get_secret_client()` creates `SecretClient` with `DefaultAzureCredential`
- **Create/Update**: `client.set_secret(name, value, content_type, expires_on, tags)`
- **Delete**: `client.begin_delete_secret(name)` → `poller.wait()`
- `ResourceNotFoundError` on delete is handled (returns True, logs warning)

### Step 5: Cleanup (finally block)
- `_remove_ip_rule()` — only runs if `is_ip_added == True`; removes `0.0.0.0/0` from KV firewall
- `_delete_private_endpoint()` — only runs if `is_pe_created == True`; deletes DNS zone group + PE
- **Always executes** regardless of success/failure (in `finally` block)
