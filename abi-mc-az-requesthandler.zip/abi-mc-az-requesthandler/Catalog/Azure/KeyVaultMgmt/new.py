import base64
from shared_code.akv_secrets import AkvSecrets
from shared_code.keyvault_client import KeyVaultClient
from azure.keyvault.secrets import SecretClient
from azure.identity import DefaultAzureCredential
from shared_code.lock_manager import LockManager
from shared_code.networkmgmt_client import NetworkMgmtClient
from shared_code.privatedns_client import PrivateDNSClient
from azure.core.exceptions import HttpResponseError,ResourceNotFoundError
from azure.mgmt.authorization.v2020_10_01_preview.models import (RoleAssignmentScheduleRequest,
                                                                RoleAssignmentScheduleRequestPropertiesScheduleInfo,
                                                                RoleAssignmentScheduleRequestPropertiesScheduleInfoExpiration,
                                                                Type,
                                                                RequestType)
from shared_code.authorization_client import AuthorizationClient
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from datetime import datetime,timedelta,timezone
import logging,os,json,uuid,time


class KeyVaultManagement:
    def __init__(self,json_data):
        data = json_data
        self.zone = json_data["Zone"].lower()
        self.subscription_id = data["SubscriptionId"]
        self.resource_group_name = data["ResourceGroupName"]
        self.keyvault_name = data["KeyVaultName"]
        self.secret_name = data["SecretName"]
        self.secret_value = data["SecretValue"]
        self.iv = data["IV"]
        self.tag = data["Tag"]
        self.content_type = data["ContentType"]
        self.expires_on = f"{data["ExpiresOn"]}T12:00:00Z"
        self.tags = json.loads(data["Tags"]) if data['Tags'] != "{}" else None
        self.action = data["Action"]
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.private_endpoint_name = f"{self.keyvault_name}-pe-kv-brewmation"
        self.dns_zone_name = "privatelink.vaultcore.azure.cn" if self.zone == "china" else "privatelink.vaultcore.azure.net"
        self.kv_client = KeyVaultClient().get_kv_client(self.subscription_id,self.cloud)
        self.keyvault = self.kv_client.vaults.get(self.resource_group_name, self.keyvault_name)
        self.network_client = NetworkMgmtClient().get_network_mgmt_client("2db7c27b-2f9f-4088-981b-2bd88c5c1905",self.cloud) #global prod
        self.dns_client = PrivateDNSClient().get_dns_client("2db7c27b-2f9f-4088-981b-2bd88c5c1905", self.cloud)
        self.auth_client = AuthorizationClient().get_auth_client(self.cloud,self.subscription_id)

    def create_private_endpoint_and_dns(self):
        kv_pe = self.network_client.private_endpoints.begin_create_or_update(
            "CONFIG-MGMT-RG-GB-PROD",
            self.private_endpoint_name,
            parameters={
                    "location": "westeurope",
                    "subnet": {
                        "id": "/subscriptions/2db7c27b-2f9f-4088-981b-2bd88c5c1905/resourceGroups/MGMTPVT-RG-GB-PROD/providers/Microsoft.Network/virtualNetworks/PVT-VNET-GB-PROD/subnets/Infra"
                    },
                    "privateLinkServiceConnections": [{
                        "name": f"{self.private_endpoint_name}-dnsconfig",
                        "properties": {
                            "privateLinkServiceId": self.keyvault.id,
                            "groupIds": ["vault"],
                            "requestMessage": None
                        }
                    }],
                }
        ).result()
        logging.info(f"Private endpoint '{self.private_endpoint_name}' created for Key Vault '{self.keyvault_name}'")
        pe_dns = self.dns_client.private_zones.get(
            "MGMTPVTDNS-RG-GB-PROD",
            self.dns_zone_name
        )
        kv_dns = self.network_client.private_dns_zone_groups.begin_create_or_update(
            "CONFIG-MGMT-RG-GB-PROD",
            self.private_endpoint_name,
            "default",
            parameters={
                "privateDnsZoneConfigs": [{
                    "name": self.dns_zone_name,
                    "properties": {
                        "privateDnsZoneId": pe_dns.id
                    }
                }]
            }
        ).result()
        time.sleep(30)  # Wait for DNS propagation
        logging.info(f"Private DNS zone group created for endpoint '{self.private_endpoint_name}'")

    def delete_private_dns(self):
        try:
            self.network_client.private_dns_zone_groups.begin_delete(
                "CONFIG-MGMT-RG-GB-PROD",
                self.private_endpoint_name,
                "default"
            ).result()
            logging.info(f"Private DNS zone group deleted from endpoint '{self.private_endpoint_name}'")
        except Exception as e:
            logging.warning(f"Could not delete DNS zone group for '{self.private_endpoint_name}': {str(e)}")

    def delete_private_endpoint(self):
        try:
            lock_client = LockManager('2db7c27b-2f9f-4088-981b-2bd88c5c1905', self.zone, "MGMTPVTDNS-RG-GB-PROD")
            lock_client.remove_all_locks()
            self.network_client.private_endpoints.begin_delete(
                "CONFIG-MGMT-RG-GB-PROD",
                self.private_endpoint_name
            ).result()
            lock_client.restore_locks()
            logging.info(f"Private endpoint '{self.private_endpoint_name}' deleted for Key Vault '{self.keyvault_name}'")
        except Exception as e:
            logging.error(f"Error deleting private endpoint '{self.private_endpoint_name}': {str(e)}")

    
    def grant_pim(self):
        scope = f"/subscriptions/{self.subscription_id}/resourceGroups/{self.resource_group_name}/providers/Microsoft.KeyVault/vaults/{self.keyvault_name}"
        role_def_id = '/providers/Microsoft.Authorization/roleDefinitions/b86a8fe4-44ce-4948-aee5-eccb2c155cd7'
        uid = str(uuid.uuid4())
        try:
            self.auth_client.role_assignment_schedule_requests.create(
                scope=scope,
                role_assignment_schedule_request_name=uid,
                parameters=RoleAssignmentScheduleRequest(
                    request_type=RequestType.ADMIN_ASSIGN,
                    justification=f"Brewmation KV Secret Management",
                    role_definition_id=role_def_id,
                    principal_id='175069f8-dddf-4e77-ad30-4d87da8904c4',
                    schedule_info=RoleAssignmentScheduleRequestPropertiesScheduleInfo(
                        start_date_time=datetime.now(timezone.utc),
                        expiration=RoleAssignmentScheduleRequestPropertiesScheduleInfoExpiration(
                            type=Type.AFTER_DURATION,
                            duration="PT1H"
                        ),
                    ),
                )
            )
            logging.info(f"PIM KV Officer role granted on '{self.keyvault_name}'")
            time.sleep(60)
        except HttpResponseError as e:
            if "RoleAssignmentExists" in str(e.error.code):
                logging.info(f"PIM KV Officer role already active on '{self.keyvault_name}'")
            else:
                raise

    def decrypt_secret_value(self):
        aes_secret = AkvSecrets(os.environ["KEYVAULT_URI"], 'secrets-aes-key').get_tokens()
        aes_key = base64.b64decode(json.loads(aes_secret.value)["key"])
        nonce = base64.b64decode(self.iv)
        ciphertext = base64.b64decode(self.secret_value)
        tag = base64.b64decode(self.tag)
        aesgcm = AESGCM(aes_key)
        plaintext = aesgcm.decrypt(nonce, ciphertext + tag, None)
        return plaintext.decode("utf-8")

    def get_secret_client(self):
        credential = DefaultAzureCredential()
        secret_client = SecretClient(vault_url=self.keyvault.properties.vault_uri, credential=credential)
        return secret_client

    def manage_kv(self):
        try:
            self.create_private_endpoint_and_dns()
            self.grant_pim()
            client = self.get_secret_client()
            if self.action.lower() in ['create','update']:
                client.set_secret(
                    name=self.secret_name,
                    value=self.decrypt_secret_value(),
                    content_type=self.content_type,
                    expires_on=datetime.fromisoformat(self.expires_on),
                    tags=self.tags
                )
                logging.info(f"Secret '{self.secret_name}' {'created' if self.action.lower() == 'create' else 'updated'} in Key Vault '{self.keyvault_name}'")
            elif self.action.lower() == 'delete':
                client.begin_delete_secret(
                    self.secret_name
                ).result()
                logging.info(f"Secret '{self.secret_name}' deleted from Key Vault '{self.keyvault_name}'")
        except Exception as e:
            logging.error(f'Error {e}')
            raise 
        finally:
            self.delete_private_dns()
            self.delete_private_endpoint()