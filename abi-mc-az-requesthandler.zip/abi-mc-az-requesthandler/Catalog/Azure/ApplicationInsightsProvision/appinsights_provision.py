from shared_code.storage_client import StorageClient
from shared_code.appinsightsmgmt_client import AppInsightsClient
from shared_code.networkmgmt_client import NetworkMgmtClient
from shared_code.privatedns_client import PrivateDNSClient
from shared_code.loganalytics_client import LogAnalyticsClient
import json,logging

class AppInsightsProvision:
    def __init__(self,json_data):
        data = json.loads(json_data['Payload'])['payload']["data"]
        self.zone = json_data["Zone"].lower()
        self.tags = data["tags"]
        self.subscription_id = data["subscription_id"]
        self.resource_group_name = data["resource_group_name"]
        self.location = data["location"]
        self.log_analytics_workspace_name = data["new_workspace_name"] if data.get("new_workspace_name") else data.get("existing_workspace")
        self.log_analytics_type = data["log_analytics_type"]
        self.application_insights_name = data["application_insights_name"]
        self.application_insights_retention_in_days = data["application_retention"]
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.storage_client = StorageClient().get_storage_client(self.subscription_id,self.cloud)
        self.loganalytics_client = LogAnalyticsClient().get_loganalytics_client(self.subscription_id,self.cloud)
        self.appinsights_client = AppInsightsClient().get_appinsights_client(self.subscription_id,self.cloud)
        self.network_client = NetworkMgmtClient().get_network_mgmt_client(self.subscription_id,self.cloud)
        self.dns_client = PrivateDNSClient().get_dns_client(self.subscription_id,self.cloud)

    def create_appinsights(self):
        try:
            if self.log_analytics_type.lower() == 'new':
            # Prepare Log Analytics Workspace parameters
                self.log_analytics_workspace_params = {
                    "location": self.location,
                    "sku": {
                        "name": "PerGB2018"
                    },
                    "retention_in_days": min(
                        max(
                            int(self.application_insights_retention_in_days),
                            30
                        ),
                        730
                    ) if int(self.application_insights_retention_in_days) in [30, 60, 90, 120, 180, 270, 365, 550, 730] else 30,
                    "tags": self.tags
                }

                # Create or update Log Analytics Workspace
                law_poller = self.loganalytics_client.workspaces.begin_create_or_update(
                    self.resource_group_name,
                    self.log_analytics_workspace_name,
                    self.log_analytics_workspace_params
                )
                law_result = law_poller.result()
                workspace_id = law_result.id
            else:
                # Use existing Log Analytics Workspace
                workspace_id = self.loganalytics_client.workspaces.get(
                    self.resource_group_name,
                    self.log_analytics_workspace_name
                ).id
                logging.info(f"Using existing Log Analytics Workspace: {workspace_id}")

            # Prepare Application Insights parameters
            app_insights_params = {
                "location": self.location,
                "kind": "web",
                "properties": {
                    "Application_Type": "web",
                    "WorkspaceResourceId": workspace_id
                },
                "tags": self.tags
            }

            # Create or update Application Insights
            appi_poller = self.appinsights_client.components.create_or_update(
                self.resource_group_name,
                self.application_insights_name,
                app_insights_params
            )

            logging.info(f"Log Analytics Workspace created: {workspace_id}")

            return {
                "log_analytics_workspace_id": workspace_id,
                "application_insights_id": appi_poller.id
            }
        except Exception as e:
            logging.error(f"Failed to provision Application Insights: {e}")
            raise