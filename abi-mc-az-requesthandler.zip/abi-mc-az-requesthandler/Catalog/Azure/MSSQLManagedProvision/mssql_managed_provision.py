from shared_code.sqlmgmt_client import SqlMgmtClient
from azure.mgmt.sql.models import ManagedInstanceAdministrator,AdministratorType
from shared_code.akv_secrets import AkvSecrets
from shared_code.lock_manager import LockManager
from shared_code.storage_client import StorageClient
import pyodbc,logging,os,struct,json

class MSSQLManagedProvision:
    def __init__(self,json_data):
        data = json.loads(json_data['Payload'])['payload']["data"]
        self.subscription_id = data['subscription_id']
        self.subscription_name = data['subscription_name']
        self.zone = json_data['Zone'].lower()
        self.resource_group_name = data['resource_group_name']
        self.sql_server_name = data['managed_instance_name']
        self.tags = data['tags']
        self.sku_tier = data['managed_instance_tier']
        self.sku_name = data['managed_instance_sku_name'].split('-')[0]
        self.location = data['location']
        self.azenvironment = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.sql_mgmt_client = SqlMgmtClient().get_sql_mgmt_client(self.subscription_id,self.azenvironment)
        self.storage_client = StorageClient().get_storage_client(self.subscription_id,self.azenvironment)
        self.lock_client = LockManager(self.subscription_id,self.zone,self.resource_group_name,self.sql_server_name)
        self.secret = AkvSecrets(os.environ["KEYVAULT_URI"],'sql-creds-prov').get_tokens()

    def mssql_server_provision(self):
        try:
            self.lock_client.remove_all_locks()
            subscription_config = {
                "2db7c27b-2f9f-4088-981b-2bd88c5c1905": {
                    "vnet_name": "SQLMI-VNET-GLOBAL-Prod",
                    "vnet_rg_name": "MGMTPVT-RG-GB-PROD",
                    "subnet_name": "SQLMI",
                    "ad_gp": "SONEG-Admin-Global-Azure-Operations"
                },
                "73f88e6b-3a35-4612-b550-555157e7059f": {
                    "vnet_name": "SQLMI-VNET-GLOBAL-Non-Prod",
                    "vnet_rg_name": "mgmtpvt-rg-gb-non-prod",
                    "subnet_name": "SQLMI",
                    "ad_gp": "SONEG-Admin-Global-Azure-Operations"
                },
                "25137c49-ffa8-4cef-a4db-f8aaf059d980": {
                    "vnet_name": "SQL-MI-MAINFRAME-NAZ-NON-PROD",
                    "vnet_rg_name": "MAINFRAME-RG-NAZ-NON-PROD",
                    "subnet_name": "SQL-MI",
                    "ad_gp": "SONEG-Admin-Global-Azure-Operations"
                },
                "95c54dda-ae35-43c0-aeea-bcfc596674c1": {
                    "vnet_name": "PVT-VNET-SQLMI-NAZ-PROD",
                    "vnet_rg_name": "Supply-ZBS-TechSupply-RG-NAZ-Prod",
                    "subnet_name": "SQLMI",
                    "ad_gp": "SONEG-Admin-Global-Azure-Operations"
                },
                "3617a45e-beab-410a-9476-d6e000e1fb77": {
                    "vnet_name": "SQLMI-VNET-EU-Non-Prod",
                    "vnet_rg_name": "MGMTPVT-RG-EU-NON-PROD",
                    "subnet_name": "SQLMI",
                    "ad_gp": "SONEG-Admin-Global-Azure-Operations"
                },
                "1c1db8ee-5d54-460b-bd71-fd031be2a7e5": {
                    "vnet_name": "SQLMI-VNET-EU-Prod",
                    "vnet_rg_name": "MGMTPVT-RG-EU-PROD",
                    "subnet_name": "SQLMI",
                    "ad_gp": "SONEG-Admin-Global-Azure-Operations"
                },
                "77a7f337-8588-4076-b526-5f1ce0e55671": {
                    "vnet_name": "SQLMI-VNET-AFRICA-Prod",
                    "vnet_rg_name": "MGMTPVT-RG-AFR-PROD",
                    "subnet_name": "SQLMI",
                    "ad_gp": "SONEG-Admin-Global-Azure-Operations"
                },
                "15bcebd1-794e-49c6-9548-8a4a4357ee16": {
                    "vnet_name": "SQLMI-VNET-AFRICA-Non-Prod",
                    "vnet_rg_name": "MGMTPVT-RG-AFR-NON-PROD",
                    "subnet_name": "SQLMI",
                    "ad_gp": "SONEG-Admin-Global-Azure-Operations"
                },
                "b413c513-77a1-4416-84d4-4057920111c6": {
                    "vnet_name": "SQLMI-VNET-KR-Non-Prod",
                    "vnet_rg_name": "MGMTPVT-RG-KR-NON-PROD",
                    "subnet_name": "SQLMI",
                    "ad_gp": "SONEG-Admin-Global-Azure-Operations"
                },
                "a831d6f9-cdd3-4d49-9dd5-9389dd3a1902": {
                    "vnet_name": "SQLMI-VNET-KR-Prod",
                    "vnet_rg_name": "MGMTPVT-RG-KR-PROD",
                    "subnet_name": "SQLMI",
                    "ad_gp": "SONEG-Admin-Global-Azure-Operations"
                }
            }

            if self.subscription_id not in subscription_config:
                raise ValueError(f"Subscription ID {self.subscription_id} not found in configuration")
            
            config = subscription_config[self.subscription_id]
            vnet_name = config['vnet_name']
            vnet_rg_name = config['vnet_rg_name']
            subnet_name = config['subnet_name']
            ad_group = config['ad_gp']
            
            # Create SQL Server
            server = self.sql_mgmt_client.managed_instances.begin_create_or_update(
                self.resource_group_name,
                self.sql_server_name,
                {
                    "location": self.location,
                    "version": "12.0",
                    "administrator_login": "ABISQLADMIN",
                    "administrator_login_password": self.secret.value,
                    "minimal_tls_version": "1.2",
                    "public_network_access": "Disabled",
                    "sku": {
                        "name": self.sku_name,
                        "tier": self.sku_tier
                    },
                    "tags": self.tags,
                    "subnet_id": f"/subscriptions/{self.subscription_id}/resourceGroups/{vnet_rg_name}/providers/Microsoft.Network/virtualNetworks/{vnet_name}/subnets/{subnet_name}",
                    "identity": {
                        "type": "SystemAssigned"
                    }
                }
            )
            server.result()
            logging.info(f"SQL Server '{self.sql_server_name}' created successfully")

            if self.zone == 'naz':
                login = "AADS_A_ABI NAZ SQL DB Admins"
                sid = "eacb2675-7fbc-4f91-a3eb-906c78bd0043"
            elif self.zone == 'china':
                login = "Cloudbolt"
                sid = "6a956c8e-0e11-4d70-84ef-4ea2c018964b"
            else:
                login = "AADS_A_ABI GlobalOps SQL DB Admins"
                sid = "c643a250-a7e8-44b2-bc5f-7ed4437e7cf9"
            tenant_id = "cef04b19-7776-4a94-b89b-375c77a8f936" if self.zone != 'china' else "c99b23b6-4fa8-4eee-a7cc-2f420106e730"
            self.sql_mgmt_client.managed_instance_administrators.begin_create_or_update(self.resource_group_name,self.sql_server_name,"ActiveDirectory", 
                ManagedInstanceAdministrator(     
                    administrator_type=AdministratorType("ActiveDirectory"),
                    login=login,
                    sid=sid,
                    tenant_id=tenant_id,
                    azure_ad_only_authentication=False,
                    )
            )
            logging.info(f"AD Administrator added to SQL Server '{self.sql_server_name}'")

            # Enable Security Alert Policy
            self.sql_mgmt_client.managed_server_security_alert_policies.begin_create_or_update(
                self.resource_group_name,
                self.sql_server_name,
                "Default",
                {
                    "state": "Enabled"
                }
            )
            logging.info(f"Security alert policy enabled for SQL Server '{self.sql_server_name}'")
            logging.info(f"Vulnerability assessment enabled for SQL Server '{self.sql_server_name}'")            
        except Exception as e:
            logging.error(f"Error provisioning SQL database: {str(e)}")
            raise e
        finally:
            self.lock_client.restore_locks()