import logging
from Catalog.Azure.InstanceStatus.instance_status import AzVmStatus
from DAL.DbActivityManager import DbActivityManager
from shared_code.resourcemgmt_client import ResourceMgmtClient
from azure.mgmt.resource.resources.models import TagsPatchResource
from azure.core.exceptions import HttpResponseError,ResourceExistsError,ResourceNotFoundError


class HoursOfOperationInstance:
    def __init__(self, data):
        self.data = data
        self.db_activity_manager = DbActivityManager()

    def _remove_hours_of_operation_tag(self, resource_id: str, tag_value: str, resource_client) -> None:
        try:
            tag_patch = TagsPatchResource(
                operation="Delete",
                properties={"tags": {"HoursOfOperation": tag_value}}
            )
            resource_client.tags.begin_update_at_scope(resource_id, tag_patch)
            logging.info(f"Removed HoursOfOperation tag from resource {resource_id}")
        except Exception as e:
            logging.warning(f"Failed to remove HoursOfOperation tag from resource {resource_id}: {e}")

    def _remove_hours_of_operation_tag_from_data(self) -> None:
        try:
            resource_id = self.data.get("ResourceId", "")
            if not resource_id:
                return
            zone = self.data.get("Zone", "")
            subscription_id = self.data.get("SubscriptionId", "")
            if not subscription_id:
                return
            cloud = "AzureChinaCloud" if zone.lower() == "china" else "AzurePublicCloud"
            resource_client = ResourceMgmtClient().get_resource_client(cloud, subscription_id)
            resource = resource_client.resources.get_by_id(resource_id, api_version="2021-04-01")
            tags = resource.tags or {}
            if "HoursOfOperation" not in tags:
                return
            self._remove_hours_of_operation_tag(resource_id, tags["HoursOfOperation"], resource_client)
        except Exception as e:
            logging.warning(f"Failed to remove HoursOfOperation tag: {e}")

    async def execute_vm_operation(self):
        action = self.data.get("Action", "").lower()
        try:
            self.db_activity_manager.insert_hoursofoperationinstance_activity(self.data)
        except Exception:
            pass
        self._remove_hours_of_operation_tag_from_data()
        try:
            return await AzVmStatus(self.data).vm_start_stop_restart(action)
        except HttpResponseError as e:
            if e.error.code == "ResourceNotFound" or type(e) is ResourceExistsError or type(e) is ResourceNotFoundError:
                try:
                    self.db_activity_manager.mark_hoursofoperationinstance_decommissioned(self.data.get("ActivityId"))
                    self.db_activity_manager.insert_hoursofoperationinstance_activity(self.data, "Failed")
                except Exception:
                    pass
            raise