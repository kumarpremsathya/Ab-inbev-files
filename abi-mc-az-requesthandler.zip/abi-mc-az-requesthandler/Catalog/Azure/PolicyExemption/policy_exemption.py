import json
import logging
import uuid
import os
from datetime import datetime, timezone, timedelta
from azure.mgmt.resource.policy.models import PolicyExemption as PolicyExemptionModel
from shared_code.policy_client import AzPolicyClient


class AzPolicyExemption:

    def __init__(self, json_data):
        self.event_id = json_data.get('EventId', '')
        self.subscription_id = json_data.get('SubscriptionId', '')
        self.subscription_name = json_data.get('SubscriptionName', '')
        self.resource_group_name = json_data.get('ResourceGroupName', '')
        self.resource_group_id = json_data.get('ResourceGroupId', '')
        self.policy_exemption_resources = self._parse_exemption_resources(json_data.get('PolicyExemptionResources', '[]'))
        self.policy_auditors = json_data.get('PolicyAuditors', '')
        self.is_temporary = json_data.get('IsTemporary', '')
        self.duration = json_data.get('Duration', '')
        self.technical_justification = json_data.get('TechnicalJustification', '')
        self.business_impact = json_data.get('BusinessImpact', '')
        self.snow_item_id = json_data.get('SnowItemId', '')
        self.zone = json_data.get('Zone', '').lower()
        self.azenvironment = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.env = os.environ.get("Environment", "").lower()
        self.policy_client_obj = AzPolicyClient()

    def _parse_exemption_resources(self, resources):
        if isinstance(resources, list):
            return resources
        return json.loads(resources)

    async def apply_exemption(self):
        try:
            if not self.policy_exemption_resources:
                raise ValueError(f"PolicyExemptionResources is empty | EventId: {self.event_id}")

            policy_client = self.policy_client_obj.get_policy_client(self.subscription_id, self.azenvironment)

            is_temp = str(self.is_temporary).lower() in ('true', 'temporary')
            exemption_category = "Waiver"

            expires_on = None
            if is_temp and self.duration:
                duration = self._parse_duration(self.duration)
                if duration > timedelta(days=60):
                    logging.warning(f"Duration {self.duration} exceeds 60-day cap | EventId: {self.event_id} | Capping to 60 days")
                    duration = timedelta(days=60)
                expires_on = datetime.now(timezone.utc) + duration
            elif is_temp and not self.duration:
                logging.warning(f"IsTemporary=true but Duration not provided | EventId: {self.event_id}")

            for resource in self.policy_exemption_resources:
                resource_name = resource.get('resource_name', '')
                resource_id = resource.get('resource_id', '')
                policy_display_name = resource.get('policy_display_name', '')
                policy_assignment_id = resource.get('policy_assignment_id', '')
                policy_def_ref_id = resource.get('policy_definition_reference_id', '')

                if not policy_assignment_id:
                    logging.error(f"Skipping resource '{resource_name}' — no policy_assignment_id | EventId: {self.event_id}")
                    continue

                policy_def_ref_ids = self._parse_policy_definition_reference_ids(policy_def_ref_id)

                exemption_name = f"brewmation_{self.snow_item_id}_{uuid.uuid4().hex[:24]}"

                description = (
                    f"Exemption created via ABI Cloud Management Portal. "
                    f"EventId: {self.event_id}. "
                    f"SnowItemId: {self.snow_item_id}. "
                    f"Technical Justification: {self.technical_justification}. "
                    f"Business Impact: {self.business_impact}"
                )

                exemption_params = {
                    "policy_assignment_id": policy_assignment_id,
                    "exemption_category": exemption_category,
                    "display_name": policy_display_name[:128],
                    "description": description[:512],
                }

                if expires_on:
                    exemption_params["expires_on"] = expires_on

                if policy_def_ref_ids:
                    exemption_params["policy_definition_reference_ids"] = policy_def_ref_ids

                exemption = PolicyExemptionModel(**exemption_params)

                scope = self._resolve_scope(resource_id)
                # Temporary test: simulate failure for one specific resource
                # if resource_name == "ghq-00000-datadog-scu-dev-evh":
                #     raise Exception(f"Simulated failure for {resource_name}")
                if self.env == "local":
                    logging.info(f"[LOCAL] Would create PolicyExemption | EventId: {self.event_id} | ExemptionName: {exemption_name} | Resource: {resource_name} | Scope: {scope}")
                    logging.info(f"\n\n\n[LOCAL] Exemption Parameters: {exemption_params}")

                    
                # if self.env == "production":
                #     result = policy_client.policy_exemptions.create_or_update(
                #         scope=scope,
                #         policy_exemption_name=exemption_name,
                #         parameters=exemption
                #     )
                #     logging.info(
                #         f"PolicyExemption created | EventId: {self.event_id} | "
                #         f"ExemptionName: {exemption_name} | Resource: {resource_name} | "
                #         f"ExemptionId: {result.id}"
                #     )
                # else:
                #     logging.info(f"[NON-PROD] Skipping exemption creation | EventId: {self.event_id} | Resource: {resource_name} | ExemptionName: {exemption_name}")

        except Exception as e:
            logging.error(
                f"Failed to apply policy exemption | EventId: {self.event_id} | Error: {e}"
            )
            raise e

    def _parse_duration(self, duration_str):
        """Parse duration string to timedelta. Supports '30', '30d', '30h'."""
        duration_str = str(duration_str).strip().lower()
        try:
            if duration_str.endswith('d'):
                return timedelta(days=int(duration_str[:-1]))
            elif duration_str.endswith('h'):
                return timedelta(hours=int(duration_str[:-1]))
            else:
                return timedelta(days=int(duration_str))
        except (ValueError, TypeError):
            logging.error(f"Invalid duration format '{duration_str}'")
            raise ValueError(f"Invalid duration format: '{duration_str}'")

    def _resolve_scope(self, resource_id):
        """Resolve exemption scope: resource → resource group → subscription."""
        if resource_id:
            return resource_id
        if self.resource_group_id:
            return self.resource_group_id
        if self.subscription_id:
            return f"/subscriptions/{self.subscription_id}"
        raise ValueError(f"No valid scope found | EventId: {self.event_id}")

    def _parse_policy_definition_reference_ids(self, policy_def_ref_id):
        if not policy_def_ref_id:
            return None
        if isinstance(policy_def_ref_id, list):
            return policy_def_ref_id
        return [policy_def_ref_id]