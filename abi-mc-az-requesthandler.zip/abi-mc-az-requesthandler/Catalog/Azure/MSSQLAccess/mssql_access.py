from shared_code.sqlmgmt_client import SqlMgmtClient
from azure.mgmt.sql.models import ServerAzureADAdministrator,AdministratorType,ManagedInstanceAdministrator
from shared_code.client_secret_auth import ClientSecretAuth
from shared_code.lock_manager import LockManager
from shared_code.graphservice_client import GraphClient
from shared_code.policy_client import AzPolicyClient
from shared_code.networkmgmt_client import NetworkMgmtClient
from shared_code.privatedns_client import PrivateDNSClient
from azure.core.exceptions import HttpResponseError,ResourceNotFoundError
from datetime import datetime,timedelta
import pyodbc,logging,os,struct,json,uuid,time
import re

class AzMSSQLAccess:
    def __init__(self,json_data):
        self.subscription_id = json_data['SubscriptionId']
        self.subscription_name = json_data['SubscriptionName']
        self.zone = json_data['Zone'].lower()
        self.resource_group_name = json_data['ResourceGroupName']
        self.sql_server_name = json_data['SqlServerName']
        self.sql_db_names = json_data['SqlDbName'].split(",")
        self.members_ids = json.loads(json_data['MemberIds'])
        self.db_role = json_data['SqlDbRole']
        self.azenvironment = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.sql_mgmt_client = SqlMgmtClient().get_sql_mgmt_client(self.subscription_id,self.azenvironment)
        self.is_public_access_enabled_by_brewmation = None
        self.old_uai = None
        self.old_uai_dict = {}
        self.lock_client = LockManager(self.subscription_id,self.zone,self.resource_group_name,self.sql_server_name)
        self.private_endpoint_name = f"{self.sql_server_name}-pe-db-brewmation"
        self.dns_zone_name = "privatelink.sql.cn" if self.zone == "china" else "privatelink.database.windows.net"
        self.server_type,self.server = self.get_server_type()
        self.network_client = NetworkMgmtClient().get_network_mgmt_client("2db7c27b-2f9f-4088-981b-2bd88c5c1905",self.azenvironment) #global prod
        self.dns_client = PrivateDNSClient().get_dns_client("2db7c27b-2f9f-4088-981b-2bd88c5c1905", self.azenvironment)

    def get_server_type(self):
        try:
            return "logicalserver", self.sql_mgmt_client.servers.get(self.resource_group_name, self.sql_server_name)
        except ResourceNotFoundError:
            pass
        try:
            return "managedinstance", self.sql_mgmt_client.managed_instances.get(self.resource_group_name, self.sql_server_name)
        except ResourceNotFoundError:
            raise Exception(f"SQL Server '{self.sql_server_name}' not found in resource group '{self.resource_group_name}' and subscription '{self.subscription_id}'")

    def apply_firewall_rules(self):
        self.sql_mgmt_client.firewall_rules.create_or_update(
            self.resource_group_name,
            self.sql_server_name,
            "Brewmation",
            {
                "start_ip_address": '0.0.0.0',
                "end_ip_address": '255.255.255.255'
            }
        )
        logging.info(f"Firewall rule 'Brewmation' created for SQL Server '{self.sql_server_name}'")

    def enable_public_network_access(self):
        if self.server.public_network_access == "Enabled":
            logging.info(f"Public network access already enabled for SQL Server '{self.sql_server_name}'")
            return
        server = self.sql_mgmt_client.servers.begin_update(
            self.resource_group_name,
            self.sql_server_name,
            {
                "public_network_access": "Enabled"
            }
        )
        server.result()
        self.is_public_access_enabled_by_brewmation = True
        logging.info(f"Public network access enabled for SQL Server '{self.sql_server_name}'")
    
    def disable_public_network_access(self):
        if not self.is_public_access_enabled_by_brewmation:
            logging.info(f"Public network access not enabled by Brewmation for SQL Server '{self.sql_server_name}'")
            return
        server = self.sql_mgmt_client.servers.begin_update(
            self.resource_group_name,
            self.sql_server_name,
            {
                "public_network_access": "Disabled"
            }
        )
        server.result()
        logging.info(f"Public network access disabled for SQL Server '{self.sql_server_name}'")

    def remove_firewall_rules(self):
        self.sql_mgmt_client.firewall_rules.delete(
            self.resource_group_name,
            self.sql_server_name,
            "Brewmation"
        )
        logging.info(f"Firewall rule 'Brewmation' deleted for SQL Server '{self.sql_server_name}'")

    def add_administrators(self):
        if self.zone == 'naz':
            login = "AADS_A_ABI NAZ SQL DB Admins"
            sid = "eacb2675-7fbc-4f91-a3eb-906c78bd0043"
        elif self.zone == 'china':
            login = "Cloudbolt"
            sid = "6a956c8e-0e11-4d70-84ef-4ea2c018964b"
        else:
            login = "AADS_A_ABI GlobalOps SQL DB Admins"
            sid = "c643a250-a7e8-44b2-bc5f-7ed4437e7cf9"
        tenant_id = "cef04b19-7776-4a94-b89b-375c77a8f936" if self.zone != 'china' else "c99b23b6-4fa8-4eee-a7cc-2f420106e730"
        if self.server_type == 'managedinstance':
            self.sql_mgmt_client.managed_instance_administrators.begin_create_or_update(self.resource_group_name,self.sql_server_name,"ActiveDirectory",
            ManagedInstanceAdministrator(
                administrator_type=AdministratorType("ActiveDirectory"),
                login=login,
                sid=sid,
                tenant_id=tenant_id
                )
            ).result()
        else:
            self.sql_mgmt_client.server_azure_ad_administrators.begin_create_or_update(self.resource_group_name,self.sql_server_name,"ActiveDirectory", 
            ServerAzureADAdministrator(     
                administrator_type=AdministratorType("ActiveDirectory"),
                login=login,
                sid=sid,
                tenant_id=tenant_id
                )
            ).result()

    def add_managed_identity(self):
        parameters = {
                "identity": {
                    "type": "SystemAssigned,UserAssigned" if self.server.identity and self.server.identity.type.lower() in ["systemassigned","systemassigned,userassigned"] else "UserAssigned",
                    "user_assigned_identities": {
                        "/subscriptions/2db7c27b-2f9f-4088-981b-2bd88c5c1905/resourceGroups/CONFIG-MGMT-RG-GB-PROD/providers/Microsoft.ManagedIdentity/userAssignedIdentities/brewmation-sqlaccess-identity": {}
                    }
                },
                "primary_user_assigned_identity_id": "/subscriptions/2db7c27b-2f9f-4088-981b-2bd88c5c1905/resourceGroups/CONFIG-MGMT-RG-GB-PROD/providers/Microsoft.ManagedIdentity/userAssignedIdentities/brewmation-sqlaccess-identity"
            }
        if self.server_type == 'managedinstance':
            self.old_uai = self.server.primary_user_assigned_identity_id if self.server.primary_user_assigned_identity_id else None
            self.old_uai_dict = self.server.identity.user_assigned_identities if self.server.identity and self.server.identity.user_assigned_identities else {}
            server = self.sql_mgmt_client.managed_instances.begin_update(self.resource_group_name, self.sql_server_name, parameters)
            server.result()
        else:
            self.old_uai = self.server.primary_user_assigned_identity_id if self.server.primary_user_assigned_identity_id else None
            self.old_uai_dict = self.server.identity.user_assigned_identities if self.server.identity and self.server.identity.user_assigned_identities else {}
            server = self.sql_mgmt_client.servers.begin_update(self.resource_group_name, self.sql_server_name, parameters)
            server.result()
        logging.info(f"Managed Identity 'sql-access-mi' added to SQL Server '{self.sql_server_name}'")
    
    def update_managed_identity(self):
        if self.server_type == 'managedinstance':
            server = self.sql_mgmt_client.managed_instances.begin_update(self.resource_group_name, self.sql_server_name, {
                "primary_user_assigned_identity_id": self.old_uai
            })
            server.result()
            logging.info(f"Managed Identity 'sql-access-mi' updated on Managed Instance '{self.sql_server_name}'")
        else:   
            server = self.sql_mgmt_client.servers.begin_update(self.resource_group_name, self.sql_server_name, {
                "primary_user_assigned_identity_id": self.old_uai
            })
            server.result()
            logging.info(f"Managed Identity 'sql-access-mi' updated on SQL Server '{self.sql_server_name}'")

    def execute_query(self,connection_string,query,token):
        exptoken = b""
        for i in token.token:
            exptoken += bytes({ord(i)})
            exptoken += bytes(1)
        tokenstruct = struct.pack("=i", len(exptoken)) + exptoken
        try:
            with pyodbc.connect(connection_string, attrs_before={1256: tokenstruct}, timeout=30) as conn:
                cursor = conn.cursor()
                cursor.execute(query)
                logging.info(f"Query executed successfully")
        except Exception as e:
            logging.error(f"Error executing query: {str(e)}")
            raise e

    def provide_access_to_user(self,user):
        fqdn = self.server.fully_qualified_domain_name.replace("database.windows.net","privatelink.database.windows.net")
        spn = os.environ["SPN_SECRET_PUBLIC"] if self.zone != 'china' else os.environ["SPN_SECRET_CHINA"]
        token = ClientSecretAuth().client_credential(spn).get_token("https://database.windows.net//.default")
        connection_string = f"Driver={os.environ['DB_DRIVER']};Server=tcp:{fqdn},1433;Database=master;TrustServerCertificate=yes;"
        query = f"""
        DECLARE @User NVARCHAR(255) = N'{user}';
        -- Step 1: Create LOGIN in master if not exists
        IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = @User)
        BEGIN
            CREATE LOGIN [{user}] FROM EXTERNAL PROVIDER;
        END
        -- Step 2: Create USER in master if not exists
        IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = @User)
        BEGIN
            CREATE USER [{user}] FROM EXTERNAL PROVIDER;
        END
        """
        self.execute_query(connection_string,query,token)
        for db in self.sql_db_names:
            if self.if_db_exists(db):
                connection_string = f"Driver={os.environ['DB_DRIVER']};Server=tcp:{fqdn},1433;Database={db};TrustServerCertificate=yes;"
                query = f"""
                DECLARE @User NVARCHAR(255) = N'{user}';
                IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = @User)
                BEGIN
                    CREATE USER [{user}] FROM EXTERNAL PROVIDER;
                END
                IF NOT EXISTS (
                    SELECT 1 FROM sys.database_role_members drm
                    JOIN sys.database_principals role ON drm.role_principal_id = role.principal_id
                    JOIN sys.database_principals member ON drm.member_principal_id = member.principal_id
                    WHERE role.name = '{self.db_role}' AND member.name = @User
                )
                BEGIN
                    EXEC sp_addrolemember '{self.db_role}', @User;
                END
                """
                self.execute_query(connection_string,query,token)
        
    def if_db_exists(self,db_name):
        try:
            if self.server_type == 'managedinstance':
                self.sql_mgmt_client.managed_databases.get(self.resource_group_name, self.sql_server_name, db_name)
                return True
            else:
                self.sql_mgmt_client.databases.get(self.resource_group_name, self.sql_server_name, db_name)
                return True
        except Exception as e:
            logging.info(f"Database '{db_name}' does not exists")
            return False
        
    def exempt_policy(self,id):
        policy_client = AzPolicyClient().get_policy_client(self.subscription_id,self.azenvironment)
        try:
            response = policy_client.policy_exemptions.create_or_update(
            scope=f"/subscriptions/{self.subscription_id}/resourceGroups/{self.resource_group_name}/providers/Microsoft.Sql/servers/{self.sql_server_name}",
            policy_exemption_name=f"{self.sql_server_name}-Brewmation-{str(uuid.uuid4()).split('-')[0]}",
            parameters={
                "properties": {
                    "policyAssignmentId": id,
                    "exemptionCategory": "Waiver",
                    "expiresOn": datetime.now() + timedelta(hours=3),
                }
                },
            )
            logging.info(f"Policy exemption created: {response}")
            time.sleep(180)  # Wait for exemption to take effect
        except Exception as e:
            logging.error(f"Error creating policy exemption: {str(e)}")
            raise e

    async def get_user_principal_name(self,user_id):
        graph_client = GraphClient().get_graph_client(self.azenvironment)
        try:
            user = await graph_client.directory_objects.by_directory_object_id(user_id).get()
            if user.odata_type == "#microsoft.graph.user":
                return user.user_principal_name
            elif user.odata_type == "#microsoft.graph.servicePrincipal": 
                return user.app_display_name
            elif user.odata_type == "#microsoft.graph.application":
                return user.app_id
            elif user.odata_type == "#microsoft.graph.managedIdentity":
                return user.display_name
            elif user.odata_type == "#microsoft.graph.group":
                return user.display_name
            else:
                raise Exception(f"Unsupported object type: {user.odata_type}")
        except Exception as e:
            logging.error(f"Error fetching user principal name for user ID '{user_id}': {str(e)}")
            raise e 

    def create_private_endpoint_and_dns(self):
        sql_pe = self.network_client.private_endpoints.begin_create_or_update(
            "CONFIG-MGMT-RG-GB-PROD",
            self.private_endpoint_name,
            parameters={
                    "location": "westeurope",
                    "subnet": {
                        "id": "/subscriptions/2db7c27b-2f9f-4088-981b-2bd88c5c1905/resourceGroups/MGMTPVT-RG-GB-PROD/providers/Microsoft.Network/virtualNetworks/PVT-VNET-GB-PROD/subnets/DB"
                    },
                    "privateLinkServiceConnections": [{
                        "name": f"{self.private_endpoint_name}-dnsconfig",
                        "properties": {
                            "privateLinkServiceId": self.server.id,
                            "groupIds": ["sqlServer"] if self.server_type == "logicalserver" else ["managedInstance"],
                            "requestMessage": None
                        }
                    }],
                }
        ).result()
        logging.info(f"Private endpoint '{self.private_endpoint_name}' created for SQL Server '{self.sql_server_name}'")
        pe_dns = self.dns_client.private_zones.get(
            "MGMTPVTDNS-RG-GB-PROD",
            self.dns_zone_name
        )
        sql_dns = self.network_client.private_dns_zone_groups.begin_create_or_update(
            "CONFIG-MGMT-RG-GB-PROD",
            self.private_endpoint_name,
            "default",
            parameters={
                "privateDnsZoneConfigs": [{
                    "name": self.dns_zone_name,
                    "properties": {
                        "privateDnsZoneId": pe_dns.id
                    }
                }]
            }
        ).result()
        time.sleep(30)  # Wait for DNS propagation
        logging.info(f"Private DNS zone group created for endpoint '{self.private_endpoint_name}'")


    def delete_private_dns(self):
        try:
            self.network_client.private_dns_zone_groups.begin_delete(
                "CONFIG-MGMT-RG-GB-PROD",
                self.private_endpoint_name,
                "default"
            ).result()
            logging.info(f"Private DNS zone group deleted from endpoint '{self.private_endpoint_name}'")
        except Exception as e:
            logging.warning(f"Could not delete DNS zone group for '{self.private_endpoint_name}': {str(e)}")

    def delete_private_endpoint(self):
        try:
            lock_client = LockManager('2db7c27b-2f9f-4088-981b-2bd88c5c1905', self.zone, "MGMTPVTDNS-RG-GB-PROD")
            lock_client.remove_all_locks()
            self.network_client.private_endpoints.begin_delete(
                "CONFIG-MGMT-RG-GB-PROD",
                self.private_endpoint_name
            ).result()
            lock_client.restore_locks()
            logging.info(f"Private endpoint '{self.private_endpoint_name}' deleted for SQL Server '{self.sql_server_name}'")
        except Exception as e:
            logging.error(f"Error deleting private endpoint '{self.private_endpoint_name}': {str(e)}")

    async def grant_access_old(self):
        try:
            self.lock_client.remove_all_locks()
            self.add_administrators()
            self.enable_public_network_access()
            self.apply_firewall_rules()
            self.add_managed_identity()
            for member in self.members_ids:
                member_principal_name = await self.get_user_principal_name(member["OID"])
                self.provide_access_to_user(member_principal_name)
        except HttpResponseError as e:
            if "RequestDisallowedByPolicy" in e.error.code:
                logging.warning("Access grant was blocked by policy, attempting to exempt policy and retry")
                match = re.search(r'"policyAssignment":\{"name":".+?","id":"(.*?)"', e.error.message)
                id = match.group(1) if match else None
                try:
                    self.exempt_policy(id)
                    self.enable_public_network_access()
                    self.apply_firewall_rules()
                    self.add_managed_identity()
                    for member in self.members_ids:
                        member_principal_name = await self.get_user_principal_name(member["OID"])
                        self.provide_access_to_user(member_principal_name)
                except Exception as ex:
                    logging.error(f"Retry after policy exemption failed: {str(ex)}")
                    raise ex
                logging.error(f"Error granting access: {str(e)}")
            else:
                raise e
        finally:
            self.update_managed_identity()
            self.remove_firewall_rules()
            self.disable_public_network_access()
            self.lock_client.restore_locks()

    async def grant_access(self):
        try:
            self.lock_client.remove_all_locks()
            self.add_managed_identity()
            self.add_administrators()
            for member in self.members_ids:
                member_principal_name = await self.get_user_principal_name(member["OID"])
                self.provide_access_to_user(member_principal_name)
        except Exception as e:
            logging.error(f"Error granting access: {str(e)} Creating PE and trying")
            self.create_private_endpoint_and_dns()
            try:
                for member in self.members_ids:
                    member_principal_name = await self.get_user_principal_name(member["OID"])
                    self.provide_access_to_user(member_principal_name)
            except Exception as ex:
                logging.error(f"Retry after creating private endpoint failed: {str(ex)}")
                raise ex
        finally:
            self.delete_private_dns()
            self.delete_private_endpoint()
            self.update_managed_identity()
            self.lock_client.restore_locks()