import logging,json,time
from azure.mgmt.compute.models import VirtualMachineExtension
from shared_code.compute_client import ComputeClient
from shared_code.lock_manager import LockManager
from DAL.DbActivityManager import DbActivityManager
from shared_code.EmailNotification.NotifyUser import NotifyUser

class AzVMCreds:
    def __init__(self,data):
        self.data = data
        self.subscription_id = data["SubscriptionId"]
        self.resource_group_name = data["ResourceGroupName"]
        self.vm_name = data["ResourceName"]
        self.vm_id = data["ResourceId"]
        self.access_key = data["AccessKey"]
        self.zone = data['Zone'].lower()
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.compute_client = ComputeClient().get_compute_client(self.subscription_id, self.cloud)
        self.lock_manager = LockManager(self.subscription_id, self.zone, self.resource_group_name,self.vm_name,self.vm_id)

    def is_vm_agent_available(self):
        response = self.compute_client.virtual_machines.instance_view(self.resource_group_name, self.vm_name)
        if response.vm_agent is None:
            return False
        if response.vm_agent.statuses[0].display_status == 'Ready':
            return True
        return False
    
    def get_vm_os_type_and_location(self):
        response = self.compute_client.virtual_machines.get(self.resource_group_name, self.vm_name,expand='instanceView')
        if response.storage_profile.os_disk.os_type == 'Windows':
            if hasattr(response.storage_profile, 'image_reference') and response.storage_profile.image_reference:
                sku = response.storage_profile.image_reference.sku
                if sku is not None and any(year in sku for year in ['2008', '2012','2016', '2019','2022','2025']):
                    return 'windows-old', response.location
            os_name = getattr(response.instance_view, 'os_name', '').lower()
            if 'windows' in os_name:
                if any(year in os_name for year in ['2008', '2012', '2016', '2019','2022','2025']):
                    return 'windows-old', response.location
                return 'windows', response.location        
        return 'linux', response.location
        # elif response.storage_profile.os_disk.os_type == 'Linux':
        #     if response.storage_profile.image_reference.publisher == 'Canonical':
        #         return 'linux-debian', response.location
        #     return 'linux-redhat', response.location
        # else:
        #     raise Exception(f'Unknown OS type for VM {self.vm_name}')
    
    def get_vm_admin(self):
        if self.data.get('admin_username'):
            return self.data['admin_username']
        response = self.compute_client.virtual_machines.get(self.resource_group_name, self.vm_name)
        return response.os_profile.admin_username
    
    async def notify_user(self,vm_name,status,comments):
        event = {}
        objdb = DbActivityManager()
        dataset = objdb.get_event_info(self.data['EventId'])
        event['SnowItemId'] = dataset[0].SnowItemId
        requested_by = dataset[0].RequestedBy
        event['details']=[
            {
             'vm_name':vm_name,
             'status':status,
             'comments':comments
            }
        ]
        await NotifyUser().send_email_notification(event,requested_by)
    
    def get_command(self,access_key,os_type):
        commands = {
            'windows': f"""
                powershell -Command "$x = '{access_key}'; $AbiCloudAdminCheck = Get-LocalUser -Name AbiCloudAdmin -ErrorAction SilentlyContinue; if ($AbiCloudAdminCheck) {{ Enable-LocalUser -Name AbiCloudAdmin }} else {{ New-LocalUser -Name AbiCloudAdmin -Password (ConvertTo-SecureString -String $x -AsPlainText -Force); Add-LocalGroupMember -Group Administrators -Member AbiCloudAdmin }}; Set-LocalUser -Name AbiCloudAdmin -Password (ConvertTo-SecureString -String $x -AsPlainText -Force); $ExpirationDate = (Get-Date).AddDays(1); Set-LocalUser -Name AbiCloudAdmin -AccountExpires $ExpirationDate; Write-Output 'Password reset successfully for user';"            """,
            "windows-old": f"""
                powershell -Command "$x = '{access_key}';  if (net user AbiCloudAdmin 2>$null) {{ net user AbiCloudAdmin /active:yes /expires:never ;}} else {{ net user AbiCloudAdmin $x /ADD /y; net localgroup administrators AbiCloudAdmin /add ;}}; net user AbiCloudAdmin $x /y; wmic useraccount where \\"name='AbiCloudAdmin'\\" set PasswordExpires=FALSE; $CurrentDate = (Get-Date).AddHours(24); $NextDay = Get-Date -Date $CurrentDate -Format 'MM/dd/yyyy'; net user AbiCloudAdmin /expires:$NextDay; echo 'Password reset successfully for user';"
            """,
            'linux': f"""
                #!/bin/bash
                cat /etc/passwd | grep AbiCloudAdmin
                UserCheck=$(echo $?)
                if [ "$UserCheck" -eq '0' ]; then
                    echo "AbiCloudAdmin exists"
                else
                    useradd AbiCloudAdmin
                fi
                rdm="{access_key}"
                usermod --password $(echo $rdm|openssl passwd -1 -stdin) AbiCloudAdmin
                chage -E '1 day' -M 9999 AbiCloudAdmin
                echo "AbiCloudAdmin ALL=(ALL) NOPASSWD: ALL" > /etc/sudoers.d/AbiCloudAdmin
                usermod -aG sshusers AbiCloudAdmin &>/dev/null
                echo 'Password reset successfully for user'
            """,
        }
        return commands.get(os_type,None)

    async def vm_creds(self):
        if not self.is_vm_agent_available():
            logging.error(f'VM Agent is not available or VM is not running on {self.vm_name}')
            await self.notify_user(self.vm_name,'Failed',"VM is not running or VM Agent is not available")
            raise Exception(f'VM Agent is not available or VM is not running on {self.vm_name}')
        self.lock_manager.remove_all_locks()
        try:
            os_type,location = self.get_vm_os_type_and_location()
            if  os_type in ['windows','windows-old']:
                puslisher = 'Microsoft.Compute'
                type_properties_type = 'CustomScriptExtension'
                type_handler_version = '1.10'
            else:
                puslisher = 'Microsoft.Azure.Extensions'
                type_properties_type = 'CustomScript'
                type_handler_version = '2.1'
            response = self.compute_client.virtual_machine_extensions.list(resource_group_name=self.resource_group_name, vm_name=self.vm_name)
            if response.value:
                for ext in response.value:
                    if ext.publisher in ["Microsoft.Compute","Microsoft.Azure.Extensions"] and ext.type_properties_type in ["CustomScript","CustomScriptExtension"]:
                        response = self.compute_client.virtual_machine_extensions.begin_delete(resource_group_name=self.resource_group_name, vm_name=self.vm_name, vm_extension_name=ext.name)
                        result = response.result()
                        logging.info(f'VM Access Extension deleted successfully')
                        break
            response = self.compute_client.virtual_machine_extensions.begin_create_or_update(
                    resource_group_name=self.resource_group_name, 
                    vm_name=self.vm_name, 
                    vm_extension_name='Bewmation-VM-Creds', 
                    extension_parameters=VirtualMachineExtension(
                        location=location,
                        publisher=puslisher,
                        type_properties_type=type_properties_type, 
                        type_handler_version=type_handler_version, 
                        protected_settings= {
                            'commandToExecute': self.get_command(self.access_key,os_type)}
                        )
                )
            max_wait_seconds = 30 * 60
            start = time.time()
            interval = 5
            while not response.done() and (time.time() - start) < max_wait_seconds:
                time.sleep(interval)
                interval = min(interval * 2, 60)
            if not response.done():
                raise Exception('Timedout')
            result = response.result()
            logging.info(f'VM Access Extension created successfully {result.as_dict()}')
            response = self.compute_client.virtual_machine_extensions.get(
                resource_group_name=self.resource_group_name,
                vm_name=self.vm_name,
                vm_extension_name='Bewmation-VM-Creds',
                expand='instanceView'
            )
            if os_type in ['windows','windows-old'] and response.instance_view.substatuses != None:
                if not "Password reset successfully for user" in response.instance_view.substatuses[0].message:
                    await self.notify_user(self.vm_name,'Failed',"Password Reset Failed")
                    logging.error(f'Error while VM Cred Reset {response.as_dict()}')
                    raise Exception(f'Error while VM Cred Reset {response.as_dict()}')
            else:
                if not "Password reset successfully for user" in response.instance_view.statuses[0].message or "Enable failed:" in response.instance_view.statuses[0].message:
                    await self.notify_user(self.vm_name,'Failed',"Password Reset Failed")
                    logging.error(f'Error while VM Cred Reset {response.as_dict()}')
                    raise Exception(f'Error while VM Cred Reset {response.as_dict()}')
            await self.notify_user(self.vm_name,'Successful',"Password Reset Successfully")
            logging.info(f'VM Access Added successfully {response.as_dict()}')
        except Exception as e:
            logging.error(f'Error while adding VM Access {e}')
            raise e
        finally:
            response = self.compute_client.virtual_machine_extensions.begin_delete(
                resource_group_name=self.resource_group_name,
                vm_name=self.vm_name,
                vm_extension_name='Bewmation-VM-Creds'
            )
            result = response.result()
            logging.info(f'Removed VM Creds Extension')
            self.lock_manager.restore_locks()