from shared_code.graphservice_client import GraphClient
from msgraph.generated.groups.groups_request_builder import GroupsRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from msgraph.generated.models.group import Group
from shared_code.authorization_client import AuthorizationClient
from azure.mgmt.authorization.v2020_10_01_preview.models import (RoleAssignmentScheduleRequest,
                                                                RoleAssignmentScheduleRequestPropertiesScheduleInfo,
                                                                RoleAssignmentScheduleRequestPropertiesScheduleInfoExpiration,
                                                                Type,
                                                                RequestType)
import logging,asyncio,uuid,datetime,json,traceback,time
from shared_code.resourcemgmt_client import ResourceMgmtClient
from azure.core.exceptions import HttpResponseError

class AzRbacPublic:

    def __init__(self,json_data) -> None:
        self.subscription_id = json_data['SubscriptionId']
        self.subscription_name = json_data['SubscriptionName']
        self.auth_client = AuthorizationClient().get_auth_client("AzurePublicCloud",self.subscription_id) if self.subscription_id else None
        self.graph_client_obj = GraphClient()
        self.scope_type = json_data['Scope'].lower()
        self.members_id = json.loads(json_data['MemberIds'])
        match self.scope_type:
            case "managementgroup":
                self.scope = json_data['ManagementGroupId']
                self.managementgroup = json_data['ManagementGroupName'].split(" > ")
                self.auth_client = AuthorizationClient().get_auth_client("AzurePublicCloud",'73f88e6b-3a35-4612-b550-555157e7059f')
            case "subscription":
                self.scope = f"subscriptions/{self.subscription_id}"
            case "resourcegroup":
                self.resource_group = json_data['ResourceGroupId']
                self.scope = f"subscriptions/{self.subscription_id}/resourceGroups/{self.resource_group}"
            case "resource":
                self.scope = json_data["ResourceId"]
                self.resource = json_data["ResourceId"]
                self.resource_group = json_data['ResourceGroupId']
        self.roles = json.loads(json_data['Roles'])
        self.is_temporary = json_data['IsTemporary'].lower()
        self.duration = json_data['Duration'] if self.is_temporary == '1' else None
        self.justification = json_data['Justification']
        self.error = None

    def is_role_assignments_exhausted(self):
        try:
            logging.info("Checking role assignments metrics for subscription")
            metrics = self.auth_client.role_assignment_metrics.get_metrics_for_subscription()
            logging.info(f"Result: {metrics}")
            if metrics.role_assignments_remaining_count == 0:
                return True
            return False
        except Exception as e:
            logging.error(e)
            self.error = traceback.format_exc()
            return None
        
    def batch(self,iterable, n=1):
        l = len(iterable)
        for ndx in range(0, l, n):
            yield iterable[ndx:min(ndx + n, l)]
        
    def get_role_assignments(self):
        result = []
        try:
            logging.info("Getting role definitions for subscription")
            role_assignments = self.auth_client.role_assignments.list_for_subscription()
            for role in role_assignments:
                result.append(role.as_dict())
            return result
        except Exception as e:
            logging.error(e)
            self.error = traceback.format_exc()
            return False
    
    async def is_member_of_group(self,group_id,user_id):
        logging.info(f"Checking if member is present in group - {group_id} , member - {user_id}")
        try: 
            self.graph_client= self.graph_client_obj.get_client_request_adapter("AzurePublicCloud")
            query_params = GroupsRequestBuilder.GroupsRequestBuilderGetQueryParameters(
                        filter = f"id eq '{user_id}'",
                    )
            request_configuration = RequestConfiguration(query_parameters = query_params,)
            request_configuration.headers.add("ConsistencyLevel", "eventual")
            result = await self.graph_client.groups.by_group_id(group_id).members.count.get(request_configuration = request_configuration)
            # await self.graph_client_obj.close()
            logging.info(result)
            if result == 0:
                return False
            return True
        except Exception as e:
            logging.error(e)
            self.error = traceback.format_exc()
            return None

    async def add_member_to_group(self,group_id,members_id:list):
        logging.info(f"Adding members - {members_id} to the group - {group_id}")
        try:
            self.graph_client= self.graph_client_obj.get_client_request_adapter("AzurePublicCloud")
            additional_data = {}
            additional_data["members@odata.bind"] = []
            for member_id in members_id:
                if not await self.is_member_of_group(group_id,member_id['OID']):
                    additional_data["members@odata.bind"].append(f"https://graph.microsoft.com/v1.0/directoryObjects/{member_id['OID']}")
            if len(additional_data["members@odata.bind"]) == 0:
                logging.info("No new members to add to the group")
                return True
            request_body = Group(additional_data=additional_data)
            result = await self.graph_client.groups.by_group_id(group_id).patch(request_body)
            # await self.graph_client_obj.close()
            logging.info(f"Result: {result}")
            return True
        except Exception as e:
            logging.error(e)
            self.error = traceback.format_exc()
            raise e
        
    async def create_group(self,group_name):
        logging.info(f"Creating Group with name {group_name}")
        try:
            self.graph_client= self.graph_client_obj.get_client_request_adapter("AzurePublicCloud")
            request_body = Group(
                description = None,
                display_name = group_name,
                group_types = [],
                mail_enabled = False,
                mail_nickname = "library",
                security_enabled = True,
            )   
            result = await self.graph_client.groups.post(request_body)
            # await self.graph_client_obj.close()
            logging.info(f"Result: {result}")
            time.sleep(120)
            return result.id
        except Exception as e:
            logging.error(e)
            self.error = traceback.format_exc()
            raise e
        
    async def delete_group(self,group_id):
        logging.info(f"Removing Group - {group_id}")
        try: 
            self.graph_client= self.graph_client_obj.get_client_request_adapter("AzurePublicCloud")
            result = await self.graph_client.groups.by_group_id(group_id).delete()
            # await self.graph_client_obj.close()
            logging.info(result)
            return True
        except Exception as e:
            logging.error(e)
            self.error = traceback.format_exc()
            return False
        
    async def exists_group(self,group_name):
        logging.info(f"Checking if group exists - {group_name}")
        try: 
            self.graph_client= self.graph_client_obj.get_client_request_adapter("AzurePublicCloud")
            query_params = GroupsRequestBuilder.GroupsRequestBuilderGetQueryParameters(
                        count=True,
                        filter = f"displayName eq '{group_name}'", 
                    )
            request_configuration = RequestConfiguration(query_parameters = query_params)
            request_configuration.headers.add("ConsistencyLevel", "eventual")
            result = await self.graph_client.groups.get(request_configuration = request_configuration)
            # await self.graph_client_obj.close()
            logging.info(result)
            if result.odata_count == 0:
                return False
            return result.value[0].id
        except Exception as e:
            logging.error(e)
            self.error = traceback.format_exc()
            return None
        
    def add_role_to_member(self,scope,role_assignment_name,role_def_id,member_id):
        logging.info(f"Adding Role assignments")
        parameters = {
                "properties": {
                    "principalId": member_id,
                    "principalType": "Group",
                    "roleDefinitionId": role_def_id
                    }
                }
        try :
            result = self.auth_client.role_assignments.create(scope,role_assignment_name=role_assignment_name,parameters=parameters)
            logging.info(result)
            return True
        except Exception as e:
            logging.error(e)
            self.error = traceback.format_exc()
            raise e
    
    def get_role_definitions(self,scope):
        result = []
        logging.info(f"Get all role definitions")
        try:
            response = self.auth_client.role_definitions.list(scope=scope)
            for item in response:
                result.append(item.as_dict())            
            return result
        except Exception as e:
            logging.error(e)
            self.error = traceback.format_exc()
            return False
    
    def get_existing_roles_for_member(self,scope,member_id):
        result = []
        try :
            role_assignments = self.auth_client.role_assignments.list_for_scope(scope=scope,filter=f"principalId eq '{member_id}'")
            for role in role_assignments:
                result.append(role.as_dict())
            return result
        except Exception as e:
            logging.info(e)
            self.error = traceback.format_exc()
            return False
    
    def exists_role_for_member(self,scope,role_def_id,member_id):
        try :
            role_assignments = self.auth_client.role_assignments.list_for_scope(scope=scope,filter=f"principalId eq '{member_id}'")
            for role in role_assignments:
                if role.role_definition_id.lower() == role_def_id.lower() or role.role_definition_id.split('/')[-1] == role_def_id.split('/')[-1]:
                    return True
            return False
        except Exception as e:
            logging.info(e)
            self.error = traceback.format_exc()
            return None

    def delete_role_from_member(self,scope,role_assignment_name):
        try :
            result = self.auth_client.role_assignments.delete(scope,role_assignment_name)
            logging.info(result)
            return True
        except Exception as e:
            logging.info(e)
            self.error = traceback.format_exc()
            return False
    
    def grant_pim(self):
        result = []
        try:
            for role in self.roles:
                for member in self.members_id:
                    try:
                        uid = str(uuid.uuid4())
                        status = self.auth_client.role_assignment_schedule_requests.create(
                        scope = self.scope,
                        role_assignment_schedule_request_name= uid,
                        parameters= RoleAssignmentScheduleRequest(
                            request_type = RequestType.ADMIN_ASSIGN,
                            justification = self.justification,
                            role_definition_id = role['role_id'],
                            principal_id = member['OID'],
                            schedule_info = RoleAssignmentScheduleRequestPropertiesScheduleInfo(
                                start_date_time = datetime.datetime.now(datetime.timezone.utc),
                                expiration = RoleAssignmentScheduleRequestPropertiesScheduleInfoExpiration(
                                    type = Type.AFTER_DURATION,
                                    duration = f"PT{self.duration}H"
                                    ),
                                ),
                            )
                        )
                        logging.info(status)
                        result.append({'Role':role['role_id'],'Member':member,'Status': True,'Message':'Success'})
                    except HttpResponseError as e:
                        if "RoleAssignmentExists" in str(e.error.code):
                            result.append({'Role':role['role_id'],'Member':member,'Status': True,'Message':'Already Assigned'})
                            continue
            return result,self.error
        except Exception as e:
            logging.error(f'Error in Assigning PIM for {member} role {role} - {e}')
            self.error = traceback.format_exc()
            result.append({'Role':role['role_id'],'Member':member,'Status': False,'Message':e})
            raise e
            
    async def grant_rbac(self):
        if self.scope_type in ["resourcegroup","resource"]:
            self.resource_client = ResourceMgmtClient().get_resource_client("AzurePublicCloud",self.subscription_id)
            if self.scope_type == "resourcegroup":
                exists = self.resource_client.resource_groups.check_existence(self.resource_group)
                if not exists:
                    raise Exception(f"Scope does not exist - {self.resource_group}")
            elif self.scope_type == "resource":
                try:
                    exists = self.resource_client.resources.get_by_id(self.resource,self.resource.split('/')[-1])
                except HttpResponseError as e:
                    if e.error.code == "ResourceNotFound":
                        raise Exception(f"Scope does not exist - {self.resource}")
        if self.is_temporary == '1' and self.duration:
            return self.grant_pim()
        logging.info("Granting RBAC")
        result = []
        if self.is_role_assignments_exhausted():
            logging.error("Role assignments are exhausted for subscription")
            self.error = "Role assignments are exhausted for subscription"
            return False,self.error
        for role in self.roles:
            if role['role_name'].lower() == 'reader' and self.scope_type != "managementgroup":
                match self.scope_type:
                    case "subscription":
                        group_name = f"AADS_A_CMP_{self.subscription_name} Reader Users"
                    case "resourcegroup":
                        group_name = f"AADS_A_CMP_{self.subscription_name} {self.resource_group} Reader Users"
                    case "resource":
                        group_name = f"AADS_A_CMP_{self.subscription_name} {self.resource_group} {self.resource.split('/')[-1]} Reader Users"
                group_id = await self.exists_group(group_name)
                if group_id:
                    if not self.exists_role_for_member(self.scope,role['role_id'],group_id):
                        temp = self.add_role_to_member(self.scope,str(uuid.uuid4()),role['role_id'],group_id)
                    for batch_members in self.batch(self.members_id,20):
                        temp = await self.add_member_to_group(group_id,batch_members)
                    result.append({"Role":role,"Status":temp})
                else:
                    group_id = await self.create_group(group_name)
                    for batch_members in self.batch(self.members_id,20):
                        temp1 = await self.add_member_to_group(group_id,batch_members)
                    temp2 = self.add_role_to_member(self.scope,str(uuid.uuid4()),role['role_id'],group_id) ## Reader Role
                    result.append({"Role":role,"Status":temp1 and temp2})
            elif role['role_name'].lower() == 'custom_contributor':
                match self.scope_type:
                    case "resourcegroup":
                        group_name = f"AADS_A_CMP_{self.subscription_name} {self.resource_group} Custom Contributor Users"
                    case "resource":
                        group_name = f"AADS_A_CMP_{self.subscription_name} {self.resource_group} {self.resource.split('/')[-1]} Custom Contributor Users"
                group_id = await self.exists_group(group_name)
                if group_id:
                    if not self.exists_role_for_member(self.scope,role['role_id'],group_id):
                        temp = self.add_role_to_member(self.scope,str(uuid.uuid4()),role['role_id'],group_id)
                    for batch_members in self.batch(self.members_id,20):
                        temp = await self.add_member_to_group(group_id,batch_members)
                    result.append({"Role":role,"Status":temp})
                else:
                    group_id = await self.create_group(group_name)
                    for batch_members in self.batch(self.members_id,20):
                        temp1 = await self.add_member_to_group(group_id,batch_members)
                    temp2 = self.add_role_to_member(self.scope,str(uuid.uuid4()),role['role_id'],group_id) ## Contributor Role
                    result.append({"Role":role,"Status":temp1 and temp2})
            else:
                match self.scope_type:
                    case "resourcegroup":
                        group_name = f"AADS_A_CMP_{self.subscription_name} {self.resource_group} {role['role_name']} Users"
                    case "resource":
                        group_name = f"AADS_A_CMP_{self.subscription_name} {self.resource_group} {self.resource.split('/')[-1]} {role['role_name']} Users"
                    case "subscription":
                        group_name = f"AADS_A_CMP_{self.subscription_name} {role['role_name']} Users"
                    case "managementgroup":
                        group_name = f"AADS_A_CMP_{''.join(self.managementgroup[1:])} ManagementGroup {role['role_name']} Users"
                group_id = await self.exists_group(group_name)
                if group_id:
                    if not self.exists_role_for_member(self.scope,role['role_id'],group_id):
                        temp = self.add_role_to_member(self.scope,str(uuid.uuid4()),role['role_id'],group_id)
                    for batch_members in self.batch(self.members_id,20):
                        temp = await self.add_member_to_group(group_id,batch_members)
                    result.append({"Role":role,"Status":temp})
                elif group_id == False:
                    group_id = await self.create_group(group_name)
                    for batch_members in self.batch(self.members_id,20):
                        temp1 = await self.add_member_to_group(group_id,batch_members)
                    temp2 = self.add_role_to_member(self.scope,str(uuid.uuid4()),role['role_id'],group_id)                      
                    result.append({"Role":role,"Status":temp1 and temp2})
                else:
                    raise ValueError("Unexpected group ID state")
        return result,self.error