from shared_code.graphservice_client import GraphClient
from msgraph.generated.groups.groups_request_builder import GroupsRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from msgraph.generated.models.group import Group
from shared_code.authorization_client import AuthorizationClient
from azure.mgmt.authorization.v2020_10_01_preview.models import (RoleAssignmentScheduleRequest,
                                                                RoleAssignmentScheduleRequestPropertiesScheduleInfo,
                                                                RoleAssignmentScheduleRequestPropertiesScheduleInfoExpiration,
                                                                Type,
                                                                RequestType)
import logging,asyncio,uuid,datetime,json,traceback,time
from azure.core.exceptions import HttpResponseError

class AzRbacChina:

    def __init__(self,json_data) -> None:
        self.subscription_id = json_data['SubscriptionId']
        self.subscription_name = json_data['SubscriptionName']
        self.auth_client = AuthorizationClient().get_auth_client("AzureChinaCloud",self.subscription_id) if self.subscription_id else None
        self.graph_client_obj = GraphClient()
        self.scope_type = json_data['Scope'].lower()
        self.members_id = json.loads(json_data['MemberIds'])
        match self.scope_type:
            case "managementgroup":
                self.scope = json_data['ManagementGroupId']
                self.auth_client = AuthorizationClient().get_auth_client("AzureChinaCloud",'08ba6e07-14eb-4984-9176-9261b8a2781d')
            case "subscription":
                self.scope = f"subscriptions/{self.subscription_id}"
            case "resourcegroup":
                self.resource_group = json_data['ResourceGroupId']
                self.scope = f"subscriptions/{self.subscription_id}/resourceGroups/{self.resource_group}"
            case "resource":
                self.scope = json_data["ResourceId"]
                self.resource = json_data["ResourceId"]
                self.resource_group = json_data['ResourceGroupId']
        self.roles = json.loads(json_data['Roles'])
        self.is_temporary = json_data['IsTemporary'].lower()
        self.duration = json_data['Duration'] if self.is_temporary == '1' else None
        self.justification = json_data['Justification']
        self.error = None

    def is_role_assignments_exhausted(self):
        try:
            logging.info("Checking role assignments metrics for subscription")
            metrics = self.auth_client.role_assignment_metrics.get_metrics_for_subscription()
            logging.info(f"Result: {metrics}")
            if metrics.role_assignments_remaining_count == 0:
                return False
            return True
        except Exception as e:
            logging.error(e)
            self.error = traceback.format_exc()
            return None
        
    def get_role_assignments(self):
        result = []
        try:
            logging.info("Getting role definitions for subscription")
            role_assignments = self.auth_client.role_assignments.list_for_subscription()
            for role in role_assignments:
                result.append(role.as_dict())
            return result
        except Exception as e:
            logging.error(e)
            self.error = traceback.format_exc()
            return False
    
    async def is_member_of_group(self,group_id,user_id):
        logging.info(f"Checking if member is present in group - {group_id} , member - {user_id}")
        try: 
            self.graph_client= self.graph_client_obj.get_client_request_adapter("AzureChinaCloud")
            query_params = GroupsRequestBuilder.GroupsRequestBuilderGetQueryParameters(
                        filter = f"id eq '{user_id}'",
                    )
            request_configuration = RequestConfiguration(query_parameters = query_params,)
            request_configuration.headers.add("ConsistencyLevel", "eventual")
            result = await self.graph_client.groups.by_group_id(group_id).members.count.get(request_configuration = request_configuration)
            # await self.graph_client_obj.close()
            logging.info(result)
            if result == 0:
                return True
            return False
        except Exception as e:
            logging.error(e)
            self.error = traceback.format_exc()
            return None

    async def add_member_to_group(self,group_id,members_id:list):
        logging.info(f"Adding members - {members_id} to the group - {group_id}")
        try:
            self.graph_client= self.graph_client_obj.get_client_request_adapter("AzureChinaCloud")
            additional_data = {}
            additional_data["members@odata.bind"] = []
            for member_id in members_id:
                additional_data["members@odata.bind"].append(f"https://microsoftgraph.chinacloudapi.cn/v1.0/directoryObjects/{member_id['OID']}")
            if len(additional_data["members@odata.bind"]) == 0:
                logging.info("No new members to add to the group")
                return True
            request_body = Group(additional_data=additional_data)
            result = await self.graph_client.groups.by_group_id(group_id).patch(request_body)
            # await self.graph_client_obj.close()
            logging.info(f"Result: {result}")
            return True
        except Exception as e:
            logging.error(e)
            self.error = traceback.format_exc()
            return False
        
    async def create_group(self,group_name):
        logging.info(f"Creating Group with name {group_name}")
        try:
            self.graph_client= self.graph_client_obj.get_client_request_adapter("AzureChinaCloud")
            request_body = Group(
                description = None,
                display_name = group_name,
                group_types = [],
                mail_enabled = False,
                mail_nickname = "library",
                security_enabled = True,
            )   
            result = await self.graph_client.groups.post(request_body)
            # await self.graph_client_obj.close()
            time.sleep(120)
            logging.info(f"Result: {result}")
            return result.id
        except Exception as e:
            logging.error(e)
            self.error = traceback.format_exc()
            return False
        
    async def delete_group(self,group_id):
        logging.info(f"Removing Group - {group_id}")
        try: 
            self.graph_client= self.graph_client_obj.get_client_request_adapter("AzureChinaCloud")
            result = await self.graph_client.groups.by_group_id(group_id).delete()
            # await self.graph_client_obj.close()
            logging.info(result)
            return True
        except Exception as e:
            logging.error(e)
            self.error = traceback.format_exc()
            return False
        
    async def exists_group(self,group_name):
        logging.info(f"Checking if group exists - {group_name}")
        try: 
            self.graph_client= self.graph_client_obj.get_client_request_adapter("AzureChinaCloud")
            query_params = GroupsRequestBuilder.GroupsRequestBuilderGetQueryParameters(
                        count=True,
                        filter = f"displayName eq '{group_name}'", 
                    )
            request_configuration = RequestConfiguration(query_parameters = query_params)
            request_configuration.headers.add("ConsistencyLevel", "eventual")
            result = await self.graph_client.groups.get(request_configuration = request_configuration)
            # await self.graph_client_obj.close()
            logging.info(result)
            if result.odata_count == 0:
                return False
            return result.value[0].id
        except Exception as e:
            logging.error(e)
            self.error = traceback.format_exc()
            return None
        
    def add_role_to_member(self,scope,role_assignment_name,role_def_id,member_id):
        logging.info(f"Adding Role assignments")
        parameters = {
                "properties": {
                    "principalId": member_id,
                    "principalType": "Group",
                    "roleDefinitionId": role_def_id
                    }
                }
        try :
            result = self.auth_client.role_assignments.create(scope,role_assignment_name=role_assignment_name,parameters=parameters)
            logging.info(result)
            return True
        except Exception as e:
            logging.error(e)
            self.error = traceback.format_exc()
            return False
    
    def get_role_definitions(self,scope):
        result = []
        logging.info(f"Get all role definitions")
        try:
            response = self.auth_client.role_definitions.list(scope=scope)
            for item in response:
                result.append(item.as_dict())            
            return result
        except Exception as e:
            logging.error(e)
            self.error = traceback.format_exc()
            return False
        
    def get_existing_roles_for_member(self,scope,member_id):
        result = []
        try :
            role_assignments = self.auth_client.role_assignments.list_for_scope(scope=scope,filter=f"principalId eq '{member_id}'")
            for role in role_assignments:
                result.append(role.as_dict())
            return result
        except Exception as e:
            logging.info(e)
            self.error = traceback.format_exc()
            return False
    
    def exists_role_for_member(self,scope,role_def_id,member_id):
        try :
            role_assignments = self.auth_client.role_assignments.list_for_scope(scope=scope,filter=f"principalId eq '{member_id}'")
            for role in role_assignments:
                if role.role_definition_id == role_def_id:
                    return True
            return False
        except Exception as e:
            logging.info(e)
            self.error = traceback.format_exc()
            return None

    def delete_role_from_member(self,scope,role_assignment_name):
        try :
            result = self.auth_client.role_assignments.delete(scope,role_assignment_name)
            logging.info(result)
            return True
        except Exception as e:
            logging.info(e)
            self.error = traceback.format_exc()
            return False
        
    def grant_pim(self):
        result = []
        try:
            for role in self.roles:
                for member in self.members_id:
                    try:
                        uid = str(uuid.uuid4())
                        status = self.auth_client.role_assignment_schedule_requests.create(
                        scope = self.scope,
                        role_assignment_schedule_request_name= uid,
                        parameters= RoleAssignmentScheduleRequest(
                        request_type = RequestType.ADMIN_ASSIGN,
                        justification = self.justification,
                        role_definition_id = role['role_id'],
                        principal_id = member['OID'],
                        schedule_info = RoleAssignmentScheduleRequestPropertiesScheduleInfo(
                            start_date_time = datetime.datetime.now(datetime.timezone.utc),
                            expiration = RoleAssignmentScheduleRequestPropertiesScheduleInfoExpiration(
                                type = Type.AFTER_DURATION,
                                duration = f"PT{self.duration}H"
                                ),
                            ),
                        )
                        )
                        logging.info(status)
                        result.append({'Role':role['role_id'],'Member':member,'Status': True,'Message':'Success'})
                    except HttpResponseError as e:
                        if "RoleAssignmentExists" in str(e.error.code):
                            result.append({'Role':role['role_id'],'Member':member,'Status': True,'Message':'Already Assigned'})
                            continue
            return result,self.error
        except Exception as e:
            logging.error(f'Error in Assigning PIM for {member} role {role} - {e}')
            self.error = traceback.format_exc()
            result.append({'Role':role['role_id'],'Member':member,'Status': False,'Message':e})
            return False,self.error

    def grant_rbac_v1_cloudbolt(self):
        logging.info("Granting RBAC")
        result = []
        try:
            if self.is_role_assignments_exhausted():
                logging.error("Role assignments are exhausted for subscription")
                return False
            custom_roles = []
            for role in self.roles:
                if 'Reader' not in role['role_name'] and role['role_name'] != 'Reader Role':
                    custom_roles.append(role)
                if role['role_name'] == 'Reader Role' or role['role_name'] == 'Reader':
                    group_name = f" AADS_A_{self.subscription_name} Reader Users" ## Group Name created by cloudbolt are having whitespace in front
                    group_id = asyncio.run(self.exists_group(group_name))
                    if group_id:
                        temp = asyncio.run(self.add_member_to_group(group_id,self.members_id))
                        result.append({"Role":role,"Status":temp})
                    else:
                        group_id = asyncio.run(self.create_group(group_name))
                        temp1 = asyncio.run(self.add_member_to_group(group_id,self.members_id))
                        temp2 = self.add_role_to_member(self.scope,"acdd72a7-3385-48ef-bd42-f606fba81ae7","/providers/Microsoft.Authorization/RoleDefinitions/acdd72a7-3385-48ef-bd42-f606fba81ae7",group_id) ## Reader Role
                        result.append({"Role":role,"Status":temp1 and temp2})
                        
            ## Check for number of custom roles
            if len(custom_roles) == 1:
                group_name = f" AADS_A_{self.subscription_name} {self.resource_group} {custom_roles[0]} Users"
                group_id = asyncio.run(self.exists_group(group_name))
                if group_id:
                    temp = asyncio.run(self.add_member_to_group(group_id,self.members_id))
                    if not self.exists_role_for_member(role['id'],group_id):
                        temp2 = self.add_role_to_member(self.scope,str(uuid.uuid4()),role['id'],group_id)
                    result.append({"Role":role,"Status":temp})
                else:
                    group_id = asyncio.run(self.create_group(group_name))
                    temp1 = asyncio.run(self.add_member_to_group(group_id,self.members_id))
                    temp2 = self.add_role_to_member(self.scope,str(uuid.uuid4()),custom_roles[0]['id'],group_id)                      
                    result.append({"Role":role,"Status":temp1 and temp2})

            elif len(custom_roles) > 1:
                group_name = f" AADS_A_{self.subscription_name} {self.resource_group} Users"
                group_id = asyncio.run(self.exists_group(group_name))
                if group_id:
                    temp1 = asyncio.run(self.add_member_to_group(group_id,self.members_id))
                    for role in custom_roles:
                        if not self.exists_role_for_member(role['id'],group_id):
                            temp2 = self.add_role_to_member(self.scope,str(uuid.uuid4()),role['id'],group_id)                      
                    result.append({"Role":role,"Status":temp1})
                else:
                    group_id = asyncio.run(self.create_group(group_name))
                    temp1 = asyncio.run(self.add_member_to_group(group_id,self.members_id))
                    for role in custom_roles:
                        temp2 = self.add_role_to_member(self.scope,str(uuid.uuid4()),role['id'],group_id)                      
                        result.append({"Role":role,"Status":temp1 and temp2})
            return result
        except Exception as e:
            logging.error(e)
            return False
    
    async def grant_rbac(self):
        if self.is_temporary == '1' and self.duration:
            return self.grant_pim()
        logging.info("Granting RBAC")
        result = []
        if self.is_role_assignments_exhausted():
            logging.error("Role assignments are exhausted for subscription")
            self.error = "Role assignments are exhausted for subscription"
            return False
        for role in self.roles:
            if role['role_name'].lower() == 'reader':
                group_name = f"AADS_A_CMP_{self.subscription_name} Reader Users" 
                group_id = await self.exists_group(group_name)
                if group_id:
                    if not self.exists_role_for_member(self.scope,role['role_id'],group_id):
                        temp = self.add_role_to_member(self.scope,str(uuid.uuid4()),role['role_id'],group_id)
                    temp = await self.add_member_to_group(group_id,self.members_id)
                    result.append({"Role":role,"Status":temp})
                else:
                    group_id = await self.create_group(group_name)
                    temp1 = await self.add_member_to_group(group_id,self.members_id)
                    temp2 = self.add_role_to_member(f"subscriptions/{self.subscription_id}",str(uuid.uuid4()),role['role_id'],group_id) ## Reader Role
                    result.append({"Role":role,"Status":temp1 and temp2})
            elif role['role_name'].lower() == 'custom_contributor':
                match self.scope_type:
                    case "resourcegroup":
                        group_name = f"AADS_A_CMP_{self.subscription_name} {self.resource_group} Custom Contributor Users"
                    case "resource":
                        group_name = f"AADS_A_CMP_{self.subscription_name} {self.resource_group} {self.resource.split('/')[-1]} Custom Contributor Users"
                group_id = await self.exists_group(group_name)
                if group_id:
                    if not self.exists_role_for_member(self.scope,role['role_id'],group_id):
                        temp = self.add_role_to_member(self.scope,str(uuid.uuid4()),role['role_id'],group_id)
                    temp = await self.add_member_to_group(group_id,self.members_id)
                    result.append({"Role":role,"Status":temp})
                else:
                    group_id = await self.create_group(group_name)
                    temp1 = await self.add_member_to_group(group_id,self.members_id)
                    temp2 = self.add_role_to_member(self.scope,str(uuid.uuid4()),role['role_id'],group_id) ## Contributor Role
                    result.append({"Role":role,"Status":temp1 and temp2})
            else:
                match self.scope_type:
                    case "resourcegroup":
                        group_name = f"AADS_A_CMP_{self.subscription_name} {self.resource_group} {role['role_name']} Users"
                    case "resource":
                        group_name = f"AADS_A_CMP_{self.subscription_name} {self.resource_group} {self.resource.split('/')[-1]} {role['role_name']} Users"
                    case "subscription":
                        group_name = f"AADS_A_CMP_{self.subscription_name} {role['role_name']} Users"
                group_id = await self.exists_group(group_name)
                if group_id:
                    if not self.exists_role_for_member(self.scope,role['role_id'],group_id):
                        temp = self.add_role_to_member(self.scope,str(uuid.uuid4()),role['role_id'],group_id)
                    temp = await self.add_member_to_group(group_id,self.members_id)
                    result.append({"Role":role,"Status":temp})
                else:
                    group_id = await self.create_group(group_name)
                    temp1 = await self.add_member_to_group(group_id,self.members_id)
                    temp2 = self.add_role_to_member(self.scope,str(uuid.uuid4()),role['role_id'],group_id)                      
                    result.append({"Role":role,"Status":temp1 and temp2})
        return result,self.error