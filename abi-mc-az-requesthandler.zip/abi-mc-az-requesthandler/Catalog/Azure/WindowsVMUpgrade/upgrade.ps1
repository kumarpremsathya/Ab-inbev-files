Param(
    [Parameter(Mandatory=$true)]
    [string]$target
)
# Ensure user 'abicloudadmin' exists, create if not
$adminUser = "abicloudadmin"
$hostname = $env:COMPUTERNAME.ToLower()
$adminPassword = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($hostname))
$adminPassword = ConvertTo-SecureString $adminPassword -AsPlainText -Force
if (-not (Get-LocalUser -Name $adminUser -ErrorAction SilentlyContinue)) {
    Write-Output "User '$adminUser' does not exist. Creating user..."
    New-LocalUser -Name $adminUser -Password $adminPassword  -PasswordNeverExpires:$true
    Add-LocalGroupMember -Group "Administrators" -Member $adminUser
} else {
    Write-Output "User '$adminUser' exists. Updating password..."
    Enable-LocalUser -Name $adminUser
    Set-LocalUser -Name $adminUser -Password $adminPassword -PasswordNeverExpires:$true
    if (-not (Get-LocalGroupMember -Group "Administrators" -Member $adminUser -ErrorAction SilentlyContinue)) {
        Add-LocalGroupMember -Group "Administrators" -Member $adminUser -ErrorAction SilentlyContinue
    }
}
# Enable the user account
Enable-LocalUser -Name $adminUser
$currentEdition = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").EditionID
Write-Output "Current OS Edition: $currentEdition"
switch ($currentEdition) {
    "ServerStandard"   { $imageIndex = 2 } 
    "ServerDatacenter" { $imageIndex = 4 } 
    default {
        Write-Output "Unsupported EditionID: $currentEdition"
        exit 1
    }
}
$deviceid = (Get-CimInstance -ClassName Win32_LogicalDisk | Where-Object { $_.VolumeName -eq "upgrade" } | Select-Object DeviceID, VolumeName).DeviceID
Write-Output "Device Id: $deviceid"
if (-not $deviceid -or $deviceid.ToUpper() -eq 'C') {
    Write-Output "No valid upgrade volume found. Exiting safely."
    exit 0
}
cd "$deviceid\Windows Server $target" ##Dynamically changes in python based on os selection
$process = Start-Process -FilePath ".\setup.exe" -ArgumentList "/auto upgrade /dynamicupdate disable /imageindex $imageIndex /eula accept /showoobe none /noreboot" -PassThru
Write-Output "Started process with PID: $($process.Id)"
$process.WaitForExit()
$exitCode = $process.ExitCode
Write-Output "Process exited with code: $exitCode"
if ($exitCode -eq 0) {
    Write-Output "Upgrade completed successfully."
    exit 0
} else {
    Write-Output "Upgrade failed."
    exit 1
}