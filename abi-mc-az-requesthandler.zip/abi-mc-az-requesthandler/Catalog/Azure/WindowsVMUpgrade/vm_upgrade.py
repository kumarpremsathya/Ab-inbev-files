from shared_code.compute_client import ComputeClient
from shared_code.resourcemgmt_client import ResourceMgmtClient
from azure.mgmt.compute.models import Snapshot ,Snapshot
from azure.mgmt.compute.models import Disk, CreationData, DiskCreateOption
from azure.mgmt.compute.models import DataDisk ,VirtualMachineExtension
import json,logging,os,time,base64

class WindowsVMUpgrade:
    def __init__(self,data):
        self.subscription_id = data["SubscriptionId"]
        self.resource_group_name = data["ResourceGroup"]
        self.vm_name = data["VmName"]
        self.upgrade = data["TargetVersion"]
        self.zone = data['Zone'].lower()
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.resource_client = ResourceMgmtClient().get_resource_client(self.cloud, self.subscription_id)
        self.compute_client = ComputeClient().get_compute_client(self.subscription_id,self.cloud)

    def check_and_upgrade_vm(self):
        try:
            # Get VM details
            vm = self.compute_client.virtual_machines.get(self.resource_group_name, self.vm_name)
            os_disk_name = vm.storage_profile.os_disk.name
            os_disk = self.compute_client.disks.get(self.resource_group_name, os_disk_name)

            # 1. Create snapshot of OS disk
            snapshot_name = f"{os_disk_name}-snapshot-Brewmation"
            snapshot_params = Snapshot(
                location=os_disk.location,
                creation_data=CreationData(
                    create_option=DiskCreateOption.COPY,
                    source_resource_id=os_disk.id
                )
            )
            self.compute_client.snapshots.begin_create_or_update(
                self.resource_group_name, snapshot_name, snapshot_params
            ).result()

            logging.info(f"Created snapshot: {snapshot_name}")

            # 2. Check free OS disk space (minimum 32GB)
            # Use RunCommand to check free space inside the VM
            command = {
                'command_id': 'RunPowerShellScript',
                'script': [
                    "(Get-PSDrive -Name C).Free/1GB"
                ]
            }
            poller = self.compute_client.virtual_machines.begin_run_command(
                self.resource_group_name, self.vm_name, command
            )
            result = poller.result()
            free_gb = float(result.value[0].message.strip())

            logging.info(f"Free OS disk space: {free_gb} GB")

            # 3. If free space < 32GB, stop VM, increase disk, start VM
            if free_gb < 32:
                self.compute_client.virtual_machines.begin_deallocate(
                    self.resource_group_name, self.vm_name
                ).result()

                # Find next higher disk size (Azure disks: 32, 64, 128, 256, etc.)
                current_size = os_disk.disk_size_gb
                new_size = 32
                while new_size <= current_size:
                    new_size *= 2

                self.compute_client.disks.begin_update(
                    self.resource_group_name, os_disk_name, Disk(location=os_disk.location,disk_size_gb=new_size)
                ).result()

                self.compute_client.virtual_machines.begin_start(
                    self.resource_group_name, self.vm_name
                ).result()
                # Wait for the VM to start and become available
                max_retries = 24  # Wait up to 2 hours (24 * 5min)
                for attempt in range(max_retries):
                    try:
                        vm_view = self.compute_client.virtual_machines.instance_view(
                            self.resource_group_name, self.vm_name
                        )
                        power_state = ''
                        for status in vm_view.statuses:
                            if status.code.startswith('PowerState/'):
                                power_state = status.code
                                break
                        if power_state == 'PowerState/running':
                            logging.info("VM is running after resize.")
                            break
                        else:
                            logging.info(f"Waiting for VM to start... Attempt {attempt+1}/{max_retries}")
                    except Exception as e:
                        logging.warning(f"Error checking VM status: {e}")
                    time.sleep(5 * 60)
                else:
                    logging.error("VM did not start after disk resize.")
                    raise Exception("VM did not start after disk resize.")
                command = {
                    'command_id': 'RunPowerShellScript',
                    'script': [
                        "Get-Partition -DriveLetter C | Resize-Partition -Size (Get-PartitionSupportedSize -DriveLetter C).SizeMax"
                    ]
                }
                poller = self.compute_client.virtual_machines.begin_run_command(
                    self.resource_group_name, self.vm_name, command
                )
                result = poller.result()
                logging.info("Resized partition inside VM.")
            # 4. Create managed disk with selected upgrade public image
            # Example: Use upgrade variable to select image
            image_ref = {
                "windows server 2025": {
                "publisher": "MicrosoftWindowsServer",
                "offer": "WindowsServerUpgrade",
                "sku": "server2025Upgrade",
                "target":"2025"
                },
                "windows server 2022": {
                "publisher": "MicrosoftWindowsServer",
                "offer": "WindowsServerUpgrade",
                "sku": "server2022Upgrade",
                "target":"2022"
                },
                "windows server 2019": {
                "publisher": "MicrosoftWindowsServer",
                "offer": "WindowsServerUpgrade",
                "sku": "server2019Upgrade",
                "target":"2019"
                },
                "windows server 2016": {
                "publisher": "MicrosoftWindowsServer",
                "offer": "WindowsServerUpgrade",
                "sku": "server2016Upgrade",
                "target":"2016"
                },
            }
            upgrade_image = image_ref.get(self.upgrade.lower())
            images = self.compute_client.virtual_machine_images.list(
                location=os_disk.location,
                publisher_name=upgrade_image['publisher'],
                offer=upgrade_image['offer'],
                skus=upgrade_image['sku'],
                orderby="name desc"
            )
            if not images:
                raise Exception(f"No images found for upgrade: {self.upgrade}")
            
            managed_disk_name = f"{self.vm_name}-upgrade-disk"
            # Get zone from VM if available
            vm_zones = getattr(vm, 'zones', None)
            zone = vm_zones[0] if vm_zones else None

            disk_params = Disk(
                location=os_disk.location,
                sku={'name': 'StandardSSD_LRS'},
                creation_data=CreationData(
                    create_option=DiskCreateOption.FROM_IMAGE,
                    image_reference={
                        'id': images[0].id,
                        'lun': 0
                    }
                ),
                disk_size_gb='10',
                encryption={
                    "type":"EncryptionAtRestWithPlatformKey"
                },
                zones=[zone] if zone else None
            )
            managed_disk = self.compute_client.disks.begin_create_or_update(
                self.resource_group_name, managed_disk_name, disk_params
            ).result()

            logging.info(f"Created managed disk: {managed_disk_name}")

            # 5. Attach the managed disk
            lun = 0  # Find next available LUN
            if vm.storage_profile.data_disks:
                luns = [d.lun for d in vm.storage_profile.data_disks]
                lun = max(luns) + 1
            self.compute_client.virtual_machines.begin_attach_detach_data_disks(
                self.resource_group_name,
                self.vm_name,
                parameters={
                    'data_disks_to_attach': [
                        {
                            "disk_id": managed_disk.id,
                            "lun": lun
                        }
                    ]
                }
            ).result()

            logging.info(f"Attached managed disk: {managed_disk.name}")
            # 6. Run VM extension custom script
            response = self.compute_client.virtual_machine_extensions.list(resource_group_name=self.resource_group_name, vm_name=self.vm_name)
            if response.value:
                for ext in response.value:
                    if ext.publisher in ["Microsoft.Compute","Microsoft.Azure.Extensions"] and ext.type_properties_type in ["CustomScript","CustomScriptExtension"]:
                        response = self.compute_client.virtual_machine_extensions.begin_delete (resource_group_name=self.resource_group_name, vm_name=self.vm_name, vm_extension_name=ext.name)
                        result = response.result()
                        logging.info(f'Extension deleted successfully')
                        break
            with open(os.path.join('Catalog', 'Azure', 'WindowsVMUpgrade', 'upgrade.ps1'), 'rb') as f:
                ps_script = base64.b64encode(f.read()).decode('utf-8')
            command = (
                "powershell.exe -Command \""
                f"$b64='{ps_script}'; $bytes=[Convert]::FromBase64String($b64); "
                "[IO.File]::WriteAllBytes('C:\\Windows\\Temp\\abicloud-eol-upgrade-win.ps1', $bytes); "
                f"powershell.exe -ExecutionPolicy Unrestricted -File C:\\Windows\\Temp\\abicloud-eol-upgrade-win.ps1 "
                f"-target {upgrade_image['target']}\""
            )
            self.compute_client.virtual_machine_extensions.begin_create_or_update(
                resource_group_name=self.resource_group_name,
                vm_name=self.vm_name,
                vm_extension_name='Brewmation-VM-Upgrade',
                extension_parameters=VirtualMachineExtension(
                    location=vm.location,
                    publisher='Microsoft.Compute',
                    type_properties_type='CustomScriptExtension',
                    type_handler_version='1.10',
                    auto_upgrade_minor_version=True,
                    protected_settings= {
                        'commandToExecute': command
                    },
                )
            ).result()
            logging.info("VM extension created successfully.")
            response = self.compute_client.virtual_machine_extensions.get(
                resource_group_name=self.resource_group_name,
                vm_name=self.vm_name,
                vm_extension_name='Brewmation-VM-Upgrade',
                expand='instanceView'
            )
            logging.info(f"VM extension result: {response.instance_view.substatuses[0].message}")
            self.compute_client.virtual_machines.begin_attach_detach_data_disks(
                self.resource_group_name, 
                self.vm_name,
                {
                    'data_disks_to_detach': [
                        {
                            'disk_id': managed_disk.id
                        }
                    ]
                }
            ).result()
            logging.info(f"Detached managed disk: {managed_disk.name}")
            self.compute_client.disks.begin_delete(
                self.resource_group_name, managed_disk.name
            ).result()
            logging.info(f"Deleted managed disk")

            # 7. Reboot VM
            self.compute_client.virtual_machines.begin_restart(
                self.resource_group_name, self.vm_name
            ).result()

            logging.info("VM rebooted successfully.")

            logging.info("Checking Upgrade Status...")
            max_retries = 36  # Wait up to 2 hours (24 * 5min)
            for attempt in range(max_retries):
                vm_view = self.compute_client.virtual_machines.instance_view(
                    self.resource_group_name, self.vm_name
                )
                os_name = getattr(vm_view, 'os_name', '').lower()
                agent_statuses = getattr(getattr(vm_view, 'vm_agent', None), 'statuses', [])
                agent_code = agent_statuses[0].display_status if agent_statuses else ''
                if upgrade_image['target'] not in os_name and agent_code in ['Ready', 'Updating']:
                    logging.info("VM upgrade is in progress after reboot.")
                elif upgrade_image['target'] in os_name and agent_code == 'Ready':
                    logging.info("VM upgrade completed successfully.")
                    break
                elif upgrade_image['target'] not in os_name and agent_code != 'Ready':
                    logging.warning("VM upgrade could have failed.")
                    # raise Exception("VM upgrade could have failed.")
                time.sleep(5 * 60)
                logging.info(f"Waiting for VM to start... Attempt {attempt + 1}/{max_retries}")
            else:
                logging.error("VM upgrade status check timed out.")
                raise Exception("VM upgrade status check timed out.")
            logging.info("VM upgrade check completed.")
        except Exception as e:
            logging.error(f"VM upgrade failed: {e}")
            raise