import json,logging,os,traceback,time
from datetime import datetime,timezone,timedelta
from DAL.DbActivityManager import DbActivityManager
from msgraph.generated.users.item.app_role_assignments.app_role_assignments_request_builder import AppRoleAssignmentsRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from shared_code.graphservice_client import GraphClient
from msgraph.generated.models.app_role_assignment import AppRoleAssignment
from msgraph.generated.groups.groups_request_builder import GroupsRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from msgraph.generated.models.group import Group
from shared_code.db import DB
from uuid import UUID

class AzAppRole:

    def __init__(self):
        self.objdb= DB()
        self.objactivitymgr = DbActivityManager()
        self.graph_client_obj = GraphClient()
        self.graph_client= self.graph_client_obj.get_client_request_adapter("AzurePublicCloud")
    
    async def list_app_roles(self):
        roles = []
        result = await self.graph_client.applications_with_app_id(os.environ["DASHBOARD_APP_ID"]).get()
        await self.graph_client_obj.close()
        for role in result.app_roles:
            roles.append({"id":role.id,"display_name":role.display_name,"is_enabled":role.is_enabled,"value":role.value})
        return roles
    
    async def get_roles_of_user(self,user_id):
        self.graph_client= self.graph_client_obj.get_client_request_adapter("AzurePublicCloud")
        query_params = AppRoleAssignmentsRequestBuilder.AppRoleAssignmentsRequestBuilderGetQueryParameters(
            filter = f'resourceId eq {os.environ["DASHBOARD_APP_OBJECT_ID"]}'
            )
        request_configuration = RequestConfiguration(query_parameters = query_params)
        result = await self.graph_client.users.by_user_id(user_id).app_role_assignments.get(request_configuration = request_configuration)
        await self.graph_client_obj.close()
        return result.value
    
    def is_uuid(self,s):
        try:
            UUID(s)
            return True
        except ValueError:
            return False
    
    async def grant_user_with_role(self,user_id,role):
        group_id = None
        zone = role.split("-")[0].upper()
        group_name = f'AADS_A_{zone}_Brewmation_Contributors'
        group_id = await self.exists_group(group_name)
        if group_id:
            await self.add_member_to_group(group_id=group_id,members_id=[user_id])
            return True,None
        else:
            group_id = self.create_group(group_name)
            self.add_member_to_group(group_id=group_id,members_id=[user_id])
            for r in await self.list_app_roles():
                if r["display_name"].lower() == role.lower():
                   role_id = r["id"]
                   break
            request_body = AppRoleAssignment(
                principal_id = UUID(str(group_id)),
                resource_id = UUID(str(os.environ["DASHBOARD_APP_OBJECT_ID"])),
                app_role_id = UUID(str(role_id)))
            self.graph_client= self.graph_client_obj.get_client_request_adapter("AzurePublicCloud")
            result =  await self.graph_client.groups.by_group_id(group_id).app_role_assignments.post(body=request_body)
            logging.info(f"Role assigned successfully {result}")
            await self.graph_client_obj.close()
            return True,None
    
    async def revoke_user_with_role(self,user_id,role):
        if self.is_uuid(role):
            role_id = role
        else:
            for r in await self.list_app_roles():
                if r["display_name"].lower() == role.lower():
                   role_id = r["id"]
        role_exists = False
        for ra in await self.get_roles_of_user(user_id):
            if str(ra.app_role_id) == str(role_id):
                role_exists = True
                assignment_id = ra.id
        if not role_exists:
            return True
        try:
            self.graph_client= self.graph_client_obj.get_client_request_adapter("AzurePublicCloud")
            result =  await self.graph_client.users.by_user_id(user_id).app_role_assignments.by_app_role_assignment_id(assignment_id).delete()
            await self.graph_client_obj.close()
            logging.info(result)
            return True
        except Exception as e:
            logging.error(e)
            return False
        
    async def is_member_of_group(self,group_id,user_id):
        logging.info(f"Checking if member is present in group - {group_id} , member - {user_id}")
        try: 
            self.graph_client= self.graph_client_obj.get_client_request_adapter("AzurePublicCloud")
            query_params = GroupsRequestBuilder.GroupsRequestBuilderGetQueryParameters(
                        filter = f"id eq '{user_id}'",
                    )
            request_configuration = RequestConfiguration(query_parameters = query_params,)
            request_configuration.headers.add("ConsistencyLevel", "eventual")
            result = await self.graph_client.groups.by_group_id(group_id).members.count.get(request_configuration = request_configuration)
            await self.graph_client_obj.close()
            logging.info(result)
            if result == 0:
                return False
            return True
        except Exception as e:
            logging.error(e)
            self.error = traceback.format_exc()
            return None

    async def add_member_to_group(self,group_id,members_id:list):
        logging.info(f"Adding members - {members_id} to the group - {group_id}")
        try:
            self.graph_client= self.graph_client_obj.get_client_request_adapter("AzurePublicCloud")
            additional_data = {}
            additional_data["members@odata.bind"] = []
            for member_id in members_id:
                additional_data["members@odata.bind"].append(f"https://graph.microsoft.com/v1.0/directoryObjects/{member_id}")
            request_body = Group(additional_data=additional_data)
            result = await self.graph_client.groups.by_group_id(group_id).patch(request_body)
            await self.graph_client_obj.close()
            logging.info(f"Result: {result}")
            return True
        except Exception as e:
            logging.error(e)
            self.error = traceback.format_exc()
            return False
        
    async def create_group(self,group_name):
        logging.info(f"Creating Group with name {group_name}")
        try:
            self.graph_client= self.graph_client_obj.get_client_request_adapter("AzurePublicCloud")
            request_body = Group(
                description = None,
                display_name = group_name,
                group_types = [],
                mail_enabled = False,
                mail_nickname = "library",
                security_enabled = True,
            )   
            result = await self.graph_client.groups.post(request_body)
            await self.graph_client_obj.close()
            logging.info(f"Result: {result}")
            time.sleep(120)
            return result.id
        except Exception as e:
            logging.error(e)
            self.error = traceback.format_exc()
            return False
        
    async def delete_group(self,group_id):
        logging.info(f"Removing Group - {group_id}")
        try: 
            self.graph_client= self.graph_client_obj.get_client_request_adapter("AzurePublicCloud")
            result = await self.graph_client.groups.by_group_id(group_id).delete()
            await self.graph_client_obj.close()
            logging.info(result)
            return True
        except Exception as e:
            logging.error(e)
            self.error = traceback.format_exc()
            return False
        
    async def exists_group(self,group_name):
        logging.info(f"Checking if group exists - {group_name}")
        try: 
            self.graph_client= self.graph_client_obj.get_client_request_adapter("AzurePublicCloud")
            query_params = GroupsRequestBuilder.GroupsRequestBuilderGetQueryParameters(
                        count=True,
                        filter = f"displayName eq '{group_name}'", 
                    )
            request_configuration = RequestConfiguration(query_parameters = query_params)
            request_configuration.headers.add("ConsistencyLevel", "eventual")
            result = await self.graph_client.groups.get(request_configuration = request_configuration)
            await self.graph_client_obj.close()
            logging.info(result)
            if result.odata_count == 0:
                return False
            return result.value[0].id
        except Exception as e:
            logging.error(e)
            self.error = traceback.format_exc()
            return None