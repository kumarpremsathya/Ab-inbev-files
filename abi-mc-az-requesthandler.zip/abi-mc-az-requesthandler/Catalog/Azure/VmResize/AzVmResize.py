import logging
import os
from datetime import datetime, timezone
from azure.core.exceptions import ResourceExistsError
from shared_code.compute_client import ComputeClient
from shared_code.client_secret_auth import ClientSecretAuth
from shared_code.lock_manager import LockManager
from shared_code.vm_run_command import execute_run_command


class AzVmResize:

    def __init__(self, subscription_id, zone, resource_group_name, resource_name, resource_id, post_start_config=None, pre_stop_config=None):
        self.subscription_id = subscription_id
        self.zone = zone.lower()
        self.resource_group_name = resource_group_name
        self.resource_name = resource_name
        self.resource_id = resource_id
        self.post_start_config = post_start_config
        self.pre_stop_config = pre_stop_config
        self.azenvironment = (
            "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        )

        self.compute_client = ComputeClient().get_compute_client(
            self.subscription_id, self.azenvironment
        )

        # Initialize LockManager
        self.lock_manager = LockManager(
            subscription_id=self.subscription_id,
            zone=self.zone,
            resource_group_name=self.resource_group_name,
            resource_name=self.resource_name,
            resource_id=self.resource_id,
        )

    def get_snapshot_name(self):
        current_date = datetime.now(timezone.utc).strftime("%Y%m%d")
        return f"{self.resource_name}-snapshot-{current_date}-BeforeResize"

    def check_vm_status(self):
        try:
            vm = self.compute_client.virtual_machines.get(
                self.resource_group_name, self.resource_name
            )
            instance_view = self.compute_client.virtual_machines.instance_view(
                self.resource_group_name, self.resource_name
            )

            power_state = next(
                (status.code for status in instance_view.statuses if status.code.startswith("PowerState/")),
                None,
            )

            if not power_state:
                return False, f"Could not determine power state for VM '{self.resource_name}'"

            if power_state != "PowerState/running":
                return False, f"VM '{self.resource_name}' exists but is not in running state (Current state: {power_state})"

            return True, f"VM '{self.resource_name}' exists and is running"

        except Exception as e:
            return False, f"VM '{self.resource_name}' not found: {str(e)}"

    def get_vm_power_state(self):
        """Returns the current power state of the VM without enforcing any required state."""
        try:
            instance_view = self.compute_client.virtual_machines.instance_view(
                self.resource_group_name, self.resource_name
            )
            power_state = next(
                (status.code for status in instance_view.statuses if status.code.startswith("PowerState/")),
                None,
            )
            if not power_state:
                raise Exception(f"Could not determine power state for VM '{self.resource_name}'")
            logging.info(f"VM '{self.resource_name}' current power state: {power_state}")
            return power_state
        except Exception as e:
            logging.error(f"Error getting VM power state for '{self.resource_name}': {e}")
            raise

    def deallocate_vm(self):
        logging.info(f"Deallocating VM '{self.resource_name}'...")
        async_deallocate = self.compute_client.virtual_machines.begin_deallocate(
            self.resource_group_name, self.resource_name
        )
        async_deallocate.result()
        logging.info(f"VM '{self.resource_name}' deallocated successfully.")

    def start_vm(self):
        logging.info(f"Starting VM '{self.resource_name}'...")
        async_start = self.compute_client.virtual_machines.begin_start(
            self.resource_group_name, self.resource_name
        )
        async_start.result()
        logging.info(f"VM '{self.resource_name}' started successfully.")

    def create_vm_snapshot(self):
        try:
            vm_status, message = self.check_vm_status()
            if not vm_status:
                logging.error(message)
                raise Exception(message)

            vm = self.compute_client.virtual_machines.get(
                self.resource_group_name, self.resource_name
            )
            snapshot_name = self.get_snapshot_name()

            if vm.storage_profile.os_disk.managed_disk:
                os_disk = vm.storage_profile.os_disk

                snapshot_params = {
                    "location": vm.location,
                    "creation_data": {
                        "create_option": "Copy",
                        "source_resource_id": os_disk.managed_disk.id,
                    },
                }

                async_snapshot_creation = (
                    self.compute_client.snapshots.begin_create_or_update(
                        self.resource_group_name, snapshot_name, snapshot_params
                    )
                )
                async_snapshot_creation.result()
                logging.info(f"Created OS disk snapshot: {snapshot_name}")
                return True

            else:
                raise Exception("No managed OS disk found to snapshot")

        except Exception as e:
            logging.error(f"Error creating VM snapshot: {e}")
            raise

    def vm_resize(self, vm_size):
        pre_stop_executed = False
        vm_was_deallocated = False
        try:

            initial_power_state = self.get_vm_power_state()
            vm_was_initially_running = initial_power_state == "PowerState/running"
            logging.info(
                f"VM '{self.resource_name}' initial power state: {initial_power_state}. "
                f"Will {'start' if vm_was_initially_running else 'leave stopped'} after resize."
            )

            if self.pre_stop_config and vm_was_initially_running:
                success = execute_run_command(
                    self.compute_client,
                    self.resource_group_name,
                    self.resource_name,
                    self.pre_stop_config,
                    "PreStopConfig",
                    required=True
                )
                if not success:
                    raise Exception("PreStopConfig script failed - VM resize aborted")
                pre_stop_executed = True

            vm = self.compute_client.virtual_machines.get(
                self.resource_group_name, self.resource_name
            )
            vm.hardware_profile.vm_size = vm_size

            try:
                async_vm_update = self.compute_client.virtual_machines.begin_create_or_update(
                    self.resource_group_name, self.resource_name, vm
                )
                async_vm_update.result()
            except ResourceExistsError as e:
                if e.error and e.error.code == "OperationNotAllowed" and "deallocated" in str(e.error.message).lower():
                    self.deallocate_vm()
                    vm_was_deallocated = True
                    vm = self.compute_client.virtual_machines.get(
                        self.resource_group_name, self.resource_name
                    )
                    vm.hardware_profile.vm_size = vm_size
                    async_vm_update = self.compute_client.virtual_machines.begin_create_or_update(
                        self.resource_group_name, self.resource_name, vm
                    )
                    async_vm_update.result()
                else:
                    raise

            if vm_was_initially_running and vm_was_deallocated:
                self.start_vm()

            if self.post_start_config and vm_was_initially_running:
                vm_status, message = self.check_vm_status()
                if vm_status:
                    success = execute_run_command(
                        self.compute_client,
                        self.resource_group_name,
                        self.resource_name,
                        self.post_start_config,
                        "PostStartConfig",
                        required=False
                    )
                    if not success:
                        logging.warning(f"Post-start commands failed for VM '{self.resource_name}' (non-blocking)")
                else:
                    logging.warning(f"VM not in running state, skipping post-start commands: {message}")

        except Exception as e:
            logging.error(f"An error occurred while resizing VM: {e}")
            if pre_stop_executed and self.post_start_config:
                try:
                    execute_run_command(
                        self.compute_client,
                        self.resource_group_name,
                        self.resource_name,
                        self.post_start_config,
                        "PostStartConfig (Rollback)",
                        required=False
                    )
                except Exception as rollback_error:
                    logging.error(f"Failed to restart services during rollback: {rollback_error}")
            raise

    def resize_with_snapshot_create(self, vm_size):
        try:
            logging.info("Starting resize operation with snapshot creation...")

            # Remove all locks at resource and resource group levels
            removed_locks = self.lock_manager.remove_all_locks()
        
            if removed_locks:
                logging.info(f"Removed locks: {removed_locks}")
            else:
                logging.info("No locks found. Proceeding with resize operation.")

            try:
                # Create snapshot and resize
                snapshot_created = self.create_vm_snapshot()
                if snapshot_created:
                    logging.info(f"Snapshot created. Proceeding with resize to {vm_size}.")
                    self.vm_resize(vm_size.split(" - ")[0].strip())
                    return True
                else:
                    logging.error("Snapshot creation failed. Resize operation skipped.")
                    return False

            finally:
                # Always restore locks after operation
                self.lock_manager.restore_locks()

        except Exception as e:
            logging.error(f"Error during resize operation: {e}")
            raise
