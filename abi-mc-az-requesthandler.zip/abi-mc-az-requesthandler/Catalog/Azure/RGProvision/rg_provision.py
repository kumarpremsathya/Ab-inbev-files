from shared_code.resourcemgmt_client import ResourceMgmtClient
import logging,json


class AzRGProvision:
    def __init__(self, data):
        self.json_data = json.loads(data['Payload'])['payload']["data"]
        self.subscription_id = self.json_data['subscription_id']
        self.location = self.json_data['location']
        self.zone = data['Zone'].lower()
        self.resource_group_name = self.json_data['resource_group_name']
        if self.zone == "china":
            self.cloud = "AzureChinaCloud"
        else:
            self.cloud = "AzurePublicCloud"
        self.resource_client = ResourceMgmtClient().get_resource_client(self.cloud, self.subscription_id)
        self.tags = self.json_data["tags"]
        if self.zone == 'saz':
            tag_mappings = {
            "ambevtech.productid": "applicationUID",
            "ambevtech.product": "ProjectName",
            "ambevtech.architect": "DevOwnerEmail",
            "ambevtech.productmanager": "BusinessOwnerEmail",
            "ambevtech.impact": "Criticality",
            "ambevtech.tower": "Department",
            "ambevtech.costallocation": "CostCenter"
            }
        elif self.zone == 'brewdat':
            tag_mappings = {
            "ApplicationUID":"applicationUID",
            "BDAppName": "ProjectName",
            "BDAppDOEmail": "DevOwnerEmail"
            }
        else:
            tag_mappings = {
            "ApplicationUID":"applicationUID"
            }
        for new_tag, old_tag in tag_mappings.items():
            self.tags[new_tag] = self.tags.pop(old_tag)

    def create_rg(self):
        if not self.resource_client.resource_groups.check_existence(self.resource_group_name):        
            self.resource_client.resource_groups.create_or_update(
                self.resource_group_name,
                {
                    "location": self.location,
                    "tags" : self.tags
                }
            )
            logging.info(f"Resource Group '{self.resource_group_name}' created in '{self.location}'")
        else:
            logging.info(f"Resource Group '{self.resource_group_name}' already exists in '{self.location}'")