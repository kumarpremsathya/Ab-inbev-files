from shared_code.storage_client import StorageClient
from shared_code.databricksmgmt_client import DatabricksClient
from shared_code.networkmgmt_client import NetworkMgmtClient
from shared_code.privatedns_client import PrivateDNSClient
import json,logging

class DataBricksProvision:
    def __init__(self,json_data):
        data = json.loads(json_data['Payload'])['payload']["data"]
        self.zone = json_data["Zone"].lower()
        self.tags = data["tags"]
        self.subscription_id = data["subscription_id"]
        self.resource_group_name = data["resource_group_name"]
        self.location = data["location"]
        self.databricks_sku = data["sku"]
        self.databricks_name = data["databrics_resource_name"]
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.storage_client = StorageClient().get_storage_client(self.subscription_id,self.cloud)
        self.databricks_client = DatabricksClient().get_databricks_client(self.subscription_id,self.cloud)
        self.network_client = NetworkMgmtClient().get_network_mgmt_client(self.subscription_id,self.cloud)
        self.dns_client = PrivateDNSClient().get_dns_client(self.subscription_id,self.cloud)

    def create_databricks(self):
        try:
            # 1. Create Virtual Network
            vnet_params = {
                "location": self.location,
                "address_space": {
                    "address_prefixes": ["10.0.0.0/24"]
                },
                "tags": self.tags,
                "enable_ddos_protection": False,
                "enable_vm_protection": False
            }
            vnet_name = f"{self.resource_group_name}-databricks-VNET"
            vnet_poller = self.network_client.virtual_networks.begin_create_or_update(
                self.resource_group_name,
                vnet_name,
                vnet_params
            )
            vnet_result = vnet_poller.result()
            vnet_id = vnet_result.id

            # 2. Create Private Subnet with delegation
            private_subnet_params = {
                "address_prefix": "10.0.0.0/25",
                "delegations": [{
                    "name": "pvt-delegation",
                    "type": "service_delegation",
                    "service_name": "Microsoft.Databricks/workspaces",
                    "actions": [
                        "Microsoft.Network/virtualNetworks/subnets/join/action",
                        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
                        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action"
                    ]
                }],
                "enforce_private_link_endpoint_network_policies": True
            }
            private_subnet_name = "Private-Subnet"
            private_subnet_poller = self.network_client.subnets.begin_create_or_update(
                self.resource_group_name,
                vnet_name,
                private_subnet_name,
                private_subnet_params
            )
            private_subnet_result = private_subnet_poller.result()
            private_subnet_id = private_subnet_result.id

            # 3. Create Network Security Group for Private Subnet
            private_nsg_params = {
                "location": self.location,
                "tags": self.tags
            }
            private_nsg_name = "Private-Subnet-NSG"
            private_nsg_poller = self.network_client.network_security_groups.begin_create_or_update(
                self.resource_group_name,
                private_nsg_name,
                private_nsg_params
            )
            private_nsg_result = private_nsg_poller.result()
            private_nsg_id = private_nsg_result.id

            # 4. Associate NSG with Private Subnet
            subnet_update_params = {
                "address_prefix": "10.0.0.0/25",
                "delegations": [{
                    "name": "pvt-delegation",
                    "type": "service_delegation",
                    "service_name": "Microsoft.Databricks/workspaces",
                    "actions": [
                        "Microsoft.Network/virtualNetworks/subnets/join/action",
                        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
                        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action"
                    ]
                }],
                "enforce_private_link_endpoint_network_policies": True,
                "network_security_group": {
                    "id": private_nsg_id
                }
            }
            self.network_client.subnets.begin_create_or_update(
                self.resource_group_name,
                vnet_name,
                private_subnet_name,
                subnet_update_params
            ).result()

            # 5. Create Public Subnet with delegation
            public_subnet_params = {
                "address_prefix": "10.0.0.128/26",
                "delegations": [{
                    "name": "pub-delegation",
                    "type": "service_delegation",
                    "service_name": "Microsoft.Databricks/workspaces",
                    "actions": [
                            "Microsoft.Network/virtualNetworks/subnets/join/action",
                            "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
                            "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action"
                        ]
                }],
                "enforce_private_link_endpoint_network_policies": True
            }
            public_subnet_name = "Public-Subnet"
            public_subnet_poller = self.network_client.subnets.begin_create_or_update(
                self.resource_group_name,
                vnet_name,
                public_subnet_name,
                public_subnet_params
            )
            public_subnet_result = public_subnet_poller.result()
            public_subnet_id = public_subnet_result.id

            # 6. Create Network Security Group for Public Subnet
            public_nsg_params = {
                "location": self.location,
                "tags": self.tags
            }
            public_nsg_name = "Public-Subnet-NSG"
            public_nsg_poller = self.network_client.network_security_groups.begin_create_or_update(
                self.resource_group_name,
                public_nsg_name,
                public_nsg_params
            )
            public_nsg_result = public_nsg_poller.result()
            public_nsg_id = public_nsg_result.id

            # 7. Associate NSG with Public Subnet
            subnet_update_params_pub = {
                "address_prefix": "10.0.0.128/26",
                "delegations": [{
                    "name": "pub-delegation",
                    "type": "service_delegation",
                    "service_name": "Microsoft.Databricks/workspaces",
                    "actions": [
                        "Microsoft.Network/virtualNetworks/subnets/join/action",
                        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
                        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action"
                    ]
                }],
                "enforce_private_link_endpoint_network_policies": True,
                "network_security_group": {
                    "id": public_nsg_id
                }
            }
            self.network_client.subnets.begin_create_or_update(
                self.resource_group_name,
                vnet_name,
                public_subnet_name,
                subnet_update_params_pub
            ).result()

            # 8. Create Databricks Workspace
            managed_rg_name = f"{self.databricks_name}-managed-databricks-rg"
            databricks_params = {
                "location": self.location,
                "sku": {"name": self.databricks_sku},
                "managed_resource_group_id": f"/subscriptions/{self.subscription_id}/resourceGroups/{managed_rg_name}",
                "tags": self.tags,
                "parameters": {
                    "customVirtualNetworkId": {"value": vnet_id},
                    "customPrivateSubnetName": {"value": private_subnet_name},
                    "customPublicSubnetName": {"value": public_subnet_name},
                    "noPublicIp": {"value": True},
                    "publicSubnetNetworkSecurityGroupAssociationId": {"value": public_nsg_id},
                    "privateSubnetNetworkSecurityGroupAssociationId": {"value": private_nsg_id},
                    "infrastructureEncryption": {"value": True if self.databricks_sku == "premium" else False}
                }
            }
            workspace_poller = self.databricks_client.workspaces.begin_create_or_update(
                self.resource_group_name,
                self.databricks_name,
                databricks_params
            )
            workspace_result = workspace_poller.result()

            logging.info(f"Databricks Workspace created: {workspace_result.id}")
            return {
                "vnet_id": vnet_id,
                "private_subnet_id": private_subnet_id,
                "public_subnet_id": public_subnet_id,
                "private_nsg_id": private_nsg_id,
                "public_nsg_id": public_nsg_id,
                "databricks_workspace_id": workspace_result.id
            }
        except Exception as e:
            logging.error(f"Failed to provision Databricks: {e}")
            raise