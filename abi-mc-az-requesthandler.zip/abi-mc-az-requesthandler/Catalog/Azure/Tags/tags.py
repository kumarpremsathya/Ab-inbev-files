from shared_code.resourcemgmt_client import ResourceMgmtClient
from azure.mgmt.resource.resources.models import TagsPatchResource
import logging,json

class TagsUpdater:
    
    def __init__(self,data) -> None:
        self.subscription_id = data["SubscriptionId"]
        self.resource_group = data["ResourceGroupName"]
        self.zone = data['Zone'].lower()
        if self.zone == "china":
            self.cloud = "AzureChinaCloud"
        else:
            self.cloud = "AzurePublicCloud"        
        self.resource_client = ResourceMgmtClient().get_resource_client(self.cloud,self.subscription_id)
        self.tags = json.loads(data["Tags"])    
        if self.zone == 'saz':
            tag_mappings = {
            "ambevtech.productid": "applicationUID",
            "ambevtech.product": "ProjectName",
            "ambevtech.architect": "DevOwnerEmail",
            "ambevtech.productmanager": "BusinessOwnerEmail",
            "ambevtech.impact": "Criticality",
            "ambevtech.tower": "Department",
            "ambevtech.costallocation": "CostCenter"
            }
        elif self.zone == 'brewdat':
            tag_mappings = {
            "ApplicationUID":"applicationUID",
            "BDAppName": "ProjectName",
            "BDAppDOEmail": "DevOwnerEmail"
            }
        else:
            tag_mappings = {
            "ApplicationUID":"applicationUID"
            }
        for new_tag, old_tag in tag_mappings.items():
            self.tags[new_tag] = self.tags.pop(old_tag)

    def update_rg_tags(self):
        tag_patch_resource = TagsPatchResource(operation="Merge",properties={"tags": self.tags})
        try: 
            rg = self.resource_client.resource_groups.get(self.resource_group)
            if rg.managed_by and 'microsoft.databricks' in rg.managed_by.lower():
                logging.info(f"Databricks resource group {self.resource_group} found, updating tags")
                self.resource_client.tags.begin_update_at_scope(rg.managed_by, tag_patch_resource)
            else:
                self.resource_client.tags.begin_update_at_scope(rg.id, tag_patch_resource)
            logging.info(f"Tags {tag_patch_resource.properties} were added to resource")
            return True,None
        except Exception as e:
            logging.error(e)
            return False,e