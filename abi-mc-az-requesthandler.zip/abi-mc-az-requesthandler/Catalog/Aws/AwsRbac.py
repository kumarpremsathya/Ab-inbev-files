class AwsRbac:
    def __init__(self) -> None:
        pass
    
    def snow_data(self,data):
        self.request_data = data
        self.request_data["short_description"] = f"ABI Cloud Management Portal - Aws - {data['RequestorEmail']}"
        self.request_data["description"] = f"The user {data['RequestorEmail']} has requested for access for a Resource in ABI Cloud Management"
        self.request_data["variables"] = {}
        self.request_data["variables"]["catalog_name"] = "RBAC"
        self.request_data["variables"]["category"] = "RBAC"
        self.request_data["variables"]["catalog_description"] = "Provide RBAC roles to Users/Groups/Service Principals"

        return self.request_data