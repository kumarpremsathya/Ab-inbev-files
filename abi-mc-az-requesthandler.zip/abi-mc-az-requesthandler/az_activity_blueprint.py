# Register this blueprint by adding the following line of code 
# to your entry point file.  
# app.register_functions(topic_triggers_blueprint) 
# 
# Please refer to https://aka.ms/azure-functions-python-blueprints

import logging,json,traceback
import azure.durable_functions as dff
from DAL.DbActivityManager import DbActivityManager
from Activity.AzActivityClassifier import AzActivityClassifier
activity_blueprints = dff.Blueprint()


def make_func(fname):
    @activity_blueprints.function_name(f"{fname}")
    @activity_blueprints.activity_trigger(input_name="payload")
    async def funcs(payload):
        try:
            objhandler = AzActivityClassifier(payload)
            handler = getattr(objhandler, f"{fname}_activity")
            result = await handler()
            return result
        except Exception as e:
            lines = traceback.format_exception_only(type(e), e)
            readable_error = "".join(lines).strip()
            DbActivityManager().log_exception_activityinfo(payload["EventId"],payload['ActivityId'],payload["ActivityName"],traceback.format_exc(),readable_error)
            logging.error(f"{fname} Handler Error - {e}")
            raise e
    return funcs

# activities = [
#     "RBAC", "APPROLE", "TAGS", "INSTANCESTATUS", "RESIZEVMSKU", "MSSQLACCESS", "POSTGRESQLACCESS", "RESIZEVMDISK", 
#     "RESIZESQLDB", "DECOMMPREACTIVITY", "DECOMM", "RGPROVISION", "VMPROVISION_PREPROVISION", 
#     "VMPROVISION_CREATEVM", "VMPROVISION_VMBACKUP", "VMPROVISION_BGINFO", "VMPROVISION_DOMAINJOIN", "VMPROVISION_REGISTERSQLVM",
#     "VMPROVISION_PUPPET", "VMPROVISION_SAM","VMACCESSMGMT","VMCREDMGMT","SNAPSHOTCREATION","WEBAPPPROVISION",
#     "KEYVAULTPROVISION", "STORAGEACCOUNTPROVISION", "FUNCTIONAPPPROVISION", "LOGICAPPPROVISION","RBACEXCEPTIONAL",
#     "POSTGREDBPROVISION", "COSMOSDBPROVISION", "MSSQLMGMTINSTANCEPROVISION","MSSQLSERVERPROVISION", "MSSQLELASTICPOOLPROVISION",
#     "MSSQLDBPROVISION","REDISCACHEPROVISION","EVENTHUBPROVISION","APPINSIGHTSPROVISION","DATABRICKSPROVISION","SERVICEBUSPROVISION",
#     "DATAFACTORYPROVISION", "WINDOWSVMUPGRADE", "HOURSOFOPERATION", "HOURSOFOPERATIONINSTANCE",
#     "INACTIVERBAC", "DISKCLEANUP", "BACKUPFAILURE", "CPUHIGHALERT", "MEMORYHIGHALERT", "PRIVATEENDPOINTPROVISION","INACTIVEVMACCOUNTS",
#     "RBACINVENTORYREVIEW", "RBACGROUPMEMBERREVIEW", "POLICYEXEMPTION"
# ]

activities = ["KEYVAULTMGMT"]

for activity in map(str.lower, activities):
    make_func(activity)