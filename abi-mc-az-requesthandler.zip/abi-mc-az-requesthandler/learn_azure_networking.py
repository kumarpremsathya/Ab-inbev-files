"""
Azure Networking - Hands-On Learning Guide
==========================================
Uses your personal Azure account (subscription: 8d62fea6-...).
Run each lesson one at a time. Read the comments, then run the function.

Prerequisites:
  1. Set your SP secret:  $env:TEST_SP_SECRET = "your-sp-password"
  2. Resource group 'test-kvmgmt-rg' must exist (from setup_personal_test.sh)

Topics covered (in order):
  Lesson 1: VNet & Subnets — the foundation of all Azure networking
  Lesson 2: NSG (Network Security Groups) — firewall rules on subnets/NICs
  Lesson 3: Service Endpoints — allow a subnet to talk to PaaS services
  Lesson 4: Key Vault Firewall (Network ACLs) — IP rules & VNet rules
  Lesson 5: Private Endpoints — private IP for a PaaS service inside your VNet
  Lesson 6: Private DNS Zones — name resolution for private endpoints
  Lesson 7: Full Flow — ties it all together (what keyvault_mgmt.py does)
"""

import os, sys, logging, time

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logging.getLogger("azure").setLevel(logging.WARNING)

# ── Auth Setup ──────────────────────────────────────────────────────────────
os.environ["AZURE_TENANT_ID"] = "1b58d4b5-b54d-4750-ab29-b6aa6dfdd73a"
os.environ["AZURE_CLIENT_ID"] = "7268919e-22ab-407b-ac77-24253e78f360"
os.environ["AZURE_CLIENT_SECRET"] = os.environ.get("TEST_SP_SECRET", "")

if not os.environ["AZURE_CLIENT_SECRET"]:
    print("ERROR: Set TEST_SP_SECRET first:  $env:TEST_SP_SECRET = 'your-sp-secret'")
    sys.exit(1)

from azure.identity import ClientSecretCredential
from azure.mgmt.network import NetworkManagementClient
from azure.mgmt.keyvault import KeyVaultManagementClient
from azure.mgmt.privatedns import PrivateDnsManagementClient
from azure.core.exceptions import HttpResponseError, ResourceNotFoundError

SUBSCRIPTION_ID = "8d62fea6-3260-4070-a3b7-d87a6985fa4b"
RESOURCE_GROUP = "test-kvmgmt-rg"
LOCATION = "westeurope"
KEY_VAULT_NAME = "test-kvmgmt-brewmation"

credential = ClientSecretCredential(
    tenant_id=os.environ["AZURE_TENANT_ID"],
    client_id=os.environ["AZURE_CLIENT_ID"],
    client_secret=os.environ["AZURE_CLIENT_SECRET"],
)
network_client = NetworkManagementClient(credential, SUBSCRIPTION_ID)
kv_client = KeyVaultManagementClient(credential, SUBSCRIPTION_ID)
dns_client = PrivateDnsManagementClient(credential, SUBSCRIPTION_ID)


# ════════════════════════════════════════════════════════════════════════════
# LESSON 1: Virtual Networks (VNets) & Subnets
# ════════════════════════════════════════════════════════════════════════════
#
# THEORY:
#   A VNet is your private network in Azure — like your own data center's LAN.
#   Everything that needs private communication lives inside a VNet.
#
#   Key concepts:
#   - Address space: The IP range for the entire VNet (e.g., 10.0.0.0/16 = 65,536 IPs)
#   - Subnet: A partition of the VNet (e.g., 10.0.1.0/24 = 256 IPs)
#   - CIDR notation: /16 = 65536 IPs, /24 = 256 IPs, /27 = 32 IPs, /32 = 1 IP
#
#   Why subnets?
#   - Separate workloads (web tier in one subnet, DB in another)
#   - Apply different security rules (NSGs) to each subnet
#   - Some Azure features require dedicated subnets (e.g., private endpoints)
#
#   Real-world analogy:
#     VNet = your office building's entire network
#     Subnet = each floor's network segment
#     NSG = the security badge rules for each floor

def lesson_1_vnets_and_subnets():
    print("\n" + "=" * 60)
    print("  LESSON 1: VNets & Subnets")
    print("=" * 60)

    VNET_NAME = "learn-networking-vnet"
    SUBNET_1 = "web-subnet"
    SUBNET_2 = "db-subnet"

    # ── 1a: Create a VNet with an address space ──
    print("\n[1a] Creating VNet with address space 10.1.0.0/16...")
    print("     This gives us 65,536 IP addresses to work with.")
    vnet = network_client.virtual_networks.begin_create_or_update(
        RESOURCE_GROUP,
        VNET_NAME,
        {
            "location": LOCATION,
            "address_space": {"address_prefixes": ["10.1.0.0/16"]},
        },
    ).result()
    print(f"     VNet created: {vnet.name}")
    print(f"     Address space: {vnet.address_space.address_prefixes}")
    print(f"     Resource ID: {vnet.id}")

    # ── 1b: Create subnets (slicing the VNet into smaller networks) ──
    print(f"\n[1b] Creating subnet '{SUBNET_1}' (10.1.1.0/24 = 256 IPs)...")
    subnet1 = network_client.subnets.begin_create_or_update(
        RESOURCE_GROUP, VNET_NAME, SUBNET_1,
        {"address_prefix": "10.1.1.0/24"},
    ).result()
    print(f"     Subnet: {subnet1.name}, Range: {subnet1.address_prefix}")
    print(f"     Subnet ID: {subnet1.id}")

    print(f"\n     Creating subnet '{SUBNET_2}' (10.1.2.0/24 = 256 IPs)...")
    subnet2 = network_client.subnets.begin_create_or_update(
        RESOURCE_GROUP, VNET_NAME, SUBNET_2,
        {"address_prefix": "10.1.2.0/24"},
    ).result()
    print(f"     Subnet: {subnet2.name}, Range: {subnet2.address_prefix}")

    # ── 1c: List all subnets in the VNet ──
    print(f"\n[1c] Listing all subnets in '{VNET_NAME}':")
    for s in network_client.subnets.list(RESOURCE_GROUP, VNET_NAME):
        print(f"     - {s.name}: {s.address_prefix}")

    # ── 1d: Read back the VNet and inspect properties ──
    print(f"\n[1d] Reading VNet properties:")
    vnet = network_client.virtual_networks.get(RESOURCE_GROUP, VNET_NAME)
    print(f"     Name: {vnet.name}")
    print(f"     Location: {vnet.location}")
    print(f"     Provisioning state: {vnet.provisioning_state}")
    print(f"     Subnets: {[s.name for s in vnet.subnets]}")

    print("\n  KEY TAKEAWAYS:")
    print("  - VNet = your private network, Subnet = a slice of it")
    print("  - Subnet IDs are used everywhere (NSGs, private endpoints, service endpoints)")
    print("  - The subnet ID format: /subscriptions/.../subnets/<name>")
    print(f"\n  Your subnet ID (save this — used in later lessons):")
    print(f"  {subnet1.id}")
    return subnet1.id


# ════════════════════════════════════════════════════════════════════════════
# LESSON 2: Network Security Groups (NSGs)
# ════════════════════════════════════════════════════════════════════════════
#
# THEORY:
#   NSG = a firewall you attach to a subnet or NIC.
#   It has rules that Allow or Deny traffic based on:
#     - Direction: Inbound / Outbound
#     - Source & Destination: IP, CIDR, service tag, or ASG
#     - Port: 80, 443, 3389, *, etc.
#     - Protocol: TCP, UDP, *
#     - Priority: Lower number = higher priority (100 beats 200)
#
#   Default rules (you can't delete these):
#     - AllowVNetInBound (priority 65000): VNet ↔ VNet traffic allowed
#     - AllowAzureLoadBalancerInBound (65001): Health probes allowed
#     - DenyAllInBound (65500): Everything else denied
#
#   Service Tags (built-in groups of IPs):
#     - "Internet", "VirtualNetwork", "AzureLoadBalancer"
#     - "Storage", "Sql", "KeyVault", "AzureCloud", etc.

def lesson_2_nsg():
    print("\n" + "=" * 60)
    print("  LESSON 2: Network Security Groups (NSGs)")
    print("=" * 60)

    NSG_NAME = "learn-web-nsg"
    VNET_NAME = "learn-networking-vnet"
    SUBNET_NAME = "web-subnet"

    # ── 2a: Create an NSG ──
    print(f"\n[2a] Creating NSG '{NSG_NAME}'...")
    nsg = network_client.network_security_groups.begin_create_or_update(
        RESOURCE_GROUP, NSG_NAME,
        {"location": LOCATION},
    ).result()
    print(f"     NSG created: {nsg.name}")

    # ── 2b: View default rules (these exist automatically) ──
    print(f"\n[2b] Default security rules (built-in, can't delete):")
    for rule in nsg.default_security_rules:
        print(f"     Priority {rule.priority}: {rule.name}")
        print(f"       {rule.direction} | {rule.access} | {rule.source_address_prefix} → {rule.destination_address_prefix}:{rule.destination_port_range}")

    # ── 2c: Add custom rules ──
    print(f"\n[2c] Adding custom rules...")

    # Allow HTTPS inbound from anywhere
    rule1 = network_client.security_rules.begin_create_or_update(
        RESOURCE_GROUP, NSG_NAME, "Allow-HTTPS-Inbound",
        {
            "protocol": "Tcp",
            "source_address_prefix": "*",
            "destination_address_prefix": "*",
            "source_port_range": "*",
            "destination_port_range": "443",
            "access": "Allow",
            "direction": "Inbound",
            "priority": 100,
        },
    ).result()
    print(f"     Rule added: {rule1.name} (Allow TCP 443 inbound, priority 100)")

    # Deny all other inbound from internet
    rule2 = network_client.security_rules.begin_create_or_update(
        RESOURCE_GROUP, NSG_NAME, "Deny-All-Internet-Inbound",
        {
            "protocol": "*",
            "source_address_prefix": "Internet",
            "destination_address_prefix": "*",
            "source_port_range": "*",
            "destination_port_range": "*",
            "access": "Deny",
            "direction": "Inbound",
            "priority": 200,
        },
    ).result()
    print(f"     Rule added: {rule2.name} (Deny all from Internet, priority 200)")

    # ── 2d: Associate NSG with a subnet ──
    print(f"\n[2d] Attaching NSG to subnet '{SUBNET_NAME}'...")
    subnet = network_client.subnets.get(RESOURCE_GROUP, VNET_NAME, SUBNET_NAME)
    subnet = network_client.subnets.begin_create_or_update(
        RESOURCE_GROUP, VNET_NAME, SUBNET_NAME,
        {
            "address_prefix": subnet.address_prefix,
            "network_security_group": {"id": nsg.id},
        },
    ).result()
    print(f"     NSG '{NSG_NAME}' attached to subnet '{SUBNET_NAME}'")

    # ── 2e: List effective rules ──
    print(f"\n[2e] All rules on '{NSG_NAME}':")
    nsg = network_client.network_security_groups.get(RESOURCE_GROUP, NSG_NAME)
    for rule in sorted(nsg.security_rules, key=lambda r: r.priority):
        print(f"     Priority {rule.priority}: {rule.name} | {rule.access} {rule.direction} {rule.protocol} port {rule.destination_port_range}")

    print("\n  KEY TAKEAWAYS:")
    print("  - NSGs are stateful firewalls (if inbound allowed, response auto-allowed)")
    print("  - Lower priority number = evaluated first")
    print("  - Service tags like 'Internet', 'VirtualNetwork' save you from listing IPs")
    print("  - Attach NSG to subnet (affects all resources in it) or to a specific NIC")


# ════════════════════════════════════════════════════════════════════════════
# LESSON 3: Service Endpoints
# ════════════════════════════════════════════════════════════════════════════
#
# THEORY:
#   Without service endpoints, traffic from your VNet to Azure PaaS services
#   (Storage, SQL, Key Vault) goes over the public internet.
#
#   Service Endpoint = a shortcut that routes traffic directly through
#   Azure's backbone network (faster, more secure, stays within Azure).
#
#   How it works:
#   1. Enable a service endpoint on a subnet (e.g., Microsoft.KeyVault)
#   2. Add that subnet to the PaaS service's firewall (VNet rule)
#   3. Now only that subnet can access the service — public access is blocked
#
#   Service Endpoint vs Private Endpoint:
#   ┌───────────────────────┬─────────────────────┬──────────────────────────┐
#   │                       │ Service Endpoint     │ Private Endpoint         │
#   ├───────────────────────┼─────────────────────┼──────────────────────────┤
#   │ IP used               │ Public IP of service │ Private IP in your VNet  │
#   │ DNS                   │ No change            │ Needs Private DNS Zone   │
#   │ Cross-region          │ No                   │ Yes                      │
#   │ Cost                  │ Free                 │ Charged per hour + data  │
#   │ On-prem access        │ No                   │ Yes (via VPN/ExpressRoute│
#   └───────────────────────┴─────────────────────┴──────────────────────────┘

def lesson_3_service_endpoints():
    print("\n" + "=" * 60)
    print("  LESSON 3: Service Endpoints")
    print("=" * 60)

    VNET_NAME = "learn-networking-vnet"
    SUBNET_NAME = "db-subnet"

    # ── 3a: Check current service endpoints on subnet ──
    print(f"\n[3a] Current service endpoints on '{SUBNET_NAME}':")
    subnet = network_client.subnets.get(RESOURCE_GROUP, VNET_NAME, SUBNET_NAME)
    if subnet.service_endpoints:
        for ep in subnet.service_endpoints:
            print(f"     - {ep.service} (status: {ep.provisioning_state})")
    else:
        print("     None — all PaaS traffic goes over public internet")

    # ── 3b: Enable service endpoints for KeyVault and Storage ──
    print(f"\n[3b] Enabling service endpoints: Microsoft.KeyVault, Microsoft.Storage...")
    subnet = network_client.subnets.begin_create_or_update(
        RESOURCE_GROUP, VNET_NAME, SUBNET_NAME,
        {
            "address_prefix": subnet.address_prefix,
            "service_endpoints": [
                {"service": "Microsoft.KeyVault"},
                {"service": "Microsoft.Storage"},
            ],
            # NSG must be preserved if already attached
            "network_security_group": {"id": subnet.network_security_group.id} if subnet.network_security_group else None,
        },
    ).result()
    print(f"     Service endpoints enabled!")

    # ── 3c: Verify ──
    print(f"\n[3c] Verifying service endpoints on '{SUBNET_NAME}':")
    subnet = network_client.subnets.get(RESOURCE_GROUP, VNET_NAME, SUBNET_NAME)
    for ep in subnet.service_endpoints:
        print(f"     - {ep.service} (status: {ep.provisioning_state})")

    print(f"\n  WHAT THIS MEANS:")
    print(f"  Traffic from '{SUBNET_NAME}' to Key Vault and Storage now goes")
    print(f"  through Azure's backbone, not the public internet.")
    print(f"  But you still need to add a VNet rule on the KV/Storage firewall")
    print(f"  to actually allow this subnet (see Lesson 4).")

    print("\n  KEY TAKEAWAYS:")
    print("  - Service endpoint = route optimization (Azure backbone instead of internet)")
    print("  - Must enable on the subnet AND add VNet rule on the PaaS service")
    print("  - Free, but limited to same region and no on-prem access")
    return subnet.id


# ════════════════════════════════════════════════════════════════════════════
# LESSON 4: Key Vault Firewall (Network ACLs)
# ════════════════════════════════════════════════════════════════════════════
#
# THEORY:
#   Every Key Vault has a firewall controlled by "network ACLs":
#     - default_action: "Allow" (public) or "Deny" (private)
#     - ip_rules: specific IPs/CIDRs allowed through
#     - virtual_network_rules: specific subnets allowed through
#     - bypass: "AzureServices" lets trusted Azure services through
#
#   This is what keyvault_mgmt.py checks in _is_public_network() and
#   modifies in _add_ip_rule() / _remove_ip_rule().

def lesson_4_kv_firewall():
    print("\n" + "=" * 60)
    print("  LESSON 4: Key Vault Firewall (Network ACLs)")
    print("=" * 60)

    # ── 4a: Read current firewall settings ──
    print(f"\n[4a] Reading firewall settings for '{KEY_VAULT_NAME}'...")
    vault = kv_client.vaults.get(RESOURCE_GROUP, KEY_VAULT_NAME)
    acls = vault.properties.network_acls

    if not acls or acls.default_action == "Allow":
        print("     defaultAction: Allow — vault is publicly accessible")
        print("     (This is what _is_public_network() returns True for)")
    else:
        print(f"     defaultAction: {acls.default_action} — vault is private")
        print(f"     bypass: {acls.bypass}")
        print(f"     IP rules: {[r.value for r in (acls.ip_rules or [])]}")
        print(f"     VNet rules: {[r.id.split('/')[-1] for r in (acls.virtual_network_rules or [])]}")

    # ── 4b: Add an IP rule (what _add_ip_rule does) ──
    print(f"\n[4b] Adding IP rule '203.0.113.50' (example IP)...")
    ip_rules = list(acls.ip_rules) if acls and acls.ip_rules else []
    ip_rules.append({"value": "203.0.113.50/32"})
    kv_client.vaults.update(
        RESOURCE_GROUP, KEY_VAULT_NAME,
        {"properties": {"network_acls": {"ip_rules": ip_rules}}},
    )
    print("     IP rule added. Only this IP (plus existing rules) can access the vault.")

    # ── 4c: Read back and verify ──
    print(f"\n[4c] Verifying:")
    vault = kv_client.vaults.get(RESOURCE_GROUP, KEY_VAULT_NAME)
    acls = vault.properties.network_acls
    print(f"     IP rules: {[r.value for r in (acls.ip_rules or [])]}")

    # ── 4d: Remove the IP rule (what _remove_ip_rule does) ──
    print(f"\n[4d] Removing IP rule '203.0.113.50/32'...")
    ip_rules = [r for r in (acls.ip_rules or []) if r.value != "203.0.113.50/32"]
    kv_client.vaults.update(
        RESOURCE_GROUP, KEY_VAULT_NAME,
        {"properties": {"network_acls": {"ip_rules": [{"value": r.value} for r in ip_rules]}}},
    )
    print("     Cleaned up.")

    # ── 4e: Show how VNet rules work ──
    print(f"\n[4e] VNet rules (subnets allowed to access this vault):")
    vault = kv_client.vaults.get(RESOURCE_GROUP, KEY_VAULT_NAME)
    acls = vault.properties.network_acls
    if acls and acls.virtual_network_rules:
        for rule in acls.virtual_network_rules:
            print(f"     - {rule.id}")
        print("\n     These subnets can access the vault even though defaultAction=Deny.")
        print("     This requires a service endpoint (Microsoft.KeyVault) on the subnet.")
    else:
        print("     None configured.")

    print("\n  KEY TAKEAWAYS:")
    print("  - defaultAction=Deny means ONLY ip_rules + virtual_network_rules can access")
    print("  - ip_rules: allow specific public IPs (e.g., your office IP)")
    print("  - virtual_network_rules: allow specific subnets (needs service endpoint)")
    print("  - bypass='AzureServices' lets trusted Azure services through regardless")
    print("  - keyvault_mgmt.py adds 0.0.0.0/0 temporarily to allow access, then removes it")


# ════════════════════════════════════════════════════════════════════════════
# LESSON 5: Private Endpoints
# ════════════════════════════════════════════════════════════════════════════
#
# THEORY:
#   Private Endpoint = a network interface (NIC) in YOUR subnet that gets a
#   private IP address, and is connected to a PaaS service via Private Link.
#
#   Before: Your VM → internet → Key Vault (public IP)
#   After:  Your VM → private endpoint (10.1.x.x) → Key Vault (no internet)
#
#   Components:
#   1. Private Endpoint resource (has a NIC with a private IP in your subnet)
#   2. Private Link Service Connection (links the PE to the target resource)
#   3. group_ids: identifies what part of the service to connect to
#      - Key Vault: ["vault"]
#      - Storage Blob: ["blob"]
#      - SQL: ["sqlServer"]
#      - Cosmos DB: ["Sql"]
#
#   The subnet needs: privateEndpointNetworkPolicies = "Disabled"
#   (otherwise Azure blocks PE creation)

def lesson_5_private_endpoints():
    print("\n" + "=" * 60)
    print("  LESSON 5: Private Endpoints")
    print("=" * 60)

    VNET_NAME = "learn-networking-vnet"
    SUBNET_NAME = "db-subnet"
    PE_NAME = "learn-kv-private-endpoint"

    # ── 5a: Prepare subnet for private endpoints ──
    print(f"\n[5a] Preparing subnet for private endpoints...")
    subnet = network_client.subnets.get(RESOURCE_GROUP, VNET_NAME, SUBNET_NAME)
    print(f"     Current privateEndpointNetworkPolicies: {subnet.private_endpoint_network_policies}")

    if subnet.private_endpoint_network_policies != "Disabled":
        print("     Disabling network policies on subnet (required for PE creation)...")
        subnet = network_client.subnets.begin_create_or_update(
            RESOURCE_GROUP, VNET_NAME, SUBNET_NAME,
            {
                "address_prefix": subnet.address_prefix,
                "private_endpoint_network_policies": "Disabled",
                "service_endpoints": [{"service": ep.service} for ep in (subnet.service_endpoints or [])],
                "network_security_group": {"id": subnet.network_security_group.id} if subnet.network_security_group else None,
            },
        ).result()
        print(f"     Done: {subnet.private_endpoint_network_policies}")

    # ── 5b: Get Key Vault resource ID ──
    print(f"\n[5b] Getting Key Vault resource ID...")
    vault = kv_client.vaults.get(RESOURCE_GROUP, KEY_VAULT_NAME)
    print(f"     Vault ID: {vault.id}")

    # ── 5c: Create Private Endpoint ──
    print(f"\n[5c] Creating Private Endpoint '{PE_NAME}'...")
    print(f"     This creates a NIC in subnet '{SUBNET_NAME}' with a private IP,")
    print(f"     connected to Key Vault via Private Link.")
    pe = network_client.private_endpoints.begin_create_or_update(
        RESOURCE_GROUP, PE_NAME,
        {
            "location": LOCATION,
            "subnet": {"id": subnet.id},
            "private_link_service_connections": [{
                "name": f"{PE_NAME}-connection",
                "properties": {
                    "private_link_service_id": vault.id,
                    "group_ids": ["vault"],
                },
            }],
        },
    ).result()
    print(f"     Private Endpoint created!")
    print(f"     PE ID: {pe.id}")
    print(f"     Provisioning state: {pe.provisioning_state}")

    # ── 5d: Inspect the private endpoint's NIC and IP ──
    print(f"\n[5d] Inspecting private endpoint details...")
    pe = network_client.private_endpoints.get(RESOURCE_GROUP, PE_NAME)
    if pe.network_interfaces:
        nic_id = pe.network_interfaces[0].id
        nic_name = nic_id.split("/")[-1]
        nic = network_client.network_interfaces.get(RESOURCE_GROUP, nic_name)
        for ip_config in nic.ip_configurations:
            print(f"     Private IP: {ip_config.private_ip_address}")
            print(f"     This IP is how resources in your VNet reach Key Vault privately!")

    if pe.private_link_service_connections:
        conn = pe.private_link_service_connections[0]
        print(f"     Connection status: {conn.private_link_service_connection_state.status}")
        print(f"     Connected to: {conn.private_link_service_id.split('/')[-1]}")

    # ── 5e: Check the vault side (private endpoint connections) ──
    print(f"\n[5e] Checking vault's private endpoint connections...")
    vault = kv_client.vaults.get(RESOURCE_GROUP, KEY_VAULT_NAME)
    for conn in (vault.properties.private_endpoint_connections or []):
        status = conn.private_link_service_connection_state.status
        pe_id = conn.private_endpoint.id if conn.private_endpoint else "?"
        print(f"     Connection: {pe_id.split('/')[-1]} | Status: {status}")

    print("\n  AT THIS POINT:")
    print(f"  Key Vault '{KEY_VAULT_NAME}' has a private IP inside your VNet.")
    print(f"  But DNS still resolves to the public IP — you need Private DNS (Lesson 6).")

    print("\n  KEY TAKEAWAYS:")
    print("  - Private Endpoint = NIC + private IP in your subnet")
    print("  - group_ids tells Azure which sub-resource to connect (vault, blob, sql, etc.)")
    print("  - Subnet needs privateEndpointNetworkPolicies=Disabled")
    print("  - PE is auto-approved when you own both the subnet and the target resource")
    return PE_NAME


# ════════════════════════════════════════════════════════════════════════════
# LESSON 6: Private DNS Zones
# ════════════════════════════════════════════════════════════════════════════
#
# THEORY:
#   Problem: After creating a private endpoint, DNS still resolves
#   test-kvmgmt-brewmation.vault.azure.net → public IP
#   But you need it to resolve → private IP (10.1.x.x)
#
#   Solution: Private DNS Zone
#   1. Create zone: privatelink.vaultcore.azure.net
#   2. Link it to your VNet (so VMs in the VNet use this zone)
#   3. Add an A record: test-kvmgmt-brewmation → 10.1.x.x
#
#   Or simpler: Create a "DNS Zone Group" on the PE — Azure auto-manages the records.
#
#   Common private DNS zone names:
#     Key Vault:      privatelink.vaultcore.azure.net
#     Storage Blob:   privatelink.blob.core.windows.net
#     SQL:            privatelink.database.windows.net
#     Cosmos DB:      privatelink.documents.azure.com

def lesson_6_private_dns(pe_name="learn-kv-private-endpoint"):
    print("\n" + "=" * 60)
    print("  LESSON 6: Private DNS Zones")
    print("=" * 60)

    VNET_NAME = "learn-networking-vnet"
    DNS_ZONE_NAME = "privatelink.vaultcore.azure.net"

    # ── 6a: Create Private DNS Zone ──
    print(f"\n[6a] Creating Private DNS Zone '{DNS_ZONE_NAME}'...")
    print(f"     This zone will override public DNS for *.vaultcore.azure.net")
    try:
        zone = dns_client.private_zones.begin_create_or_update(
            RESOURCE_GROUP, DNS_ZONE_NAME,
            {"location": "global"},
        ).result()
        print(f"     Zone created: {zone.name}")
    except HttpResponseError as e:
        if "Conflict" in str(e):
            print(f"     Zone already exists, continuing...")
            zone = dns_client.private_zones.get(RESOURCE_GROUP, DNS_ZONE_NAME)
        else:
            raise

    # ── 6b: Link the DNS zone to your VNet ──
    print(f"\n[6b] Linking DNS zone to VNet '{VNET_NAME}'...")
    print(f"     This makes VMs in the VNet use this zone for DNS resolution.")
    vnet = network_client.virtual_networks.get(RESOURCE_GROUP, VNET_NAME)
    try:
        link = dns_client.virtual_network_links.begin_create_or_update(
            RESOURCE_GROUP, DNS_ZONE_NAME, "learn-vnet-link",
            {
                "location": "global",
                "virtual_network": {"id": vnet.id},
                "registration_enabled": False,
            },
        ).result()
        print(f"     Link created: {link.name}")
    except HttpResponseError as e:
        if "Conflict" in str(e):
            print(f"     Link already exists, continuing...")
        else:
            raise

    # ── 6c: Create DNS Zone Group on the PE (auto-manages A records) ──
    print(f"\n[6c] Creating DNS Zone Group on PE '{pe_name}'...")
    print(f"     This auto-creates an A record pointing to the PE's private IP.")
    dns_zone_group = network_client.private_dns_zone_groups.begin_create_or_update(
        RESOURCE_GROUP, pe_name, "default",
        {
            "private_dns_zone_configs": [{
                "name": DNS_ZONE_NAME,
                "properties": {
                    "private_dns_zone_id": zone.id,
                },
            }],
        },
    ).result()
    print(f"     DNS Zone Group created!")

    # ── 6d: Check the auto-created A record ──
    print(f"\n[6d] Checking A records in '{DNS_ZONE_NAME}':")
    for record_set in dns_client.record_sets.list(RESOURCE_GROUP, DNS_ZONE_NAME):
        if record_set.a_records:
            for a in record_set.a_records:
                print(f"     {record_set.name}.{DNS_ZONE_NAME} → {a.ipv4_address}")
                print(f"     Now DNS resolves to the private IP inside your VNet!")

    print("\n  THE FULL PICTURE:")
    print(f"  1. PE gives Key Vault a private IP in your subnet")
    print(f"  2. Private DNS zone overrides public DNS → private IP")
    print(f"  3. VMs in the VNet resolve {KEY_VAULT_NAME}.vault.azure.net → 10.1.x.x")
    print(f"  4. Traffic never leaves your VNet!")

    print("\n  KEY TAKEAWAYS:")
    print("  - Private DNS Zone overrides public DNS within linked VNets")
    print("  - DNS Zone Group on PE = Azure auto-manages the A record")
    print("  - Without this, the PE exists but nothing can find it by name")


# ════════════════════════════════════════════════════════════════════════════
# LESSON 7: Full Flow (What keyvault_mgmt.py Does)
# ════════════════════════════════════════════════════════════════════════════
#
# This maps every networking method in keyvault_mgmt.py to the concepts above.

def lesson_7_full_flow():
    print("\n" + "=" * 60)
    print("  LESSON 7: How keyvault_mgmt.py Uses All of This")
    print("=" * 60)

    print("""
    When keyvault_mgmt.py needs to write a secret to a Key Vault:

    ┌─ _ensure_network_access() ─────────────────────────────────────────┐
    │                                                                     │
    │  Step 1: _get_vault()                                               │
    │    → Fetches the Key Vault resource (Lesson 4)                      │
    │                                                                     │
    │  Step 2: _is_public_network(vault)                                  │
    │    → Checks network_acls.default_action                             │
    │    → If "Allow" → vault is public, no firewall work needed          │
    │    → If "Deny"  → vault is private, need to get access              │
    │                                                                     │
    │  Step 3: Try _add_ip_rule()  (Lesson 4)                             │
    │    → Adds IP rule 0.0.0.0/0 to KV firewall                         │
    │    → If blocked by Azure Policy:                                    │
    │      → _exempt_policy() → create temporary policy exemption         │
    │      → Retry _add_ip_rule()                                         │
    │    → If still fails:                                                │
    │      → Fall back to _create_private_endpoint()  (Lessons 5 & 6)     │
    │                                                                     │
    │  Step 4: _create_private_endpoint()                                 │
    │    → Gets subnet from vault's virtual_network_rules (Lesson 3)      │
    │    → Creates PE in that subnet (Lesson 5)                           │
    │    → Creates DNS Zone Group (Lesson 6)                              │
    │    → Now the Function App can reach the vault privately              │
    └─────────────────────────────────────────────────────────────────────┘

    After the secret is written:

    ┌─ Cleanup (in finally block) ───────────────────────────────────────┐
    │  _remove_ip_rule()       → removes the 0.0.0.0/0 rule             │
    │  _delete_private_endpoint() → deletes PE + DNS zone group          │
    │  Vault is locked down again!                                       │
    └─────────────────────────────────────────────────────────────────────┘
    """)


# ════════════════════════════════════════════════════════════════════════════
# CLEANUP: Remove all resources created by these lessons
# ════════════════════════════════════════════════════════════════════════════

def cleanup():
    print("\n" + "=" * 60)
    print("  CLEANUP: Removing all lesson resources")
    print("=" * 60)

    PE_NAME = "learn-kv-private-endpoint"
    VNET_NAME = "learn-networking-vnet"
    NSG_NAME = "learn-web-nsg"
    DNS_ZONE_NAME = "privatelink.vaultcore.azure.net"

    steps = [
        ("DNS zone group", lambda: network_client.private_dns_zone_groups.begin_delete(RESOURCE_GROUP, PE_NAME, "default").result()),
        ("Private endpoint", lambda: network_client.private_endpoints.begin_delete(RESOURCE_GROUP, PE_NAME).result()),
        ("VNet link", lambda: dns_client.virtual_network_links.begin_delete(RESOURCE_GROUP, DNS_ZONE_NAME, "learn-vnet-link").result()),
        ("Private DNS zone", lambda: dns_client.private_zones.begin_delete(RESOURCE_GROUP, DNS_ZONE_NAME).result()),
        ("NSG", lambda: network_client.network_security_groups.begin_delete(RESOURCE_GROUP, NSG_NAME).result()),
        ("VNet (includes subnets)", lambda: network_client.virtual_networks.begin_delete(RESOURCE_GROUP, VNET_NAME).result()),
    ]

    for name, action in steps:
        try:
            print(f"  Deleting {name}...")
            action()
            print(f"  ✓ {name} deleted")
        except Exception as e:
            print(f"  ⚠ {name}: {e}")

    print("\n  Cleanup complete!")


# ════════════════════════════════════════════════════════════════════════════
# MAIN — Run one lesson at a time, or all at once
# ════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import sys

    lessons = {
        "1": ("VNets & Subnets", lesson_1_vnets_and_subnets),
        "2": ("NSGs", lesson_2_nsg),
        "3": ("Service Endpoints", lesson_3_service_endpoints),
        "4": ("KV Firewall", lesson_4_kv_firewall),
        "5": ("Private Endpoints", lesson_5_private_endpoints),
        "6": ("Private DNS", lesson_6_private_dns),
        "7": ("Full Flow (theory)", lesson_7_full_flow),
        "all": ("All lessons", None),
        "cleanup": ("Remove all resources", cleanup),
    }

    if len(sys.argv) < 2:
        print("\nUsage: python learn_azure_networking.py <lesson>")
        print("\nLessons:")
        for key, (desc, _) in lessons.items():
            print(f"  {key:8s} - {desc}")
        print("\nExamples:")
        print("  python learn_azure_networking.py 1        # Run Lesson 1")
        print("  python learn_azure_networking.py all      # Run all lessons")
        print("  python learn_azure_networking.py cleanup   # Delete all resources")
        sys.exit(0)

    choice = sys.argv[1]

    if choice == "all":
        subnet_id = lesson_1_vnets_and_subnets()
        lesson_2_nsg()
        lesson_3_service_endpoints()
        lesson_4_kv_firewall()
        pe_name = lesson_5_private_endpoints()
        lesson_6_private_dns(pe_name)
        lesson_7_full_flow()
        print("\n\n  ALL LESSONS COMPLETE!")
        print("  Run 'python learn_azure_networking.py cleanup' to delete resources.")
    elif choice in lessons:
        _, func = lessons[choice]
        if choice == "6":
            func()
        else:
            func()
    else:
        print(f"Unknown lesson: {choice}")
