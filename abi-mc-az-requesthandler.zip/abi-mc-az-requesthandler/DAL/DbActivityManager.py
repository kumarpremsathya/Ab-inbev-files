import json,logging,datetime
from shared_code.db import DB

class DbActivityManager:
    def __init__(self) -> None:
        self.objdb= DB()

    def get_activity_completed(self):
        sql_query = """
        select CA.EventId,CA.ActivityName,EM.ActivityType,EM.SnowId,EM.SnowItemId,EM.RequestedBy,CA.Status,CA.Comments from tblEventCompletedActivity as CA
        inner join tblEventMaster as EM ON CA.EventId = EM.EventId and CA.ActivityName = EM.ActivityName
        """
        datasets = self.objdb.executescalar(sql_query=sql_query,action="select",)

        return datasets
    
    def delete_activity_pending(self,dataset):
        sql_query = """
        delete from tblEventPendingActivity where EventId = ? and ActivityName = ?
        """
        values=(dataset.EventId,dataset.ActivityName)
        self.objdb.executescalar(sql_query=sql_query,action="delete",values=values)
    
    def delete_activity_completed(self,dataset):
        sql_query = """
        delete from tblEventCompletedActivity where EventId = ? and ActivityName = ?
        """
        values=(dataset.EventId,dataset.ActivityName)
        self.objdb.executescalar(sql_query=sql_query,action="delete",values=values)
    
    def end_activity(self,dataset):
        match dataset.ActivityType:
            case 'Incident':
                if dataset.Status == 'Success':
                    SnowItemStatusCode = '3'
                    SnowItemStatus = 'closed_complete'
                else:
                    SnowItemStatusCode = '4'
                    SnowItemStatus = 'closed_incomplete'
            case 'Request':
                if dataset.Status == 'Success':
                    SnowItemStatusCode = '3'
                    SnowItemStatus = 'closed_complete'
                    status = 'Completed'
                else:
                    SnowItemStatusCode = '4'
                    SnowItemStatus = 'closed_incomplete'
                    status = 'Closed Incomplete'
            case 'Change':
                if dataset.Status == 'Success':
                    SnowItemStatusCode = '3'
                    SnowItemStatus = 'closed_complete'
                else:
                    SnowItemStatusCode = '4'
                    SnowItemStatus = 'closed_incomplete'

        sql_query = """
        update tblEventMaster set SnowItemStatusCode = ?,SnowItemStatus=?
        ,LastUpdateTime=?,Status=?,Comments=?
        where EventId = ? and ActivityName = ?
        """
        values=(SnowItemStatusCode,SnowItemStatus,datetime.datetime.now(datetime.timezone.utc),status,dataset.Comments,dataset.EventId,dataset.ActivityName)
        self.objdb.executescalar(sql_query=sql_query,action="update",values=values)

    def log_exception_activityinfo(self,EventId,ActivityId,ActivityName,Exception,Message=None):
        sql_query = """
        MERGE INTO tblActivityInfo as Target
        USING (SELECT ?,?,?,?,?)
        AS SOURCE(EventId,ActivityId,ActivityName,Exception,Message)
        ON Target.EventId=Source.EventId
        AND Target.ActivityId=Source.ActivityId
        AND Target.ActivityName=Source.ActivityName
        WHEN MATCHED THEN
        UPDATE SET Exception = Source.Exception, Message = Source.Message
        WHEN NOT MATCHED THEN
        INSERT (EventId,ActivityId,ActivityName,Exception,Message)
        VALUES (Source.EventId,Source.ActivityId,Source.ActivityName, Source.Exception, Source.Message);
        """
        values=(EventId,ActivityId,ActivityName,Exception,Message)
        self.objdb.executescalar(sql_query=sql_query,action="insert",values=values)

    def get_new_activity(self):
        sql_query = """
        select * from tblEventMaster 
        where 
            (SnowItemStatusCode = '-5' and SnowItemStatus = 'waiting_for_approval' and Status = 'Pending Approval')
             or
            (SnowItemStatusCode = '8' and SnowItemStatus = 'request_approved' and Status = 'Pending Approval')
             or
            (SnowItemStatusCode = '19' and SnowItemStatus = 'Queued' and Status = 'Queued')
        order by 			
			CASE ActivityType
				WHEN 'Incident' THEN 1
				WHEN 'Request' THEN 2
				WHEN 'Change' THEN 3
				ELSE 4
	        END
			,EventStartTime asc
        """
        datasets = self.objdb.executescalar(sql_query=sql_query,action="select",)

        return datasets
    
    def get_event_info(self,EventId):
        sql_query = """
        select * from tblEventMaster where EventId = ?
        """
        values=(EventId)
        datasets = self.objdb.executescalar(sql_query=sql_query,action="select",values=values)
        return datasets
    
    def update_activity_master_status(self,dataset,SnowItemStatusCode,SnowItemStatus,status):
        sql_query = """
        update tblEventMaster set SnowItemStatusCode = ?,SnowItemStatus=?
        ,LastUpdateTime=?,Status=?
        where EventId = ? and ActivityName = ?
        """
        values=(SnowItemStatusCode,SnowItemStatus,datetime.datetime.now(datetime.timezone.utc),status,dataset.EventId,dataset.ActivityName)
        self.objdb.executescalar(sql_query=sql_query,action="update",values=values)
    
    def insert_activity_pending(self,dataset):
        sql_query = """
            MERGE INTO tblEventPendingActivity as Target
            USING (SELECT ?,?,?)
            AS SOURCE(EventId,ActivityName,RetryAttemptedAt)
            ON Target.EventId=Source.EventId
            AND Target.ActivityName=Source.ActivityName
            WHEN NOT MATCHED THEN
            INSERT (EventId,ActivityName,RetryAttemptedAt)
            VALUES (Source.EventId,Source.ActivityName,Source.RetryAttemptedAt);
        """
        values=(dataset.EventId,dataset.ActivityName,datetime.datetime.now(datetime.timezone.utc))
        self.objdb.executescalar(sql_query=sql_query,action="insert",values=values)
    
    def get_pending_activity(self):
        sql_query = f"""
            select PA.EventId,PA.ActivityName,EM.ActivityType,EM.SnowId,EM.SnowItemId,
            EM.SnowItemStatusCode,EM.SnowItemStatus,EM.Cloud from tblEventPendingActivity as PA
            inner join tblEventMaster as EM ON PA.EventId = EM.EventId and 
            PA.ActivityName = EM.ActivityName and PA.RetryAttemptedAt < ?
            order by 
            CASE EM.ActivityType
				WHEN 'Incident' THEN 1
				WHEN 'Request' THEN 2
				WHEN 'Change' THEN 3
				ELSE 4
	        END
            ,PA.RetryAttemptedAt asc
        """
        values = (datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None))
        datasets = self.objdb.executescalar(sql_query=sql_query,action="select",values=values)

        return datasets
    
    def get_pending_activity_handler(self):
        sql_query = f"""
            select * from tblEventPendingActivity where RetryAttemptedAt < ?
        """
        values = (datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None))
        datasets = self.objdb.executescalar(sql_query=sql_query,action="select",values=values)
        return datasets
    
    def get_pending_next_retry_time(self,dataset,tblname):
        sql_query = f"""
            select top(1) * from {tblname} where EventId = ? and (Status = ? or Status = ?) order by RetryAttemptedAt asc
        """
        values = (dataset.EventId,'In-Progress','Retry')
        datasets = self.objdb.executescalar(sql_query=sql_query,action="select",values=values)

        return datasets
    
    def get_activity_info(self,tblname,evenid):
        sql_query = f"""
            select * from {tblname} where EventId = ? and (Status = ? or Status = ?)
        """
        values = (evenid,'In-Progress','Retry')
        datasets = self.objdb.executescalar(sql_query=sql_query,action="select",values=values)

        return datasets

    def get_activity_info_failed_count(self,tblname,eventid):
        sql_query = f"""
            SELECT
                EventId,
                COUNT(*) AS TotalRecords,
                SUM(CASE WHEN Status = 'Success' THEN 1 ELSE 0 END) AS SuccessCount,
                SUM(CASE WHEN Status = 'Failed' THEN 1 ELSE 0 END) AS FailedCount
            FROM {tblname} where EventId = ?
            GROUP BY EventId
        """
        values = (eventid)
        datasets = self.objdb.executescalar(sql_query=sql_query,action="select",values=values)

        return datasets
    
    def db_update_activity(self,tblname,activityid,status,comments,retryattemptedat):
        sql_query = f"""
            update {tblname} SET Status = ?, Comments = ?, RetryAttemptedAt = ?
            where activityid = ?
        """
        values=(status,comments,retryattemptedat,activityid)
        self.objdb.executescalar(sql_query=sql_query,action="update",values=values)
    
    def update_activity_info(self,tblname,result,comments,eventid):
        sql_query = f"""
            update {tblname} SET Status = ?,Comments = ?
            where EventId = ? and Status = ?
        """
        values=(result,comments,eventid,'In-Progress')
        self.objdb.executescalar(sql_query=sql_query,action="update",values=values)
    
    def update_activity_pending_retry(self,dataset,retry_interval):
        sql_query = """
            update tblEventPendingActivity SET RetryAttemptedAt = ?
            where EventId = ?      
        """
        values=(retry_interval,dataset.EventId)
        self.objdb.executescalar(sql_query=sql_query,action="update",values=values)

    def insert_activity_completed(self,dataset,result,comments):
        sql_query = """
            MERGE INTO tblEventCompletedActivity as Target
            USING (SELECT ?,?,?,?)
            AS SOURCE(EventId,ActivityName,Status,Comments)
            ON Target.EventId=Source.EventId
            AND Target.ActivityName=Source.ActivityName
            WHEN NOT MATCHED THEN
            INSERT (EventId,ActivityName,Status,Comments)
            VALUES (Source.EventId,Source.ActivityName,Source.Status,Source.Comments);
        """
        values=(dataset.EventId,dataset.ActivityName,result,comments)
        self.objdb.executescalar(sql_query=sql_query,action="insert",values=values)

    def update_incomplete_activity(self,table_name,status,comments,EventId):
        sql_query = f"""
        update {table_name} set Status = ?,Comments=?
        where EventId = ? and Status = 'In-Progress'
        """
        values=(status,comments,EventId)
        self.objdb.executescalar(sql_query=sql_query,action="update",values=values)

    def mark_hoursofoperationinstance_decommissioned(self, activity_id: str):
        sql_query = """
            UPDATE tblActivityAzHoursOfOperationInstance 
            SET IsActive = 'Decommissioned'
            WHERE ActivityId = ?
        """
        values = (activity_id,)
        self.objdb.executescalar(sql_query=sql_query, action="update", values=values)

    def insert_hoursofoperationinstance_activity(self, activity_data: dict, status: str = 'In-Progress'):
        sql_query = """
            MERGE INTO tblActivityAzHoursOfOperationInstanceReport as Target
            USING (SELECT ?,?,?,?,?,?,?,?,?,?,?) AS SOURCE
            (InstanceActivityId, ActivityId, EventId, Zone, SubscriptionId, SubscriptionName,
             ResourceGroupName, ResourceName, ResourceId, Action, Status)
            ON Target.InstanceActivityId = Source.InstanceActivityId
            WHEN MATCHED THEN
                UPDATE SET Status = Source.Status, CompletedAt = CASE WHEN Source.Status IN ('Success','Failed') THEN GETUTCDATE() ELSE Target.CompletedAt END
            WHEN NOT MATCHED THEN
                INSERT (InstanceActivityId, ActivityId, EventId, Zone, SubscriptionId, SubscriptionName,
                        ResourceGroupName, ResourceName, ResourceId, Action, Status)
                VALUES (Source.InstanceActivityId, Source.ActivityId, Source.EventId, Source.Zone, 
                        Source.SubscriptionId, Source.SubscriptionName, Source.ResourceGroupName, 
                        Source.ResourceName, Source.ResourceId, Source.Action, Source.Status);
        """
        instance_activity_id = activity_data.get('InstanceActivityId', '')
        if not instance_activity_id:
            instance_activity_id = activity_data.get('ActivityId', '')
        activity_id = activity_data.get('ActivityId', '')
        values = (
            instance_activity_id,
            activity_id,
            activity_data.get('EventId', ''),
            activity_data.get('Zone', ''),
            activity_data.get('SubscriptionId', ''),
            activity_data.get('SubscriptionName', ''),
            activity_data.get('ResourceGroupName', ''),
            activity_data.get('ResourceName', ''),
            activity_data.get('ResourceId', ''),
            activity_data.get('Action', ''),
            status
        )
        self.objdb.executescalar(sql_query=sql_query, action="insert", values=values)
    
    def get_inactive_users(self,vm_name):
        sql_query = """
        select accountname from tblVmAccounts where node like ? and accountenabled = 'inactive'
        """
        values=(f"{vm_name}%",)
        datasets = self.objdb.executescalar(sql_query=sql_query,action="select",values=values)

        inactive_users = [row.accountname for row in datasets]
        return inactive_users