from azure.core.exceptions import ResourceNotFoundError, HttpResponseError
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
from azure.mgmt.authorization.v2020_10_01_preview.models import (
    RoleAssignmentScheduleRequest,
    RoleAssignmentScheduleRequestPropertiesScheduleInfo,
    RoleAssignmentScheduleRequestPropertiesScheduleInfoExpiration,
)
from azure.mgmt.authorization.v2020_10_01_preview.models._authorization_management_client_enums import (
    RequestType, Type
)
from shared_code.keyvault_client import KeyVaultClient
from shared_code.authorization_client import AuthorizationClient
from shared_code.policy_client import AzPolicyClient
from shared_code.private_endpoint_helper import PrivateEndpointHelper
from shared_code.akv_secrets import AkvSecrets
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import json, logging, os, base64, uuid, time, re
from datetime import datetime, timedelta, timezone
from shared_code.networkmgmt_client import NetworkMgmtClient

FUNCTION_APP_PRINCIPAL_ID = "175069f8-dddf-4e77-ad30-4d87da8904c4"
KV_OFFICER_ROLE_DEF_ID_TEMPLATE = "/subscriptions/{sub_id}/providers/Microsoft.Authorization/roleDefinitions/b86a8fe4-44ce-4948-aee5-eccb2c155cd7"


class KeyVaultMgmt:
    def __init__(self, data):
        self.event_id = data.get('EventId', '')
        self.zone = data.get('Zone', '').lower()
        self.subscription_id = data.get('SubscriptionId', '')
        self.resource_group_name = data.get('ResourceGroupName', '')
        self.key_vault_name = data.get('KeyVaultName', '')
        self.secret_name = data.get('SecretName', '')
        self.secret_value_enc = data.get('SecretValue', '')
        self.iv = data.get('IV', '')
        self.tag = data.get('Tag', '')
        self.content_type = data.get('ContentType') or None
        self.expires_on = data.get('ExpiresOn') or None
        self.tags = self._parse_tags(data.get('Tags'))
        self.action = data.get('Action', '')
        self.cloud = "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        self.env = os.environ.get("Environment", "").lower()

        self.kv_mgmt_client = KeyVaultClient().get_kv_client(self.subscription_id, self.cloud)
        self.auth_client = AuthorizationClient().get_auth_client(self.cloud, self.subscription_id)

        self.is_ip_added = False
        self.is_pe_created = False
        self.private_endpoint_name = f"{self.key_vault_name}-pe-brewmation"
        self.dns_zone_name = "privatelink.vaultcore.azure.cn" if self.zone == "china" else "privatelink.vaultcore.azure.net"

    def _parse_tags(self, tags):
        if not tags:
            return None
        if isinstance(tags, dict):
            return tags
        return json.loads(tags)

    def _get_vault(self):
        return self.kv_mgmt_client.vaults.get(self.resource_group_name, self.key_vault_name)

    def _is_public_network(self, vault):
        network_acls = vault.properties.network_acls
        if not network_acls or network_acls.default_action == "Allow":
            return True
        return False

    def _add_ip_rule(self):
        vault = self._get_vault()
        network_acls = vault.properties.network_acls
        ip_rules = list(network_acls.ip_rules) if network_acls and network_acls.ip_rules else []
        ip_rules.append({"value": "0.0.0.0/0"})
        self.kv_mgmt_client.vaults.update(
            self.resource_group_name,
            self.key_vault_name,
            {"properties": {"network_acls": {"ip_rules": ip_rules}}}
        )
        self.is_ip_added = True
        logging.info(f"IP rule 0.0.0.0/0 added to Key Vault '{self.key_vault_name}'")

    def _remove_ip_rule(self):
        if not self.is_ip_added:
            return
        vault = self._get_vault()
        network_acls = vault.properties.network_acls
        ip_rules = [r for r in (network_acls.ip_rules or []) if r.value != "0.0.0.0/0"]
        self.kv_mgmt_client.vaults.update(
            self.resource_group_name,
            self.key_vault_name,
            {"properties": {"network_acls": {"ip_rules": ip_rules}}}
        )
        logging.info(f"IP rule 0.0.0.0/0 removed from Key Vault '{self.key_vault_name}'")

    def _exempt_policy(self, policy_assignment_id):
        policy_client = AzPolicyClient().get_policy_client(self.subscription_id, self.cloud)
        scope = f"/subscriptions/{self.subscription_id}/resourceGroups/{self.resource_group_name}/providers/Microsoft.KeyVault/vaults/{self.key_vault_name}"
        exemption_name = f"{self.key_vault_name}-Brewmation-{str(uuid.uuid4()).split('-')[0]}"
        policy_client.policy_exemptions.create_or_update(
            scope=scope,
            policy_exemption_name=exemption_name,
            parameters={
                "properties": {
                    "policyAssignmentId": policy_assignment_id,
                    "exemptionCategory": "Waiver",
                    "expiresOn": datetime.now(timezone.utc) + timedelta(hours=1),
                }
            },
        )
        logging.info(f"Policy exemption '{exemption_name}' created for Key Vault '{self.key_vault_name}'")
        time.sleep(180)

    def _create_private_endpoint(self):
        vault = self._get_vault()
        subnet_id = self._get_subnet_id(vault)
        pe_helper = PrivateEndpointHelper(self.subscription_id, self.zone, self.cloud)
        pe_helper.create_private_endpoint(
            resource_group_name=self.resource_group_name,
            resource_id=vault.id,
            resource_name=self.key_vault_name,
            location=vault.location,
            subnet_id=subnet_id,
            group_ids=["vault"],
            dns_zone_name=self.dns_zone_name,
            private_endpoint_name=self.private_endpoint_name,
        )
        self.is_pe_created = True
        logging.info(f"Private endpoint '{self.private_endpoint_name}' created for Key Vault '{self.key_vault_name}'")

    def _get_subnet_id(self, vault):
        network_acls = vault.properties.network_acls
        if network_acls and network_acls.virtual_network_rules:
            return network_acls.virtual_network_rules[0].id
        raise ValueError(f"No subnet found for Key Vault '{self.key_vault_name}' to create private endpoint")

    def _delete_private_endpoint(self):
        if not self.is_pe_created:
            return
        try:
            network_client = NetworkMgmtClient().get_network_mgmt_client(self.subscription_id, self.cloud)
            network_client.private_dns_zone_groups.begin_delete(
                self.resource_group_name,
                self.private_endpoint_name,
                "default"
            ).result()
            network_client.private_endpoints.begin_delete(
                self.resource_group_name,
                self.private_endpoint_name
            ).result()
            logging.info(f"Private endpoint '{self.private_endpoint_name}' deleted from Key Vault '{self.key_vault_name}'")
        except Exception as e:
            logging.warning(f"Error cleaning up private endpoint '{self.private_endpoint_name}': {e}")

    def _grant_pim_kv_officer(self):
        scope = f"/subscriptions/{self.subscription_id}/resourceGroups/{self.resource_group_name}/providers/Microsoft.KeyVault/vaults/{self.key_vault_name}"
        role_def_id = KV_OFFICER_ROLE_DEF_ID_TEMPLATE.format(sub_id=self.subscription_id)
        uid = str(uuid.uuid4())
        try:
            self.auth_client.role_assignment_schedule_requests.create(
                scope=scope,
                role_assignment_schedule_request_name=uid,
                parameters=RoleAssignmentScheduleRequest(
                    request_type=RequestType.ADMIN_ASSIGN,
                    justification=f"KeyVault secret operation | EventId: {self.event_id}",
                    role_definition_id=role_def_id,
                    principal_id=FUNCTION_APP_PRINCIPAL_ID,
                    schedule_info=RoleAssignmentScheduleRequestPropertiesScheduleInfo(
                        start_date_time=datetime.datetime.now(datetime.timezone.utc),
                        expiration=RoleAssignmentScheduleRequestPropertiesScheduleInfoExpiration(
                            type=Type.AFTER_DURATION,
                            duration="PT1H"
                        ),
                    ),
                )
            )
            logging.info(f"PIM KV Officer role granted on '{self.key_vault_name}' | EventId: {self.event_id}")
            time.sleep(60)
        except HttpResponseError as e:
            if "RoleAssignmentExists" in str(e.error.code):
                logging.info(f"PIM KV Officer role already active on '{self.key_vault_name}'")
            else:
                raise

    def _ensure_network_access(self):
        vault = self._get_vault()
        if self._is_public_network(vault):
            return

        try:
            self._add_ip_rule()
        except HttpResponseError as e:
            if "RequestDisallowedByPolicy" in str(e.error.code):
                match = re.search(r'"policyAssignment":\{"name":".+?","id":"(.*?)"', e.error.message)
                policy_id = match.group(1) if match else None
                if policy_id:
                    self._exempt_policy(policy_id)
                    self._add_ip_rule()
                else:
                    self._create_private_endpoint()
            else:
                self._create_private_endpoint()

    def _decrypt_secret_value(self):
        aes_secret = AkvSecrets(os.environ["KEYVAULT_URI"], 'secrets-aes-key').get_tokens()
        aes_key = base64.b64decode(json.loads(aes_secret.value)["key"])
        nonce = base64.b64decode(self.iv)
        ciphertext = base64.b64decode(self.secret_value_enc)
        tag = base64.b64decode(self.tag)
        aesgcm = AESGCM(aes_key)
        plaintext = aesgcm.decrypt(nonce, ciphertext + tag, None)
        return plaintext.decode("utf-8")

    def _get_secret_client(self):
        vault_url = f"https://{self.key_vault_name}.vault.azure.cn" if self.cloud == "AzureChinaCloud" else f"https://{self.key_vault_name}.vault.azure.net"
        credential = DefaultAzureCredential()
        return SecretClient(vault_url=vault_url, credential=credential)

    def _validate_tags(self, tags):
        if not isinstance(tags, dict):
            return {}
        return {str(k): str(v) for k, v in tags.items()}

    async def manage_secret(self):
        action = self.action.lower()
        match action:
            case "create" | "update":
                return await self._create_or_update_secret()
            # case "delete":
            #     return await self._delete_secret()
            case _:
                raise Exception(f"Unsupported KeyVault action: {self.action}")

    async def _create_or_update_secret(self):
        try:
            secret_value = self._decrypt_secret_value()
            if not secret_value:
                raise ValueError(f"Secret value cannot be empty for '{self.secret_name}'")

            expires_on = None
            if self.expires_on:
                try:
                    expires_on = datetime.fromisoformat(self.expires_on.replace("Z", "+00:00"))
                except ValueError:
                    raise ValueError(f"Invalid date format for expires_on: '{self.expires_on}'")

            # if self.env == "production":
            if self.env == "local":
                self._ensure_network_access()
                self._grant_pim_kv_officer()

                client = self._get_secret_client()
                tags = self._validate_tags(self.tags)
                client.set_secret(
                    name=self.secret_name,
                    value=secret_value,
                    content_type=self.content_type,
                    expires_on=expires_on,
                    tags=tags
                )
                logging.info(f"Secret '{self.secret_name}' set in Key Vault '{self.key_vault_name}' | EventId: {self.event_id}")
            else:
                logging.info(f"[NON-PROD] Skipping set_secret for '{self.secret_name}' in Key Vault '{self.key_vault_name}'")
            return True
        except Exception as e:
            logging.error(f"Error setting secret '{self.secret_name}' in Key Vault '{self.key_vault_name}' | EventId: {self.event_id} - {e}")
            raise e
        finally:
            self._remove_ip_rule()
            self._delete_private_endpoint()

    async def _delete_secret(self):
        try:
            if self.env == "production":
                self._ensure_network_access()
                self._grant_pim_kv_officer()

                client = self._get_secret_client()
                poller = client.begin_delete_secret(self.secret_name)
                poller.wait()
                logging.info(f"Secret '{self.secret_name}' deleted from Key Vault '{self.key_vault_name}' | EventId: {self.event_id}")
            else:
                logging.info(f"[NON-PROD] Skipping delete_secret for '{self.secret_name}' in Key Vault '{self.key_vault_name}'")
            return True
        except ResourceNotFoundError:
            logging.warning(f"Secret '{self.secret_name}' not found in Key Vault '{self.key_vault_name}' — nothing to delete")
            return True
        except Exception as e:
            logging.error(f"Error deleting secret '{self.secret_name}' from Key Vault '{self.key_vault_name}' | EventId: {self.event_id} - {e}")
            raise e
        finally:
            self._remove_ip_rule()
            self._delete_private_endpoint()
