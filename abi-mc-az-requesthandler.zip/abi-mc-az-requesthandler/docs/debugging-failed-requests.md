# Debugging Failed Requests in abi-mc-az-requesthandler

## Table of Contents

1. [Overview](#overview)
2. [Request Lifecycle](#request-lifecycle)
3. [Understanding tblEventPendingActivity](#understanding-tbleventpendingactivity)
4. [Why a Request Gets Stuck in Retry Loop](#why-a-request-gets-stuck-in-retry-loop)
5. [Step-by-Step Debugging Guide](#step-by-step-debugging-guide)
6. [Using Durable Functions Monitor](#using-durable-functions-monitor)
7. [Common Failure Scenarios](#common-failure-scenarios)
8. [Database Queries for Investigation](#database-queries-for-investigation)
9. [Resolution Procedures](#resolution-procedures)

---

## Overview

When a request fails in the `abi-mc-az-requesthandler` function app, it follows this path:

```
ServiceBus Message → request_handler → orchestrate_activity → Activity Execution → FAILURE
    → StatusMonitor detects failure (every 5 min)
        → Marks as "Retry" in tblEventPendingActivity
            → Re-queued for execution
                → Fails again → Retry loop
```

This document covers how to identify, trace, and resolve requests stuck in this retry loop.

---

## Request Lifecycle

### Normal (Happy Path)

```
1. Message arrives on ServiceBus topic (brewmation-az-request/request-handler-sub)
2. request_handler deduplicates by ActivityId
3. Durable orchestration starts (orchestrate_activity)
4. OrchestratorClassifier routes to appropriate activity
5. Activity executes successfully
6. StatusMonitor detects "Completed" status
7. Record moves: tblEventPendingActivity → tblEventCompletedActivity
8. ServiceNow ticket closed (closed_complete)
```

### Failure Path

```
1. Activity throws an exception during execution
2. Exception logged to tblActivityInfo
3. Durable orchestration status = "Failed"
4. StatusMonitor (runs every 5 min) detects failure
5. StatusMonitor marks the record as "Retry" in tblEventPendingActivity
6. Next StatusMonitor cycle picks it up again
7. A new orchestration is started → fails again → infinite loop
```

### Special Failure Handling (Non-Retry)

Some activity types are marked as **immediate failure** (no retry):
- `DECOMM` / `WINDOWSVMUPGRADE` → marked `closed_incomplete` immediately
- `VMCREDMGMT` / `VMACCESSMGMT` (with "NoneType" errors) → marked `closed_incomplete`
- `DISKCLEANUP` → marked `closed_incomplete`

---

## Understanding tblEventPendingActivity

### Table Schema (Key Columns)

| Column | Description |
|--------|-------------|
| `ActivityId` | Unique identifier for the activity (also used as orchestration instance ID) |
| `ActivityName` | Type of activity (e.g., RBAC, INSTANCESTATUS, VMPROVISION) |
| `SnowId` | ServiceNow ticket reference |
| `Status` | Current status of the pending activity |
| `RetryCount` | Number of times execution has been attempted |
| `CreatedDate` | When the activity was first queued |
| `LastModifiedDate` | When status was last updated |

### Status Values

| Status | Meaning |
|--------|---------|
| `New` / `Queued` | Awaiting first execution |
| `InProgress` | Currently being processed by an orchestration |
| `Retry` | Failed and queued for re-execution |
| `Success` | Completed (will be moved to tblEventCompletedActivity) |
| `Failed` | Permanently failed (will be moved to tblEventCompletedActivity) |

---

## Why a Request Gets Stuck in Retry Loop

A request keeps retrying when:

1. **The underlying issue is not transient** — e.g., missing permissions, invalid resource, bad payload
2. **The activity has no retry limit** — StatusMonitor always marks failures as "Retry" (except special cases above)
3. **External dependency is persistently down** — Key Vault, SQL, target Azure resource
4. **Code bug** — Logic error in the catalog implementation that always throws

---

## Step-by-Step Debugging Guide

### Step 1: Identify the Failing Request

Query `tblEventPendingActivity` for stuck requests:

```sql
SELECT 
    ActivityId,
    ActivityName,
    SnowId,
    Status,
    RetryCount,
    CreatedDate,
    LastModifiedDate
FROM tblEventPendingActivity
WHERE Status = 'Retry'
ORDER BY LastModifiedDate DESC;
```

**Red flags:**
- `RetryCount` > 3 (has been retried multiple times)
- `CreatedDate` is significantly older than `LastModifiedDate` (stuck for a long time)

### Step 2: Check the Error in tblActivityInfo

```sql
SELECT 
    ActivityId,
    ActivityName,
    ErrorMessage,
    StackTrace,
    CreatedDate
FROM tblActivityInfo
WHERE ActivityId = '<YOUR_ACTIVITY_ID>'
ORDER BY CreatedDate DESC;
```

This gives you the **exact exception** that the activity function threw. The error is logged in `az_activity_blueprint.py` before re-raising.

### Step 3: Check tblEventMaster for Full Context

```sql
SELECT 
    ActivityId,
    ActivityName,
    SnowId,
    SnowType,
    StatusCode,
    Payload,
    CreatedDate
FROM tblEventMaster
WHERE ActivityId = '<YOUR_ACTIVITY_ID>';
```

The `Payload` column contains the full JSON payload sent to the activity — this is critical for understanding what data the activity was working with.

### Step 4: Trace in Application Insights

1. Go to **Azure Portal** → **Application Insights** for the function app
2. Navigate to **Transaction Search** or **Failures**
3. Search by `ActivityId` using the query:

```kusto
traces
| where message contains "<YOUR_ACTIVITY_ID>"
| order by timestamp desc
| take 50
```

Or for exceptions:

```kusto
exceptions
| where customDimensions contains "<YOUR_ACTIVITY_ID>"
| order by timestamp desc
| take 20
```

### Step 5: Use Durable Functions Monitor (see next section)

---

## Using Durable Functions Monitor

The **Durable Functions Monitor** is the most powerful tool for debugging orchestration failures. Access it via:

- **VS Code Extension**: Install "Durable Functions Monitor" extension
- **Azure Portal**: Function App → Durable Functions → Monitor
- **Standalone tool**: https://github.com/microsoft/DurableFunctionsMonitor

### Connecting to Durable Functions Monitor

1. Open VS Code with the Durable Functions Monitor extension installed
2. Connect to the **Azure Storage account** used by the function app (check `AzureWebJobsStorage` in `local.settings.json` or Application Settings in portal)
3. The task hub name is defined in `host.json` (default: from the function app name)

### Finding Your Failed Orchestration

1. **Search by Instance ID**: The orchestration instance ID = `ActivityId` from `tblEventPendingActivity`
2. **Filter by status**: Set filter to `Failed` status
3. **Filter by time**: Use the creation date from `tblEventPendingActivity`

### What to Look For in Durable Functions Monitor

#### A. Orchestration Overview Tab

| Field | What it tells you |
|-------|-------------------|
| **Instance ID** | Should match your ActivityId |
| **Name** | `orchestrate_activity` (top-level) |
| **Runtime Status** | `Failed`, `Completed`, `Running`, `Terminated` |
| **Created Time** | When the orchestration was started |
| **Last Updated** | When it last changed state |
| **Input** | The payload passed to the orchestration |
| **Output** | Result or error message |
| **Custom Status** | Any custom status set during execution |

#### B. Execution History Tab (MOST IMPORTANT)

This shows the **step-by-step execution** of the orchestration:

```
1. OrchestratorStarted
2. TaskScheduled (activity: <ActivityName>)
3. TaskCompleted / TaskFailed  ← LOOK HERE
4. OrchestratorCompleted / ExecutionTerminated
```

**For a failed orchestration, look at:**

- `TaskFailed` event → expand it to see:
  - **Reason**: The exception type
  - **Details**: Full stack trace and error message

#### C. Sub-Orchestrations (for VMPROVISION, HOURSOFOPERATIONINSTANCE)

If the top-level orchestration fans out to sub-orchestrators:
1. Find the parent orchestration (`orchestrate_activity`)
2. In the history, look for `SubOrchestrationInstanceCreated` events
3. Click through to the sub-orchestration to see its individual failure

#### D. Sequence Diagram View

Durable Functions Monitor can render a **sequence diagram** showing:
- Which activities were called in what order
- Where the failure occurred in the chain
- Timing between steps

### Interpreting Common Orchestration Failures

| Runtime Status | Meaning | Action |
|---------------|---------|--------|
| `Failed` | Activity threw an unhandled exception | Check TaskFailed details |
| `Terminated` | Manually terminated or system kill | Check if StatusMonitor terminated it |
| `Suspended` | Paused (rare) | Check for external signals |
| `Running` (but old) | Stuck waiting for an event or sub-orchestration | Check for deadlocks |

### Purging a Stuck Orchestration

From Durable Functions Monitor:
1. Select the orchestration instance
2. Click **Purge** to remove it from the task hub
3. This allows the StatusMonitor to create a new instance on next cycle

Or via Azure Functions Core Tools:
```bash
func durable purge-history --created-before <datetime>
```

Or programmatically (used in `request_handler`):
```python
client.purge_instance_history(activity_id)
```

---

## Common Failure Scenarios

### 1. Authentication / Token Failure

**Symptoms:**
- Error: `ClientAuthenticationError` or `DefaultAzureCredentialError`
- All activities failing simultaneously

**Root Cause:** Service principal secret expired, Key Vault access revoked, or managed identity misconfigured.

**Resolution:**
- Check Key Vault secret expiry
- Verify service principal credentials in Key Vault
- Check `KEYVAULT_URI` and `DB_KEYVAULT_SECRET` env vars

---

### 2. Resource Not Found

**Symptoms:**
- Error: `ResourceNotFoundError` or HTTP 404
- Specific activity type failing

**Root Cause:** Target Azure resource was deleted/moved, subscription changed, or resource name in payload is incorrect.

**Resolution:**
- Check the `Payload` in `tblEventMaster` for the resource identifiers
- Verify the resource exists in Azure
- Mark as permanently failed if resource no longer exists

---

### 3. Insufficient Permissions

**Symptoms:**
- Error: `AuthorizationError` or HTTP 403
- Specific subscription/resource group activities failing

**Root Cause:** Service principal lost RBAC role, policy blocking, or scope changed.

**Resolution:**
- Check SPN role assignments on target scope
- Verify no Azure Policy denying the operation

---

### 4. Database Connection Failure

**Symptoms:**
- Error: `pyodbc.OperationalError` or connection timeout
- Multiple different activities failing

**Root Cause:** SQL Server firewall, password rotation, or server maintenance.

**Resolution:**
- Check SQL Server firewall rules (function app outbound IPs)
- Verify DB password in Key Vault matches actual SQL login
- Check SQL Server availability

---

### 5. Invalid Payload / NoneType Errors

**Symptoms:**
- Error: `AttributeError: 'NoneType' object has no attribute...`
- Specific request failing repeatedly

**Root Cause:** ServiceNow sent malformed payload, missing required fields.

**Resolution:**
- Check `Payload` in `tblEventMaster`
- Verify all required fields are present
- May need to manually close the ServiceNow ticket and mark as failed

---

### 6. Timeout / Long-Running Operations

**Symptoms:**
- Orchestration shows `Running` for extended period
- Activity never completes

**Root Cause:** Azure operation (e.g., VM provisioning) taking too long, or external API hanging.

**Resolution:**
- Check Azure Activity Log for the target resource
- Look for stuck ARM deployments
- Consider terminating and retrying

---

## Database Queries for Investigation

### Find All Retrying Activities (Stuck)

```sql
SELECT 
    ep.ActivityId,
    ep.ActivityName,
    ep.SnowId,
    ep.RetryCount,
    ep.CreatedDate,
    ep.LastModifiedDate,
    DATEDIFF(HOUR, ep.CreatedDate, GETUTCDATE()) AS HoursStuck,
    ai.ErrorMessage
FROM tblEventPendingActivity ep
LEFT JOIN (
    SELECT ActivityId, ErrorMessage, 
           ROW_NUMBER() OVER (PARTITION BY ActivityId ORDER BY CreatedDate DESC) AS rn
    FROM tblActivityInfo
) ai ON ep.ActivityId = ai.ActivityId AND ai.rn = 1
WHERE ep.Status = 'Retry'
ORDER BY ep.RetryCount DESC;
```

### Get Full Error History for an Activity

```sql
SELECT 
    ActivityId,
    ErrorMessage,
    StackTrace,
    CreatedDate
FROM tblActivityInfo
WHERE ActivityId = '<ACTIVITY_ID>'
ORDER BY CreatedDate DESC;
```

### Check if Orchestration Exists in Durable Task Hub

```sql
-- Azure Storage Tables (if using Azure Table Storage backend)
-- Check the "Instances" table in the storage account
-- Or use Durable Functions Monitor UI
```

### Find Activities Stuck Longer Than 24 Hours

```sql
SELECT *
FROM tblEventPendingActivity
WHERE Status = 'Retry'
  AND DATEDIFF(HOUR, CreatedDate, GETUTCDATE()) > 24
ORDER BY CreatedDate ASC;
```

### Cross-Reference with Event Master

```sql
SELECT 
    em.ActivityId,
    em.ActivityName,
    em.SnowId,
    em.SnowType,
    em.Payload,
    ep.Status AS PendingStatus,
    ep.RetryCount
FROM tblEventMaster em
JOIN tblEventPendingActivity ep ON em.ActivityId = ep.ActivityId
WHERE ep.Status = 'Retry'
  AND ep.RetryCount > 3;
```

---

## Resolution Procedures

### Option A: Fix the Root Cause and Let Retry Succeed

1. Identify the error from `tblActivityInfo`
2. Fix the underlying issue (permissions, resource, config)
3. Wait for next StatusMonitor cycle (5 minutes)
4. The retry will automatically pick up and succeed
5. Verify in `tblEventCompletedActivity` with `closed_complete`

### Option B: Manually Mark as Failed (Permanently)

If the request can never succeed (e.g., resource deleted):

```sql
-- 1. Insert into completed activity as failed
INSERT INTO tblEventCompletedActivity (ActivityId, ActivityName, SnowId, Status, CompletedDate)
SELECT ActivityId, ActivityName, SnowId, 'Failed', GETUTCDATE()
FROM tblEventPendingActivity
WHERE ActivityId = '<ACTIVITY_ID>';

-- 2. Remove from pending
DELETE FROM tblEventPendingActivity
WHERE ActivityId = '<ACTIVITY_ID>';

-- 3. Update master status
UPDATE tblEventMaster
SET StatusCode = 'closed_incomplete'
WHERE ActivityId = '<ACTIVITY_ID>';
```

> ⚠️ **Important**: Also close the ServiceNow ticket manually with appropriate notes.

### Option C: Purge Orchestration and Re-trigger

1. Purge the failed orchestration via Durable Functions Monitor
2. Update `tblEventPendingActivity` status back to `New`/`Queued`
3. The StatusMonitor will pick it up and start a fresh orchestration

### Option D: Terminate via Durable Functions API

```python
# Using Azure Functions Core Tools
func durable terminate --id <ACTIVITY_ID> --reason "Manual termination - stuck in retry"
```

Or from Durable Functions Monitor UI: Select instance → Terminate.

---

## Debugging Checklist

Use this checklist when investigating a failed request:

- [ ] **Identify the ActivityId** from `tblEventPendingActivity`
- [ ] **Get the error** from `tblActivityInfo`
- [ ] **Get the payload** from `tblEventMaster`
- [ ] **Check Application Insights** for detailed traces
- [ ] **Open Durable Functions Monitor** and search by Instance ID (= ActivityId)
- [ ] **Review execution history** in Durable Functions Monitor
- [ ] **Identify root cause** category (auth, resource, permissions, payload, timeout)
- [ ] **Apply resolution** (fix & retry, mark failed, or purge)
- [ ] **Verify resolution** — confirm record moved to `tblEventCompletedActivity`
- [ ] **Close ServiceNow ticket** if manually resolved

---

## Tips & Best Practices

1. **Always check `tblActivityInfo` first** — it has the exact exception before going to App Insights
2. **The ActivityId IS the orchestration Instance ID** — use it directly in Durable Functions Monitor
3. **StatusMonitor runs every 5 minutes** — after fixing an issue, wait at least 5 min for auto-retry
4. **Fan-out orchestrations** (VMPROVISION, HOURSOFOPERATIONINSTANCE) have sub-orchestration IDs — check the parent first, then drill into children
5. **Deduplication in request_handler** — if an orchestration is already Running/Pending, a new message for the same ActivityId will be skipped. Purge the old one first if you need a fresh start.
6. **Check the ServiceBus dead-letter queue** — messages that fail initial processing (before orchestration starts) end up there instead of `tblEventPendingActivity`
