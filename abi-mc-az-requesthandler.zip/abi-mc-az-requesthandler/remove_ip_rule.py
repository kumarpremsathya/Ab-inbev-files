"""Remove the 0.0.0.0/0 IP rule from the test Key Vault."""
import os

os.environ["AZURE_TENANT_ID"] = "1b58d4b5-b54d-4750-ab29-b6aa6dfdd73a"
os.environ["AZURE_CLIENT_ID"] = "7268919e-22ab-407b-ac77-24253e78f360"
os.environ["AZURE_CLIENT_SECRET"] = os.environ.get("TEST_SP_SECRET", "")

if not os.environ["AZURE_CLIENT_SECRET"]:
    print("ERROR: Set TEST_SP_SECRET env var first:")
    print('  $env:TEST_SP_SECRET = "your-sp-password"')
    exit(1)

from azure.identity import ClientSecretCredential
from azure.mgmt.keyvault import KeyVaultManagementClient

SUBSCRIPTION_ID = "8d62fea6-3260-4070-a3b7-d87a6985fa4b"
RESOURCE_GROUP = "test-kvmgmt-rg"
KEY_VAULT_NAME = "test-kvmgmt-brewmation"

credential = ClientSecretCredential(
    tenant_id=os.environ["AZURE_TENANT_ID"],
    client_id=os.environ["AZURE_CLIENT_ID"],
    client_secret=os.environ["AZURE_CLIENT_SECRET"],
)
kv_mgmt_client = KeyVaultManagementClient(credential, SUBSCRIPTION_ID)

# Get current vault
vault = kv_mgmt_client.vaults.get(RESOURCE_GROUP, KEY_VAULT_NAME)
current_rules = [r.value for r in (vault.properties.network_acls.ip_rules or [])]
print(f"Current IP rules: {current_rules}")

# Remove 0.0.0.0/0
ip_rules = [r for r in vault.properties.network_acls.ip_rules if r.value != "0.0.0.0/0"]
kv_mgmt_client.vaults.update(
    RESOURCE_GROUP,
    KEY_VAULT_NAME,
    {"properties": {"network_acls": {"ip_rules": [{"value": r.value} for r in ip_rules]}}}
)

# Verify
vault = kv_mgmt_client.vaults.get(RESOURCE_GROUP, KEY_VAULT_NAME)
current_rules = [r.value for r in (vault.properties.network_acls.ip_rules or [])]
print(f"IP rules after removal: {current_rules}")
print("Done - 0.0.0.0/0 removed.")
