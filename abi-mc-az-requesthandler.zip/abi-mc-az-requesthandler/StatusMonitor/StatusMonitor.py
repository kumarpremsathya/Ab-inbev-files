from DAL.DbActivityManager import DbActivityManager
from datetime import datetime,timezone,timedelta
import azure.durable_functions as df
import json,logging,aiohttp,asyncio
from typing import List, Any, Dict
from azure.durable_functions.models.OrchestrationRuntimeStatus import OrchestrationRuntimeStatus
from azure.durable_functions.models.DurableOrchestrationStatus import DurableOrchestrationStatus
from azure.durable_functions.models.RpcManagementOptions import RpcManagementOptions
from azure.durable_functions.models.utils.http_utils import _get_session, _handle_request_error

class StatusMonitor:
    def __init__(self,client: df.DurableOrchestrationClient) -> None:
        self.client = client
        self.db_activity_manager = DbActivityManager()
        self.pending_activity = []

    async def update_status(self):
        self.pending_activity = self.db_activity_manager.get_pending_activity_handler()
        if not self.pending_activity:
            return
        date = min(self.pending_activity,key=lambda x:x.RetryAttemptedAt).RetryAttemptedAt
        results = await self.get_status_by(created_time_from=date-timedelta(hours=1))
        if not results:
            return
        for activity in self.pending_activity:
            for res in results:
                input = json.loads(res.to_json()["input"])
                output = res.to_json()["output"]
                if activity.EventId.lower() == input["EventId"].lower() and res.name == 'orchestrate_activity':
                    logging.info(f"Activity: {activity.EventId} - {activity.ActivityName} - {res.instance_id} - {res.runtime_status} - {input['EventId']} - {input['ActivityName']}")
                    if input["ActivityName"] in ["DECOMM","WINDOWSVMUPGRADE"] and res.runtime_status == df.OrchestrationRuntimeStatus.Failed:
                        self.db_activity_manager.db_update_activity(input["TableName"],res.instance_id,"Failed","Aborted with error",datetime.now(timezone.utc))
                    if input["ActivityName"] in ["VMCREDMGMT","VMACCESSMGMT"] and res.runtime_status == df.OrchestrationRuntimeStatus.Failed and any(error in output for error in ["VM Agent is not available","VM Agent is not running","Error while VM Cred Reset","Error while adding VM Access","Timedout"]):
                        self.db_activity_manager.db_update_activity(input["TableName"],res.instance_id,"Failed","Aborted with error",datetime.now(timezone.utc))
                    elif res.runtime_status == df.OrchestrationRuntimeStatus.Completed:
                        self.db_activity_manager.db_update_activity(input["TableName"],res.instance_id,"Success","Implemented Successfully",datetime.now(timezone.utc))
                    elif res.runtime_status == df.OrchestrationRuntimeStatus.Failed and input["ActivityName"] in ["DISKCLEANUP"]:
                        self.db_activity_manager.db_update_activity(input["TableName"],res.instance_id,"Failed","Failed with Error",datetime.now(timezone.utc))
                    elif res.runtime_status == df.OrchestrationRuntimeStatus.Failed:
                        self.db_activity_manager.db_update_activity(input["TableName"],res.instance_id,"Retry","Failed with Error",datetime.now(timezone.utc))
                    elif res.runtime_status == df.OrchestrationRuntimeStatus.Terminated:
                        self.db_activity_manager.db_update_activity(input["TableName"],res.instance_id,"Failed","Failed with Error",datetime.now(timezone.utc))
    
    async def update_status_hoursofoperationinstance(self):
        results = await self.get_status_by(created_time_from=datetime.now(timezone.utc)-timedelta(hours=1))
        for res in results:
            if res.name != "hoursofoperationinstance_orchestrator":
                continue
            input_data = json.loads(res.to_json()["input"])
            if res.runtime_status == df.OrchestrationRuntimeStatus.Completed:
                self.db_activity_manager.insert_hoursofoperationinstance_activity(input_data, "Success")
            elif res.runtime_status == df.OrchestrationRuntimeStatus.Failed:
                self.db_activity_manager.insert_hoursofoperationinstance_activity(input_data, "Failed")
            elif res.runtime_status == df.OrchestrationRuntimeStatus.Running:
                self.db_activity_manager.insert_hoursofoperationinstance_activity(input_data, "In-Progress")

    async def get_status_by(self, created_time_from: datetime = None,
                            created_time_to: datetime = None,
                            runtime_status: List[OrchestrationRuntimeStatus] = None) \
            -> List[DurableOrchestrationStatus]:
        options = RpcManagementOptions(created_time_from=created_time_from,
                                       created_time_to=created_time_to,
                                       runtime_status=runtime_status)
        request_url = options.to_url(self.client._orchestration_bindings.rpc_base_url)
        all_statuses: List[DurableOrchestrationStatus] = []

        continuation_token = None
        while True:
            headers = {}
            if continuation_token:
                headers['x-ms-continuation-token'] = continuation_token
            response = await self.get_async_request(request_url, headers=headers)
            switch_statement = {
                200: lambda: None, 
            }
            has_error_message = switch_statement.get(
                response[0],
                lambda: f"The operation failed with an unexpected status code {response[0]}")
            error_message = has_error_message()
            if error_message:
                raise Exception(error_message)
            else:
                statuses: List[Any] = response[1]
                all_statuses.extend([DurableOrchestrationStatus.from_json(o) for o in statuses])
                continuation_token = response[2].get('x-ms-continuation-token')
                if not continuation_token:
                    break
        return all_statuses
    
    async def get_async_request(self,url: str,
                                function_invocation_id: str = None,headers: Dict[Any, Any] = None) -> List[Any]:
        session = await _get_session()
        headers = headers or {}
        if function_invocation_id:
            headers["X-Azure-Functions-InvocationId"] = function_invocation_id
        try:
            async with session.get(url, headers=headers) as response:
                data = await response.json(content_type=None)
                if data is None:
                    data = ""
                return [response.status, data, response.headers]
        except (aiohttp.ClientError, asyncio.TimeoutError):
            await _handle_request_error()
            raise