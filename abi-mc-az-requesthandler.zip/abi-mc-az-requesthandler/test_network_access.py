"""Test _ensure_network_access() against personal Azure account."""
import os, json, logging
from datetime import datetime, timezone

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logging.getLogger("azure").setLevel(logging.WARNING)
logging.getLogger("msrest").setLevel(logging.WARNING)



# Personal Azure account credentials
os.environ["AZURE_TENANT_ID"] = "1b58d4b5-b54d-4750-ab29-b6aa6dfdd73a"
os.environ["AZURE_CLIENT_ID"] = "7268919e-22ab-407b-ac77-24253e78f360"
os.environ["AZURE_CLIENT_SECRET"] = os.environ.get("TEST_SP_SECRET", "")

if not os.environ["AZURE_CLIENT_SECRET"]:
    print("ERROR: Set TEST_SP_SECRET env var first:")
    print('  $env:TEST_SP_SECRET = "your-sp-password"')
    exit(1)

# Still need KEYVAULT_URI for the AES key (from org account) — not used in this test
os.environ.setdefault("KEYVAULT_URI", "https://puppetapi-secrets.vault.azure.net/")
os.environ.setdefault("Environment", "local")

from shared_code.keyvault_client import KeyVaultClient
from azure.core.exceptions import HttpResponseError
from azure.keyvault.secrets import SecretClient

SUBSCRIPTION_ID = "8d62fea6-3260-4070-a3b7-d87a6985fa4b"
RESOURCE_GROUP = "test-kvmgmt-rg"
KEY_VAULT_NAME = "test-kvmgmt-brewmation"

# Build a minimal KV mgmt client directly (skip full KeyVaultMgmt init which needs org KV)
from azure.identity import ClientSecretCredential
from azure.mgmt.keyvault import KeyVaultManagementClient

credential = ClientSecretCredential(
    tenant_id=os.environ["AZURE_TENANT_ID"],
    client_id=os.environ["AZURE_CLIENT_ID"],
    client_secret=os.environ["AZURE_CLIENT_SECRET"],
)
kv_mgmt_client = KeyVaultManagementClient(credential, SUBSCRIPTION_ID)


def test_ensure_network_access():
    print("\n" + "="*50)
    print("  Testing _ensure_network_access flow")
    print("="*50)

    # Step 1: Get vault and confirm it's private
    print("\n[1] Getting vault...")
    vault = kv_mgmt_client.vaults.get(RESOURCE_GROUP, KEY_VAULT_NAME)
    network_acls = vault.properties.network_acls
    default_action = network_acls.default_action if network_acls else "Allow"
    print(f"    defaultAction: {default_action}")
    assert default_action == "Deny", "Vault should have Deny as default action"
    print("    ✓ Vault is private (defaultAction=Deny)")

    # Step 2: Add IP rule (simulates _add_ip_rule)
    print("\n[2] Adding IP rule 0.0.0.0/0...")
    ip_rules = list(network_acls.ip_rules) if network_acls and network_acls.ip_rules else []
    ip_rules.append({"value": "0.0.0.0/0"})
    kv_mgmt_client.vaults.update(
        RESOURCE_GROUP,
        KEY_VAULT_NAME,
        {"properties": {"network_acls": {"ip_rules": ip_rules}}}
    )
    print("    ✓ IP rule added")

    # Step 3: Verify IP rule was added
    print("\n[3] Verifying IP rule...")
    vault = kv_mgmt_client.vaults.get(RESOURCE_GROUP, KEY_VAULT_NAME)
    current_rules = [r.value for r in (vault.properties.network_acls.ip_rules or [])]
    print(f"    Current IP rules: {current_rules}")
    assert "0.0.0.0/0" in current_rules, "IP rule should be present"
    print("    ✓ IP rule verified")

    # Step 4: Remove IP rule (simulates _remove_ip_rule)
    print("\n[4] Removing IP rule 0.0.0.0/0...")
    ip_rules = [r for r in vault.properties.network_acls.ip_rules if r.value != "0.0.0.0/0"]
    kv_mgmt_client.vaults.update(
        RESOURCE_GROUP,
        KEY_VAULT_NAME,
        {"properties": {"network_acls": {"ip_rules": [{"value": r.value} for r in ip_rules]}}}
    )
    print("    ✓ IP rule removed")

    # Step 5: Verify cleanup
    print("\n[5] Verifying cleanup...")
    vault = kv_mgmt_client.vaults.get(RESOURCE_GROUP, KEY_VAULT_NAME)
    current_rules = [r.value for r in (vault.properties.network_acls.ip_rules or [])]
    print(f"    Current IP rules: {current_rules}")
    assert "0.0.0.0/0" not in current_rules, "IP rule should be removed"
    print("    ✓ Cleanup verified")

    print("\n" + "="*50)
    print("  ALL TESTS PASSED")
    print("="*50)


def test_set_secret():
    """Mirrors the set_secret data-plane write in _create_or_update_secret()"""
    print("\n" + "="*50)
    print("  Testing set_secret (data-plane write)")
    print("="*50)

    vault_url = f"https://{KEY_VAULT_NAME}.vault.azure.net"
    secret_name = "final-test-secret"
    secret_value = "final-test-value"

    # Step 1: Open vault (add IP rule)
    print("\n[1] Opening vault (adding IP rule)...")
    vault = kv_mgmt_client.vaults.get(RESOURCE_GROUP, KEY_VAULT_NAME)
    network_acls = vault.properties.network_acls
    ip_rules = list(network_acls.ip_rules) if network_acls and network_acls.ip_rules else []
    ip_rules.append({"value": "0.0.0.0/0"})
    kv_mgmt_client.vaults.update(
        RESOURCE_GROUP, KEY_VAULT_NAME,
        {"properties": {"network_acls": {"ip_rules": ip_rules}}}
    )
    print("    ✓ IP rule added")

    try:
        import time
        print("    Waiting 10s for network rule to propagate...")
        time.sleep(10)

        # Step 2: Set secret (mirrors client.set_secret in _create_or_update_secret)
        print(f"\n[2] Setting secret '{secret_name}'...")
        secret_client = SecretClient(vault_url=vault_url, credential=credential)
        secret = secret_client.set_secret(
            name=secret_name,
            value=secret_value,
            content_type="text/plain",
            expires_on=datetime(2027, 8, 14, tzinfo=timezone.utc),
            tags={"final": "test", "ref": "brewmation-test"}
        )
        print(f"    Secret ID: {secret.id}")
        print(f"    Content type: {secret.properties.content_type}")
        print(f"    Expires on: {secret.properties.expires_on}")
        print(f"    Tags: {secret.properties.tags}")
        print("    ✓ Secret created")

        # Step 3: Read back and verify
        print(f"\n[3] Reading secret back...")
        read_secret = secret_client.get_secret(secret_name)
        assert read_secret.value == secret_value, f"Expected '{secret_value}', got '{read_secret.value}'"
        print(f"    Value matches: ✓")

        # # Step 4: Delete secret (mirrors _delete_secret)
        # print(f"\n[4] Deleting secret '{secret_name}'...")
        # poller = secret_client.begin_delete_secret(secret_name)
        # poller.wait()
        # print("    ✓ Secret deleted")

    finally:
        # Step 5: Close vault (remove IP rule)
        # print(f"\n[5] Closing vault (removing IP rule)...")
        # vault = kv_mgmt_client.vaults.get(RESOURCE_GROUP, KEY_VAULT_NAME)
        # ip_rules = [r for r in (vault.properties.network_acls.ip_rules or []) if r.value != "0.0.0.0/0"]
        # kv_mgmt_client.vaults.update(
        #     RESOURCE_GROUP, KEY_VAULT_NAME,
        #     {"properties": {"network_acls": {"ip_rules": [{"value": r.value} for r in ip_rules]}}}
        # )
        # print("    ✓ IP rule removed")
        pass

    print("\n" + "="*50)
    print("  SET_SECRET TEST PASSED")
    print("="*50)


if __name__ == "__main__":
    try:
        test_ensure_network_access()
        test_set_secret()
    except Exception as e:
        print(f"\n  FAILED: {e}")
        import traceback
        traceback.print_exc()
