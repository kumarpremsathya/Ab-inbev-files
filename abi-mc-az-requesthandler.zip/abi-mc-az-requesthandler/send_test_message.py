# from azure.servicebus import ServiceBusClient, ServiceBusMessage
# import json

# connection_str = "Endpoint=sb://puppetservicebustest.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=o0X7Xn+fV3wi2ho4KTBMd4cJgCG6dETrK+ASbKmtuJ4="
# topic_name = "request_handler"

# payload = {
#     "AccountId": "0fc06624-e5d6-469a-b4c0-3c73a0979e5a",
#     "AccountName": "Defender for Containers provisioning ARC k8s Enabled",
#     "Action": "WORKDAY",
#     "ActivityId": "DF4580CD-215E-46CC-A128-D486ECDA6925",
#     "ActivityName": "INACTIVERBAC",
#     "Approver": "amith.ajith@ab-inbev.com",
#     "EventId": "B814C65E-6DCB-4F56-B6BB-CB11FCF283B5",
#     "RoleAssignmentsId": "/subscriptions/1d3c55b6-f2e9-469b-8e3b-f2ed41ef0887/providers/Microsoft.Authorization/RoleAssignments/fa942fc8-66d5-4401-c8c4-15e3b281c3c6",
#     "RoleName": "Contributor",
#     "ScopeType": "Subscription",
#     "Status": "In-Progress",
#     "SubscriptionName": "ABI GHQ Shared Non-Prod",
#     "TableName": "tblActivityRbacInventoryReview",
#     "UniqueId": "/subscriptions/1d3c55b6-f2e9-469b-8e3b-f2ed41ef0887/providers/Microsoft.Authorization/RoleAssignments/fa942fc8-66d5-4401-c8c4-15e3b281c3c6",
#     "Zone": "GHQ"
# }

# with ServiceBusClient.from_connection_string(connection_str) as client:
#     with client.get_topic_sender(topic_name) as sender:
#         msg = ServiceBusMessage(json.dumps(payload))
#         sender.send_messages(msg)
#         print(f"Message sent! ActivityId: {payload['ActivityId']}")


from azure.servicebus import ServiceBusClient, ServiceBusMessage
import json, uuid

connection_str = "Endpoint=sb://puppetservicebustest.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=o0X7Xn+fV3wi2ho4KTBMd4cJgCG6dETrK+ASbKmtuJ4="
topic_name = "request_handler"

payload = {
  "ActivityId": "40D21B44-2B59-4206-9CAD-8864DB484845",
  "EventId": "26476B60-390C-488C-A5D7-FC7C01BFFAF2",
  "SubscriptionId": "73f88e6b-3a35-4612-b550-555157e7059f",
  "SubscriptionName": "ABI GLOBAL NON-PROD",
  "ResourceGroupName": "PUPPET-STAGE-RG-GB-TEST",
  "KeyVaultName": "brewmation-zero",
  "SecretName": "puppet-test-123",
  "SecretValue": "9J9q9waE6LpC",
  "IV": "dxKOmx3Nr+cZxvGx",
  "Tag": "WMVSazW1Vjfn9Zvg6WFoLg==",
  "ContentType": "Password",
  "ExpiresOn": "2027-08-14",
  "Tags": "{}",
  "Action": "Create",
  "Justification": "Create Secret",
  "Zone": "GHQ",
  "Cloud": "Azure",
  "Status": "In-Progress",
  "Comments": "Pending key vault secret operation",
  "ActivityName": "KEYVAULTMGMT",
  "TableName": "tblActivityAzKeyVaultMgmt"
}


with ServiceBusClient.from_connection_string(connection_str) as client:
    with client.get_topic_sender(topic_name) as sender:
        msg = ServiceBusMessage(json.dumps(payload))
        sender.send_messages(msg)
        print(f"Message sent! ActivityId: {payload['ActivityId']}")