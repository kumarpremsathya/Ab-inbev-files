"""Test _create_private_endpoint() flow against personal Azure account.

Uses PrivateEndpointHelper directly (same as KeyVaultMgmt._create_private_endpoint),
with NetworkMgmtClient and DnsZoneHelper patched to use test credentials.

Prerequisites in your personal Azure account (test-kvmgmt-rg):
  1. VNet + subnet with privateEndpointNetworkPolicies disabled
  2. Key Vault with a virtual_network_rules entry pointing to that subnet
  3. Private DNS zone: privatelink.vaultcore.azure.net

Setup commands (run once):
  az network vnet create -g test-kvmgmt-rg -n test-kvmgmt-vnet --address-prefix 10.0.0.0/16 --subnet-name test-kvmgmt-subnet --subnet-prefix 10.0.0.0/24
  az network vnet subnet update -g test-kvmgmt-rg --vnet-name test-kvmgmt-vnet -n test-kvmgmt-subnet --disable-private-endpoint-network-policies true --service-endpoints Microsoft.KeyVault
  az keyvault network-rule add --name test-kvmgmt-brewmation -g test-kvmgmt-rg --subnet test-kvmgmt-subnet --vnet-name test-kvmgmt-vnet
  az network private-dns zone create -g test-kvmgmt-rg -n privatelink.vaultcore.azure.net
"""
import os, logging
from unittest.mock import patch

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logging.getLogger("azure").setLevel(logging.WARNING)
logging.getLogger("msrest").setLevel(logging.WARNING)

# Personal Azure account credentials
os.environ["AZURE_TENANT_ID"] = "1b58d4b5-b54d-4750-ab29-b6aa6dfdd73a"
os.environ["AZURE_CLIENT_ID"] = "7268919e-22ab-407b-ac77-24253e78f360"
os.environ["AZURE_CLIENT_SECRET"] = os.environ.get("TEST_SP_SECRET", "")

if not os.environ["AZURE_CLIENT_SECRET"]:
    print("ERROR: Set TEST_SP_SECRET env var first:")
    print('  $env:TEST_SP_SECRET = "your-sp-password"')
    exit(1)

from azure.identity import ClientSecretCredential
from azure.mgmt.keyvault import KeyVaultManagementClient
from azure.mgmt.network import NetworkManagementClient
from azure.mgmt.privatedns import PrivateDnsManagementClient
from shared_code.private_endpoint_helper import PrivateEndpointHelper

SUBSCRIPTION_ID = "8d62fea6-3260-4070-a3b7-d87a6985fa4b"
RESOURCE_GROUP = "test-kvmgmt-rg"
KEY_VAULT_NAME = "test-kvmgmt-brewmation"
PE_NAME = f"{KEY_VAULT_NAME}-pe-brewmation"
DNS_ZONE_NAME = "privatelink.vaultcore.azure.net"
ZONE = "global"

credential = ClientSecretCredential(
    tenant_id=os.environ["AZURE_TENANT_ID"],
    client_id=os.environ["AZURE_CLIENT_ID"],
    client_secret=os.environ["AZURE_CLIENT_SECRET"],
)
kv_mgmt_client = KeyVaultManagementClient(credential, SUBSCRIPTION_ID)
network_client = NetworkManagementClient(credential, SUBSCRIPTION_ID)
dns_client = PrivateDnsManagementClient(credential, SUBSCRIPTION_ID)


def _mock_get_network_mgmt_client(self, subscription_id, cloud):
    return network_client

def _mock_get_dns_client_for_zone(subscription_id, zone, cloud):
    return dns_client, RESOURCE_GROUP


def test_create_private_endpoint():
    """Mirrors KeyVaultMgmt._create_private_endpoint() and _delete_private_endpoint()"""
    print("\n" + "=" * 60)
    print("  Testing _create_private_endpoint flow")
    print("=" * 60)

    # Step 1: _get_vault()
    print("\n[1] Getting vault (mirrors self._get_vault())...")
    vault = kv_mgmt_client.vaults.get(RESOURCE_GROUP, KEY_VAULT_NAME)
    print(f"    Vault ID: {vault.id}")
    print(f"    Location: {vault.location}")

    # Step 2: _get_subnet_id(vault)
    print("\n[2] Getting subnet from vault network rules (mirrors self._get_subnet_id())...")
    network_acls = vault.properties.network_acls
    if not network_acls or not network_acls.virtual_network_rules:
        print("    ERROR: No virtual_network_rules on vault.")
        print("    Run: az keyvault network-rule add --name test-kvmgmt-brewmation -g test-kvmgmt-rg --subnet test-kvmgmt-subnet --vnet-name test-kvmgmt-vnet")
        exit(1)
    subnet_id = network_acls.virtual_network_rules[0].id
    print(f"    Subnet ID: {subnet_id}")
    print("    ✓ Subnet found from vault network rules")

    # Step 3: PrivateEndpointHelper.create_private_endpoint() — same as production code
    print(f"\n[3] Creating PE via PrivateEndpointHelper (same as production)...")
    with patch.object(PrivateEndpointHelper, '__init__', lambda self, *a, **kw: None):
        pe_helper = PrivateEndpointHelper(SUBSCRIPTION_ID, ZONE, "AzurePublicCloud")
        pe_helper.subscription_id = SUBSCRIPTION_ID
        pe_helper.zone = ZONE
        pe_helper.cloud = "AzurePublicCloud"
        pe_helper.network_client = network_client

    with patch("shared_code.private_endpoint_helper.DnsZoneHelper.get_dns_client_for_zone", _mock_get_dns_client_for_zone):
        pe = pe_helper.create_private_endpoint(
            resource_group_name=RESOURCE_GROUP,
            resource_id=vault.id,
            resource_name=KEY_VAULT_NAME,
            location=vault.location,
            subnet_id=subnet_id,
            group_ids=["vault"],
            dns_zone_name=DNS_ZONE_NAME,
            private_endpoint_name=PE_NAME,
        )
    print(f"    PE ID: {pe.id}")
    print(f"    Provisioning state: {pe.provisioning_state}")
    assert pe.provisioning_state == "Succeeded"
    print("    ✓ Private endpoint + DNS zone group created via PrivateEndpointHelper")

    # Step 4: Verify PE is working (check vault's privateEndpointConnections)
    print(f"\n[4] Verifying PE connection on vault...")
    vault = kv_mgmt_client.vaults.get(RESOURCE_GROUP, KEY_VAULT_NAME)
    pe_connections = vault.properties.private_endpoint_connections or []
    found = False
    for conn in pe_connections:
        if PE_NAME in (conn.private_endpoint.id or ""):
            status = conn.private_link_service_connection_state.status
            prov_state = conn.provisioning_state
            print(f"    Connection status: {status}")
            print(f"    Provisioning state: {prov_state}")
            assert status == "Approved", f"Expected Approved, got {status}"
            assert prov_state == "Succeeded", f"Expected Succeeded, got {prov_state}"
            found = True
            break
    assert found, "PE connection not found on vault"
    print("    ✓ Private endpoint connection is Approved and Succeeded")

    # Step 5: Cleanup (mirrors _delete_private_endpoint)
    print(f"\n[5] Cleanup (mirrors self._delete_private_endpoint())...")
    print("    Deleting DNS zone group...")
    network_client.private_dns_zone_groups.begin_delete(
        RESOURCE_GROUP, PE_NAME, "default"
    ).result()
    print("    ✓ DNS zone group deleted")

    # print("    Deleting private endpoint...")
    # network_client.private_endpoints.begin_delete(
    #     RESOURCE_GROUP, PE_NAME
    # ).result()
    # print("    ✓ Private endpoint deleted")

    # Step 6: Verify cleanup
    print(f"\n[5] Verifying cleanup...")
    try:
        network_client.private_endpoints.get(RESOURCE_GROUP, PE_NAME)
        assert False, "PE should not exist after deletion"
    except Exception:
        pass
    print("    ✓ Private endpoint confirmed deleted")

    print("\n" + "=" * 60)
    print("  ALL TESTS PASSED")
    print("=" * 60)


if __name__ == "__main__":
    try:
        test_create_private_endpoint()
    except Exception as e:
        print(f"\n  FAILED: {e}")
        import traceback
        traceback.print_exc()

        # Attempt cleanup on failure
        print("\n  Attempting cleanup...")
        try:
            network_client.private_dns_zone_groups.begin_delete(
                RESOURCE_GROUP, PE_NAME, "default"
            ).result()
        except Exception:
            pass
        try:
            network_client.private_endpoints.begin_delete(
                RESOURCE_GROUP, PE_NAME
            ).result()
        except Exception:
            pass
        print("  Cleanup attempted.")

# $env:TEST_SP_SECRET = "t3D8Q~ECH9RS540vJkVcSyitWk8R955BMBKV3bDC"
# az network vnet create -g test-kvmgmt-rg -n test-kvmgmt-vnet --address-prefix 10.0.0.0/16 --subnet-name test-kvmgmt-subnet --subnet-prefix 10.0.0.0/24
# az network vnet subnet update -g test-kvmgmt-rg --vnet-name test-kvmgmt-vnet -n test-kvmgmt-subnet --disable-private-endpoint-network-policies true --service-endpoints Microsoft.KeyVault
# az keyvault network-rule add --name test-kvmgmt-brewmation -g test-kvmgmt-rg --subnet test-kvmgmt-subnet --vnet-name test-kvmgmt-vnet
# az network private-dns zone create -g test-kvmgmt-rg -n privatelink.vaultcore.azure.net