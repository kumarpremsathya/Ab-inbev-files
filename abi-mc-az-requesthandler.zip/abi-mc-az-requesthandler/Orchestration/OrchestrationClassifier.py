import azure.durable_functions as df
import logging,json

class OrchestratorClassifier:

    def classify(self,context:df.DurableOrchestrationContext):
        data = context.get_input()
        match data["ActivityName"]:
            case "VMPROVISION":
                retry_options = df.RetryOptions(21600000,2)
                quantity = json.loads(data["Payload"])["payload"]["data"]["vm_quantity"]
                provision_data = data
                tasks = []
                for vm in range(int(quantity)):
                    provision_data["VMNumber"] = vm
                    provision_data = yield context.call_activity("vmprovision_preprovision",provision_data)
                    task = context.call_sub_orchestrator_with_retry("vmprovision_orchestrator",retry_options,provision_data,instance_id=f'{data["ActivityId"]}-VMProvisioning-{str(vm)}')
                    tasks.append(task)
                yield context.task_all(tasks)
            case "HOURSOFOPERATIONINSTANCE":
                retry_options = df.RetryOptions(300000, 2)
                batch_operations = data.get("BatchOperations", [])
                if batch_operations:
                    tasks = []
                    for idx, vm_operation in enumerate(batch_operations):
                        task = context.call_sub_orchestrator_with_retry(
                            "hoursofoperationinstance_orchestrator",
                            retry_options,
                            vm_operation,
                            instance_id=vm_operation["InstanceActivityId"]
                        )
                        tasks.append(task)
                    yield context.task_all(tasks)
                else:
                    yield context.call_sub_orchestrator_with_retry(
                        "hoursofoperationinstance_orchestrator", 
                        retry_options, 
                        data,
                        instance_id=data["InstanceActivityId"]
                    )
            case _:
                yield context.call_activity(str(data["ActivityName"]).lower(), data)