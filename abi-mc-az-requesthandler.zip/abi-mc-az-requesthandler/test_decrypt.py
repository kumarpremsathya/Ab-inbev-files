"""Test safe read-only methods of KeyVaultMgmt against brewmation-zero."""
import os, json, asyncio, logging

logging.basicConfig(level=logging.INFO)
logging.getLogger("azure").setLevel(logging.WARNING)
logging.getLogger("msrest").setLevel(logging.WARNING)


with open("local.settings.json") as f:
    settings = json.load(f)
for k, v in settings.get("Values", {}).items():
    os.environ.setdefault(k, v)

from Catalog.Azure.KeyVaultMgmt.keyvault_mgmt import KeyVaultMgmt

payload = {
    "ActivityId": "40D21B44-2B59-4206-9CAD-8864DB484845",
    "EventId": "26476B60-390C-488C-A5D7-FC7C01BFFAF2",
    "SubscriptionId": "73f88e6b-3a35-4612-b550-555157e7059f",
    "SubscriptionName": "ABI GLOBAL NON-PROD",
    "ResourceGroupName": "PUPPET-STAGE-RG-GB-TEST",
    "KeyVaultName": "brewmation-zero",
    "SecretName": "puppet-test-123",
    "SecretValue": "9J9q9waE6LpC",
    "IV": "dxKOmx3Nr+cZxvGx",
    "Tag": "WMVSazW1Vjfn9Zvg6WFoLg==",
    "ContentType": "Password",
    "ExpiresOn": "2027-08-14",
    "Tags": "{}",
    "Action": "Create",
    "Zone": "GHQ",
    "Cloud": "Azure",
}

kv = KeyVaultMgmt(payload)
results = {}

# 1. Decrypt
try:
    val = kv._decrypt_secret_value()
    results["1. _decrypt_secret_value"] = f"PASS -> '{val}'"
except Exception as e:
    results["1. _decrypt_secret_value"] = f"FAIL -> {e}"

# 2. Get vault metadata
try:
    vault = kv._get_vault()
    results["2. _get_vault"] = f"PASS -> location={vault.location}, sku={vault.properties.sku.name}"
except Exception as e:
    results["2. _get_vault"] = f"FAIL -> {e}"

# 3. Check public network
try:
    vault = kv._get_vault()
    is_public = kv._is_public_network(vault)
    results["3. _is_public_network"] = f"PASS -> {is_public}"
except Exception as e:
    results["3. _is_public_network"] = f"FAIL -> {e}"

# 4. Get secret client
try:
    client = kv._get_secret_client()
    results["4. _get_secret_client"] = f"PASS -> {client.vault_url}"
except Exception as e:
    results["4. _get_secret_client"] = f"FAIL -> {e}"

# 5. Validate tags
try:
    tags = kv._validate_tags({"env": "test", "project": "keyvault"})
    results["5. _validate_tags"] = f"PASS -> {tags}"
except Exception as e:
    results["5. _validate_tags"] = f"FAIL -> {e}"

# 6. Full create flow (env=local, writes are commented out)
try:
    ok = asyncio.run(kv.manage_secret())
    results["6. manage_secret (dry)"] = f"PASS -> returned {ok}"
except Exception as e:
    results["6. manage_secret (dry)"] = f"FAIL -> {e}"

print("\n" + "="*50)
print("  KeyVaultMgmt Test Results")
print("="*50)
for test, result in results.items():
    print(f"  {test}: {result}")


