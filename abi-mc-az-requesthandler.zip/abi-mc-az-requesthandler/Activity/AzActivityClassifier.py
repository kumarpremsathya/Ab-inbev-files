import json,logging,asyncio
from shared_code.db import DB
# from Catalog.Azure.AppRoles.AzAppRole import AzAppRole
# from Catalog.Azure.Tags.tags import TagsUpdater
# from Catalog.Azure.Rbac.China.rbac import AzRbacChina
# from Catalog.Azure.Rbac.Public.rbac import AzRbacPublic
# from Catalog.Azure.InstanceStatus.instance_status import AzVmStatus
# from Catalog.Azure.VmResize.AzVmResize import AzVmResize
# from Catalog.Azure.VmDiskResize.AzVmDiskResize import AzVmDiskResize
# from Catalog.Azure.MSSQLAccess.mssql_access import AzMSSQLAccess
# from Catalog.Azure.PostgreSQLAccess.postgresql_access import AzPostgreSQLAccess
# from Catalog.Azure.SqlDbResize.AzMsSqlDbResize import AzMsSqlDbResize
# from Catalog.Azure.Decommission.decommission import AzDecommission
# from Catalog.Azure.RGProvision.rg_provision import AzRGProvision
# from Catalog.Azure.VmProvision.vm_provision import AzVMProvision
# from Catalog.Azure.VmSnapshot.vm_snapshot import AzVMSnapshot
# from Catalog.Azure.VmAccess.vm_access import AzVMAccess
# from Catalog.Azure.VmCreds.vm_creds import AzVMCreds
# from Catalog.Azure.KeyVaultProvision.key_vault_provision import KVProvision
# from Catalog.Azure.WebappProvision.webapp_provision import WebAppProvision
# from Catalog.Azure.StorageAccountProvision.storage_account_provision import StorageAccountProvision
# from Catalog.Azure.FunctionAppProvision.function_app_provision import FunctionAppProvision
# from Catalog.Azure.LogicAppProvision.logic_app_provision import LogicAppProvision
# from Catalog.Azure.CosmosDBProvision.cosmos_provision import CosmosDBProvision
# from Catalog.Azure.PostgreSQLFlexiServerProvision.postgre_provision import PostgreSQLProvision
# from Catalog.Azure.MSSQLServerProvision.mssql_provision import MSSQLServerProvision
# from Catalog.Azure.MSSQLElasticPoolProvision.mssql_elastic_provision import MSSQLElasticPoolProvision
# from Catalog.Azure.MSSQLManagedProvision.mssql_managed_provision import MSSQLManagedProvision
# from Catalog.Azure.MSSQLDBProvision.mssql_db_provision import MSSQLDBProvision
# from Catalog.Azure.RedisCacheProvision.redis_cache_provision import RedisCacheProvision
# from Catalog.Azure.EventHubProvision.eventhub_provision import EventHubProvision
# from Catalog.Azure.ApplicationInsightsProvision.appinsights_provision import AppInsightsProvision
# from Catalog.Azure.DataBricksProvision.databricks_provision import DataBricksProvision
# from Catalog.Azure.ServiceBusProvision.servicebus_provision import ServiceBusProvision
# from Catalog.Azure.DatafactoryProvision.datafactory_provision import DatafactoryProvision
# from Catalog.Azure.WindowsVMUpgrade.vm_upgrade import WindowsVMUpgrade
# from Catalog.Azure.HoursOfOperation.hours_of_operations import HoursOfOperationUpdater
# from Catalog.Azure.HoursOfOperationInstance.hours_of_operation_instance import HoursOfOperationInstance
# from Catalog.Azure.InactiveRbac.InactiveRbac import InactiveRbac
# from Catalog.Azure.PrivateEndpointProvision.private_endpoint_provision import PrivateEndpointProvision
# from IncidentCatalog.BackupFailure.backup_failure  import AzVMBackupFailure
# from IncidentCatalog.DiskCleanup.disk_cleanup import AzVMDiskCleanup
# from IncidentCatalog.CpuHighAlert.cpu_high_alert import AzVMCpuHighAlert
# from IncidentCatalog.MemoryHighAlert.memory_high_alert import AzVMMemoryHighAlert
# from Catalog.Azure.InactiveVmAccounts.InactiveVmAccounts import InactiveVMAccounts
# from Catalog.Azure.VmInventoryReview.VmInventoryReview import VmInventoryReview
# from Catalog.Azure.RbacInventoryReview.RbacInventoryReview import RbacInventoryReview
# from Catalog.Azure.RbacGroupMemberReview.rbac_group_member_review import RbacGroupMemberReview
from Catalog.Azure.PolicyExemption.policy_exemption import AzPolicyExemption
from Catalog.Azure.KeyVaultMgmt.keyvault_mgmt import KeyVaultMgmt
import asyncio


class AzActivityClassifier:

    def __init__(self,data):
        self.data = data

    # async def approle_activity(self):
    #     result,reason = await AzAppRole().grant_user_with_role(self.data["OID"],self.data["AppRoleName"])
    #     if result:
    #         return True
    #     raise Exception(f"Error in granting AppRole: {reason} ")

    # async def tags_activity(self):
    #     result,reason = TagsUpdater(self.data).update_rg_tags()
    #     if result:
    #         return True
    #     raise Exception(f"Error updating Tags: {reason} ")

    # async def rbac_activity(self):
    #     rbac_class = AzRbacChina if self.data["Zone"].lower() == "china" else AzRbacPublic
    #     result, reason = await rbac_class(self.data).grant_rbac()
    #     if result:
    #         return result
    #     raise Exception(f"Error in granting RBAC: {reason}")
    
    # async def rbacexceptional_activity(self):
    #     rbac_class = AzRbacChina if self.data["Zone"].lower() == "china" else AzRbacPublic
    #     result, reason = await rbac_class(self.data).grant_rbac()
    #     if result:
    #         return result
    #     raise Exception(f"Error in granting RBAC: {reason}")

    # async def instancestatus_activity(self):
    #     result = await AzVmStatus(self.data).vm_start_stop_restart(self.data["Action"].lower())
    #     return result

    # async def resizevmsku_activity(self):
    #     post_start_config = self.data.get("PostStartConfig")
    #     pre_stop_config = self.data.get("PreStopConfig")
    #     result = AzVmResize(
    #         self.data["SubscriptionId"], 
    #         self.data["Zone"], 
    #         self.data["ResourceGroupName"], 
    #         self.data["ResourceName"], 
    #         self.data["ResourceId"],
    #         post_start_config=post_start_config,
    #         pre_stop_config=pre_stop_config
    #     ).resize_with_snapshot_create(self.data["TargetSkuSize"])
    #     return result
    
    # async def resizevmdisk_activity(self):
    #     result = await AzVmDiskResize(self.data["SubscriptionId"], self.data["Zone"], self.data["ResourceGroupName"], self.data["ResourceName"], self.data["DiskName"], self.data["ResourceId"]).resize_with_snapshot(self.data["TargetDiskSize"])
    #     return result
    
    # async def mssqlaccess_activity(self):
    #     result = await AzMSSQLAccess(self.data).grant_access()
    #     return result
    
    # async def postgresqlaccess_activity(self):
    #     result = await AzPostgreSQLAccess(self.data).grant_access()
    #     return result
    
    # async def resizesqldb_activity(self):
    #     result = AzMsSqlDbResize(self.data["SubscriptionId"], self.data["Zone"], self.data["ResourceGroupName"], self.data["DbServer"], self.data["DbName"], self.data["TargetSize"], self.data["DbId"]).resize_database()
    #     return result
    
    # async def decomm_activity(self):
    #     result = AzDecommission(self.data).decommission()
    #     return result
    
    # async def decommpreactivity_activity(self):
    #     result = await AzDecommission(self.data).decommission_preactivity()
    #     return result
    
    # async def rgprovision_activity(self):
    #     result = AzRGProvision(self.data).create_rg()
    #     return result
    
    # async def vmprovision_preprovision_activity(self):
    #     result = AzVMProvision(self.data).vm_preprovision()
    #     return result
    
    # async def vmprovision_createvm_activity(self):
    #     result = AzVMProvision(self.data).create_vm(self.data["VMName"],self.data["NIC"])
    #     return result

    # async def vmprovision_vmbackup_activity(self):
    #     result = AzVMProvision(self.data).enable_backup(self.data["VMName"])
    #     return result
    
    # async def vmprovision_bginfo_activity(self):
    #     result = AzVMProvision(self.data).bginfo_extension(self.data["VMName"])
    #     return result
    
    # async def vmprovision_domainjoin_activity(self):
    #     result = AzVMProvision(self.data).domain_join_extension(self.data["VMName"])
    #     return result
    
    # async def vmprovision_puppet_activity(self):
    #     result = AzVMProvision(self.data).puppet_extension(self.data["VMName"])
    #     return result   
    
    # async def vmprovision_sam_activity(self):
    #     result = await AzVMProvision(self.data).notify_sam(self.data["EventId"])
    #     return result
    
    # async def vmprovision_registersqlvm_activity(self):
    #     result = AzVMProvision(self.data).register_sql_vm(self.data["VMName"])
    #     return result
    
    # async def snapshotcreation_activity(self):
    #     result = AzVMSnapshot(self.data).create_snaphot()
    #     return result
    
    # async def vmaccessmgmt_activity(self):
    #     result = await AzVMAccess(self.data).vm_access()
    #     return result
    
    # async def vmcredmgmt_activity(self):
    #     result = await AzVMCreds(self.data).vm_creds()
    #     return result
    
    # async def keyvaultprovision_activity(self):
    #     result = KVProvision(self.data).create_kv()
    #     return result
    
    # async def webappprovision_activity(self):
    #     result = WebAppProvision(self.data).create_webapp()
    #     return result
    
    # async def storageaccountprovision_activity(self):
    #     result = StorageAccountProvision(self.data).create_storage_account()
    #     return result
    
    # async def functionappprovision_activity(self):
    #     result = FunctionAppProvision(self.data).create_function_app()
    #     return result
    
    # async def logicappprovision_activity(self):
    #     result = LogicAppProvision(self.data).create_logic_app()
    #     return result
    
    # async def cosmosdbprovision_activity(self):
    #     result = CosmosDBProvision(self.data).provision_db()
    #     return result
    
    # async def postgredbprovision_activity(self):
    #     result = PostgreSQLProvision(self.data).provision_server()
    #     return result
    
    # async def mssqlserverprovision_activity(self):
    #     result = MSSQLServerProvision(self.data).mssql_server_provision()
    #     return result
    
    # async def mssqlelasticpoolprovision_activity(self):
    #     result = MSSQLElasticPoolProvision(self.data).provision_db()
    #     return result
    
    # async def mssqlmgmtinstanceprovision_activity(self):
    #     result = MSSQLManagedProvision(self.data).mssql_server_provision()
    #     return result
    
    # async def mssqldbprovision_activity(self):
    #     result = MSSQLDBProvision(self.data).mssql_server_provision()
    #     return result
    
    # async def rediscacheprovision_activity(self):
    #     result = RedisCacheProvision(self.data).create_redis_cache()
    #     return result
    
    # async def eventhubprovision_activity(self):
    #     result = EventHubProvision(self.data).create_eventhub()
    #     return result
    
    # async def appinsightsprovision_activity(self):
    #     result = AppInsightsProvision(self.data).create_appinsights()
    #     return result
    
    # async def databricksprovision_activity(self):
    #     result = DataBricksProvision(self.data).create_databricks()
    #     return result
    
    # async def servicebusprovision_activity(self):
    #     result = ServiceBusProvision(self.data).create_servicebus()
    #     return result
    
    # async def datafactoryprovision_activity(self):
    #     result = DatafactoryProvision(self.data).create_datafactory()
    #     return result

    # async def windowsvmupgrade_activity(self):
    #     result = WindowsVMUpgrade(self.data).check_and_upgrade_vm()
    #     return result
    
    # async def hoursofoperation_activity(self):
    #     result = HoursOfOperationUpdater(self.data).update_hours_of_operation()
    #     return result
    
    # async def hoursofoperationinstance_activity(self):
    #     result = await HoursOfOperationInstance(self.data).execute_vm_operation()
    
    # async def inactiverbac_activity(self):
    #     result = await InactiveRbac(self.data).delete_inactive_users_roles()
    #     return result
    
    # async def diskcleanup_activity(self):
    #     result = await AzVMDiskCleanup(self.data).cleanup()
    #     return result
    
    # async def backupfailure_activity(self):
    #     result = await AzVMBackupFailure(self.data).handle_backup_failure()
    #     return result
    
    # async def cpuhighalert_activity(self):
    #     result = await AzVMCpuHighAlert(self.data).handle_cpu_high_alert()
    #     return result
    
    # async def memoryhighalert_activity(self):
    #     result = await AzVMMemoryHighAlert(self.data).handle_memory_high_alert()
    #     return result
    
    # async def privateendpointprovision_activity(self):
    #     result = PrivateEndpointProvision(self.data).create_private_endpoint()
    #     return result

    # async def inactivevmaccounts_activity(self):
    #     result = InactiveVMAccounts(self.data).remove_inactive_vm_accounts()
    #     return result

    # async def vminvreview_activity(self):
    #     result = VmInventoryReview(self.data).process_vm_inventory_review()
    #     return result
    
    # async def rbacinventoryreview_activity(self):
    #     result = await RbacInventoryReview(self.data).remove_inventory_reviewed_role_assignment()
    #     return result
    
    # async def rbacgroupmemberreview_activity(self):
    #     result = await RbacGroupMemberReview(self.data).remove_group_member()
    #     return result

    # async def policyexemption_activity(self):
    #     result = await AzPolicyExemption(self.data).apply_exemption()
    #     return result

    async def keyvaultmgmt_activity(self):
        result = await KeyVaultMgmt(self.data).manage_secret()
        return result
