# Run these in Azure Cloud Shell or a terminal with az CLI logged in
# Subscription: 8d62fea6-3260-4070-a3b7-d87a6985fa4b

# 1. Set subscription
az account set --subscription "8d62fea6-3260-4070-a3b7-d87a6985fa4b"

# 2. Create resource group
az group create --name "test-kvmgmt-rg" --location "westeurope"

# 3. Create Key Vault with RBAC and private networking (defaultAction=Deny)
az keyvault create \
  --name "test-kvmgmt-brewmation" \
  --resource-group "test-kvmgmt-rg" \
  --location "westeurope" \
  --enable-rbac-authorization true \
  --default-action Deny

# 4. Create a Service Principal for testing (save the output!)
az ad sp create-for-rbac \
  --name "test-kvmgmt-sp" \
  --role "Contributor" \
  --scopes "/subscriptions/8d62fea6-3260-4070-a3b7-d87a6985fa4b/resourceGroups/test-kvmgmt-rg"

# Output will look like:
# {
#   "appId": "<CLIENT_ID>",
#   "displayName": "test-kvmgmt-sp",
#   "password": "<CLIENT_SECRET>",
#   "tenant": "<TENANT_ID>"
# }
# Save these values — you'll need them for the test.

# ============================================================
# CLEANUP (run after testing is done):
# az group delete --name "test-kvmgmt-rg" --yes --no-wait
# az ad sp delete --id "<appId from step 4>"
# ============================================================
