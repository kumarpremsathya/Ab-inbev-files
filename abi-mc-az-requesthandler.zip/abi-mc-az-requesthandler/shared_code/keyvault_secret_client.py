from azure.keyvault.secrets import SecretClient
from azure.identity import DefaultAzureCredential


def get_vault_url(key_vault_name, cloud):
    if cloud == "AzureChinaCloud":
        return f"https://{key_vault_name}.vault.azure.cn"
    return f"https://{key_vault_name}.vault.azure.net"


def get_secret_client(key_vault_name, cloud):
    vault_url = get_vault_url(key_vault_name, cloud)
    credential = DefaultAzureCredential()
    return SecretClient(vault_url=vault_url, credential=credential)
