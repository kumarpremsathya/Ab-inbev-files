import logging
import json
from azure.mgmt.compute.models import RunCommandInput

def execute_run_command(
    compute_client,
    resource_group_name: str,
    resource_name: str,
    config_json: str,
    config_type: str,
    required: bool = False
) -> bool:
    try:
        config = json.loads(config_json)
        
        kernel = config.get("kernel", "Linux")
        script = config.get("scripts", [])
        
        if not script:
            logging.warning(f"{config_type} has no script commands to execute")
            return True
        
        command_id = "RunShellScript" if kernel.lower() == "linux" else "RunPowerShellScript"
        command = RunCommandInput(command_id=command_id, script=script)
        poller = compute_client.virtual_machines.begin_run_command(
            resource_group_name=resource_group_name,
            vm_name=resource_name,
            parameters=command,
        )
        poller.wait()
        run_command_result = poller.result()
        
        if run_command_result and hasattr(run_command_result, 'value'):
            for output in run_command_result.value:
                if output.message:
                    logging.info(f"{config_type} Output: {output.message}")
        return True
        
    except json.JSONDecodeError as e:
        error_msg = f"Invalid JSON in {config_type}: {e}"
        logging.error(error_msg)
        if required:
            raise Exception(error_msg)
        return False
    except Exception as e:
        error_msg = f"Error executing {config_type} for {resource_name}: {e}"
        logging.error(error_msg)
        if required:
            raise Exception(error_msg)
        return False
