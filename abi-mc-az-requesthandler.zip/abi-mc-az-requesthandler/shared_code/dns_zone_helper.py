from shared_code.db import DB
from shared_code.privatedns_client import PrivateDNSClient
import logging

class DnsZoneHelper:

    @staticmethod
    def get_dns_zone_config(subscription_id, zone):
        try:
            db = DB()
            query = """
                SELECT DnsResourceGroup, DnsSubscriptionId 
                FROM tblDnsZones 
                WHERE SubscriptionId = ? AND Zone = ? AND IsActive = 1
            """
            result = db.executescalar(sql_query=query, action="select", values=(subscription_id, zone))
            if result and len(result) > 0:
                row = result[0]
                return {
                    "resource_group": row[0],
                    "dns_subscription_id": row[1]
                }
            else:
                raise ValueError(f"No DNS zone configuration found in tblDnsZones for subscription '{subscription_id}' and zone '{zone}'")
        except Exception as e:
            logging.error(f"Error querying tblDnsZones: {e}")
            raise

    @staticmethod
    def get_dns_client_for_zone(subscription_id, zone, cloud):

        config = DnsZoneHelper.get_dns_zone_config(subscription_id, zone)
        dns_subscription_id = config["dns_subscription_id"] or subscription_id
        dns_client = PrivateDNSClient().get_dns_client(dns_subscription_id, cloud)
        return dns_client, config["resource_group"]
