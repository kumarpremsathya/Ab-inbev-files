from.constants import Constants
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

class Notification:
    def __init__(self,subject,body,email_cred):
        objcons = Constants()
        msg = MIMEMultipart()        
        msg['From'] = objcons.EMAIL_FROM
        msg['To'] = objcons.EMAIL_TO     
        msg['Subject'] = f'ERROR - {subject}'
        msgText = MIMEText(body,_subtype='plain', _charset='UTF-8')
        msg.attach(msgText)
        smtpObj = smtplib.SMTP(objcons.SMTP_SERVER,objcons.SMTP_PORT)
        smtpObj.ehlo()
        smtpObj.starttls()
        smtpObj.login(objcons.EMAIL_FROM, email_cred)
        smtpObj.sendmail(objcons.EMAIL_FROM, objcons.EMAIL_TO, msg.as_string())
        smtpObj.quit()
