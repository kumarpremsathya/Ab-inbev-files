from azure.mgmt.web import WebSiteManagementClient
from shared_code.client_secret_auth import ClientSecretAuth
from msrestazure.azure_cloud import AZURE_CHINA_CLOUD as CHINA
import os

class WebSiteClient:
    def __init__(self):
        pass

    def get_web_client(self,subscriptionid,azenvironment):
        if azenvironment=="AzurePublicCloud":
            spn_secret_name = os.environ["SPN_SECRET_PUBLIC"]
            credentials = ClientSecretAuth().client_credential(spn_secret_name)
            web_client = WebSiteManagementClient(credentials,subscriptionid)
        elif azenvironment=="AzureChinaCloud":
            spn_secret_name = os.environ["SPN_SECRET_CHINA"]
            credentials = ClientSecretAuth().client_credential(spn_secret_name)
            web_client = WebSiteManagementClient(credentials,
                                                subscription_id=subscriptionid,
                                                base_url=CHINA.endpoints.resource_manager,
                                                credential_scopes=[CHINA.endpoints.resource_manager + "/.default"])
        return web_client