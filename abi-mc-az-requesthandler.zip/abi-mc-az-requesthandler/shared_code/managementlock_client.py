from azure.mgmt.resource.locks import ManagementLockClient
from shared_code.client_secret_auth import ClientSecretAuth
from msrestazure.azure_cloud import AZURE_CHINA_CLOUD as CHINA
import os

class ManagementLocksClient:
    def __init__(self) -> None:
        pass

    def get_lock_client(self,azenvironment,subscription):
        if azenvironment=="AzurePublicCloud":
            spn_secret_name = os.environ["SPN_SECRET_PUBLIC"]
            credentials = ClientSecretAuth().client_credential(spn_secret_name)
            mgmtlock_client= ManagementLockClient(credential=credentials,subscription_id=subscription)
        elif azenvironment=="AzureChinaCloud":
            spn_secret_name = os.environ["SPN_SECRET_CHINA"]
            credentials = ClientSecretAuth().client_credential(spn_secret_name)
            mgmtlock_client = ManagementLockClient(credential=credentials,
                                             base_url=CHINA.endpoints.resource_manager,
                                             credential_scopes=[CHINA.endpoints.resource_manager + "/.default"],
                                             subscription_id=subscription)
        return mgmtlock_client