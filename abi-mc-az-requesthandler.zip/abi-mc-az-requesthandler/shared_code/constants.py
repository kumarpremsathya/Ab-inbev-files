from datetime import datetime,timezone,timedelta
class Constants:
    EMAIL_FROM = "no-reply-brewmation@ab-inbev.com"
    EMAIL_FROM_UID = "cd840aec-c048-476d-bed9-9279b26b216c"
    EMAIL_TO = "global-puppet-engineering@ab-inbev.com"
    SMTP_SERVER = 'smtp.office365.com'
    SMTP_PORT = '587' 
    SMTP_KEYVAULT_SECRET = "smtp-brewmation-cred"
    SNOW_ASSIGNMENT_GROUP = "422ddc4ac3a6da5013c9f5cf05013151"
    SNOW_ASSIGNMENT_USER = "8f8c5c3e1bc4781090e42026bd4bcb39"
    SNOW_INCIDENT_CALLER_ID  = "8f8c5c3e1bc4781090e42026bd4bcb39"