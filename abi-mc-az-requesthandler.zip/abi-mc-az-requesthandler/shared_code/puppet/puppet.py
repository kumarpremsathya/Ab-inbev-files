from shared_code.puppet.api import Requestor
import json,logging

class Puppet(object):
    """Python wrapper for Puppet Orchestrator REST API"""

    def __init__(self, host='localhost', port=8143, key_file=None,
        cert_file=None, ssl_verify=False, cache_enabled=True,
        cache_file='/tmp/pypuppet_cache', cache_backend='sqlite', 
        cache_expire_after=3600,token = None, environment = 'production'):

        self.environment = environment
        self.requestor = Requestor(host=host, port=port, key_file=key_file,
            cert_file=cert_file, ssl_verify=ssl_verify, cache=cache_enabled,
            cache_file=cache_file, cache_backend=cache_backend,
            cache_expire_after=cache_expire_after,token=token)
    
    def build_json(self,task):
        json_template = {}
        json_template['environment'] = self.environment
        match task:
            case 'DiskCleanUp':
                json_template['task'] = 'exec::linux'
                json_template['scope'] = {}
                params = {}
                params['command'] = 'df -TH'
                json_template['params'] = params
            case 'Other':
                json_template['task'] = 'exec::linux'
                params = {}
                params['command'] = 'df -TH'
                json_template['params'] = params
        
        return json_template
        

    def diskcleanup_task(self,data):
        json_data = self.build_json('DiskCleanUp')
        res = data['resource']
        resource = res if '.one.ofc.loc' in res else res.strip()+".one.ofc.loc"
        json_data['scope'] = {'nodes':[resource]}
        json_data['description'] = data['id']
        json_data['userdata'] = {'snow_ticket': data['id'] }
        logging.info(json.dumps(json_data))
        return self.requestor.post('orchestrator/v1/command/task',data=json.dumps(json_data))

    def command_task(self,data):
        return self.requestor.post('orchestrator/v1/command/task',data=data)
    
    def get_tasks(self):
        return self.requestor.get('orchestrator/v1/tasks',environment=self.environment)