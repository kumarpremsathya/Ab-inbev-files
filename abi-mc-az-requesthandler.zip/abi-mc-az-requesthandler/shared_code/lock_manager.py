import logging,time
from shared_code.managementlock_client import ManagementLocksClient


class LockManager:
    def __init__(
        self,
        subscription_id,
        zone,
        resource_group_name,
        resource_name=None,
        resource_id=None,
    ):
        self.subscription_id = subscription_id
        self.zone = zone.lower()
        self.resource_group_name = resource_group_name
        self.resource_name = resource_name
        self.resource_id = resource_id
        self.azenvironment = (
            "AzureChinaCloud" if self.zone == "china" else "AzurePublicCloud"
        )

        self.lock_client = ManagementLocksClient().get_lock_client(
            self.azenvironment, self.subscription_id
        )
        self.removed_locks = []  # Track removed locks with their scopes

    def get_locks(self, locktype, notes):
        if locktype == "ReadOnly":
            read_payload = {"properties": {"level": "ReadOnly", "notes": notes}}
            name = "ReadOnlyLock"
            return read_payload

        if locktype == "CanNotDelete":
            delete_payload = {"properties": {"level": "CanNotDelete", "notes": notes}}
            name = "CanNotDeleteLock"
            return delete_payload

    def add_locks(self, scope, lock_type, notes=None):
        if lock_type not in ["ReadOnly", "CanNotDelete"]:
            raise ValueError("lock_type must be either 'ReadOnly' or 'CanNotDelete'")

        try:
            lock_payload = self.get_locks(lock_type, notes)

            created_lock = self.lock_client.management_locks.create_or_update_by_scope(
                scope=scope, lock_name=f'Brewmation - {lock_type}', parameters=lock_payload
            )

            lock_details = {
                "name": created_lock.name,
                "scope": scope,
                "level": created_lock.level,
                "notes": created_lock.notes
            }

            logging.info(f"Successfully created {lock_type} lock at scope: {scope}")
            time.sleep(10)
            return lock_details
        
        except Exception as e:
            logging.error(f"Failed to create {lock_type} lock at scope {scope}: {e}")
            raise

    def remove_all_locks(self, scope=None, lock_types=["ReadOnly", "CanNotDelete"]):
        # If no specific scope provided, use resource and resource group scopes
        if not scope:
            scope = f"/subscriptions/{self.subscription_id}/resourceGroups/{self.resource_group_name}"
        try:
            # List all locks at the current scope
            locks = list(
                self.lock_client.management_locks.list_by_scope(scope=scope)
            )

            # Remove each lock and track its scope
            for lock in locks:
                if lock.level in lock_types:
                    scope = lock.id.replace("/providers/Microsoft.Authorization/locks/",'|').split('|')[0]
                    if len(scope.split("/")) == 5 or (self.resource_name is None and self.resource_id is None) or self.resource_name.lower() in scope.lower():
                        try:
                            # Delete the lock directly using its full name and scope
                            self.lock_client.management_locks.delete_by_scope(
                                scope=scope, lock_name=lock.name
                            )

                            self.removed_locks.append(
                                {
                                    "name": lock.name,
                                    "scope": scope,
                                    "level": lock.level,
                                    "notes": lock.notes
                                }
                            )
                            logging.info(f"Removed lock: {lock.name} from {scope}")

                        except Exception as e:
                            logging.error(f"Failed to remove lock {lock.name}: {e}")

        except Exception as e:
            logging.error(f"Error listing locks at {scope}: {e}")
        time.sleep(10)
        return [lock["name"] for lock in self.removed_locks]

    def restore_locks(
        self, lock_types=["ReadOnly", "CanNotDelete"]
    ):
        logging.info(f"Attempting to restore locks: {self.removed_locks}")
        logging.info("Restoring locks...")

        for removed_lock in self.removed_locks:
            # Check if the lock type matches and extract the base type (remove 'Lock')
            lock_type = removed_lock["level"]
            lock_notes = removed_lock["notes"]
            if lock_type in lock_types:
                try:
                    lock_payload = self.get_locks(lock_type, lock_notes)

                    # Restore lock to its original scope
                    self.lock_client.management_locks.create_or_update_by_scope(
                        scope=removed_lock["scope"],
                        lock_name=removed_lock["name"],
                        parameters=lock_payload,
                    )
                    logging.info(
                        f"Restored lock: {removed_lock['name']} to {removed_lock['scope']}"
                    )

                except Exception as e:
                    logging.error(f"Failed to restore lock {removed_lock['name']}: {e}")
        time.sleep(10)
        # Clear removed locks after restoration
        self.removed_locks = []
    
    def restore_locks_at_rg(self, lock_types=["ReadOnly", "CanNotDelete"]):
        logging.info("Restoring locks...")

        for removed_lock in self.removed_locks:
            # Check if the lock type matches and extract the base type (remove 'Lock')
            lock_type = removed_lock["level"]
            lock_notes = removed_lock["notes"]
            if lock_type in lock_types and removed_lock["scope"].split("/")[4] == self.resource_group_name:
                try:
                    lock_payload = self.get_locks(lock_type, lock_notes)

                    # Restore lock to its original scope
                    self.lock_client.management_locks.create_or_update_by_scope(
                        scope=removed_lock["scope"],
                        lock_name=removed_lock["name"],
                        parameters=lock_payload,
                    )
                    logging.info(
                        f"Restored lock: {removed_lock['name']} to {removed_lock['scope']}"
                    )
                    self.removed_locks.remove(removed_lock)

                except Exception as e:
                    logging.error(f"Failed to restore lock {removed_lock['name']}: {e}")
        time.sleep(10)        