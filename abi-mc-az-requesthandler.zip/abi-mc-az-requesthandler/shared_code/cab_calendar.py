from datetime import datetime, timedelta
from dateutil import tz,parser

class CabCalendar:
    def __init__(self,zone,cooling_period):
        self.days_mapping = {
        'Monday': 0,
        'Tuesday': 1,
        'Wednesday': 2,
        'Thursday': 3,
        'Friday': 4,
        'Saturday': 5,
        'Sunday': 6
        }
        self.cab = {
            "GHQ": ["Tuesday","Friday"],
            "NAZ": ["Tuesday","Thursday"],
            "EUROPE": ["Tuesday","Thursday"],
            "AFRICA": ["Tuesday","Friday"]
        }
        self.zone = zone
        self.cooling_period = int(cooling_period)
    
    def get_nearest_cab_date(self):
        today = datetime.now()
        search = self.cab.get(self.zone,["Tuesday","Thursday"])
        days_ahead = {
            search[0]: (self.days_mapping.get(search[0]) - today.weekday() + 7) % 7,
            search[1]: (self.days_mapping.get(search[1]) - today.weekday() + 7) % 7
        }
        if days_ahead[search[0]] == 0:
            days_ahead[search[0]] = 7
        if days_ahead[search[1]] == 0:
            days_ahead[search[1]] = 7
        next_cab_1 = today + timedelta(days=days_ahead[search[0]])
        next_cab_2 = today + timedelta(days=days_ahead[search[1]])
        if days_ahead[search[0]] < days_ahead[search[1]]:
            return next_cab_1
        else:
            return next_cab_2
        
    def get_cab_date(self,cab_date):
        cab_date = parser.isoparse(cab_date)
        new_cab = self.get_nearest_cab_date()
        new_cab = new_cab.replace(tzinfo=cab_date.tzinfo)
        return new_cab.isoformat()
    
    def get_start_date(self,cab_date):
        cab_date = parser.isoparse(cab_date)
        new_cab = self.get_nearest_cab_date()
        new_start_time = new_cab + timedelta(days=self.cooling_period)
        new_start_time = new_start_time.replace(tzinfo=cab_date.tzinfo)
        return new_start_time.isoformat()
    
    def get_end_date(self,cab_date):
        cab_date = parser.isoparse(cab_date)
        new_cab = self.get_nearest_cab_date()
        new_end_time = new_cab + timedelta(days=self.cooling_period,hours=2)
        new_end_time = new_end_time.replace(tzinfo=cab_date.tzinfo)
        return new_end_time.isoformat()