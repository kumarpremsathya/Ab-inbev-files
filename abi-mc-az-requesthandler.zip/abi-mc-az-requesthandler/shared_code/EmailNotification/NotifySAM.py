from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from shared_code.constants import Constants
from shared_code.akv_secrets import AkvSecrets
import logging,os,asyncio
from functools import lru_cache
from msgraph.generated.users.item.send_mail.send_mail_post_request_body import SendMailPostRequestBody
from msgraph.generated.models.message import Message
from msgraph.generated.models.item_body import ItemBody
from msgraph.generated.models.recipient import Recipient
from msgraph.generated.models.email_address import EmailAddress
from msgraph.generated.models.body_type import BodyType
from msgraph import GraphServiceClient
from shared_code.client_secret_auth import ClientSecretAuth

class NotifySAM:

    def __init__(self) -> None:
        self.email_creds = ClientSecretAuth().client_credential(Constants.SMTP_KEYVAULT_SECRET)

    def create_email_body(self,subject, content, to_recipients, cc_recipients=[], bcc_recipients=[Constants.EMAIL_TO]):
        to_recipients_list = [Recipient(email_address=EmailAddress(address=recipient)) for recipient in to_recipients]
        cc_recipients_list = [Recipient(email_address=EmailAddress(address=recipient)) for recipient in cc_recipients]
        bcc_recipients_list = [Recipient(email_address=EmailAddress(address=recipient)) for recipient in bcc_recipients]
        body = SendMailPostRequestBody(
			message=Message(
				subject=subject,
				body=ItemBody(
					content_type=BodyType.Html,
					content=content,
				),
				to_recipients=to_recipients_list,
				cc_recipients=cc_recipients_list,
                bcc_recipients=bcc_recipients_list
			),
			save_to_sent_items=True
		)
        return body

    async def send_email_notification(self,zone,event,toemail=Constants.EMAIL_TO):
        subject = f"Proof submission for software licence on VM - {event['VMName']} - {event['SnowItemId']} - {event['SnowId']}"
        if zone.lower() == "maz":
            sam_email = ['ana.duran@ab-inbev.com','nora.rodriguez-ext@ab-inbev.com','Ivan.Salinas-ext@ab-inbev.com',
                         'MAZ.SAMlicensingdesk@ab-inbev.com','ABIITAMCloud@ab-inbev.com','SAMinCloud@ab-inbev.com']
        elif zone.lower() == "europe":
            sam_email = ['eu.samlicensingdesk@ab-inbev.com','ABIITAMCloud@ab-inbev.com','SAMinCloud@ab-inbev.com']
        elif zone.lower() == "ghq":
            sam_email = ['GHQ.GlobalSAMlicensingdesk@ab-inbev.com','ABIITAMCloud@ab-inbev.com','SAMinCloud@ab-inbev.com']
        else:
            sam_email = ['ABIITAMCloud@ab-inbev.com','SAMinCloud@ab-inbev.com']



        image_header= open(os.path.join('shared_code','EmailNotification', 'image_header.b64'),"r")
        image_footer = open(os.path.join('shared_code','EmailNotification', 'image_footer.b64'),"r")
        footer_image = image_footer.read()
        header_image = image_header.read()
        # CSS styles
        css_styles = """
        <style>
            .report table {
              border: solid 2px #DDEEEE;
              border-collapse: collapse;
              border-spacing: 0;
              font: normal 14px Roboto, sans-serif;
            }

            .report thead th {
              background-color: #000000;
              border: solid 1px #DDEEEE;
              color: #FFFFFF;
              padding: 10px;
              text-align: left;
            }

            .report tbody td {
              border: solid 1px #DDEEEE;
              color: #333;
              padding: 10px;
              text-shadow: 1px 1px 1px #fff;
            }

            .progress {
                list-style: none ;     
                margin: 0 ; 
                padding: 0 ; 
                display: table ; 
                table-layout: fixed ;
                width: 100% ; 
                color: #849397; 
            }
            .progress > li {
                position: relative ;
                display: table-cell ;
                text-align: center ;
                font-size: 0.8em ;
            }
            
            .progress > li > span {
                content: attr(data-step);
                margin: 0 auto ;
                background: #dfe3e4 ;
                width: 3em ;
                height: 3em ;
                text-align: center ;
                margin-bottom: 0.25em ;
                line-height: 3em ;
                border-radius: 100% ;
                position: absolute ;
                z-index: 999999 ;
            }
            .progress > li > i {
                content: "" ;
                position: absolute ;
                background: #dfe3e4 ;
                width: 100% ;
                height: 0.5em ;
                top: 0.725em ;
                left: 50% ;
                margin-left: 1.5em\9 ;
                z-index: 9000;
            }
            .progress > li.last-child > i {
                display: none ;
            }
            .progress > li.is-complete {
                color: #f5e003 ;
            }
            .progress > li.is-complete > span {
                color: #fff ;
                background: #f5e003 ;
            }
            .progress > li.is-complete > i {
                color: #fff ;
                background: #f5e003 ;
            }
            .progress > li.is-active {
                color: #2ecc71 ; 
            }
            .progress > li.is-active > span{
                color: #fff  ;
                background: #2ecc71 ;
            }
            .progress > li.is-active > i {
                color: #2ecc71 ; 
            }
            .progress__last > i {
                display: none !important;
            }
            .progress-container {
            width: 100%;
            max-width: 600px;
            margin: auto;
            background-color: #e0e0e0;
            border-radius: 5px;
            overflow: hidden;
            }
            .progress-step {
                text-align: center;
                padding: 10px;
                flex: 1;
            }
            .completed {
                background-color: #4caf50; /* Green */
                color: white;
            }
            .pending {
                background-color: #e0e0e0; /* Grey */
                color: #666;
            }
        </style>
        """
        
        body = f"""
        <html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office">
             <head>
            <meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
        </head>
        {css_styles}
        <body marginheight="0" topmargin="0" marginwidth="0" style="margin: 0px; background-color: #f2f3f8;" leftmargin="0">
            <table cellspacing="0" border="0" cellpadding="0" width="100%" bgcolor="#f2f3f8"
                style="@import url(https://fonts.googleapis.com/css?family=Rubik:300,400,500,700|Open+Sans:300,400,600,700); font-family: 'Open Sans', sans-serif;">
                <tr>
                    <td>
                        <table style="background-color: #f2f3f8; max-width:535px; margin:0 auto;" width="100%" border="0"
                            align="center" cellpadding="0" cellspacing="0">
                            <tr>
                                <td style="text-align:center;">
                                    <img style="display:block;" width="100%" height="100%" src="data:image/png;base64,{header_image}"/>
                                </td>
                            </tr>
                            <tr>   
                                <td>
                                    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0"
                                        style="max-width:535px; background:#fff; border-radius:3px;-webkit-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);-moz-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);box-shadow:0 6px 18px 0 rgba(0,0,0,.06);padding:0;">
                                        <!-- Details Table -->
                                        <tr>
                                            <td style="height:10px;">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td style="padding:0 40px">
                                            <p>Hello,</p>
                                            <p>You are receving this email due to the order submission on Brewmation</p>
                                            </p>
                                            <p>VM Name: <b>{event['VMName']}</b></p>
                                            </td>
                                        </tr>                                        
                                        <tr>
                                            <td style="padding:0 40px">
                                                    <p>You can efficiently request software licenses through our <a href='https://abinbevww.service-now.com/abiex?id=sc_category_abi&catalog_id=2e3a07fbdb8e985002085bd05b961922&sys_id=b896ed871bc8c5d4a5ddddf3b24bcbf1'>ServiceNow Software Catalog</a>.<br>Utilizing this catalog helps streamline the process, ensuring that your requests are handled promptly and accurately. </p>
                                                    <p>Requesting you to bookmark the <a href='https://abinbevww.service-now.com/abiex?id=sc_category_abi&catalog_id=2e3a07fbdb8e985002085bd05b961922&sys_id=b896ed871bc8c5d4a5ddddf3b24bcbf1'>ServiceNow Software Catalog</a> and submit any software license installation/purchase requests via the catalog to ensure licenses are deployed in a compliant manner. </p>
                                                    <p>If you have any questions or need further assistance, please do not hesitate to contact the SAM Licensing Desk: </p>
                                                    <ul style="list-style-type:disc;">
                                                    {"".join([f'<li>{email}</li>' for email in sam_email])}
                                                    </ul>  
                                            <td>
                                        </tr>
                                        <tr>
                                            <td style="height:20px;">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td style="padding:0 40px">
                                            <div class='report'>
                                            <table border="1">
                                                {"".join([f"<tr><td>{qa['name']}</td><td>{qa['value']}</td></tr>" for qa in event['sam']])}
                                            </table>
                                            </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="padding:0 40px">
                                                <br>
                                                <p>Cheers,</p>
                                                <p><b>Global-Puppet-Engineering </b> &#127866;</p>
                                                <br>
                                                <br>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td style="text-align:center;">
                                    <img style="display:block;" width="100%" height="100%" src="data:image/png;base64,{footer_image}"/>
                                </td>
                            </tr>
                            <tr>
                                <td style="height:20px;">&nbsp;</td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </body>
        </html>
        """
        try:
            email_body = self.create_email_body(subject, body, [toemail], cc_recipients=sam_email)
            client = GraphServiceClient(credentials=self.email_creds)
            await client.users.by_user_id(Constants.EMAIL_FROM_UID).send_mail.post(body=email_body)
        except Exception as e:
            if "Event loop is closed" in str(e):
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)                
                loop.run_until_complete(client.users.by_user_id(Constants.EMAIL_FROM_UID).send_mail.post(body=email_body))
                loop.close()
            logging.error(f"Error sending email: {e}")