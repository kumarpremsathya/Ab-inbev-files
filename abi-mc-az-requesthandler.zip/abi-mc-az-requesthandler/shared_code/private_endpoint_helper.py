from shared_code.networkmgmt_client import NetworkMgmtClient
from shared_code.privatedns_client import PrivateDNSClient
from shared_code.dns_zone_helper import DnsZoneHelper
import logging


class PrivateEndpointHelper:

    def __init__(self, subscription_id, zone, cloud):
        self.subscription_id = subscription_id
        self.zone = zone
        self.cloud = cloud
        self.network_client = NetworkMgmtClient().get_network_mgmt_client(subscription_id, cloud)

    def create_private_endpoint(
        self,
        resource_group_name,
        resource_id,
        resource_name,
        location,
        subnet_id,
        group_ids,
        dns_zone_name,
        private_endpoint_name=None,
        tags=None,
        create_dns_zone_if_not_exists=False
    ):

        if not private_endpoint_name:
            private_endpoint_name = f"{resource_name}-pe-db"

        # Create private endpoint
        private_endpoint = self.network_client.private_endpoints.begin_create_or_update(
            resource_group_name=resource_group_name,
            private_endpoint_name=private_endpoint_name,
            parameters={
                "location": location,
                "subnet": {
                    "id": subnet_id
                },
                "privateLinkServiceConnections": [{
                    "name": f"{private_endpoint_name}-connection",
                    "properties": {
                        "privateLinkServiceId": resource_id,
                        "groupIds": group_ids,
                        "requestMessage": None
                    }
                }],
                "tags": tags or {}
            }
        ).result()

        logging.info(f"Private endpoint '{private_endpoint_name}' created successfully")

        # Resolve DNS zone
        dns_client, dns_rg = DnsZoneHelper.get_dns_client_for_zone(self.subscription_id, self.zone, self.cloud)
        try:
            private_dns_zone = dns_client.private_zones.get(
                resource_group_name=dns_rg,
                private_zone_name=dns_zone_name
            )
        except Exception as e:
            if create_dns_zone_if_not_exists and "ResourceNotFound" in str(e):
                private_dns_zone = dns_client.private_zones.begin_create_or_update(
                    resource_group_name=dns_rg,
                    private_zone_name=dns_zone_name,
                    parameters={
                        "location": "global",
                        "properties": {
                            "max_number_of_record_sets": 25000,
                            "max_number_of_virtual_network_links": 1000,
                            "max_number_of_virtual_network_links_with_registration": 100,
                        }
                    }
                ).result()
            else:
                raise

        # Create private DNS zone group
        private_dns_zone_group_params = {
            "privateDnsZoneConfigs": [{
                "name": private_dns_zone.name,
                "properties": {
                    "privateDnsZoneId": private_dns_zone.id
                }
            }]
        }

        self.network_client.private_dns_zone_groups.begin_create_or_update(
            resource_group_name,
            private_endpoint_name,
            "default",
            private_dns_zone_group_params
        ).result()

        logging.info(f"Private DNS zone group created for '{private_endpoint_name}'")

        return private_endpoint

    def get_subnet_id(self, vnet_rg_name, vnet_name, subnet_name):
        """
        Retrieves the subnet resource ID.
        """
        subnet = self.network_client.subnets.get(
            resource_group_name=vnet_rg_name,
            virtual_network_name=vnet_name,
            subnet_name=subnet_name
        )
        return subnet.id
