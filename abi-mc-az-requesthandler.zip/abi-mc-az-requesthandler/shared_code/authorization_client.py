from msrestazure.azure_cloud import AZURE_CHINA_CLOUD as CHINA
from azure.mgmt.authorization import AuthorizationManagementClient
from shared_code.client_secret_auth import ClientSecretAuth
import os

class AuthorizationClient:
    def __init__(self) -> None:
        pass

    def get_auth_client(self,azenvironment,subscription):
        if azenvironment=="AzurePublicCloud":
            spn_secret_name = os.environ["SPN_SECRET_PUBLIC"]
            credentials = ClientSecretAuth().client_credential(spn_secret_name)
            auth_client= AuthorizationManagementClient(credential=credentials,subscription_id=subscription)
        elif azenvironment=="AzureChinaCloud":
            spn_secret_name = os.environ["SPN_SECRET_CHINA"]
            credentials = ClientSecretAuth().client_credential(spn_secret_name)
            auth_client = AuthorizationManagementClient(credential=credentials,
                                             base_url=CHINA.endpoints.resource_manager,
                                             credential_scopes=[CHINA.endpoints.resource_manager + "/.default"],
                                             subscription_id=subscription)
        return auth_client