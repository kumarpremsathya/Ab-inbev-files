import pyodbc
import logging
import os,json
from shared_code.akv_secrets import AkvSecrets
from functools import lru_cache

class DB:
    @classmethod
    @lru_cache(maxsize=None,typed=True)
    def __init__(self):
        secrets_obj = AkvSecrets(os.environ["KEYVAULT_URI"],os.environ["DB_KEYVAULT_SECRET"])
        logging.info("Obtained db password")
        dbpass = secrets_obj.get_tokens()
        self.cnxn_str = f'Driver={os.environ["DB_DRIVER"]};Server={os.environ["DB_SERVER"]},1433;Database={os.environ["DATABASE"]};Uid={os.environ["DB_UID"]};Pwd={dbpass.value};Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;'        
        
    def _connect(self):
        try:
            self._cnxn = pyodbc.connect(self.cnxn_str)
            self._cursor = self._cnxn.cursor()
        except Exception as e:
            logging.info(repr(e))

    def _close_cnxn(self):
        self._cursor.close()
        self._cnxn.close()
    
    def executescalar(self,sql_query=None,action=None,values=None):
        self._connect()
        if(action=="select"):
            if values:                
                self._cursor.execute(sql_query,values)
            else:
                self._cursor.execute(sql_query)
            result = self._cursor.fetchall()
            self._close_cnxn()
            return result
        if(action=="check"):
            self._cursor.execute(sql_query,values)
            result = self._cursor.fetchone()
            self._close_cnxn()
            return result
        elif(action=="insert"):
            self._cursor.execute(sql_query,values)
            logging.info(f"Sql insert start {sql_query}")
        elif(action=="eventinsert"):            
            self._cursor.execute(sql_query,values)
            eventid = self._cursor.fetchone()[0]
            self._cursor.commit()
            self._close_cnxn()
            logging.info(f"Sql insert start {sql_query}")
            return eventid
        elif(action=="delete"):
            self._cursor.execute(sql_query,values)
            logging.info(f"Sql delete start {sql_query}")
        elif(action=="update"):
            self._cursor.execute(sql_query,values)
            logging.info(f"Sql update start {sql_query}")
        elif(action=="exec"):
            self._cursor.execute(sql_query)
        elif(action=="upsert"):
            upsert_query = """
            MERGE INTO tblVMUserDetails as Target
            USING (SELECT ?,?,?,?,?,?,?,?,?)
            AS SOURCE(Username,Node,Kernel,Zone,LocalGroup,PasswordExpiration,PasswordChange,AccountStatus,PrivilegedAccess)
            ON Target.Username=Source.Username AND Target.Node=Source.Node
            WHEN NOT MATCHED THEN
            INSERT (Username,Node,Kernel,Zone,LocalGroup,PasswordExpiration,PasswordChange,AccountStatus,PrivilegedAccess) 
            VALUES (Source.Username,Source.Node,Source.Kernel,Source.Zone,Source.LocalGroup,Source.PasswordExpiration,Source.PasswordChange,Source.AccountStatus,Source.PrivilegedAccess)
            WHEN MATCHED THEN
            UPDATE SET LocalGroup=Source.LocalGroup, PasswordExpiration=Source.PasswordExpiration, PasswordChange=Source.PasswordChange, AccountStatus=Source.AccountStatus, PrivilegedAccess=Source.PrivilegedAccess;
            """
            self._cursor.execute(upsert_query,values["username"],values["node"],values["kernel"],values["zone"],values["group"],values["password_expiration"],values["password_change"],values["account_status"],values["privileged_access"])
        self._cursor.commit()
        self._close_cnxn()

   