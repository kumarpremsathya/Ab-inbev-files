from azure.keyvault.secrets import SecretClient
from azure.identity import DefaultAzureCredential

class AkvSecrets:
    def __init__(self,keyVaultUri,keyVaultSecretName):
      self.uri = keyVaultUri
      self.token = keyVaultSecretName

    def get_tokens(self):
        credential = DefaultAzureCredential()
        client = SecretClient(vault_url=self.uri, credential=credential)
        retrieved_secret = client.get_secret(self.token)
        return retrieved_secret