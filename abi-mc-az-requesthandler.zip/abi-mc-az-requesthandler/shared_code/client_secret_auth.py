from azure.identity import ClientSecretCredential
from shared_code.spn_token import SpnToken

class ClientSecretAuth:

    def __init__(self) -> None:
        pass

    def client_credential(self,kv_secret_name):
        spn_token_obj = SpnToken()
        spn_token = spn_token_obj.get_spn_token(kv_secret_name)
        credentials = ClientSecretCredential(
            client_id = spn_token["client_id"],
            client_secret = spn_token["secret"],
            tenant_id = spn_token["tenant"]
        )
        return credentials