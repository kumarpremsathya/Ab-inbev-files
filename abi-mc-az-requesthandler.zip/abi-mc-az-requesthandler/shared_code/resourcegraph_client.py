from azure.identity import ClientSecretCredential
from azure.mgmt.resourcegraph import ResourceGraphClient
from azure.identity.aio import ClientSecretCredential as ClientSecretCredentialAsync
from azure.mgmt.resourcegraph.aio import ResourceGraphClient as ResourceGraphClientAsync
from msrestazure.azure_cloud import AZURE_CHINA_CLOUD as CHINA
from shared_code.spn_token import SpnToken

class ResourceGraph:
    def __init__(self) -> None:
        pass

    def get_resorce_graph(self,azenvironment):
        spn_token_obj = SpnToken()
        if azenvironment=="AzurePublicCloud":
            spn_secret_name = "az-public-spn-reader"
        elif azenvironment=="AzureChinaCloud":
            spn_secret_name = "az-china-spn-reader"
        spn_token = spn_token_obj.get_spn_token(spn_secret_name)
        credentials = ClientSecretCredential(
        client_id = spn_token["client_id"],
        client_secret = spn_token["secret"],
        tenant_id = spn_token["tenant"]
        )
        if azenvironment == "AzurePublicCloud":
            res_graph_client = ResourceGraphClient(credentials)
        elif azenvironment == "AzureChinaCloud":
            res_graph_client = ResourceGraphClient(credentials,
                                                base_url=CHINA.endpoints.resource_manager,
                                                credential_scopes=[CHINA.endpoints.resource_manager + "/.default"])
        return res_graph_client
    
    def get_resorce_graph_async(self,azenvironment):
        spn_token_obj = SpnToken()
        if azenvironment=="AzurePublicCloud":
            spn_secret_name = "az-public-spn-reader"
        elif azenvironment=="AzureChinaCloud":
            spn_secret_name = "az-china-spn-reader"
        spn_token = spn_token_obj.get_spn_token(spn_secret_name)
        credentials = ClientSecretCredentialAsync(
        client_id = spn_token["client_id"],
        client_secret = spn_token["secret"],
        tenant_id = spn_token["tenant"]
        )
        if azenvironment == "AzurePublicCloud":
            res_graph_client = ResourceGraphClientAsync(credentials)
        elif azenvironment == "AzureChinaCloud":
            res_graph_client = ResourceGraphClientAsync(credentials,
                                                base_url=CHINA.endpoints.resource_manager,
                                                credential_scopes=[CHINA.endpoints.resource_manager + "/.default"])
        return res_graph_client