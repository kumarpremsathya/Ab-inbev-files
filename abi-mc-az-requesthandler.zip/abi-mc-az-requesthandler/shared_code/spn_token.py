from shared_code.akv_secrets import AkvSecrets
import os
import json
from functools import lru_cache

class SpnToken:
    def __init__(self):
        pass

    # def get_spn_token(self,environment):

    #     # Check the environment
    #     if environment=="AzurePublicCloud":
    #         secrets_obj = AkvSecrets(os.environ["KEYVAULT_URI"],"az-public-spn")
    #     elif environment=="AzureChinaCloud":
    #         secrets_obj = AkvSecrets(os.environ["KEYVAULT_URI"],"az-china-spn")
    #     else:
    #         raise Exception("Invalid Environment")

    #     spn_token = secrets_obj.get_tokens()
    #     spn_token = json.loads(spn_token.value)
        
    #     return spn_token
    @classmethod
    @lru_cache(maxsize=None,typed=True)
    def get_spn_token(self,secret_name):
        secrets_obj = AkvSecrets(os.environ["KEYVAULT_URI"],secret_name)
        spn_token = secrets_obj.get_tokens()
        spn_token = json.loads(spn_token.value)
        return spn_token