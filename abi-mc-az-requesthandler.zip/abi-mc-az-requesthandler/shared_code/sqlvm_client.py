from azure.mgmt.sqlvirtualmachine import SqlVirtualMachineManagementClient
from azure.common.credentials import ServicePrincipalCredentials
from msrestazure.azure_cloud import AZURE_CHINA_CLOUD as CHINA
from shared_code.spn_token import SpnToken
import os

class SqlVMClient:
    def __init__(self):
        pass
    
    def get_spn_credentials(self,kv_secret_name):
        spn_token_obj = SpnToken()
        spn_token = spn_token_obj.get_spn_token(kv_secret_name)
        credentials = ServicePrincipalCredentials(
            client_id = spn_token["client_id"],
            secret = spn_token["secret"],
            tenant = spn_token["tenant"]
        )
        return credentials

    def get_sqlvm_client(self,subscriptionid,azenvironment):
        if azenvironment=="AzurePublicCloud":
            spn_secret_name = os.environ["SPN_SECRET_PUBLIC"]
            credentials = self.get_spn_credentials(spn_secret_name)
            sqlvm_client = SqlVirtualMachineManagementClient(credentials,subscriptionid)
        elif azenvironment=="AzureChinaCloud":
            spn_secret_name = os.environ["SPN_SECRET_CHINA"]
            credentials = self.get_spn_credentials(spn_secret_name)
            sqlvm_client = SqlVirtualMachineManagementClient(credentials,
                                                subscription_id=subscriptionid,
                                                base_url=CHINA.endpoints.resource_manager,
                                                credential_scopes=[CHINA.endpoints.resource_manager + "/.default"])
        return sqlvm_client