from azure.mgmt.resource.policy import PolicyClient
from msrestazure.azure_cloud import AZURE_CHINA_CLOUD as CHINA
from shared_code.client_secret_auth import ClientSecretAuth
import os

class AzPolicyClient:
    def __init__(self) -> None:
        pass

    def get_policy_client(self, subscription_id, azenvironment):
        if azenvironment=="AzurePublicCloud":
            spn_secret_name = os.environ["SPN_SECRET_PUBLIC"]
            credentials = ClientSecretAuth().client_credential(spn_secret_name)
            policy_client = PolicyClient(credentials, subscription_id)
        elif azenvironment=="AzureChinaCloud":
            spn_secret_name = os.environ["SPN_SECRET_CHINA"]
            credentials = ClientSecretAuth().client_credential(spn_secret_name)
            policy_client = PolicyClient(credentials,
                                                subscription_id=subscription_id,
                                                base_url=CHINA.endpoints.resource_manager,
                                                credential_scopes=[CHINA.endpoints.resource_manager + "/.default"])
        return policy_client