import json, os

# Load local.settings.json env vars (Azure Functions host does this automatically, standalone scripts don't)
with open("local.settings.json") as f:
    settings = json.load(f)
for key, value in settings["Values"].items():
    os.environ.setdefault(key, value)


import asyncio, json, uuid
from RequestReceiver.RequestReceiver import RequestReceiver
from Events.Azure.BackupFailure import BackupFailure
from Catalog.Azure.KeyVaultMgmt.KeyVaultMgmt import AzKeyVaultMgmt
from shared_code.db import DB

# The exact payload from your TEST MODE logs
payload = {
    "ActivityName": "BACKUPFAILURE",
    "ActivityType": "Incident",
    "RequestorEmail": "Alex.Green@anheuser-busch.com",
    "SnowItemId": "INC9997580",
    "SnowId": "INC9997580",
    "SnowItemStatusCode": "7",
    "SnowItemStatus": "Queued",
    "zone": "NAZ",
    "message_id": str(uuid.uuid4()),   # required by event_db_insert
    "payload": {
        "cloud": "Azure",
        "devowners": "Alex.Green@anheuser-busch.com,Rajesh.Poojari@ab-inbev.com",
        "justification": "Brewmation Auto Remediation",
        "data": {
            "subscription_id": "95c54dda-ae35-43c0-aeea-bcfc596674c1",
            "subscription_name": "ABI NAZ PROD",
            "resource_group_name": "mgmtrsvault-rg-naz-prod",
            "resource_id": "/subscriptions/95c54dda-ae35-43c0-aeea-bcfc596674c1/resourcegroups/mgmtrsvault-rg-naz-prod/providers/microsoft.recoveryservices/vaults/mgmtrsvault-zrs-naz-prod",
            "resource_name": "oneazap30597",   # ← add this
            "recovery_vault_id": None,
            "error_code": 380022,
            "error_message": "Snapshot operation failed due to COM+ error",
            "error_title": "ExtensionSnapshotFailedCOM",
            "recommendations": "Please restart windows service \"COM+ System Application\" (COMSysApp). If the issue persists,, restart the VM."
        }
    }
}

# async def main():
#     # STEP 1: Insert into tblEventMaster (simulates Phase 2 / request_receiver_trigger)
#     print("Step 1: Inserting into tblEventMaster...")
#     event_id = await RequestReceiver().request_initilize(payload)
#     print(f"\n\n\n → SnowItemId returned: {event_id}")

#     # STEP 2: Fetch that row back from DB
#     print("\n\n\nStep 2: Fetching dataset row from tblEventMaster...")
#     objdb = DB()
#     dataset = objdb.executescalar(
#         sql_query="SELECT * FROM tblEventMaster WHERE SnowItemId = ? AND ActivityName = 'BACKUPFAILURE'",
#         action="check",
#         values=("INC9997580",)
#     )
#     print(f"  → EventId: {dataset.EventId}, Status: {dataset.Status}")

#     # STEP 3: Call activity_data directly (simulates Phase 3a deserialize)
#     print("\n\n\nStep 3: Calling BackupFailure.activity_data()...")
#     BackupFailure().activity_data(dataset)
#     print("  → Done. Check tblActivityBackupFailure and tblEventPendingActivity.")

# asyncio.run(main())


# ── KEYVAULTMGMT direct activity_data test ──────────────────────────────────

kv_payload = {
    "ActivityName": "KEYVAULTMGMT",
    "ActivityType": "Request",
    "RequestorEmail": "merina.davis@ab-inbev.com",
    "SnowItemId": "RITM20320974",
    "SnowId": "REQ6655077",
    "SnowItemStatusCode": "8",
    "SnowItemStatus": "request_approved",
    "zone": "GHQ",
    "message_id": str(uuid.uuid4()),
    "payload": {
        "cloud": "Azure",
        "devowners": "abc@ab-inbev.com",
        "justification": "Create Secret",
        "data": {
            "zone": "GHQ",
            "subscription_id": "",
            "subscription_name": "",
            "resource_group_name": "",
            "key_vault_name": "my-keyvault",
            "secret_name": "test-secret",
            "secret_value": "fyZEF4CxPv+7XAKY1yE=",
            "iv": "vIxOGafHIvzXOFur",
            "tag": "dPvrpzBVxABgfQD7Yt3yig==",
            "content_type": "Password",
            "expires_on": "",
            "tags": {}
        }
    }
}

async def test_keyvault_activity_data():
    print("\n\nStep 1: Fetching existing KEYVAULTMGMT record from tblEventMaster...")
    objdb = DB()
    dataset = objdb.executescalar(
        sql_query="SELECT * FROM tblEventMaster WHERE SnowItemId = ? AND ActivityName = 'KEYVAULTMGMT'",
        action="check",
        values=("RITM20321006",)
    )
    if not dataset:
        print("  → No record found. Run test_keyvault.py first to insert via RequestReceiver.")
        return
    print(f"  → EventId: {dataset.EventId}, Status: {dataset.Status}")

    print("\nStep 2: Calling AzKeyVaultMgmt.activity_data()...")
    AzKeyVaultMgmt().activity_data(dataset)
    print("  → Done. Check tblActivityAzKeyVaultMgmt and tblEventPendingActivity.")

asyncio.run(test_keyvault_activity_data())