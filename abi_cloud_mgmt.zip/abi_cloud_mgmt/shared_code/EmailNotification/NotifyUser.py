from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from shared_code.constants import Constants
from shared_code.akv_secrets import AkvSecrets
import logging,os,asyncio
from functools import lru_cache
from msgraph.generated.users.item.send_mail.send_mail_post_request_body import SendMailPostRequestBody
from msgraph.generated.models.message import Message
from msgraph.generated.models.item_body import ItemBody
from msgraph.generated.models.recipient import Recipient
from msgraph.generated.models.email_address import EmailAddress
from msgraph.generated.models.body_type import BodyType
from msgraph import GraphServiceClient
from shared_code.client_secret_auth import ClientSecretAuth
from shared_code.db import DB
import json

class NotifyUser:

    def __init__(self) -> None:
        self.email_creds = ClientSecretAuth().client_credential(Constants.SMTP_KEYVAULT_SECRET)
        self.objdb= DB()

    def get_cc_recipients(self, event):
        event_id = event["EventId"]

        query = """
            SELECT Payload FROM tblEventMaster WHERE Eventid = ?
        """
        values = (event_id,)
        payload = self.objdb.executescalar(sql_query=query, action="select", values=values)
        devowners = json.loads(payload[0].Payload).get("devowners", [])
        return devowners

    def create_email_body(self,subject, content, to_recipients, cc_recipients=[], bcc_recipients=[Constants.EMAIL_TO]):
        to_recipients_list = [Recipient(email_address=EmailAddress(address=recipient)) for recipient in to_recipients]
        cc_recipients_list = [Recipient(email_address=EmailAddress(address=recipient)) for recipient in cc_recipients]
        bcc_recipients_list = [Recipient(email_address=EmailAddress(address=recipient)) for recipient in bcc_recipients]
        body = SendMailPostRequestBody(
			message=Message(
				subject=subject,
				body=ItemBody(
					content_type=BodyType.Html,
					content=content,
				),
				to_recipients=to_recipients_list,
				cc_recipients=cc_recipients_list,
                bcc_recipients=bcc_recipients_list
			),
			save_to_sent_items=True
		)
        return body

    async def send_email_notification(self,event,toemail=Constants.EMAIL_TO):
        subject = f"ABI Cloud Management Portal - {event['SnowItemId']} - {event['Status']}"
        
        image_header= open(os.path.join('shared_code','EmailNotification', 'image_header.b64'),"r")
        image_footer = open(os.path.join('shared_code','EmailNotification', 'image_footer.b64'),"r")
        footer_image = image_footer.read()
        header_image = image_header.read()
        # CSS styles
        css_styles = """
        <style>
            .report table {
              border: solid 2px #DDEEEE;
              border-collapse: collapse;
              border-spacing: 0;
              font: normal 14px Roboto, sans-serif;
            }

            .report thead th {
              background-color: #000000;
              border: solid 1px #DDEEEE;
              color: #FFFFFF;
              padding: 10px;
              text-align: left;
            }

            .report tbody td {
              border: solid 1px #DDEEEE;
              color: #333;
              padding: 10px;
              text-shadow: 1px 1px 1px #fff;
            }

            .progress {
                list-style: none ;     
                margin: 0 ; 
                padding: 0 ; 
                display: table ; 
                table-layout: fixed ;
                width: 100% ; 
                color: #849397; 
            }
            .progress > li {
                position: relative ;
                display: table-cell ;
                text-align: center ;
                font-size: 0.8em ;
            }
            
            .progress > li > span {
                content: attr(data-step);
                margin: 0 auto ;
                background: #dfe3e4 ;
                width: 3em ;
                height: 3em ;
                text-align: center ;
                margin-bottom: 0.25em ;
                line-height: 3em ;
                border-radius: 100% ;
                position: absolute ;
                z-index: 999999 ;
            }
            .progress > li > i {
                content: "" ;
                position: absolute ;
                background: #dfe3e4 ;
                width: 100% ;
                height: 0.5em ;
                top: 0.725em ;
                left: 50% ;
                margin-left: 1.5em\9 ;
                z-index: 9000;
            }
            .progress > li.last-child > i {
                display: none ;
            }
            .progress > li.is-complete {
                color: #f5e003 ;
            }
            .progress > li.is-complete > span {
                color: #fff ;
                background: #f5e003 ;
            }
            .progress > li.is-complete > i {
                color: #fff ;
                background: #f5e003 ;
            }
            .progress > li.is-active {
                color: #2ecc71 ; 
            }
            .progress > li.is-active > span{
                color: #fff  ;
                background: #2ecc71 ;
            }
            .progress > li.is-active > i {
                color: #2ecc71 ; 
            }
            .progress__last > i {
                display: none !important;
            }
            .progress-container {
            width: 100%;
            max-width: 600px;
            margin: auto;
            background-color: #e0e0e0;
            border-radius: 5px;
            overflow: hidden;
            }
            .progress-step {
                text-align: center;
                padding: 10px;
                flex: 1;
            }
            .completed {
                background-color: #4caf50; /* Green */
                color: white;
            }
            .pending {
                background-color: #e0e0e0; /* Grey */
                color: #666;
            }
        </style>
        """
        
        body = f"""
        <html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office">
             <head>
            <meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
        </head>
        {css_styles}
        <body marginheight="0" topmargin="0" marginwidth="0" style="margin: 0px; background-color: #f2f3f8;" leftmargin="0">
            <table cellspacing="0" border="0" cellpadding="0" width="100%" bgcolor="#f2f3f8"
                style="@import url(https://fonts.googleapis.com/css?family=Rubik:300,400,500,700|Open+Sans:300,400,600,700); font-family: 'Open Sans', sans-serif;">
                <tr>
                    <td>
                        <table style="background-color: #f2f3f8; max-width:535px; margin:0 auto;" width="100%" border="0"
                            align="center" cellpadding="0" cellspacing="0">
                            <tr>
                                <td style="text-align:center;">
                                    <img style="display:block;" width="100%"  src="data:image/png;base64,{header_image}"/>
                                </td>
                            </tr>
                            <tr>   
                                <td>
                                    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0"
                                        style="max-width:535px; background:#fff; border-radius:3px;-webkit-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);-moz-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);box-shadow:0 6px 18px 0 rgba(0,0,0,.06);padding:0;">
                                        <!-- Details Table -->
                                        <tr>
                                            <td style="height:10px;">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td style="padding:0 40px">
                                            <p>Hello,</p>
                                            <p>{"Your request has been successfully completed" if event["Status"] == "Success" else ("We are working on your request" if event["Status"] == "In-Progress" else ("Sorry your request was " + event["Status"].lower() if event["Status"] in ["Cancelled","Failed","Aborted"] else ("Your request was rejected" if event["Status"] == "Rejected" else "We have received your request and awaiting approval")))}</p>
                                            <p>Please keep the below details for reference</b>
                                            </p>
                                            <br>
                                            </td>
                                        </tr>                                        
                                        <tr>
                                            <td>
                                                    <table width="435px" align="center" style="border-collapse: collapse;">
                                                    <tr>
                                                        <td style="text-align: center; padding: 10px;">
                                                            <div style="width: 30px; height: 30px; border-radius: 50%; background-color: #4caf50; color: white; display: inline-flex; align-items: center; justify-content: center;">✓
                                                            </div>
                                                            <br>
                                                            <br>
                                                            Submitted
                                                        </td>
                                                        <td style="text-align: center; padding: 10px;">
                                                            <div style="width: 30px; height: 30px; border-radius: 50%; background-color: {"#f5e003" if event["Status"] == "Submitted" else ("#DC143C" if event["Status"] == "Rejected" else "#4caf50")}; color: white; display: inline-flex; align-items: center; justify-content: center;">
                                                            {"✗" if event["Status"] == "Rejected" else "✓"}
                                                            </div>
                                                                <br>
                                                                <br>
                                                            {"Rejected" if event["Status"] == "Rejected" else "Pending Approval"}
                                                        </td>
                                                        <td style="text-align: center; padding: 10px;">
                                                            <div style="width: 30px; height: 30px; border-radius: 50%; background-color: {"#4caf50" if event["Status"] == "In-Progress" else ("#4caf50" if event["Status"] in ["Success","Cancelled","Failed","Closed Incomplete","Aborted"] else "#e0e0e0")}; color: white; display: inline-flex; align-items: center; justify-content: center;">✓</div>
                                                            <br>
                                                            <br>
                                                            In Progress
                                                        </td>
                                                        <td style="text-align: center; padding: 10px;">
                                                            <div style="width: 30px; height: 30px; border-radius: 50%; background-color: {"#e0e0e0" if event["Status"] == "In-Progress" else ("#4caf50" if event["Status"] in ["Success","Closed Incomplete"] else ("#DC143C" if event["Status"] in ["Cancelled","Failed","Aborted"] else "#e0e0e0"))}; color: white; display: inline-flex; align-items: center; justify-content: center;">
                                                            {"✗" if event["Status"] in ["Cancelled","Failed","Aborted"] else "✓"}
                                                            </div>
                                                            <br>
                                                            <br>
                                                            {event["Status"] if event["Status"] in ["Cancelled","Failed","Aborted"] else ("Closed Incomplete" if event["Status"] == "Closed Incomplete" else "Completed")}
                                                        </td>
                                                    </tr>
                                                </table>
                                            <td>
                                        </tr>
                                        <tr>
                                            <td style="height:20px;">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td style="padding:0 40px">
                                            <div class='report'>
                                            <table border="1">
                                                <tr><td>Event ID</td><td>{event["EventId"]}</td></tr>
                                                <tr><td>Activity Name</td><td>{event["ActivityName"]}</td></tr>
                                                <tr><td>ServiceNow ID</td><td>{
                                                        '<a href="{0}sc_req_item.do?sysparm_query=number={1}">{1}</a>'.format(os.environ["SNOW_INSTANCE"], event["SnowItemId"])
                                                    if event['SnowItemId'].startswith("RITM") else (
                                                        '<a href="{0}incident.do?sysparm_query=number={1}">{1}</a>'.format(os.environ["SNOW_INSTANCE"], event["SnowItemId"])
                                                    if event['SnowItemId'].startswith("INC") else (
                                                        '<a href="{0}change_request.do?sysparm_query=number={1}">{1}</a>'.format(os.environ["SNOW_INSTANCE"], event["SnowItemId"])
                                                    ))
                                                }</td></tr>
                                                <tr><td>Status</td><td>{event["Status"]}</td></tr>
                                            </table>
                                            </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="padding:0 40px">
                                                <br>
                                                <p>Cheers,</p>
                                                <p><b>Brewmation Solutions</b> &#127866;</p>
                                                <br>
                                                <br>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td style="text-align:center;">
                                    <img style="display:block;" width="100%" height="100%" src="data:image/png;base64,{footer_image}"/>
                                </td>
                            </tr>
                            <tr>
                                <td style="height:20px;">&nbsp;</td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </body>
        </html>
        """
        try:
            cc_recipients = []
            devowners = self.get_cc_recipients(event)
            if devowners:
                cc_recipients = devowners.split(";")
            email_body = self.create_email_body(subject, body, [toemail],cc_recipients)
            client = GraphServiceClient(credentials=self.email_creds)
            await client.users.by_user_id(Constants.EMAIL_FROM_UID).send_mail.post(body=email_body)
        except Exception as e:
            if "Event loop is closed" in str(e):
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)                
                loop.run_until_complete(client.users.by_user_id(Constants.EMAIL_FROM_UID).send_mail.post(body=email_body))
                loop.close()
            logging.error(f"Error sending email: {e}")
    
    async def send_error_notification(self, error_type: str, error_message: str, additional_details: dict = None):
        """
        Send formatted error notification using professional template
        
        Args:
            error_type: Type of error (e.g., "Processing Error", "Scheduler Error")
            error_message: Detailed error message
            additional_details: Optional dict of additional information to display
        """
        from datetime import datetime
        
        timestamp = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')
        environment = os.environ.get('Environment', 'DEV')
        
        subject = f"{environment} - {error_type}"
        
        # Build details rows
        details_rows = f"""
            <tr>
                <td><b>Error Type</b></td>
                <td style="color: #d35400;">{error_type}</td>
            </tr>
            <tr>
                <td><b>Error Message</b></td>
                <td style="color: #d35400;">{error_message}</td>
            </tr>
            <tr>
                <td><b>Environment</b></td>
                <td>{environment}</td>
            </tr>
            <tr>
                <td><b>Timestamp</b></td>
                <td>{timestamp}</td>
            </tr>
        """
        
        # Add additional details if provided
        if additional_details:
            for key, value in additional_details.items():
                details_rows += f"""
                <tr>
                    <td><b>{key}</b></td>
                    <td>{value}</td>
                </tr>
                """
        
        # Load header and footer images
        image_header = open(os.path.join('shared_code','EmailNotification', 'image_header.b64'),"r")
        image_footer = open(os.path.join('shared_code','EmailNotification', 'image_footer.b64'),"r")
        footer_image = image_footer.read()
        header_image = image_header.read()
        
        # CSS styles
        css_styles = """
        <style>
            .report table {
              border: solid 2px #DDEEEE;
              border-collapse: collapse;
              border-spacing: 0;
              font: normal 14px Roboto, sans-serif;
              width: 100%;
            }

            .report thead th {
              background-color: #000000;
              border: solid 1px #DDEEEE;
              color: #FFFFFF;
              padding: 10px;
              text-align: left;
            }

            .report tbody td {
              border: solid 1px #DDEEEE;
              color: #333;
              padding: 10px;
              text-shadow: 1px 1px 1px #fff;
            }
        </style>
        """
        
        # Build HTML body
        body = f"""
        <html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office">
            <head>
                <meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
            </head>
            {css_styles}
            <body marginheight="0" topmargin="0" marginwidth="0" style="margin: 0px; background-color: #f2f3f8;" leftmargin="0">
                <table cellspacing="0" border="0" cellpadding="0" width="100%" bgcolor="#f2f3f8"
                    style="@import url(https://fonts.googleapis.com/css?family=Rubik:300,400,500,700|Open+Sans:300,400,600,700); font-family: 'Open Sans', sans-serif;">
                    <tr>
                        <td>
                            <table style="background-color: #f2f3f8; max-width:535px; margin:0 auto;" width="100%" border="0"
                                align="center" cellpadding="0" cellspacing="0">
                                <tr>
                                    <td style="text-align:center;">
                                        <img style="display:block;" width="100%" height="100%" src="data:image/png;base64,{header_image}"/>
                                    </td>
                                </tr>
                                <tr>   
                                    <td>
                                        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0"
                                            style="max-width:535px; background:#fff; border-radius:3px;-webkit-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);-moz-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);box-shadow:0 6px 18px 0 rgba(0,0,0,.06);padding:0;">
                                            <tr>
                                                <td style="height:10px;">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="padding:0 40px">
                                                    <h2 style="color: #EE4B2B; margin-bottom: 10px;">❌ Error Alert</h2>
                                                    <p>Hello,</p>
                                                    <p>An error has occurred in the ABI Cloud Management system. Please review the details below and take appropriate action.</p>
                                                    <br>
                                                </td>
                                            </tr>                                        
                                            <tr>
                                                <td style="padding:0 40px">
                                                    <table class="report" width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                                                        <thead>
                                                            <tr>
                                                                <th>Field</th>
                                                                <th>Value</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            {details_rows}
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding:0 40px">
                                                    <br>        
                                                    <p>Cheers,</p>
                                                    <p><b>Brewmation Solutions </b> &#127866;</p>
                                                    <br>
                                                    <br>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="text-align:center;">
                                        <img style="display:block;" width="100%" height="100%" src="data:image/png;base64,{footer_image}"/>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="height:20px;">&nbsp;</td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </body>
        </html>
        """
        
        try:
            email_body = self.create_email_body(subject, body, [Constants.EMAIL_TO])
            client = GraphServiceClient(credentials=self.email_creds)
            await client.users.by_user_id(Constants.EMAIL_FROM_UID).send_mail.post(body=email_body)
            logging.info(f"Error notification sent for: {error_type}")
        except Exception as e:
            logging.error(f"Failed to send error notification: {e}")
            if "Event loop is closed" in str(e):
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                loop.run_until_complete(
                    client.users.by_user_id(Constants.EMAIL_FROM_UID).send_mail.post(body=email_body)
                )
                loop.close()