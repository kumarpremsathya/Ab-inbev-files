from azure.identity import ClientSecretCredential
from azure.mgmt.recoveryservicesbackup import RecoveryServicesBackupClient
from msrestazure.azure_cloud import AZURE_CHINA_CLOUD as CHINA
from shared_code.client_secret_auth import ClientSecretAuth
import os

class RecoveryServicesClient:
    def __init__(self) -> None:
        pass

    def get_recoveryservice_client(self,azenvironment):
        if azenvironment=="AzurePublicCloud":
            spn_secret_name = os.environ["SPN_SECRET_PUBLIC"]
            credentials = ClientSecretAuth().client_credential(spn_secret_name)
            recoveryservice_client = RecoveryServicesBackupClient(credentials)
        elif azenvironment=="AzureChinaCloud":
            spn_secret_name = os.environ["SPN_SECRET_CHINA"]
            credentials = ClientSecretAuth().client_credential(spn_secret_name)
            recoveryservice_client = RecoveryServicesBackupClient(credentials,
                                                base_url=CHINA.endpoints.resource_manager,
                                                credential_scopes=[CHINA.endpoints.resource_manager + "/.default"])            
        return recoveryservice_client