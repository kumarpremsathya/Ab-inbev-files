from datetime import datetime,timezone,timedelta
class Constants:
    EMAIL_FROM = "no-reply-brewmation@ab-inbev.com"
    EMAIL_FROM_UID = "cd840aec-c048-476d-bed9-9279b26b216c"
    EMAIL_TO = "global-puppet-engineering@ab-inbev.com"
    SMTP_SERVER = 'smtp.office365.com'
    SMTP_PORT = '587' 
    SMTP_KEYVAULT_SECRET = "smtp-brewmation-cred"
    SNOW_ASSIGNMENT_GROUP = "422ddc4ac3a6da5013c9f5cf05013151"
    SNOW_ASSIGNMENT_USER = "8f8c5c3e1bc4781090e42026bd4bcb39"
    SNOW_INCIDENT_CALLER_ID  = "8f8c5c3e1bc4781090e42026bd4bcb39"
    SNOW_BUSINESS_SERVICE = "9d45becc37358e00ad52148543990e2c"
    SNOW_ZONE_GHQ = "388556871b3f00104aae202a2d4bcb43"
    SNOW_ZONE_AFRICA = "155412471b3f00104aae202a2d4bcbd9"
    SNOW_ZONE_EU = "55ccca0f1bfb00104aae202a2d4bcbb5"
    SNOW_ZONE_MAZ = "4ab316071b3f00104aae202a2d4bcb87"
    SNOW_ZONE_NAZ = "9c359a471b3f00104aae202a2d4bcbe9"
    SNOW_ZONE_KOREA = "59c41a471b3f00104aae202a2d4bcba6"
    SNOW_ZONE_CHINA = "59c41a471b3f00104aae202a2d4bcba6"
    SNOW_ZONE_SAZ = "59c41a471b3f00104aae202a2d4bcba6"
    SNOW_ZONE_LAS = "30d7f7a797be465082bffaa6f053afb0"    