import json,logging,requests,os
from shared_code.spn_token import SpnToken
from pysnc import ServiceNowClient,AttachmentAPI


class SNOWClient:
    def __init__(self) -> None:
        spn_token = SpnToken().get_spn_token(os.environ["SPN_SECRET_SNOW"])
        self.instance = os.environ["SNOW_INSTANCE"]
        self.client = ServiceNowClient(self.instance, (spn_token['username'], spn_token['password']))

    def create_request(self,data):
        try:
            params = self.client.table_api._set_params()
            if data['assignment_group'] == "d4c4b485dbc623402f1b51a4ce9619f4":                
                target_url = self.instance + '/api/sn_sc/v1/servicecatalog/items/fd27857d1be7b810f861a640604bcbdc/order_now'
            else:
                target_url = self.instance + '/api/sn_sc/servicecatalog/items/c4eb5ee1db77ac502ebe5612f396192e/order_now?assignment_group=' + data['assignment_group']
            req = requests.Request('POST', target_url, params=params, json=data)
            res = self.client.table_api._send(req)
            self.client.table_api._validate_response(res)
            ritm = self.get_ritm_status_by_request(res.json()['result']['number'])
            gr = self.client.GlideRecord('sc_req_item')
            gr.get(ritm['sys_id'])
            gr.short_description = data['short_description']
            gr.description = data['description']
            gr.assignment_group = data['assignment_group']
            gr.update()
            sreq = self.get_request_by_sys_id(ritm['request'])
            return gr.serialize(), sreq
        except Exception as e:
            logging.error(e)
            return False
    
    def get_request_status(self,req_id):
        gr = self.client.GlideRecord('sc_request')
        gr.add_query('number', req_id)
        gr.query()
        req = gr.serialize() if gr.next() else False
        return req
    
    def create_incident(self,data):
        gr = self.client.GlideRecord('incident')
        gr.initialize()
        gr.short_description = data['short_description']
        gr.description = data['description']
        gr.business_service = data['business_service']
        gr.u_select_zone = data['u_select_zone']
        gr.caller_id = data['caller_id']
        gr.u_symptom = data['u_symptom']
        gr.category = data['category']
        gr.assignment_group = data['assignment_group']
        gr.insert()
        inc = gr.serialize()
        return inc
    
    def get_incident_status(self,inc_id):
        gr = self.client.GlideRecord('incident')
        gr.add_query('number', inc_id)
        gr.query()
        inc = gr.serialize() if gr.next() else False
        return inc

    def update_incident_status(self,inc_id,state,comments,assigned_to=None,close_notes=None,work_notes=None,assignment_group=None):
        try:
            gr = self.client.GlideRecord('incident')
            gr.get('number',inc_id)
            gr.state = state        
            gr.close_notes = close_notes if close_notes else False
            gr.work_notes = work_notes if work_notes else False
            gr.assigned_to = None if assigned_to == '' else False if assigned_to is None else assigned_to
            gr.assignment_group =  None if assignment_group == '' else False if assignment_group is None else assignment_group
            gr.close_code = 'Solved' if state in ['7'] else False
            gr.comments = comments
            gr.update()
            return True
        except Exception as e:
            logging.error(f"Error updating incident: {e}")
            return False


    def get_ritm_status(self,ritm):
        gr = self.client.GlideRecord('sc_req_item')
        gr.add_query('number', ritm)
        gr.query()
        ritm = gr.serialize() if gr.next() else False
        return ritm

    def get_user_details_by_email(self,email):
        gr = self.client.GlideRecord('sys_user')
        gr.add_query("email",email)
        gr.query()
        user = gr.serialize() if gr.next() else False
        return user
    
    def get_user_details_by_sys_id(self,sys_id):
        gr = self.client.GlideRecord('sys_user')
        gr.add_query("sys_id",sys_id)
        gr.query()
        user = gr.serialize() if gr.next() else False
        return user
    
    def get_user_details_by_employee_id(self,id):
        gr = self.client.GlideRecord('sys_user')
        gr.add_query("employee_number",id)
        gr.query()
        user = gr.serialize() if gr.next() else False
        return user
    
    def get_user_details_by_oid(self,id):
        gr = self.client.GlideRecord('sys_user')
        gr.add_query("u_object_id",id)
        gr.query()
        user = gr.serialize() if gr.next() else False
        return user
    
    def get_request_by_sys_id(self,sys_id):
        gr = self.client.GlideRecord('sc_request')
        gr.add_query('sys_id', sys_id)
        gr.query()
        req = gr.serialize() if gr.next() else False
        return req
    
    def get_ritm_status_by_request(self,req_id):
        req = self.get_request_status(req_id)
        gr = self.client.GlideRecord('sc_req_item')
        gr.add_query('request', req['sys_id'])
        gr.query()
        req = gr.serialize() if gr.next() else False
        return req
    
    def get_request_from_ritm(self,ritm):
        gr = self.client.GlideRecord('sc_req_item')
        gr.add_query('number', ritm)
        gr.query()
        rit = gr.serialize() if gr.next() else False
        req = self.get_request_by_sys_id(rit['request'])
        return req
    
    def update_ritm(self,ritm,state,close_notes,comments):
        try:
            gr = self.client.GlideRecord('sc_req_item')
            gr.get(self.get_ritm_status(ritm)['sys_id'])
            gr.state = state        
            gr.close_notes = close_notes
            gr.comments = comments
            gr.update()
            return True
        except Exception as e:
            logging.error(f"Error updating RITM: {e}")
            return e
        
    def upload_attachment_json(self,ritm,data):
        try:
            attachment = AttachmentAPI(self.client)
            sys_id = self.get_ritm_status(ritm)['sys_id']
            attachment.upload_file('request.json','sc_req_item',sys_id,json.dumps(data).encode('UTF-8'))
            return True
        except Exception as e:
            logging.error(e)
            return False
    
    def upload_attachment_text(self,ritm,data):
        try:
            attachment = AttachmentAPI(self.client)
            sys_id = self.get_ritm_status(ritm)['sys_id']
            attachment.upload_file('request.txt','sc_req_item',sys_id,data)
            return True
        except Exception as e:
            logging.error(e)
            return False
    
    def create_change_request(self,data):
        params = self.client.table_api._set_params()
        target_url = self.instance + '/api/now/table/change_request'
        req = requests.Request('POST', target_url, params=params, json=data)
        res = self.client.table_api._send(req)
        self.client.table_api._validate_response(res)
        chg = res.json()
        return chg
    
    def get_change_status(self,chg_id):
        gr = self.client.GlideRecord('change_request')
        gr.add_query('number', chg_id)
        gr.query()
        chg = gr.serialize() if gr.next() else False
        return chg
    
    def update_change_status(self,chg_id,state,comments,close_notes=None,work_notes=None):
        try:
            gr = self.client.GlideRecord('change_request')
            gr.get('number',chg_id)
            gr.state = state        
            gr.close_notes = close_notes if close_notes else False
            gr.work_notes = work_notes if work_notes else False
            gr.comments = comments
            gr.update()
            return True
        except Exception as e:
            logging.error(f"Error updating change request: {e}")
            return e
        
    def get_ctasks_by_change(self,chg_id):
        chg = self.get_change_status(chg_id)
        gr = self.client.GlideRecord('change_task')
        gr.add_query('change_request', chg['sys_id'])
        gr.query()
        tasks = []
        while gr.next():
            tasks.append(gr.serialize())
        return tasks
    
    def update_ctask_status(self,task_id,state,assignto,close_code=None,closed_notes=None):
        try:
            gr = self.client.GlideRecord('change_task')
            gr.get('number',task_id)
            gr.state = state   
            gr.assigned_to = assignto     
            gr.close_code = close_code if close_code else False
            gr.close_notes = closed_notes
            gr.update()
            return True
        except Exception as e:
            logging.error(f'Error updating ctask {e}')
            return e
        
    def get_ctask(self,task_id):
        gr = self.client.GlideRecord('change_task')
        gr.add_query('number', task_id)
        gr.query()
        task = gr.serialize() if gr.next() else False
        return task
    
    def get_alert_status(self,alert_id):
        gr = self.client.GlideRecord('em_alert')
        gr.add_query('number', alert_id)
        gr.query()
        alert = gr.serialize() if gr.next() else False
        return alert
    
    def update_alert_status(self,alert_id,state,comments,assigned_to=None,assignment_group=None,work_notes=None,close_notes=None):
        try:
            gr = self.client.GlideRecord('em_alert')
            gr.get('number',alert_id)
            gr.state = state
            gr.comments = comments
            gr.assignment_group =  None if assignment_group == '' else False if assignment_group is None else assignment_group
            gr.assigned_to = assigned_to if assigned_to else False
            gr.work_notes = work_notes if work_notes else False
            gr.close_notes = close_notes if close_notes else False
            gr.update()
            return True
        except Exception as e:
            logging.error(f"Error updating alert: {e}")
            return False