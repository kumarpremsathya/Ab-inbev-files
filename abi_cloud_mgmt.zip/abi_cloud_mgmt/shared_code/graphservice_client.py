from msgraph import GraphServiceClient,GraphRequestAdapter
from msrestazure.azure_cloud import AZURE_CHINA_CLOUD as CHINA
from kiota_http.kiota_client_factory import KiotaClientFactory
from kiota_authentication_azure.azure_identity_authentication_provider import AzureIdentityAuthenticationProvider
from shared_code.client_secret_auth import ClientSecretAuth
import os


class GraphClient:
    def __init__(self) -> None:
        pass

    def get_graph_client(self,azenvironment):
        self.azenvironment = azenvironment
        if azenvironment=="AzurePublicCloud":
            spn_secret_name = os.environ["SPN_SECRET_PUBLIC"]
            credentials = ClientSecretAuth().client_credential(spn_secret_name)
            graph_service_client = GraphServiceClient(credentials)
        elif azenvironment=="AzureChinaCloud":
            spn_secret_name = os.environ["SPN_SECRET_CHINA"]
            credentials = ClientSecretAuth().client_credential(spn_secret_name)
            graph_service_client = GraphServiceClient(credentials,
                                                scopes=[CHINA.endpoints.resource_manager + "/.default"])
        return graph_service_client

    def get_client_request_adapter(self,azenvironment):
        self.azenvironment = azenvironment
        if azenvironment=="AzurePublicCloud":
            spn_secret_name = os.environ["SPN_SECRET_PUBLIC"]
            credentials = ClientSecretAuth().client_credential(spn_secret_name)
            auth_provider = AzureIdentityAuthenticationProvider(credentials, scopes=['https://graph.microsoft.com/.default'])
            self.http_client = KiotaClientFactory.get_default_client()
            req_adapter = GraphRequestAdapter(auth_provider,self.http_client)
            graph_service_client = GraphServiceClient(request_adapter=req_adapter)
        elif azenvironment=="AzureChinaCloud":
            spn_secret_name = os.environ["SPN_SECRET_CHINA"]
            credentials = ClientSecretAuth().client_credential(spn_secret_name)
            auth_provider = AzureIdentityAuthenticationProvider(credentials, scopes=[CHINA.endpoints.microsoft_graph_resource_id + "/.default"])
            self.http_client = KiotaClientFactory.get_default_client()
            req_adapter = GraphRequestAdapter(auth_provider,self.http_client)
            req_adapter.base_url = "https://microsoftgraph.chinacloudapi.cn/v1.0"
            graph_service_client = GraphServiceClient(request_adapter=req_adapter,
                                                        scopes=[CHINA.endpoints.microsoft_graph_resource_id + "/.default"])
        return graph_service_client
    
    async def close(self):
        await self.http_client.aclose()