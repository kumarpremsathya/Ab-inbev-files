from.constants import Constants
import asyncio,logging
from shared_code.client_secret_auth import ClientSecretAuth
from msgraph import GraphServiceClient
from msgraph.generated.users.item.send_mail.send_mail_post_request_body import SendMailPostRequestBody
from msgraph.generated.models.message import Message
from msgraph.generated.models.item_body import ItemBody
from msgraph.generated.models.recipient import Recipient
from msgraph.generated.models.email_address import EmailAddress
from msgraph.generated.models.body_type import BodyType

class Notification:
    def __init__(self):
        pass

    async def send_email_notification(self, subject,body,email_cred):
        self.email_creds = ClientSecretAuth().client_credential(email_cred)
        to_recipients_list = [Recipient(email_address=EmailAddress(address=Constants.EMAIL_TO))]
        email_body = SendMailPostRequestBody(
			message=Message(
				subject=subject,
				body=ItemBody(
					content_type=BodyType.Html,
					content=body,
				),
				to_recipients=to_recipients_list,
			),
			save_to_sent_items=True
		)
        try:
            client = GraphServiceClient(credentials=self.email_creds)
            await client.users.by_user_id(Constants.EMAIL_FROM_UID).send_mail.post(body=email_body)
        except Exception as e:
            if "Event loop is closed" in str(e):
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)                
                loop.run_until_complete(client.users.by_user_id(Constants.EMAIL_FROM_UID).send_mail.post(body=email_body))
                loop.close()
            logging.error(f"Error sending email: {e}")