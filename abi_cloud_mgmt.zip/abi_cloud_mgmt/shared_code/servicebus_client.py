import os,json,hashlib,copy
from azure.servicebus.aio import ServiceBusClient

class ServiceBusClientAbstract:

    def get_servicebus_client(self):
        servicebus_client = ServiceBusClient.from_connection_string(
            conn_str=os.environ['AzureWebJobsMyServiceBus'],logging_enable=True)
        return servicebus_client
    
    def generate_unique_key(self,json_payload):
        payload = copy.deepcopy(json_payload)
        if 'data' in payload.get('payload',{}).keys() and 'justification' in payload['payload']['data'] :
            payload['payload']['data'].pop('justification')
        json_string = json.dumps(payload,sort_keys=True,default=str)
        json_bytes = json_string.encode('utf-8')
        hash_object = hashlib.sha256(json_bytes)
        unique_key = hash_object.hexdigest()
        return unique_key