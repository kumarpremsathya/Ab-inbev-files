from datetime import datetime
from dateutil import tz,parser

class TimezoneConverter:
    def __init__(self):
        self.utc = tz.UTC

    def to_utc(self, dt, tz_name):
        """
        Converts a datetime object to UTC from given tz_name (timezone name)
        """
        if type(dt) is str:
            #dt = datetime.strptime(dt, "%Y-%m-%dT%H:%M:%S.%fZ")
            dt = parser.isoparse(dt)
        local_tz = tz.gettz(tz_name)
        local_dt = dt.replace(tzinfo=local_tz)
        utc_dt = local_dt.astimezone(self.utc)
        return utc_dt.strftime("%Y-%m-%d %H:%M:%S")

    def from_utc(self, dt, tz_name):
        """
        Converts a datetime object from UTC to given tz_name (timezone name)
        """
        if type(dt) is str:
            #dt = datetime.strptime(dt, "%Y-%m-%dT%H:%M:%S.%fZ")
            dt = parser.isoparse(dt)
        local_tz = tz.gettz(tz_name)
        local_dt = dt.astimezone(local_tz)
        return local_dt.strftime("%Y-%m-%d %H:%M:%S")