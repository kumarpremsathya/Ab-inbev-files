import requests
import json


url = "http://localhost:7071/api/test_request_receiver"


payload = {
  "ActivityType": "Request",
  "ActivityName": "KEYVAULTMGMT",
  "RequestorEmail": "merina.davis@ab-inbev.com",
  "OID": "",
  "zone": "GHQ",
  "action": "Create",
  "payload": {
    "cloud": "Azure",
    "devowners": " ",
    "justification": "Create Secret",
    "data": {
      "zone": "GHQ",
      "subscription_id": "test data",
      "subscription_name": "testing",
      "resource_group_name": "demo-rg",
      "key_vault_name": "my-keyvault",
      "secret_name": "test-secret",
      "secret_value": "fyZEF4CxPv+7XAKY1yE=",
      "iv": "vIxOGafHIvzXOFur",
      "tag": "dPvrpzBVxABgfQD7Yt3yig==", 
      "content_type": "Password",
      "expires_on": "",
      "tags": {"env": "test", "project": "keyvault"},
    }
  }
}


response = requests.post(url, json=payload)
print(f"Status: {response.status_code}")
print(f"Response: {response.text}")

#  Invoke-RestMethod -Uri "http://localhost:7071/api/test_processor"