from shared_code.db import DB
from shared_code.snow_client import SNOWClient
from shared_code.constants import Constants
import logging,json,re
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from datetime import datetime,timezone,timedelta


class CpuHighAlert:
    def __init__(self):
        self.TABLE_NAME = 'tblActivityCpuHighAlert'
        self.objdb = DB()
        self.objactivitymgr = DbActivityManager()
        self.objsnow = SNOWClient()
        self.extracted_values = {}

    def refactor_json(self,data):
        if data['SnowId'].lower().startswith("alert"):
            alert_details = self.objsnow.get_alert_status(data["SnowId"])
            state = 2
            data["description"] = json.loads(alert_details['additional_info'])['body']
            provider = json.loads(alert_details['additional_info'])['provider']
            if provider.lower() != 'azure':
                return None
        else:
            incident_details = self.objsnow.get_incident_status(data["SnowId"])
            state = incident_details['state']
            data["description"] = incident_details['description']
        self.extracted_values = self.extract_key_values(data)
        resource_group_name = self.extracted_values["resource_group_name"]
        subscription_name = self.extracted_values["subscription_name"].replace("_"," ")
        sub_data = self.objactivitymgr.get_subscription_id_zone(subscription_name)
        if not sub_data:
            logging.error(f"Subscription {subscription_name} not found in database.")
            return None
        self.extracted_values["subscription_id"] = sub_data.SubscriptionId
        self.zone = sub_data.Zone
        self.extracted_values["resource_id"] = f"/subscriptions/{self.extracted_values['subscription_id']}/resourceGroups/{self.extracted_values['resource_group_name']}/providers/Microsoft.Compute/virtualMachines/{self.extracted_values['resource']}"
        owners = self.objactivitymgr.get_owners(self.zone, resource_group_name, self.extracted_values["subscription_id"])
        owners_list = owners.Owners.split(';') if owners and owners.Owners else []
        self.incident_json = {
            "ActivityName": "CPUHIGHALERT",
            "ActivityType": "Alert",
            "RequestorEmail": owners_list[0] if owners_list else "integration.cmp",
            "SnowItemId": data["SnowId"],
            "SnowId": data["SnowId"],
            "SnowItemStatusCode": state,
            "SnowItemStatus": "Queued",
            "zone": self.zone,
            "payload": {
                "cloud": "Azure",
                "devowners": ",".join(owners_list) if owners_list else "",
                "justification": "Brewmation Auto Remediation",
                "data": {
                    "subscription_id": self.extracted_values["subscription_id"],
                    "subscription_name": self.extracted_values["subscription_name"],
                    "resource_group_name": resource_group_name,
                    "resource_id": self.extracted_values["resource_id"],
                    "resource_name": self.extracted_values["resource"],
                    "threshold": self.extracted_values["threshold"],
                    "current_usage": self.extracted_values.get("current_usage")
                }
            }
        }
        self.snow_update_alert(data["SnowId"],'Assign')
        return self.incident_json

    def extract_key_values(self,data):
        pattern_mappings = {
            "resource": r"(?i)Server:\s*([A-Za-z0-9\-\._]+)",
            "resource_group_name": r"(?i)Resource Group:\s*([A-Za-z0-9\-\._]+)",
            "subscription_name": r"(?i)Subscription Name :\s*([A-Za-z0-9\-\._]+)",
            "ip": r"(?i)IP:\s*([0-9\.]+)",
            "os": r"(?i)OS:\s*([A-Za-z0-9\-\._]+)",
            "current_usage": r"(?i)Current Usage:\s*([0-9]+(?:\.[0-9]+)?)",
            "threshold": r"(?i)critical value of\s*([0-9]+(?:\.[0-9]+)?)"
        }
        extracted_values = {}
        for key, pattern in pattern_mappings.items():
            match = re.search(pattern, data["description"])
            if match:
                extracted_values[key] = match.group(1).strip()
            else:
                extracted_values[key] = None
        if not extracted_values.get("subscription_name"):
            match = re.search(r"(?i)Subscription:\s*([A-Za-z0-9\-\._]+)", data["description"])
            if match:
                extracted_values["subscription_name"] = match.group(1).strip()
        if not extracted_values.get("threshold"):
            match = re.search(r">\s*([0-9]+(?:\.[0-9]+)?)", data["description"])
            if match:
                extracted_values["threshold"] = match.group(1).strip()
        if not extracted_values.get("threshold") and extracted_values.get("current_usage"):
            extracted_values["threshold"] = extracted_values["current_usage"]
        if not extracted_values.get("resource"):
            match = re.search(r"(?i)Server Name:\s*([A-Za-z0-9\-\._]+)", data["description"])
            if match:
                extracted_values["resource"] = match.group(1).strip()
        return extracted_values

    def snow_update_incident(self,incident_id,status):
        if status == 'Queued':
            state = '2'
            assigned_to = Constants.SNOW_ASSIGNMENT_USER
            result = self.objsnow.update_incident_status(incident_id,state,"In-Progress",assigned_to=assigned_to,work_notes="In-Progress")
        logging.info(f"Update SNOW Incident Result: {result}")
        return result

    def snow_update_alert(self,alert_id,status):
        if status == 'Success':
            state = 'Closed'
            result = self.objsnow.update_alert_status(alert_id,state,"Success",close_notes="Success")
        if status == 'Assign':
            state = 'Open'
            assigned_to = Constants.SNOW_ASSIGNMENT_USER
            result = self.objsnow.update_alert_status(alert_id,state,"Assigned",assigned_to=assigned_to,work_notes="Assigned",assignment_group=Constants.SNOW_ASSIGNMENT_GROUP)
        if status == 'Queued':
            state = 'Open'
            assigned_to = Constants.SNOW_ASSIGNMENT_USER
            result = self.objsnow.update_alert_status(alert_id,state,"In-Progress",assigned_to=assigned_to,work_notes="In-Progress")
        logging.info(f"Update SNOW Alert Result: {result}")
        return result

    def activity_data(self, dataset):
        logging.info(f"Activity data called with dataset: {dataset}")
        sql_query = """
            MERGE INTO tblActivityCpuHighAlert as Target
            USING (SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            AS SOURCE(EventId, SubscriptionId, SubscriptionName, ResourceGroupName, ResourceName, ResourceId, Threshold, Zone, Status, RunCommand, RetryAttemptedAt)
            ON Target.EventId = Source.EventId
            AND Target.SubscriptionId = Source.SubscriptionId
            AND Target.ResourceId = Source.ResourceId
            AND Target.Status = 'In-Progress'
            WHEN NOT MATCHED THEN
            INSERT (EventId, SubscriptionId, SubscriptionName, ResourceGroupName, ResourceName, ResourceId, Threshold, Zone, Status, RunCommand, RetryAttemptedAt)
            VALUES (Source.EventId, Source.SubscriptionId, Source.SubscriptionName, Source.ResourceGroupName, Source.ResourceName, Source.ResourceId, Source.Threshold, Source.Zone, Source.Status, Source.RunCommand, Source.RetryAttemptedAt);
        """

        payload = json.loads(dataset.Payload)
        values = (
            dataset.EventId,
            payload['data']["subscription_id"],
            payload['data']["subscription_name"],
            payload['data']["resource_group_name"],
            payload['data']["resource_name"],
            payload['data']["resource_id"],
            payload['data']["threshold"],
            dataset.Zone,
            "In-Progress",
            None,  # RunCommand - to be populated later with remediation command
            datetime.now(timezone.utc)  # RetryAttemptedAt
        )
        self.objdb.executescalar(
            sql_query=sql_query, action="insert", values=values
        )
        self.objactivitymgr.insert_activity_pending(dataset)
        self.snow_update_incident(dataset.SnowItemId,'Queued')
