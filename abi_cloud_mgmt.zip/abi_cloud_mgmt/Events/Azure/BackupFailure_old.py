# from RequestProcessor.DAL.DbActivityManager import DbActivityManager
# from shared_code.resourcegraph_client import ResourceGraph
# import azure.mgmt.resourcegraph as arg
# from shared_code.db import DB
# from shared_code.snow_client import SNOWClient
# from shared_code.constants import Constants
# from datetime import datetime,timezone
# import logging,json,re
# import asyncio
# from shared_code.EmailNotification.NotifyUserIncident import NotifyUserIncident


# class BackupFailure:
#     def __init__(self):
#         self.TABLE_NAME = 'tblActivityBackupFailure'
#         self.objdb = DB()
#         self.objactivitymgr = DbActivityManager()
#         self.extracted_values = {}
#         self.objsnow = SNOWClient()


#     def refactor_json(self,data):
#         incident_details = self.objsnow.get_incident_status(data["SnowId"])
        
#         logging.info(f"\n\n[DEBUG] incident_details type: {type(incident_details)}")
#         logging.info(f"[DEBUG] incident_details value: {incident_details}")
        
#         data["description"] = incident_details['description']
#         data["html_description"] = incident_details.get('u_soc_team_description', '')
#         self.extracted_values = self.extract_key_values(data)
#         resource_group_name = self.extracted_values["resource_id"].split("/")[4]
#         self.zone = self.objactivitymgr.get_zone(self.extracted_values["subscription_id"])
#         owners = self.objactivitymgr.get_owners(self.zone, resource_group_name, self.extracted_values["subscription_id"])
#         owners_list = owners.Owners.split(';') if owners and owners.Owners else []
#         self.incident_json = {
#             "ActivityName": "BACKUPFAILURE",
#             "ActivityType": "Incident",
#             "RequestorEmail": owners_list[0] if owners_list else "",
#             "SnowItemId": data["SnowId"],
#             "SnowId": data["SnowId"],
#             "SnowItemStatusCode": incident_details['state'],
#             "SnowItemStatus": "Queued",
#             "zone": self.zone,
#             "payload": {
#                 "cloud": "Azure",
#                 "devowners": ",".join(owners_list) if owners_list else "",
#                 "justification": "Brewmation Auto Remediation",
#                 "data": {
#                     "subscription_id": self.extracted_values["subscription_id"],
#                     "subscription_name": self.extracted_values["subscription_name"],
#                     "resource_group_name": resource_group_name,
#                     "resource_id": self.extracted_values["resource_id"],
#                     "recovery_vault_id": self.extracted_values["backup_vault_id"]
#                 }
#             }
#         }
#         recommendations,error_code = self.get_backup_health()
        
#         # FOR TESTING: Log all results regardless of recommendations
#         logging.info(f"\n\n\n[TEST MODE] recommendations: {recommendations}, error_code: {error_code}")
#         # if recommendations:
#         #     self.incident_json["Recommendations"] = self.get_recommendations(error_code)
#         #     # self.snow_update_incident(data["SnowId"],'Assign')
#         #     return self.incident_json
#         # return None
    

        
#         # if recommendations:
#         #     self.incident_json["Recommendations"] = "; ".join(recommendations) if isinstance(recommendations, list) else recommendations
            
#         #     # Send email notification
#         #     email_event = {
#         #         "EventId": data["SnowId"],
#         #         "ActivityName": "BACKUPFAILURE",
#         #         "SnowItemId": data["SnowId"],
#         #         "Status": "Queued",
#         #         "Recommendations": recommendations
#         #     }
#         #     try:
#         #         asyncio.ensure_future(
#         #             NotifyUserIncident().send_email_notification(email_event, toemail=["Prem.Kumar-ext3@ab-Inbev.com"])
#         #         )
#         #     except Exception as e:
#         #         logging.error(f"Error sending backup failure email: {e}")
            
#         #     return self.incident_json
#         # return None

#         if recommendations:
        
#             # Unhandled error code - use Azure's own recommendation text
#             # self.incident_json["Recommendations"] = "; ".join(recommendations) if isinstance(recommendations, list) else recommendations
#             self.incident_json["payload"]["data"]["error_code"] = error_code
#             self.incident_json["payload"]["data"]["recommendations"] = recommendations
            
#             # self.snow_update_incident(data["SnowId"],'Assign')
#             return self.incident_json
#         return None



#     def get_backup_health(self):
#         azenvironment = "AzurePublicCloud" if self.zone.lower() != "china" else "AzureChinaCloud"
#         argClient = ResourceGraph().get_resorce_graph(azenvironment)
#         argQueryOptions = arg.models.QueryRequestOptions(result_format="objectArray")
#         # strQuery = f"""
#         #     RecoveryServicesResources 
#         #     | where type in~ ('Microsoft.RecoveryServices/vaults/backupFabrics/protectionContainers/protectedItems')
#         #     | extend vaultName = case(type =~ 'microsoft.dataprotection/backupVaults/backupInstances',split(split(id, '/Microsoft.DataProtection/backupVaults/')[1],'/')[0],type =~ 'Microsoft.RecoveryServices/vaults/backupFabrics/protectionContainers/protectedItems',split(split(id, '/Microsoft.RecoveryServices/vaults/')[1],'/')[0],'--')
#         #     | extend dataSourceType = case(type=~'Microsoft.RecoveryServices/vaults/backupFabrics/protectionContainers/protectedItems',properties.backupManagementType,type =~ 'microsoft.dataprotection/backupVaults/backupInstances',properties.dataSourceSetInfo.datasourceType,'--')
#         #     | where properties.dataSourceSetInfo.resourceID =~ '{self.extracted_values["resource_id"]}'
#         #     | extend details = properties.healthDetails
#         # """
        
#         vault_name = self.extracted_values["resource_id"].split("/")[-1] if self.extracted_values["resource_id"] else ""
#         vm_name = self.extracted_values["resource"] if self.extracted_values["resource"] else ""
        
#         logging.info(f"[DEBUG] Querying vault: {vault_name}, vm: {vm_name}")
        
#         strQuery = f"""
#             RecoveryServicesResources 
#             | where type in~ ('Microsoft.RecoveryServices/vaults/backupFabrics/protectionContainers/protectedItems')
#             | extend vaultName = split(split(id, '/Microsoft.RecoveryServices/vaults/')[1],'/')[0]
#             | where vaultName =~ '{vault_name}'
#             | where properties.friendlyName =~ '{vm_name}'
#             | extend details = properties.healthDetails
#          """

#         argQuery = arg.models.QueryRequest(query=strQuery, options=argQueryOptions)
#         argResults = argClient.resources(argQuery)
#         result = argResults.as_dict()
#         logging.info(f"\n\n\n[DEBUG] Resource Graph result: {json.dumps(result, indent=2)}")
#         while("skip_token" in result.keys() and result["skip_token"]!= None):
#             argQueryOptions = arg.models.QueryRequestOptions(skip_token=result["skip_token"],result_format="objectArray")
#             argQuery = arg.models.QueryRequest(query=strQuery, options=argQueryOptions)
#             argResults = argClient.resources(argQuery).as_dict()
#             result["count"] += argResults["count"]
#             result["data"] += argResults["data"]
#             result["skip_token"] = argResults["skip_token"] if "skip_token" in argResults.keys() else None
#         for vm in result["data"]:
#             for detail in vm["details"]:

#                 logging.info(f"\n\n\n[TEST MODE] Error code found: {detail['code']}")
#                 logging.info(f"[TEST MODE] Full detail: {detail}")
#                 # if detail["code"] in self.enabled_errorcodes:
#                 #     logging.info(f"Backup Failure found for Resource ID: {self.extracted_values['resource_id']} with Error Code: {detail['code']}")
                
#                     #   logging.info(f"Backup Failure Detail: {detail}")
#                     #   return detail["recommendations"], detail["code"]
#                 logging.info(f"Backup Failure Detail: {detail}")
#                 return detail["recommendations"], detail["code"]
#         logging.info(f"No Backup Failure found for Resource ID: {self.extracted_values['resource_id']}")
#         return False,False

#     def extract_key_values(self,data):
#         pattern_mappings = {
#             "resource": r"Resource:\s*([A-Za-z0-9\-_]+)",
#             "resource_id": r"ResourceID:\s*(/subscriptions/[A-Fa-f0-9\-]+/resourcegroups/[A-Za-z0-9\-_]+/providers/[A-Za-z0-9\.\-/]+)",
#             "backup_vault_id": r"Vault ID:\s*(/subscriptions/[A-Fa-f0-9\-]+/resourcegroups/[A-Za-z0-9\-_]+/providers/[A-Za-z0-9\.\-/]+)",
#             "subscription_name": r"Subscription:\s*([A-Za-z0-9\-\s]+)\n\n",
#             "subscription_id": r"/subscriptions/([A-Fa-f0-9\-]+)"
#         }
#         extracted_values = {}
#         for key, pattern in pattern_mappings.items():
#             match = re.search(pattern, data["description"])
#             if match:
#                 extracted_values[key] = match.group(1).strip()
#             else:
#                 extracted_values[key] = None

#         # If resource_id not found in plain text, try HTML format (u_soc_team_description)
#         html_desc = data.get("html_description", "")
#         if not extracted_values.get("resource_id") and html_desc:
#             html_patterns = {
#                 "resource": r'<strong>resource</strong>.*?<div>\s*([^<\n]+?)\s*</div>',
#                 "resource_id": r'<strong>resource</strong>.*?<div>\s*(/subscriptions/[A-Fa-f0-9\-]+/resourceGroups/[^\s<]+)\s*</div>',
#                 "subscription_id": r'<strong>azureSubscriptionId</strong>.*?<div>\s*([A-Fa-f0-9\-]{36})\s*</div>',
#                 "subscription_name": r'<strong>Azure Subscription Name</strong>.*?<div>\s*([^<\n]+?)\s*</div>',
#             }
#             for key, pattern in html_patterns.items():
#                 match = re.search(pattern, html_desc, re.DOTALL)
#                 if match:
#                     extracted_values[key] = match.group(1).strip()
            
#             # Extract resource (VM name) from resource_id path
#             if extracted_values.get("resource_id"):
#                 extracted_values["resource"] = extracted_values["resource_id"].split("/")[-1]

#         logging.info(f"\n\n\nExtracted values: {extracted_values}")
#         return extracted_values

#     def snow_update_incident(self,incident_id,status):
#         if status == 'Success':
#             state = '6'
#             result = self.objsnow.update_incident_status(incident_id,state,"Success",close_notes="Success")
#         if status == 'Assign':
#             state = '2'
#             assigned_to = Constants.SNOW_ASSIGNMENT_USER
#             result = self.objsnow.update_incident_status(incident_id,state,"Assigned",assigned_to=assigned_to,work_notes="Assigned")
#         if status == 'Queued':
#             state = '2'
#             assigned_to = Constants.SNOW_ASSIGNMENT_USER
#             result = self.objsnow.update_incident_status(incident_id,state,"In-Progress",assigned_to=assigned_to,work_notes="In-Progress")
#         logging.info(f"Update SNOW Incident Result: {result}")
#         return result
    
#     def activity_data(self, dataset):
#         logging.info(f"Activity data called with dataset: {dataset}")
#         sql_query = """
#             MERGE INTO tblActivityBackupFailure as Target
#             USING (SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
#             AS SOURCE(EventId, SubscriptionId, SubscriptionName, , ResourceGroupName, ResourceName, ResourceId, VaultName, Zone, Status, RetryAttemptedAt)
#             ON Target.EventId = Source.EventId
#             AND Target.SubscriptionId = Source.SubscriptionId
#             AND Target.ResourceId = Source.ResourceId
#             AND Target.VaultName = Source.VaultName
#             AND Target.Status = 'In-Progress'
#             WHEN NOT MATCHED THEN
#             INSERT (EventId, SubscriptionId, SubscriptionName, ResourceGroupName, ResourceName, ResourceId, VaultName, Zone, Status, RetryAttemptedAt)
#             VALUES (Source.EventId, Source.SubscriptionId, Source.SubscriptionName, Source.ResourceGroupName, Source.ResourceName, Source.ResourceId, Source.VaultName, Source.Zone, Source.Status, Source.RetryAttemptedAt);
#         """

#         payload = json.loads(dataset.Payload)
#         values = (
#             dataset.EventId,
#             payload['data']["subscription_id"],
#             payload['data']["subscription_name"],
#             payload['data']["resource_group_name"],
#             payload['data']["resource_name"],
#             payload['data']["resource_id"],
#             dataset.Zone,
#             "In-Progress",
#             datetime.now(timezone.utc)  # RetryAttemptedAt
#         )
#         self.objdb.executescalar(
#             sql_query=sql_query, action="insert", values=values
#         )
#         self.objactivitymgr.insert_activity_pending(dataset)
#         self.snow_update_incident(dataset.SnowItemId,'Queued')




from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from shared_code.resourcegraph_client import ResourceGraph
import azure.mgmt.resourcegraph as arg
from shared_code.db import DB
from shared_code.snow_client import SNOWClient
from shared_code.constants import Constants
from datetime import datetime,timezone
import logging,json,re


class BackupFailure:
    def __init__(self):
        self.TABLE_NAME = 'tblActivityBackupFailure'
        self.objdb = DB()
        self.objactivitymgr = DbActivityManager()
        self.extracted_values = {}
        self.objsnow = SNOWClient()
     

    def refactor_json(self,data):
        incident_details = self.objsnow.get_incident_status(data["SnowId"])

        logging.info(f"\n\n[DEBUG] incident_details type: {type(incident_details)}")
        logging.info(f"[DEBUG] incident_details value: {incident_details}")

        data["description"] = incident_details['description']
        self.extracted_values = self.extract_key_values(data)
        resource_group_name = self.extracted_values["resource_id"].split("/")[4]
        self.zone = self.objactivitymgr.get_zone(self.extracted_values["subscription_id"])
        owners = self.objactivitymgr.get_owners(self.zone, resource_group_name, self.extracted_values["subscription_id"])
        owners_list = owners.Owners.split(';') if owners and owners.Owners else []
        self.incident_json = {
            "ActivityName": "BACKUPFAILURE",
            "ActivityType": "Incident",
            "RequestorEmail": owners_list[0] if owners_list else "",
            "SnowItemId": data["SnowId"],
            "SnowId": data["SnowId"],
            # "SnowItemStatusCode": incident_details['state'],
            "SnowItemStatusCode": 2,
            "SnowItemStatus": "Queued",
            "zone": self.zone,
            "payload": {
                "cloud": "Azure",
                "devowners": ",".join(owners_list) if owners_list else "",
                "justification": "Brewmation Auto Remediation",
                "data": {
                    "subscription_id": self.extracted_values["subscription_id"],
                    "subscription_name": self.extracted_values["subscription_name"],
                    "resource_group_name": resource_group_name,
                    "resource_id": self.extracted_values["resource_id"],
                    "resource_name": self.extracted_values["resource"],   # ← add 
                    "recovery_vault_id": self.extracted_values["backup_vault_id"]
                }
            }
        }
        
        recommendations = self.get_backup_health()
        
        if recommendations:
            self.incident_json["payload"]["data"]["error_code"] = recommendations["code"]
            self.incident_json["payload"]["data"]["error_message"] = recommendations["message"]
            self.incident_json["payload"]["data"]["error_title"] = recommendations["title"]
            self.incident_json["payload"]["data"]["recommendations"] = "; ".join(recommendations["recommendations"]) if isinstance(recommendations["recommendations"], list) else recommendations["recommendations"]
            
            # self.snow_update_incident(data["SnowId"],'Assign')

            return self.incident_json
        return None
    

    def get_backup_health(self):
        # TEMP TEST - remove after testing
        # return {
        #     "recommendations": ["Check VM disk space"],
        #     "code": 999999,
        #     "message": "Some Azure message",
        #     "title": "UnknownErrorTitle"
        # }

        azenvironment = "AzurePublicCloud" if self.zone.lower() != "china" else "AzureChinaCloud"
        argClient = ResourceGraph().get_resorce_graph(azenvironment)
        argQueryOptions = arg.models.QueryRequestOptions(result_format="objectArray")
        # strQuery = f"""
        #     RecoveryServicesResources 
        #     | where type in~ ('Microsoft.RecoveryServices/vaults/backupFabrics/protectionContainers/protectedItems')
        #     | extend vaultName = case(type =~ 'microsoft.dataprotection/backupVaults/backupInstances',split(split(id, '/Microsoft.DataProtection/backupVaults/')[1],'/')[0],type =~ 'Microsoft.RecoveryServices/vaults/backupFabrics/protectionContainers/protectedItems',split(split(id, '/Microsoft.RecoveryServices/vaults/')[1],'/')[0],'--')
        #     | extend dataSourceType = case(type=~'Microsoft.RecoveryServices/vaults/backupFabrics/protectionContainers/protectedItems',properties.backupManagementType,type =~ 'microsoft.dataprotection/backupVaults/backupInstances',properties.dataSourceSetInfo.datasourceType,'--')
        #     | where properties.dataSourceSetInfo.resourceID =~ '{self.extracted_values["resource_id"]}'
        #     | extend details = properties.healthDetails
        # """
    
        vault_name = self.extracted_values["resource_id"].split("/")[-1] if self.extracted_values["resource_id"] else ""
        vm_name = self.extracted_values["resource"] if self.extracted_values["resource"] else ""
        
        logging.info(f"[DEBUG] Querying vault: {vault_name}, vm: {vm_name}")

        strQuery = f"""
            RecoveryServicesResources 
            | where type in~ ('Microsoft.RecoveryServices/vaults/backupFabrics/protectionContainers/protectedItems')
            | extend vaultName = split(split(id, '/Microsoft.RecoveryServices/vaults/')[1],'/')[0]
            | where vaultName =~ '{vault_name}'
            | where properties.friendlyName =~ '{vm_name}'
            | extend details = properties.healthDetails
         """

        argQuery = arg.models.QueryRequest(query=strQuery, options=argQueryOptions)
        argResults = argClient.resources(argQuery)
        result = argResults.as_dict()
        logging.info(f"\n\n\n[DEBUG] Resource Graph result: {json.dumps(result, indent=2)}")
        while("skip_token" in result.keys() and result["skip_token"]!= None):
            argQueryOptions = arg.models.QueryRequestOptions(skip_token=result["skip_token"],result_format="objectArray")
            argQuery = arg.models.QueryRequest(query=strQuery, options=argQueryOptions)
            argResults = argClient.resources(argQuery).as_dict()
            result["count"] += argResults["count"]
            result["data"] += argResults["data"]
            result["skip_token"] = argResults["skip_token"] if "skip_token" in argResults.keys() else None
        for vm in result["data"]:
            for detail in vm["details"]:
            
                logging.info(f"Backup Failure found for Resource ID: {self.extracted_values['resource_id']} with Error Code: {detail['code']}")
                logging.info(f"Backup Failure Detail: {detail}")
                return {
                        "recommendations": detail["recommendations"],
                        "code": detail["code"],
                        "message": detail.get("message", ""),
                        "title": detail.get("title", "")
                    }
        logging.info(f"No Backup Failure found for Resource ID: {self.extracted_values['resource_id']}")
        return None

    def extract_key_values(self,data):
        pattern_mappings = {
            "resource": r"Resource:\s*([A-Za-z0-9\-_]+)",
            "resource_id": r"ResourceID:\s*(/subscriptions/[A-Fa-f0-9\-]+/resourcegroups/[A-Za-z0-9\-_]+/providers/[A-Za-z0-9\.\-/]+)",
            "backup_vault_id": r"Vault ID:\s*(/subscriptions/[A-Fa-f0-9\-]+/resourcegroups/[A-Za-z0-9\-_]+/providers/[A-Za-z0-9\.\-/]+)",
            "subscription_name": r"Subscription:\s*([A-Za-z0-9\-\s]+)\n\n",
            "subscription_id": r"/subscriptions/([A-Fa-f0-9\-]+)"
        }
        extracted_values = {}
        for key, pattern in pattern_mappings.items():
            match = re.search(pattern, data["description"])
            if match:
                extracted_values[key] = match.group(1).strip()
            else:
                extracted_values[key] = None
        return extracted_values

    def snow_update_incident(self,incident_id,status):
        if status == 'Success':
            state = '6'
            result = self.objsnow.update_incident_status(incident_id,state,"Success",close_notes="Success")
        if status == 'Assign':
            state = '2'
            assigned_to = Constants.SNOW_ASSIGNMENT_USER
            result = self.objsnow.update_incident_status(incident_id,state,"Assigned",assigned_to=assigned_to,work_notes="Assigned")
        if status == 'Queued':
            state = '2'
            assigned_to = Constants.SNOW_ASSIGNMENT_USER
            result = self.objsnow.update_incident_status(incident_id,state,"In-Progress",assigned_to=assigned_to,work_notes="In-Progress")
        logging.info(f"Update SNOW Incident Result: {result}")
        return result
    
    def activity_data(self, dataset):
        logging.info(f"Activity data called with dataset: {dataset}")
        sql_query = """
            MERGE INTO tblActivityBackupFailure as Target
            USING (SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            AS SOURCE(EventId, SubscriptionId, SubscriptionName, ResourceGroupName, ResourceName, ResourceId, VaultName, Zone, ErrorCode, ErrorMessage, ErrorTitle, Recommendations, Status, RetryAttemptedAt)
            ON Target.EventId = Source.EventId
            AND Target.SubscriptionId = Source.SubscriptionId
            AND Target.ResourceId = Source.ResourceId
            AND Target.VaultName = Source.VaultName
            AND Target.Status = 'In-Progress'
            WHEN NOT MATCHED THEN
            INSERT (EventId, SubscriptionId, SubscriptionName, ResourceGroupName, ResourceName, ResourceId, VaultName, Zone, ErrorCode, ErrorMessage, ErrorTitle, Recommendations, Status, RetryAttemptedAt)
            VALUES (Source.EventId, Source.SubscriptionId, Source.SubscriptionName, Source.ResourceGroupName, Source.ResourceName, Source.ResourceId, Source.VaultName, Source.Zone, Source.ErrorCode, Source.ErrorMessage, Source.ErrorTitle, Source.Recommendations, Source.Status, Source.RetryAttemptedAt);
        """
    
        payload = json.loads(dataset.Payload)
        values = (
            dataset.EventId,
            payload['data']["subscription_id"],
            payload['data']["subscription_name"],
            payload['data']["resource_group_name"],
            payload['data']["resource_name"],
            payload['data']["resource_id"],
            payload['data']["resource_id"].split("/")[-1],
            dataset.Zone,
            payload['data'].get("error_code"),
            payload['data'].get("error_message"),
            payload['data'].get("error_title"),
            payload['data'].get("recommendations"),
            "In-Progress",
            datetime.now(timezone.utc)
        )
        self.objdb.executescalar(
            sql_query=sql_query, action="insert", values=values
        )
        self.objactivitymgr.insert_activity_pending(dataset)