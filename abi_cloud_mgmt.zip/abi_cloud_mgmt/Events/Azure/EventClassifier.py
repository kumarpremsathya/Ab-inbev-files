
from Events.Azure.BackupFailure import BackupFailure
from Events.Azure.DiskCleanup import DiskCleanup
from Events.Azure.CpuHighAlert import CpuHighAlert
from Events.Azure.MemoryHighAlert import MemoryHighAlert
import json

class EventClassifier:
    def __init__(self):
        pass

    def classify_event(self,data):
        if data['ActivityType'].lower() == 'incident':
            match data["category"]:
                case "Backup Failed":
                    return BackupFailure().refactor_json(data)
                case "Filesystem High Alert":
                    return DiskCleanup().refactor_json(data)
                case "cpu_high_alert":
                    return CpuHighAlert().refactor_json(data)
                case "memory_high_alert":
                    return MemoryHighAlert().refactor_json(data)
                case _:
                    return None
        elif data['ActivityType'].lower() == 'alert':
            match data["metric"]:
                case "system.disk.in_use":
                    return DiskCleanup().refactor_json(data)
                case "system.cpu.idle":
                    return CpuHighAlert().refactor_json(data)
                case "system.mem.pct_usable":
                    return MemoryHighAlert().refactor_json(data)
                case _:
                    return None