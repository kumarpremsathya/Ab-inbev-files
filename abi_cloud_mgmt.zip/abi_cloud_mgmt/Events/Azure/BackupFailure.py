from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from shared_code.resourcegraph_client import ResourceGraph
import azure.mgmt.resourcegraph as arg
from shared_code.db import DB
from shared_code.snow_client import SNOWClient
from shared_code.constants import Constants
from datetime import datetime,timezone
import logging,json,re


class BackupFailure:
    def __init__(self):
        self.TABLE_NAME = 'tblActivityBackupFailure'
        self.objdb = DB()
        self.objactivitymgr = DbActivityManager()
        self.extracted_values = {}
        self.objsnow = SNOWClient()
     
     
    def refactor_json(self,data):
        if data['SnowId'].lower().startswith("alert"):
            alert_details = self.objsnow.get_alert_status(data["SnowId"])
            state = 2
            data["description"] = json.loads(alert_details['additional_info'])['body']
            provider = json.loads(alert_details['additional_info'])['provider']
            if provider.lower() != 'azure':
                return None
        else:
            incident_details = self.objsnow.get_incident_status(data["SnowId"])
            state = incident_details['state']
            data["description"] = incident_details['description']
        self.extracted_values = self.extract_key_values(data)
        self.subscription_details = self.objactivitymgr.get_subscription_id_zone(self.extracted_values["subscription_name"])
        self.zone = self.subscription_details.Zone
        self.subscription_id = self.subscription_details.SubscriptionId
        self.resource_id = self.objactivitymgr.get_resource_id(self.extracted_values["subscription_name"], self.extracted_values["resource"])
        self.resource_group_name = self.resource_id.split("/")[4]
        owners = self.objactivitymgr.get_owners(self.zone, self.resource_group_name, self.subscription_id)
        owners_list = owners.Owners.split(';') if owners and owners.Owners else []
        self.incident_json = {
            "ActivityName": "BACKUPFAILURE",
            "ActivityType": "Alert",
            "RequestorEmail": owners_list[0] if owners_list else "",
            "SnowItemId": data["SnowId"],
            "SnowId": data["SnowId"],
            "SnowItemStatusCode": state,
            "SnowItemStatus": "Queued",
            "zone": self.zone,
            "payload": {
                "cloud": "Azure",
                "devowners": ",".join(owners_list) if owners_list else "",
                "justification": "Brewmation Auto Remediation",
                "data": {
                    "subscription_id": self.subscription_id,
                    "subscription_name": self.extracted_values["subscription_name"],
                    "resource_group_name": self.resource_group_name,
                    "resource_id": self.resource_id,
                    "resource_name": self.extracted_values["resource"],   # ← add 
                    "recovery_vault_id": self.extracted_values["backup_vault_id"]
                }
            }
        }
        
        recommendations = self.get_backup_health()
        
        if recommendations:
            self.incident_json["payload"]["data"]["error_code"] = recommendations["code"]
            self.incident_json["payload"]["data"]["error_message"] = recommendations["message"]
            self.incident_json["payload"]["data"]["error_title"] = recommendations["title"]
            self.incident_json["payload"]["data"]["recommendations"] = "; ".join(recommendations["recommendations"]) if isinstance(recommendations["recommendations"], list) else recommendations["recommendations"]
            
            self.snow_update_alert(data["SnowId"],'Assign')
            return self.incident_json
        return None
    

    def get_backup_health(self):
        azenvironment = "AzurePublicCloud" if self.zone.lower() != "china" else "AzureChinaCloud"
        argClient = ResourceGraph().get_resorce_graph(azenvironment)
        argQueryOptions = arg.models.QueryRequestOptions(result_format="objectArray")
        strQuery = f"""
            RecoveryServicesResources 
            | where type in~ ('Microsoft.RecoveryServices/vaults/backupFabrics/protectionContainers/protectedItems')
            | extend vaultName = case(type =~ 'microsoft.dataprotection/backupVaults/backupInstances',split(split(id, '/Microsoft.DataProtection/backupVaults/')[1],'/')[0],type =~ 'Microsoft.RecoveryServices/vaults/backupFabrics/protectionContainers/protectedItems',split(split(id, '/Microsoft.RecoveryServices/vaults/')[1],'/')[0],'--')
            | extend dataSourceType = case(type=~'Microsoft.RecoveryServices/vaults/backupFabrics/protectionContainers/protectedItems',properties.backupManagementType,type =~ 'microsoft.dataprotection/backupVaults/backupInstances',properties.dataSourceSetInfo.datasourceType,'--')
            | where properties.dataSourceSetInfo.resourceID =~ '{self.resource_id}'
            | extend details = properties.healthDetails
        """

        argQuery = arg.models.QueryRequest(query=strQuery, options=argQueryOptions)
        argResults = argClient.resources(argQuery)
        result = argResults.as_dict()
        while("skip_token" in result.keys() and result["skip_token"]!= None):
            argQueryOptions = arg.models.QueryRequestOptions(skip_token=result["skip_token"],result_format="objectArray")
            argQuery = arg.models.QueryRequest(query=strQuery, options=argQueryOptions)
            argResults = argClient.resources(argQuery).as_dict()
            result["count"] += argResults["count"]
            result["data"] += argResults["data"]
            result["skip_token"] = argResults["skip_token"] if "skip_token" in argResults.keys() else None
        for vm in result["data"]:
            for detail in vm["details"]:
                logging.info(f"Backup Failure found for Resource ID: {self.resource_id} with Error Code: {detail['code']}")
                logging.info(f"Backup Failure Detail: {detail}")
                return {
                        "recommendations": detail["recommendations"],
                        "code": detail["code"],
                        "message": detail.get("message", ""),
                        "title": detail.get("title", "")
                    }
        logging.info(f"No Backup Failure found for Resource ID: {self.resource_id}")
        return None

    def extract_key_values(self,data):
        pattern_mappings = {
            "resource": r"Resource:\s*([A-Za-z0-9\-_]+)",
            "backup_vault_id": r"ResourceID:\s*(/subscriptions/[A-Fa-f0-9\-]+/resourcegroups/[A-Za-z0-9\-_]+/providers/[A-Za-z0-9\.\-/]+)",
            # "backup_vault_id": r"Vault ID:\s*(/subscriptions/[A-Fa-f0-9\-]+/resourcegroups/[A-Za-z0-9\-_]+/providers/[A-Za-z0-9\.\-/]+)",
            "subscription_name": r"Subscription:\s*([A-Za-z0-9\-\s]+)\n\n",
            "subscription_id": r"/subscriptions/([A-Fa-f0-9\-]+)"
        }
        extracted_values = {}
        for key, pattern in pattern_mappings.items():
            match = re.search(pattern, data["description"])
            if match:
                extracted_values[key] = match.group(1).strip()
            else:
                extracted_values[key] = None
        return extracted_values

    def snow_update_incident(self,incident_id,status):
        if status == 'Success':
            state = '6'
            result = self.objsnow.update_incident_status(incident_id,state,"Success",close_notes="Success")
        if status == 'Assign':
            state = '2'
            assigned_to = Constants.SNOW_ASSIGNMENT_USER
            result = self.objsnow.update_incident_status(incident_id,state,"Assigned",assigned_to=assigned_to,work_notes="Assigned")
        if status == 'Queued':
            state = '2'
            assigned_to = Constants.SNOW_ASSIGNMENT_USER
            result = self.objsnow.update_incident_status(incident_id,state,"In-Progress",assigned_to=assigned_to,work_notes="In-Progress")
        logging.info(f"Update SNOW Incident Result: {result}")
        return result

    def snow_update_alert(self,alert_id,status):
        if status == 'Success':
            state = 'Closed'
            result = self.objsnow.update_alert_status(alert_id,state,"Success",close_notes="Success")
        if status == 'Assign':
            state = 'Open'
            assigned_to = Constants.SNOW_ASSIGNMENT_USER
            result = self.objsnow.update_alert_status(alert_id,state,"Assigned",assigned_to=assigned_to,work_notes="Assigned",assignment_group=Constants.SNOW_ASSIGNMENT_GROUP)
        if status == 'Queued':
            state = 'Open'
            assigned_to = Constants.SNOW_ASSIGNMENT_USER
            result = self.objsnow.update_alert_status(alert_id,state,"In-Progress",assigned_to=assigned_to,work_notes="In-Progress")
        logging.info(f"Update SNOW Alert Result: {result}")
        return result
    
    def activity_data(self, dataset):
        logging.info(f"Activity data called with dataset: {dataset}")
        sql_query = """
            MERGE INTO tblActivityBackupFailure as Target
            USING (SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            AS SOURCE(EventId, SubscriptionId, SubscriptionName, ResourceGroupName, ResourceName, ResourceId, VaultName, Zone, ErrorCode, ErrorMessage, ErrorTitle, Recommendations, Status, RetryAttemptedAt)
            ON Target.EventId = Source.EventId
            AND Target.SubscriptionId = Source.SubscriptionId
            AND Target.ResourceId = Source.ResourceId
            AND Target.VaultName = Source.VaultName
            AND Target.Status = 'In-Progress'
            WHEN NOT MATCHED THEN
            INSERT (EventId, SubscriptionId, SubscriptionName, ResourceGroupName, ResourceName, ResourceId, VaultName, Zone, ErrorCode, ErrorMessage, ErrorTitle, Recommendations, Status, RetryAttemptedAt)
            VALUES (Source.EventId, Source.SubscriptionId, Source.SubscriptionName, Source.ResourceGroupName, Source.ResourceName, Source.ResourceId, Source.VaultName, Source.Zone, Source.ErrorCode, Source.ErrorMessage, Source.ErrorTitle, Source.Recommendations, Source.Status, Source.RetryAttemptedAt);
        """
    
        payload = json.loads(dataset.Payload)
        values = (
            dataset.EventId,
            payload['data']["subscription_id"],
            payload['data']["subscription_name"],
            payload['data']["resource_group_name"],
            payload['data']["resource_name"],
            payload['data']["resource_id"],
            payload['data']["resource_id"].split("/")[-1],
            dataset.Zone,
            payload['data'].get("error_code"),
            payload['data'].get("error_message"),
            payload['data'].get("error_title"),
            payload['data'].get("recommendations"),
            "In-Progress",
            datetime.now(timezone.utc)
        )
        self.objdb.executescalar(
            sql_query=sql_query, action="insert", values=values
        )
        self.objactivitymgr.insert_activity_pending(dataset)
        self.snow_update_incident(dataset.SnowItemId,'Queued')