import json,logging
from RequestProcessor.ActivityType.CompletedActivity import CompletedActivity
from RequestProcessor.ActivityType.PendingActivity import PendingActivity
from RequestProcessor.ActivityType.NewActivity import NewActivity

class RequestProcessor:
    def __init__(self) -> None:
        pass

    async def process_request(self):
        logging.info(f"\n\n\n[FLOW-8] process_request called")
        
        # await NewActivity().check_db_for_new_activity()      
        await PendingActivity().get_next_pending_activity()
        # await CompletedActivity().cleanup_completed_activity()
        