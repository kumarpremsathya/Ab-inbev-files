from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from ServiceNow.SnowRequest import SnowRequest
from ServiceNow.SnowIncident import SnowIncident
from ServiceNow.SnowChangeRequest import SnowChangeRequest
from shared_code.EmailNotification.NotifyUser import NotifyUser
from shared_code.EmailNotification.NotifyUserIncident import NotifyUserIncident
from shared_code.notification import Notification
from shared_code.constants import Constants
import logging,os

class CompletedActivity:
    def __init__(self) -> None:
        self.objactivitymgr = DbActivityManager()
        self.objreqseq = SnowRequest()
        self.objincseq = SnowIncident()
        self.objchgseq = SnowChangeRequest()
    
    async def cleanup_completed_activity(self):
        datasets = self.objactivitymgr.get_activity_completed() # Completed Table
        for dataset in datasets:
            try:
                match dataset.ActivityType:
                    case 'Alert':
                        status = self.objincseq.snow_get_alert_status(dataset.SnowItemId)
                        if status['state'] == 'Closed':
                            result = self.objincseq.snow_update_alert(dataset.SnowItemId,'Success')
                        else:
                            result = True
                    case 'Incident':
                        status = self.objincseq.snow_get_incident_status(dataset.SnowItemId)
                        if status['state'] in ['2', '19']:
                            result = self.objincseq.snow_update_incident(dataset)
                        else:
                            result = True
                    case 'Request':
                        status = self.objreqseq.snow_get_ritm_status(dataset.SnowItemId)
                        if status['state'] in ['2', '8']:
                            result = self.objreqseq.snow_update_ritm(dataset)
                        else:
                            result = True
                    case 'Change':
                        status = self.objchgseq.snow_get_change_status(dataset.SnowItemId)
                        if status['state'] == '-1':
                            result = self.objchgseq.snow_update_change(dataset)
                        else:
                            result = True
                if result == True:
                    try:
                        self.objactivitymgr.end_activity(dataset)
                        self.objactivitymgr.delete_activity_pending(dataset)
                        self.objactivitymgr.delete_activity_completed(dataset)
                        if dataset.ActivityType in ['Incident','Alert']:
                            await NotifyUserIncident().send_email_notification({'EventId':dataset.EventId,'ActivityName':dataset.ActivityName,'SnowItemId':dataset.SnowItemId,'Status':dataset.Status},dataset.RequestedBy)
                        else:
                            await NotifyUser().send_email_notification({'EventId':dataset.EventId,'ActivityName':dataset.ActivityName,'SnowItemId':dataset.SnowItemId,'Status':dataset.Status},dataset.RequestedBy)
                    except Exception as e:
                        self.objactivitymgr.log_exception_activityinfo(dataset.EventId,dataset.ActivityName,str(e))
                else:
                    logging.error(f"Snow Update Failed: {str(result)}")
                    self.objactivitymgr.log_exception_activityinfo(dataset.EventId,dataset.ActivityName,str(result))
            except Exception as e:
                logging.error(f"Error in cleanup_completed_activity: {str(e)}")
                await Notification().send_email_notification(f'{os.environ["Environment"]} - Error Processing Completed Activity :',f'{e},Dataset:{dataset}',Constants.SMTP_KEYVAULT_SECRET)