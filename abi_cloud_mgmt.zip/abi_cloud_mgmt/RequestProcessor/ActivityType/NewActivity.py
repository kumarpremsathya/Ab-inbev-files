import json,logging,os
from shared_code.db import DB
from shared_code.snow_client import SNOWClient
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from ServiceNow.SnowRequest import SnowRequest
from ServiceNow.SnowIncident import SnowIncident
from ServiceNow.SnowChangeRequest import SnowChangeRequest
from RequestProcessor.PayloadDeserializer.AzPayloadDeserializer import AzPayloadDeserializer
from RequestProcessor.ActivityType.IncompleteActivity import IncompleteActivity
from shared_code.EmailNotification.NotifyUser import NotifyUser
from datetime import datetime,timezone
from shared_code.notification import Notification
from shared_code.EmailNotification.NotifyUserIncident import NotifyUserIncident
from shared_code.constants import Constants

class NewActivity:
    def __init__(self) -> None:
        self.objsnow = SNOWClient()
        self.objactivitymgr = DbActivityManager()
        self.objreqseq = SnowRequest()
        self.objincseq = SnowIncident()
        self.objchgseq = SnowChangeRequest()
        self.objpayloadaz = AzPayloadDeserializer()
        self.objincomplete = IncompleteActivity()
    
    async def check_db_for_new_activity(self):
        logging.info(f"\n\n\n[FLOW-8] check_db_for_new_activity called")
        datasets = self.objactivitymgr.get_new_activity() # Master Table
        for dataset in datasets:
            try:
                match dataset.ActivityType:
                    case 'Alert':
                        snow_alert = self.objsnow.get_alert_status(dataset.SnowItemId)
                        status = None
                        if snow_alert['state'] == 'Closed':
                            status = 'Auto Resolved'
                            state = 3
                        elif snow_alert['state'] in ['Open','Reopen'] and snow_alert['assigned_to'] == Constants.SNOW_ASSIGNMENT_USER:
                            status = 'In-Progress'
                            state = 2
                            match dataset.Cloud:
                                case 'Azure':
                                    self.objpayloadaz.deserialize(dataset)
                        if status:
                            self.objincseq.snow_update_alert(dataset)
                            self.objactivitymgr.update_activity_master_status(dataset, state, snow_alert['state'], status)
                            await NotifyUserIncident().send_email_notification({'EventId':dataset.EventId,'ActivityName':dataset.ActivityName,'SnowItemId':dataset.SnowItemId,'Status':status},dataset.RequestedBy)
                    case 'Incident':
                        snow_inc = self.objincseq.snow_get_incident_status(dataset.SnowItemId)
                        if not snow_inc:
                            logging.warning(f"[PHASE-3a] SNOW returned no record for {dataset.SnowItemId} — skipping")
                            continue
                        status = None
                        if snow_inc['state'] == '1':
                            snow_inc['state'] = 1
                            status = 'New'
                        if snow_inc['state'] == '3':
                            snow_inc['state'] = 3
                            status = 'On-Hold'
                        if snow_inc['state'] == '6':
                            snow_inc['state'] = 6
                            status = 'Remediated'
                        if snow_inc['state'] == '7':
                            snow_inc['state'] = 7
                            status = 'Remediated'
                        if snow_inc['state'] == '8':
                            snow_inc['state'] = 8
                            status = 'Cancelled'                      
                        # if snow_inc['state'] == '2' and snow_inc['assigned_to'] == Constants.SNOW_ASSIGNMENT_USER:
                        #     status = 'In-Progress'
                        #     match dataset.Cloud:
                        #         case 'Azure':
                        #             logging.info(f"\n\nDeserializing payload for EventId: {dataset.EventId}, ActivityName: {dataset.ActivityName}")
                        #             self.objpayloadaz.deserialize(dataset)
                        
                        status = 'In-Progress'
                        if dataset.Cloud == 'Azure':
                            logging.info(f"[TEST MODE] Forcing deserialize for EventId={dataset.EventId}")
                            self.objpayloadaz.deserialize(dataset)
                        
                        if status:
                            # self.objincseq.snow_update_incident(dataset)
                            logging.info(f"\n\nUpdating activity master status for EventId: {dataset.EventId}, ActivityName: {dataset.ActivityName}, SnowItemId: {dataset.SnowItemId}, Status: {status}")
                            self.objactivitymgr.update_activity_master_status(dataset, snow_inc['state'], status, status)
                            # await NotifyUserIncident().send_email_notification({'EventId':dataset.EventId,'ActivityName':dataset.ActivityName,'SnowItemId':dataset.SnowItemId,'Status':status},dataset.RequestedBy)                    
                    case 'Request':
            
                        snow_ritm = self.objreqseq.snow_get_ritm_status(dataset.SnowItemId)                    
                        if not snow_ritm:
                            logging.warning(f"SNOW returned no record for {dataset.SnowItemId} — skipping")
                            continue

                        status = None
                        if snow_ritm['stage'] == 'request_rejected' and snow_ritm['state'] == '4':
                            status = 'Closed Incomplete'
                        elif snow_ritm['stage'] == 'Request Cancelled' and snow_ritm['state'] == '6':
                            status = 'Cancelled'
                        elif snow_ritm['stage'] == 'fulfillment' and snow_ritm['state'] == '3':
                            status = 'Closed Complete'
                        elif snow_ritm['stage'] == 'request_approved' and snow_ritm['state'] in ['2', '8'] and snow_ritm['approval'] == 'approved':
                            status = 'In-Progress' if dataset.ActivityName != 'IT_ACCESS_06' else None
                            if dataset.Cloud == 'Azure' and status:
                                logging.info(f"Deserializing payload for EventId: {dataset.EventId}, ActivityName: {dataset.ActivityName}")
                                self.objpayloadaz.deserialize(dataset)
                        if status:
                            self.objactivitymgr.update_activity_master_status(dataset, snow_ritm['state'], snow_ritm['stage'], status)
                            # await NotifyUser().send_email_notification({'EventId': dataset.EventId, 'ActivityName':dataset.ActivityName,'SnowItemId': dataset.SnowItemId, 'Status': status}, dataset.RequestedBy)
                    case 'Change':
                        snow_change = self.objchgseq.snow_get_change_status(dataset.SnowItemId)
                        status = None
                        if snow_change['state'] == '4':
                            status = 'Cancelled'
                            stage = 'Cancelled'
                        elif snow_change['state'] == '3':
                            status = 'Closed Complete'
                            stage = 'closed_complete'
                        elif (snow_change['state'] == '-1' and 
                            datetime.now(timezone.utc) > datetime.strptime(snow_change['start_date'], '%Y-%m-%d %H:%M:%S').replace(tzinfo=timezone.utc) and 
                            datetime.now(timezone.utc) < datetime.strptime(snow_change['end_date'], '%Y-%m-%d %H:%M:%S').replace(tzinfo=timezone.utc)):
                            status = 'In-Progress'
                            stage = 'In-Progress'
                            if dataset.Cloud == 'Azure':
                                self.objpayloadaz.deserialize(dataset)
                        if status:
                            self.objactivitymgr.update_activity_master_status(dataset, snow_change['state'], stage, status)
                            # await NotifyUser().send_email_notification({'EventId': dataset.EventId,'ActivityName':dataset.ActivityName, 'SnowItemId': dataset.SnowItemId, 'Status': status}, dataset.RequestedBy)
            except Exception as e:
                logging.error(f"Error Processing New Activity: {e}")
                # Send formatted error notification with professional template
                # await NotifyUser().send_error_notification(
                    # error_type="Error Processing New Activity",
                    # error_message=str(e),
                    # additional_details={
                    #     "Activity Name": dataset.ActivityName if hasattr(dataset, 'ActivityName') else 'N/A',
                    #     "Event ID": dataset.EventId if hasattr(dataset, 'EventId') else 'N/A',
                    #     "Snow Item ID": dataset.SnowItemId if hasattr(dataset, 'SnowItemId') else 'N/A',
                    #     "Activity Type": dataset.ActivityType if hasattr(dataset, 'ActivityType') else 'N/A'
                    # }
                # )