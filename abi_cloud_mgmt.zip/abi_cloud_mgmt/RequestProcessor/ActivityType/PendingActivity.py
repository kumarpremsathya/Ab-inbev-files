import json,logging
import os
from shared_code.db import DB
from shared_code.snow_client import SNOWClient
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from ServiceNow.SnowRequest import SnowRequest
from ServiceNow.SnowIncident import SnowIncident
from ServiceNow.SnowChangeRequest import SnowChangeRequest
from RequestProcessor.Processor.AzProcessor import AzProcessor
from RequestProcessor.Processor.AwsProcessor import AwsProcessor
from RequestProcessor.Processor.GcpProcessor import GcpProcessor
from RequestProcessor.ActivityType.IncompleteActivity import IncompleteActivity
from datetime import datetime,timezone
from shared_code.notification import Notification
from shared_code.constants import Constants

class PendingActivity:
    
    def __init__(self) -> None:
        self.objsnow = SNOWClient()
        self.objactivitymgr = DbActivityManager()
        self.objreqseq = SnowRequest()
        self.objincseq = SnowIncident()
        self.objchgseq = SnowChangeRequest()
        self.objazhdl = AzProcessor()
        self.objawshdl = AwsProcessor()
        self.objgcphdl = GcpProcessor()
        self.objincomplete = IncompleteActivity()

    async def get_next_pending_activity(self):
        
        datasets = self.objactivitymgr.get_pending_activity() # Pending Table
        logging.info(f"\n\n\n[FLOW-9] get_next_pending_activity called | Records found: {len(datasets)}")
        for dataset in datasets:
            try:
                logging.info(f"[FLOW-9] Processing | EventId: {dataset.EventId} | ActivityName: {dataset.ActivityName} | ActivityType: {dataset.ActivityType} | SnowItemId: {dataset.SnowItemId}") 
                match dataset.ActivityType:
                    case 'Alert':
                        snow_alert = self.objsnow.get_alert_status(dataset.SnowItemId)
                        status = None
                        if snow_alert['state'] == 'Closed':
                            status = 'Closed'
                            self.objincomplete.incomplete_activity(dataset)
                            continue
                        await self.initialize_handler(dataset)
                    case 'Incident':
                        snow_inc = self.objincseq.snow_get_incident_status(dataset.SnowItemId)
                        status = self.determine_incident_status(snow_inc)
                        if status:
                            self.objincomplete.incomplete_activity(dataset)
                            continue
                        await self.initialize_handler(dataset)
                    case 'Request':
                        snow_ritm = self.objreqseq.snow_get_ritm_status(dataset.SnowItemId)
                        if not snow_ritm:
                            logging.warning(f"\n[FLOW-9] SNOW returned no record for {dataset.SnowItemId} — skipping")
                            continue

                        status = self.determine_request_status(snow_ritm)
                        if status:
                            self.objincomplete.incomplete_activity(dataset)
                            continue
                        logging.info(f"\n\n[FLOW-9] RITM {dataset.SnowItemId} is active — calling initialize_handler")
                        await self.initialize_handler(dataset)
                    case 'Change':
                        snow_change = self.objchgseq.snow_get_change_status(dataset.SnowItemId)
                        status = self.determine_change_status(snow_change)
                        if status:
                            self.objincomplete.incomplete_activity(dataset)
                            continue
                        if snow_change['state'] == '-1': ## NEEDS REVIEW
                            await self.initialize_handler(dataset)
            except Exception as e:
                logging.error(f"Error in get_next_pending_activity: {str(e)}")
                await Notification().send_email_notification(f'{os.environ["Environment"]} - Error Processing Pending Activity :',f'{e},Dataset:{dataset}',Constants.SMTP_KEYVAULT_SECRET)
                self.objactivitymgr.log_exception_activityinfo(dataset.EventId, dataset.ActivityName, str(e))

    def determine_request_status(self, snow_ritm):
        if snow_ritm['stage'] == 'request_rejected' and snow_ritm['state'] == '4':
            return 'Closed Incomplete'
        elif snow_ritm['stage'] == 'Request Cancelled' and snow_ritm['state'] == '6':
            return 'Cancelled'
        elif snow_ritm['stage'] == 'fulfillment' and snow_ritm['state'] == '3':
            return 'Closed Complete'
        return None
    
    def determine_change_status(self, snow_change):
        if snow_change['state'] == '4':
            return 'Cancelled'
        elif snow_change['state'] == '3':
            return 'Closed Complete'
        return None
    
    def determine_incident_status(self, snow_inc):
        if snow_inc['state'] == '8':
            return 'Cancelled'
        return None

    async def initialize_handler(self, dataset):
        match dataset.Cloud:
            case "Azure":
                await self.objazhdl.initialize(dataset)
            case "Gcp":
                await self.objgcphdl.initialize(dataset)
            case "Aws":
                await self.objawshdl.initialize(dataset)