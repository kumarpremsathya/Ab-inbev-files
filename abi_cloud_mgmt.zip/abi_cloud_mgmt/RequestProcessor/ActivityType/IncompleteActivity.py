from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from RequestProcessor.Processor.AzProcessor import AzProcessor
from RequestProcessor.Processor.AwsProcessor import AwsProcessor
from RequestProcessor.Processor.GcpProcessor import GcpProcessor


class IncompleteActivity:
    def __init__(self) -> None:
        self.objactivitymgr = DbActivityManager()
    
    def update_incomplete_activity(self,table_name,status,comments,EventId):
        self.objactivitymgr.update_incomplete_activity(table_name,status,comments,EventId)

    def incomplete_activity(self,dataset):
        match dataset.Cloud:
            case "Azure":
                tblname= AzProcessor().get_table_and_topic_names(dataset.ActivityName)
            case "Gcp":
                print('Gcp')
            case "Aws":
                print('Aws')
        self.update_incomplete_activity(tblname,'Aborted','Activity Aborted',dataset.EventId)
        self.objactivitymgr.insert_activity_completed(dataset,'Aborted','Activity Aborted')