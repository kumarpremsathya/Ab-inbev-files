import json,logging,datetime
from datetime import time
from dateutil import tz
from shared_code.db import DB
from shared_code.time_zone_converter import TimezoneConverter
import traceback

class DbActivityManager:
    def __init__(self) -> None:
        self.objdb= DB()
        self.tz_converter = TimezoneConverter()

    def get_activity_completed(self):
        sql_query = """
        select CA.EventId,CA.ActivityName,EM.ActivityType,EM.SnowId,EM.SnowItemId,EM.RequestedBy,CA.Status,CA.Comments from tblEventCompletedActivity as CA
        inner join tblEventMaster as EM ON CA.EventId = EM.EventId and CA.ActivityName = EM.ActivityName
        """
        datasets = self.objdb.executescalar(sql_query=sql_query,action="select",)

        return datasets
    
    def delete_activity_pending(self,dataset):
        sql_query = """
        delete from tblEventPendingActivity where EventId = ? and ActivityName = ?
        """
        values=(dataset.EventId,dataset.ActivityName)
        self.objdb.executescalar(sql_query=sql_query,action="delete",values=values)
    
    def delete_activity_completed(self,dataset):
        sql_query = """
        delete from tblEventCompletedActivity where EventId = ? and ActivityName = ?
        """
        values=(dataset.EventId,dataset.ActivityName)
        self.objdb.executescalar(sql_query=sql_query,action="delete",values=values)
    
    def end_activity(self,dataset):
        match dataset.ActivityType:
            case 'Alert':
                if dataset.Status == 'Success':
                    SnowItemStatusCode = '3'
                    SnowItemStatus = 'closed_complete'
                    status = 'Remediated'
                else:
                    SnowItemStatusCode = '4'
                    SnowItemStatus = 'closed_incomplete'
                    status = 'Hand Over'
            case 'Incident':
                if dataset.Status == 'Success':
                    SnowItemStatusCode = '7'
                    SnowItemStatus = 'closed_complete'
                    status = 'Remediated'
                else:
                    SnowItemStatusCode = '2'
                    SnowItemStatus = 'closed_incomplete'
                    status = 'Hand Over'
            case 'Request':
                if dataset.Status == 'Success':
                    SnowItemStatusCode = '3'
                    SnowItemStatus = 'closed_complete'
                    status = 'Completed'
                else:
                    SnowItemStatusCode = '4'
                    SnowItemStatus = 'closed_incomplete'
                    status = dataset.Status
            case 'Change':
                if dataset.Status == 'Success':
                    SnowItemStatusCode = '3'
                    SnowItemStatus = 'closed_complete'
                    status = 'Completed'
                else:
                    SnowItemStatusCode = '4'
                    SnowItemStatus = 'closed_incomplete'
                    status = dataset.Status

        sql_query = """
        update tblEventMaster set SnowItemStatusCode = ?,SnowItemStatus=?
        ,LastUpdateTime=?,Status=?,Comments=?
        where EventId = ? and ActivityName = ?
        """
        values=(SnowItemStatusCode,SnowItemStatus,datetime.datetime.now(datetime.timezone.utc),status,dataset.Comments,dataset.EventId,dataset.ActivityName)
        self.objdb.executescalar(sql_query=sql_query,action="update",values=values)

    def log_exception_activityinfo(self,EventId,ActivityName,error,ActivityId=""):
        sql_query = """
        MERGE INTO tblActivityInfo as Target
        USING (SELECT ?,?,?,?)
        AS SOURCE(EventId,ActivityId,ActivityName,Exception)
        ON Target.EventId=Source.EventId
        AND Target.ActivityId=Source.ActivityId
        AND Target.ActivityName=Source.ActivityName
        WHEN MATCHED THEN
        UPDATE SET Exception = Source.Exception
        WHEN NOT MATCHED THEN        
        INSERT (EventId,ActivityId,ActivityName,Exception)
        VALUES (Source.EventId,Source.ActivityId,Source.ActivityName, Source.Exception);       
        """
        values=(EventId,ActivityId,ActivityName,error)
        self.objdb.executescalar(sql_query=sql_query,action="insert",values=values)

    def get_new_activity(self):
        sql_query = """
        select * from tblEventMaster 
        where 
            (SnowItemStatusCode = '-5' and SnowItemStatus = 'waiting_for_approval' and Status = 'Pending Approval')
             or
            (SnowItemStatusCode in ('2','8') and SnowItemStatus = 'request_approved' and Status = 'Pending Approval')
             or
            (SnowItemStatusCode in ('2','19') and SnowItemStatus = 'Queued' and Status = 'Queued')
             or
            (SnowItemStatusCode = '-4' and SnowItemStatus = 'Approval' and Status = 'Pending Approval')
        order by 			
			CASE ActivityType
				WHEN 'Incident' THEN 1
                WHEN 'Alert' THEN 1
				WHEN 'Request' THEN 2
				WHEN 'Change' THEN 3
				ELSE 4
	        END
			,EventStartTime asc
        """
        datasets = self.objdb.executescalar(sql_query=sql_query,action="select",)

        return datasets
    
    def update_activity_master_status(self,dataset,SnowItemStatusCode,SnowItemStatus,status):
        sql_query = """
        update tblEventMaster set SnowItemStatusCode = ?,SnowItemStatus=?
        ,LastUpdateTime=?,Status=?
        where EventId = ? and ActivityName = ?
        """
        values=(SnowItemStatusCode,SnowItemStatus,datetime.datetime.now(datetime.timezone.utc),status,dataset.EventId,dataset.ActivityName)
        self.objdb.executescalar(sql_query=sql_query,action="update",values=values)
    
    def insert_activity_pending(self,dataset):
        logging.info(f"Inserting pending activity for EventId: {dataset.EventId}, ActivityName: {dataset.ActivityName}")
        sql_query = """
            MERGE INTO tblEventPendingActivity as Target
            USING (SELECT ?,?,?)
            AS SOURCE(EventId,ActivityName,RetryAttemptedAt)
            ON Target.EventId=Source.EventId
            AND Target.ActivityName=Source.ActivityName
            WHEN NOT MATCHED THEN
            INSERT (EventId,ActivityName,RetryAttemptedAt)
            VALUES (Source.EventId,Source.ActivityName,Source.RetryAttemptedAt);
        """
        values=(dataset.EventId,dataset.ActivityName,datetime.datetime.now(datetime.timezone.utc))
        self.objdb.executescalar(sql_query=sql_query,action="insert",values=values)
    
    def get_pending_activity(self):
        sql_query = f"""
            select PA.EventId,PA.ActivityName,EM.ActivityType,EM.SnowId,EM.SnowItemId,
            EM.SnowItemStatusCode,EM.SnowItemStatus,EM.Cloud from tblEventPendingActivity as PA
            inner join tblEventMaster as EM ON PA.EventId = EM.EventId and 
            PA.ActivityName = EM.ActivityName and PA.RetryAttemptedAt < ?
            order by 
            CASE EM.ActivityType
				WHEN 'Incident' THEN 1
                WHEN 'Alert' THEN 1
				WHEN 'Request' THEN 2
				WHEN 'Change' THEN 3
				ELSE 4
	        END
            ,PA.RetryAttemptedAt asc
        """
        values = (datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None))
        datasets = self.objdb.executescalar(sql_query=sql_query,action="select",values=values)

        return datasets
    
    def get_pending_next_retry_time(self,dataset,tblname):
        sql_query = f"""
            select top(1) * from {tblname} where EventId = ? and (Status = ? or Status = ?) order by RetryAttemptedAt asc
        """
        values = (dataset.EventId,'In-Progress','Retry')
        datasets = self.objdb.executescalar(sql_query=sql_query,action="select",values=values)

        return datasets
    
    def get_activity_info(self,tblname,evenid):
        sql_query = f"""
            select * from {tblname} where EventId = ? and (Status = ? or Status = ?)
        """
        values = (evenid,'In-Progress','Retry')
        datasets = self.objdb.executescalar(sql_query=sql_query,action="select",values=values)

        return datasets

    def get_activity_info_failed_count(self,tblname,eventid):
        sql_query = f"""
            SELECT
                EventId,
                COUNT(*) AS TotalRecords,
                SUM(CASE WHEN Status = 'Success' THEN 1 ELSE 0 END) AS SuccessCount,
                SUM(CASE WHEN Status = 'Failed' THEN 1 ELSE 0 END) AS FailedCount
            FROM {tblname} where EventId = ?
            GROUP BY EventId
        """
        values = (eventid)
        datasets = self.objdb.executescalar(sql_query=sql_query,action="select",values=values)

        return datasets

    def get_subscription_id_zone(self,sub_name):
        sql_query = f"""
            select top(1) SubscriptionId,Zone from tblazuresubscriptionslistreport where SubscriptionName = ?
        """
        values = (sub_name)
        datasets = self.objdb.executescalar(sql_query=sql_query,action="check",values=values)

        return datasets if datasets else None

    def get_resource_id(self,sub_name,resource_name):
        sql_query = f"""
            select TagsId from tblazuretagsreport where SubscriptionName = ?  and Resource = ?
        """
        values = (sub_name,resource_name)
        datasets = self.objdb.executescalar(sql_query=sql_query,action="check",values=values)

        return datasets.TagsId if datasets else None
    
    def db_update_activity(self,tblname,activityid,status,comments,retryattemptedat):
        sql_query = f"""
            update {tblname} SET Status = ?, Comments = ?, RetryAttemptedAt = ?
            where activityid = ?
        """
        values=(status,comments,retryattemptedat,activityid)
        self.objdb.executescalar(sql_query=sql_query,action="update",values=values)
    
    def update_activity_info(self,tblname,result,comments,eventid):
        sql_query = f"""
            update {tblname} SET Status = ?,Comments = ?
            where EventId = ? and Status = ?
        """
        values=(result,comments,eventid,'In-Progress')
        self.objdb.executescalar(sql_query=sql_query,action="update",values=values)
    
    def update_activity_pending_retry(self,dataset,retry_interval):
        sql_query = """
            update tblEventPendingActivity SET RetryAttemptedAt = ?
            where EventId = ?      
        """
        values=(retry_interval,dataset.EventId)
        self.objdb.executescalar(sql_query=sql_query,action="update",values=values)

    def insert_activity_completed(self,dataset,result,comments):
        sql_query = """
            MERGE INTO tblEventCompletedActivity as Target
            USING (SELECT ?,?,?,?)
            AS SOURCE(EventId,ActivityName,Status,Comments)
            ON Target.EventId=Source.EventId
            AND Target.ActivityName=Source.ActivityName
            WHEN NOT MATCHED THEN
            INSERT (EventId,ActivityName,Status,Comments)
            VALUES (Source.EventId,Source.ActivityName,Source.Status,Source.Comments);
        """
        values=(dataset.EventId,dataset.ActivityName,result,comments)
        self.objdb.executescalar(sql_query=sql_query,action="insert",values=values)

    def update_incomplete_activity(self,table_name,status,comments,EventId):
        sql_query = f"""
        update {table_name} set Status = ?,Comments=?
        where EventId = ? and Status = 'In-Progress'
        """
        values=(status,comments,EventId)
        self.objdb.executescalar(sql_query=sql_query,action="update",values=values)
    
    def get_owners(self,zone,resource_group,subscription_id):
        sql_query = """
            EXEC spGetIncidentResourceOwners @Zone = ?, @ResourceGroup = ?, @SubscriptionId = ?
        """
        values=(zone,resource_group,subscription_id)
        dataset = self.objdb.executescalar(sql_query=sql_query,action="check",values=values)
        if dataset:
            return dataset
        else:
            return None

    def get_zone(self,subscription_id):
        sql_query = """
            select Zone from tblAzureSubscriptionsListReport where SubscriptionId = ?
        """
        values=(subscription_id,)
        dataset = self.objdb.executescalar(sql_query=sql_query,action="check",values=values)
        if dataset:
            return dataset.Zone
        else:
            return None
        
    def get_subscription_name(self,subscription_id):
        sql_query = """
            select SubscriptionName from tblAzureSubscriptionsListReport where SubscriptionId = ?
        """
        values=(subscription_id,)
        dataset = self.objdb.executescalar(sql_query=sql_query,action="check",values=values)
        if dataset:
            return dataset.SubscriptionName
        else:
            return None

    def insert_hoursofoperation_instances_from_payload(self, event_id: str, payload: dict, zone: str) -> int:
        try:
            if not event_id:
                logging.error("EventId is required")
                return 0
            
            if not payload or not isinstance(payload, dict):
                logging.error("Invalid payload: must be a non-empty dictionary")
                return 0
            
            timezone = payload.get('timezone', 'UTC')
            
            resources = payload.get('resources', [])
            
            if not resources:
                logging.error("No resources found in payload")
                return 0
            
            success_count = 0
            total_count = 0
            
            for resource_group in resources:
                subscription_id = resource_group.get('subscription_id', '')
                subscription_name = resource_group.get('subscription_name', '')
                resource_group_id = resource_group.get('resource_group_id', '')
                resource_group_name = resource_group.get('resource_group_name', '')
                resource_type = resource_group.get('resource_type', 'microsoft.compute/virtualmachines')
                
                instances = resource_group.get('instances', [])
                
                for instance in instances:
                    total_count += 1
                    
                    resource_name = instance.get('resource_name', '')
                    resource_id = instance.get('resource_id', '')
                    
                    if not resource_name:
                        logging.warning(f"Skipping instance with missing resource_name in EventId {event_id}")
                        continue
                    
                    if not resource_id:
                        logging.warning(f"Skipping instance {resource_name} with missing resource_id in EventId {event_id}")
                        continue
                    
                    is_active = self._normalize_hoursofop_is_active(instance.get('is_active', True))
                    justification = instance.get('justification', '')
                    
                    weekly_schedule = instance.get('weekly_schedule', {})
                    if not weekly_schedule:
                        logging.warning(f"No schedule provided for {resource_name}, using empty schedule")
                    
                    schedule_data = self._parse_hoursofop_weekly_schedule(weekly_schedule, timezone)
                    
                    post_start_config = self._parse_hoursofop_json_config(instance.get('post_start_config'))
                    pre_stop_config = self._parse_hoursofop_json_config(instance.get('pre_stop_config'))
                    email_notifications = self._parse_hoursofop_email_notifications(instance.get('email_notifications'))
                    
                    instance_obj = {
                        'resource_zone': zone,
                        'subscription_id': subscription_id,
                        'subscription_name': subscription_name,
                        'resource_group_id': resource_group_id,
                        'resource_group_name': resource_group_name,
                        'resource_type': resource_type,
                        'resource_name': resource_name,
                        'resource_id': resource_id,
                        'is_active': is_active,
                        'mon_schedule': schedule_data.get('mon_schedule'),
                        'tue_schedule': schedule_data.get('tue_schedule'),
                        'wed_schedule': schedule_data.get('wed_schedule'),
                        'thu_schedule': schedule_data.get('thu_schedule'),
                        'fri_schedule': schedule_data.get('fri_schedule'),
                        'sat_schedule': schedule_data.get('sat_schedule'),
                        'sun_schedule': schedule_data.get('sun_schedule'),
                        'timezone': timezone,
                        'justification': justification,
                        'post_start_config': post_start_config,
                        'pre_stop_config': pre_stop_config,
                        'email_notifications': email_notifications
                    }
                    
                    if self.insert_hoursofoperation_instance(event_id, instance_obj):
                        success_count += 1
            
            return success_count
            
        except Exception as e:
            logging.error(f"Error inserting Hours of Operation instances from payload: {str(e)}")
            return 0
    
    def _normalize_hoursofop_is_active(self, is_active_value) -> str:
        if is_active_value is None:
            return "Yes"
        if isinstance(is_active_value, bool):
            return "Yes" if is_active_value else "No"
        if isinstance(is_active_value, str):
            normalized = is_active_value.strip().lower()
            if normalized in ['decommissioned', 'decomm', 'retired']:
                return "Decommissioned"
            if normalized in ['yes', 'true', '1', 'active', 'enabled']:
                return "Yes"
            if normalized in ['no', 'false', '0', 'inactive', 'disabled']:
                return "No"
        return "Yes"
    
    def _parse_hoursofop_weekly_schedule(self, weekly_schedule: dict, timezone: str) -> dict:
        day_mapping = {
            'mon': 'mon_schedule',
            'tue': 'tue_schedule',
            'wed': 'wed_schedule',
            'thu': 'thu_schedule',
            'fri': 'fri_schedule',
            'sat': 'sat_schedule',
            'sun': 'sun_schedule'
        }
        
        result = {}
        
        for day_key, schedule_key in day_mapping.items():
            day_schedule = weekly_schedule.get(day_key)
            
            if day_schedule is None:
                result[schedule_key] = None
            else:
                start_time = day_schedule.get('start')
                stop_time = day_schedule.get('stop')
                
                schedule_obj = {}
                
                if start_time:
                    start_time_utc = self._convert_hoursofop_time_to_utc(start_time, timezone)
                    schedule_obj['start'] = start_time_utc.strftime('%H:%M:%S')
                else:
                    schedule_obj['start'] = None
                
                if stop_time:
                    stop_time_utc = self._convert_hoursofop_time_to_utc(stop_time, timezone)
                    schedule_obj['stop'] = stop_time_utc.strftime('%H:%M:%S')
                else:
                    schedule_obj['stop'] = None
                
                result[schedule_key] = json.dumps(schedule_obj) if (schedule_obj['start'] or schedule_obj['stop']) else None
        
        return result
    
    def _convert_hoursofop_time_to_utc(self, time_str: str, user_timezone: str) -> time:
        try:
            time_parts = time_str.split(':')
            hour = int(time_parts[0])
            minute = int(time_parts[1])
            second = int(time_parts[2]) if len(time_parts) > 2 else 0
            
            user_tz = tz.gettz(user_timezone)
            local_dt = datetime.datetime.now(user_tz).replace(hour=hour, minute=minute, second=second, microsecond=0)
            
            utc_dt = local_dt.astimezone(tz.UTC)
            
            return time(utc_dt.hour, utc_dt.minute, utc_dt.second)
            
        except Exception as e:
            logging.error(f"Error converting time to UTC for Hours of Operation: {str(e)}")
            time_parts = time_str.split(':')
            return time(int(time_parts[0]), int(time_parts[1]), int(time_parts[2]) if len(time_parts) > 2 else 0)
    
    def _parse_hoursofop_json_config(self, config_data) -> str:
        if config_data is None:
            return None
        try:
            if isinstance(config_data, str):
                json.loads(config_data)
                return config_data
            if isinstance(config_data, (dict, list)):
                return json.dumps(config_data)
            return None
        except:
            return None
    
    def _parse_hoursofop_email_notifications(self, email_data) -> str:
        if email_data is None:
            return None
        try:
            if isinstance(email_data, list):
                return ';'.join([email.strip() for email in email_data if email and email.strip()])
            if isinstance(email_data, str):
                return email_data.strip() if email_data.strip() else None
            return None
        except:
            return None
    
    def insert_hoursofoperation_instance(self, event_id: str, resource_data: dict) -> bool:
        try:
            sql_query = """
                MERGE INTO tblActivityAzHoursOfOperationInstance AS Target
                USING (SELECT ? AS ResourceId) AS Source
                ON Target.ResourceId = Source.ResourceId
                WHEN MATCHED THEN
                    UPDATE SET 
                        EventId = ?,
                        Zone = ?,
                        SubscriptionId = ?,
                        SubscriptionName = ?,
                        ResourceGroupId = ?,
                        ResourceGroupName = ?,
                        ResourceType = ?,
                        ResourceName = ?,
                        IsActive = ?,
                        MonSchedule = ?,
                        TueSchedule = ?,
                        WedSchedule = ?,
                        ThuSchedule = ?,
                        FriSchedule = ?,
                        SatSchedule = ?,
                        SunSchedule = ?,
                        Timezone = ?,
                        Justification = ?,
                        PostStartConfig = ?,
                        PreStopConfig = ?,
                        EmailNotifications = ?
                WHEN NOT MATCHED THEN
                    INSERT (EventId, Zone, SubscriptionId, SubscriptionName,
                            ResourceGroupId, ResourceGroupName, ResourceType, ResourceName,
                            ResourceId, IsActive, MonSchedule, TueSchedule, WedSchedule,
                            ThuSchedule, FriSchedule, SatSchedule, SunSchedule,
                            Timezone, Justification, PostStartConfig, PreStopConfig, EmailNotifications)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            """
            
            resource_id = resource_data.get('resource_id', '')
            values = (
                resource_id,
                event_id,
                resource_data.get('resource_zone', ''),
                resource_data.get('subscription_id', ''),
                resource_data.get('subscription_name', ''),
                resource_data.get('resource_group_id', ''),
                resource_data.get('resource_group_name', ''),
                resource_data.get('resource_type', ''),
                resource_data.get('resource_name', ''),
                resource_data.get('is_active', 'Yes'),
                resource_data.get('mon_schedule'),
                resource_data.get('tue_schedule'),
                resource_data.get('wed_schedule'),
                resource_data.get('thu_schedule'),
                resource_data.get('fri_schedule'),
                resource_data.get('sat_schedule'),
                resource_data.get('sun_schedule'),
                resource_data.get('timezone', 'UTC'),
                resource_data.get('justification', ''),
                resource_data.get('post_start_config'),
                resource_data.get('pre_stop_config'),
                resource_data.get('email_notifications'),
                event_id,
                resource_data.get('resource_zone', ''),
                resource_data.get('subscription_id', ''),
                resource_data.get('subscription_name', ''),
                resource_data.get('resource_group_id', ''),
                resource_data.get('resource_group_name', ''),
                resource_data.get('resource_type', ''),
                resource_data.get('resource_name', ''),
                resource_id,
                resource_data.get('is_active', 'Yes'),
                resource_data.get('mon_schedule'),
                resource_data.get('tue_schedule'),
                resource_data.get('wed_schedule'),
                resource_data.get('thu_schedule'),
                resource_data.get('fri_schedule'),
                resource_data.get('sat_schedule'),
                resource_data.get('sun_schedule'),
                resource_data.get('timezone', 'UTC'),
                resource_data.get('justification', ''),
                resource_data.get('post_start_config'),
                resource_data.get('pre_stop_config'),
                resource_data.get('email_notifications')
            )
            
            self.objdb.executescalar(sql_query=sql_query, action="insert", values=values)
            return True
            
        except Exception as e:
            logging.error(f"Error inserting Hours of Operation instance: {str(e)}")
            return False