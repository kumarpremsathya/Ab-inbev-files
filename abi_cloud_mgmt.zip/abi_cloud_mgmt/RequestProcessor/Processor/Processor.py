import json,logging,hashlib,asyncio
from datetime import datetime, timezone
from shared_code.db import DB
from shared_code.snow_client import SNOWClient
from shared_code.servicebus_client import ServiceBusClientAbstract
from azure.servicebus import ServiceBusMessage
from RequestProcessor.DAL.DbActivityManager import DbActivityManager

class Processor:
    def __init__(self) -> None:
        self.objdb= DB()
        self.objsnow = SNOWClient()
        self.objactivitymgr = DbActivityManager()
        self.objsbuscli = ServiceBusClientAbstract()
    
    async def queue_processor(self,tblname,dataset):       
        items = self.objactivitymgr.get_activity_info(tblname,dataset.EventId)
        logging.info(f"\n[FLOW-10] queue_processor | EventId: {dataset.EventId} | Table: {tblname} | Items: {len(items)}")
        pending = 0
        for item in items: 
            payload = {column[0]: value for column, value in zip(item.cursor_description, item)}
            payload['ActivityName'] = dataset.ActivityName
            payload['TableName'] = tblname
            payload.pop('RetryAttemptedAt')
            unique_key = self.objsbuscli.generate_unique_key(payload)            
            if item.RetryAttemptedAt < datetime.now(timezone.utc).replace(tzinfo=None):
               logging.info(f"[FLOW-10] Publishing message | ResourceId: {payload.get('ResourceId','N/A')} | MessageId: {unique_key}")
               await self.publish_message(payload,unique_key)
            pending +=1 
        if pending > 0:   
            retrytime = self.objactivitymgr.get_pending_next_retry_time(dataset,tblname)        
            self.objactivitymgr.update_activity_pending_retry(dataset,retrytime[0].RetryAttemptedAt)
        else:
            status_count = self.objactivitymgr.get_activity_info_failed_count(tblname,dataset.EventId)
            success_count = status_count[0].SuccessCount
            failed_count = status_count[0].FailedCount
            if failed_count == 0:
                self.objactivitymgr.insert_activity_completed(dataset,'Success','Implemented Successfully')
            elif failed_count > 0 and success_count > 0:
                self.objactivitymgr.insert_activity_completed(dataset,'Failed','Implemented Partially')
            elif success_count == 0:
                self.objactivitymgr.insert_activity_completed(dataset,'Failed','Failed')
            else:
                self.objactivitymgr.insert_activity_completed(dataset,'Aborted','Activity Aborted')
    
    async def publish_message(self,payload,unique_key):
        await self.publish_api(payload,unique_key)

    async def publish_api(self,payload,unique_key):
        servicebus_client = self.objsbuscli.get_servicebus_client()
        try:
            sender = servicebus_client.get_topic_sender(topic_name='request_handler')
            async with sender:
                message = ServiceBusMessage(json.dumps(payload, sort_keys=True),message_id=unique_key)
                logging.info(f"\n\n[FLOW-10] Payload before send | MessageId: {unique_key} | Payload: {json.dumps(payload, indent=2)}")
                # await sender.send_messages(message)
                # logging.info(f"Successfully sent message to Service Bus. MessageId: {unique_key}, ActivityName: {payload.get('ActivityName', 'N/A')}")
        except Exception as e:
            logging.error(e)