import json,logging,hashlib,asyncio
from datetime import datetime, timezone
from RequestProcessor.Processor.Processor import Processor
from Catalog.Azure.AppRoles.AzAppRole import AzAppRole
from Catalog.Azure.Rbac.AzRbac import AzRbac
from Catalog.Azure.Tags.AzTags import AzTags
from Catalog.Azure.AzInstanceStatus.AzInstanceStatus import AzInstanceStatus
from Catalog.Azure.VmResize.AzVmResize import AzVmResize
from Catalog.Azure.VmDiskResize.AzVmDiskResize import AzVmDiskResize
from Catalog.Azure.MSSqlAccess.mssql_access import AzMsSqlAccess
from Catalog.Azure.MsSqlDbResize.AzMsSqlDbResize import AzMsSqlDbResize
from Catalog.Azure.PostgreSqlAccess.postgresql_access import AzPostgreSqlAccess
from Catalog.Azure.Decommission.decommission import AzDecommission
from Catalog.Azure.Decommission.decommission_preactivity import AzDecommissionPreactivity
from Catalog.Azure.Provisioning.Provisioning import AzProvisioning
from Catalog.Azure.AzSnapshot.AzSnapshotCreation import AzSnapshotCreation
from Catalog.Azure.VmAccessMgmt.VmAccessMgmt import AzVmAccessMgmt
from Catalog.Azure.VmCredMgmt.VmCredMgmt import AzVmCredMgmt
from Catalog.Azure.Rbac.AzRbacExceptional import AzRbacExceptional
from Catalog.Azure.HoursOfOperation.HoursOfOperation import AzHoursOfOperation
from Catalog.Azure.HoursOfOperationInstance.AzHoursOfOperationInstance import AzHoursOfOperationInstance
from Catalog.Azure.WindowsOSUpgrade.WindowsOSUpgrade import AzWindowsVmUpgrade
from Events.Azure.BackupFailure import BackupFailure
from Events.Azure.DiskCleanup import DiskCleanup
from Events.Azure.CpuHighAlert import CpuHighAlert
from Events.Azure.MemoryHighAlert import MemoryHighAlert
from Catalog.Azure.InactiveRbac.InactiveRbac import AzInactiveRbac
from Catalog.Azure.VmInventoryReview.VmInventoryReview import VmInventoryReview
from Catalog.Azure.RbacInventoryReview.RbacInventoryReview import RbacInventoryReview
from Catalog.Azure.GroupMemberReview.VmGroupMemberReview import VmGroupMemberReview
from Catalog.Azure.GroupMemberReview.RbacGroupMemberReview import RbacGroupMemberReview
from Catalog.Azure.InactiveVMAccounts.InactiveVMAccounts import InactiveVMAccounts
from Catalog.Azure.PolicyExemption.PolicyExemption import AzPolicyExemption
from Catalog.Azure.KeyVaultMgmt.KeyVaultMgmt import AzKeyVaultMgmt

class AzProcessor:
    def __init__(self) -> None:
        pass
    
    async def initialize(self,dataset) -> None: 
        logging.info(f"\n\n[FLOW-10] initialize_handler called | EventId: {dataset.EventId} | ActivityName: {dataset.ActivityName} | ActivityType: {dataset.ActivityType} | SnowItemId: {dataset.SnowItemId}")      
        tblname = self.get_table_and_topic_names(dataset.ActivityName)
        await Processor().queue_processor(tblname, dataset)

    def get_table_and_topic_names(self, activity_name: str) -> tuple:
        match activity_name:
            # case "RBAC":
            #     return AzRbac().TABLE_NAME
            # case "APPROLE":
            #     return AzAppRole().TABLE_NAME
            # case "TAGS":
            #     return AzTags().TABLE_NAME
            # case "INSTANCESTATUS":
            #     return AzInstanceStatus().TABLE_NAME
            # case "RESIZEVMSKU":
            #     return AzVmResize().TABLE_NAME
            # case "RESIZEVMDISK":
            #     return AzVmDiskResize().TABLE_NAME
            # case "MSSQLACCESS":
            #     return AzMsSqlAccess().TABLE_NAME
            # case "POSTGRESQLACCESS":
            #     return AzPostgreSqlAccess().TABLE_NAME
            # case "RESIZESQLDB":
            #     return AzMsSqlDbResize().TABLE_NAME
            # case "DECOMM":
            #     return AzDecommission().TABLE_NAME
            # case "DECOMMPREACTIVITY":
            #     return AzDecommissionPreactivity().TABLE_NAME
            # case "RGPROVISION":
            #     return AzProvisioning().TABLE_NAME
            # case "SNAPSHOTCREATION":
            #     return AzSnapshotCreation().TABLE_NAME
            # case "VMACCESSMGMT":
            #     return AzVmAccessMgmt().TABLE_NAME
            # case "VMPROVISION":
            #     return AzProvisioning().TABLE_NAME
            # case "VMCREDMGMT":
            #     return AzVmCredMgmt().TABLE_NAME
            # case "KEYVAULTPROVISION":
            #     return AzProvisioning().TABLE_NAME
            # case "RBACEXCEPTIONAL":
            #     return AzRbacExceptional().TABLE_NAME
            # case "STORAGEACCOUNTPROVISION":
            #     return AzProvisioning().TABLE_NAME
            # case "WEBAPPPROVISION":
            #     return AzProvisioning().TABLE_NAME
            # case "LOGICAPPPROVISION":
            #     return AzProvisioning().TABLE_NAME
            # case "FUNCTIONAPPPROVISION":
            #     return AzProvisioning().TABLE_NAME
            # case "POSTGREDBPROVISION":
            #     return AzProvisioning().TABLE_NAME
            # case "COSMOSDBPROVISION":
            #     return AzProvisioning().TABLE_NAME
            # case "MSSQLDBPROVISION":
            #     return AzProvisioning().TABLE_NAME
            # case "MSSQLELASTICPOOLPROVISION":
            #     return AzProvisioning().TABLE_NAME
            # case "MSSQLSERVERPROVISION":
            #     return AzProvisioning().TABLE_NAME
            # case "MSSQLMGMTINSTANCEPROVISION":
            #     return AzProvisioning().TABLE_NAME
            # case "APPINSIGHTSPROVISION":
            #     return AzProvisioning().TABLE_NAME
            # case "DATABRICKSPROVISION":
            #     return AzProvisioning().TABLE_NAME
            # case "DATAFACTORYPROVISION":
            #     return AzProvisioning().TABLE_NAME
            # case "EVENTHUBPROVISION":
            #     return AzProvisioning().TABLE_NAME
            # case "REDISCACHEPROVISION":
            #     return AzProvisioning().TABLE_NAME
            # case "SERVICEBUSPROVISION":
            #     return AzProvisioning().TABLE_NAME
            # case "PRIVATEENDPOINTPROVISION":
            #     return AzProvisioning().TABLE_NAME
            # case "HOURSOFOPERATION":
            #     return AzHoursOfOperation().TABLE_NAME
            # case "HOURSOFOPERATIONINSTANCE":
            #     return AzHoursOfOperationInstance().TABLE_NAME
            # case "IT_ACCESS_06":
            #     pass
            # case "BACKUPFAILURE":
            #     return BackupFailure().TABLE_NAME
            # case "DISKCLEANUP":
            #     return DiskCleanup().TABLE_NAME
            # case "CPUHIGHALERT":
            #     return CpuHighAlert().TABLE_NAME
            # case "MEMORYHIGHALERT":
            #     return MemoryHighAlert().TABLE_NAME
            # case "WINDOWSVMUPGRADE":
            #     return AzWindowsVmUpgrade().TABLE_NAME
            # case "INACTIVERBAC":
            #     return AzInactiveRbac().TABLE_NAME
            # case "VMINVREVIEW":
            #     return VmInventoryReview().TABLE_NAME
            # case "RBACINVENTORYREVIEW":
            #     return RbacInventoryReview().TABLE_NAME
            # case "VMGROUPMEMBERREVIEW":
            #     return VmGroupMemberReview().TABLE_NAME
            # case "RBACGROUPMEMBERREVIEW":
            #     return RbacGroupMemberReview().TABLE_NAME
            # case "INACTIVEVMACCOUNTS":
            #     return InactiveVMAccounts().TABLE_NAME
            case "POLICYEXEMPTION":
                return AzPolicyExemption().TABLE_NAME
            case "KEYVAULTMGMT":
                return AzKeyVaultMgmt().TABLE_NAME
            case _:
                raise ValueError(f"Unknown activity name: {activity_name}")