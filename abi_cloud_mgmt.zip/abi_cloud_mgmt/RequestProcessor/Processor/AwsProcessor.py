import json,logging
from shared_code.db import DB
from shared_code.snow_client import SNOWClient
from RequestProcessor.DAL.DbActivityManager import DbActivityManager


class AwsProcessor:
    def __init__(self) -> None:
        self.objsnow = SNOWClient()
        self.objactivitymgr = DbActivityManager()
      
    def initialize(self,dataset):
        match dataset.ActivityName:      
            case "RBAC":
                print('RBAC')              

                