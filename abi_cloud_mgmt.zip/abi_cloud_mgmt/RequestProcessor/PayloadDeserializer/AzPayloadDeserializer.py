import json,logging
from shared_code.db import DB
from shared_code.snow_client import SNOWClient
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from Catalog.Azure.AppRoles.AzAppRole import AzAppRole
from Catalog.Azure.Rbac.AzRbac import AzRbac
from Catalog.Azure.Tags.AzTags import AzTags
from Catalog.Azure.RunCommand.AzEndTaskProcess import AzEndTaskProcess
from Catalog.Azure.AzInstanceStatus.AzInstanceStatus import AzInstanceStatus
from Catalog.Azure.VmResize.AzVmResize import AzVmResize
from Catalog.Azure.VmDiskResize.AzVmDiskResize import AzVmDiskResize
from Catalog.Azure.MsSqlDbResize.AzMsSqlDbResize import AzMsSqlDbResize
from Catalog.Azure.MSSqlAccess.mssql_access import AzMsSqlAccess
from Catalog.Azure.PostgreSqlAccess.postgresql_access import AzPostgreSqlAccess
from Catalog.Azure.LockManagement.lock_management import LockManagement
from Catalog.Azure.Decommission.decommission import AzDecommission
from Catalog.Azure.Decommission.decommission_preactivity import AzDecommissionPreactivity
from Catalog.Azure.Provisioning.Provisioning import AzProvisioning
from Catalog.Azure.AzSnapshot.AzSnapshotCreation import AzSnapshotCreation
from Catalog.Azure.VmAccessMgmt.VmAccessMgmt import AzVmAccessMgmt
from Catalog.Azure.VmCredMgmt.VmCredMgmt import AzVmCredMgmt
from Catalog.Azure.Rbac.AzRbacExceptional import AzRbacExceptional
from Catalog.Azure.HoursOfOperation.HoursOfOperation import AzHoursOfOperation
from Catalog.Azure.HoursOfOperationInstance.AzHoursOfOperationInstance import AzHoursOfOperationInstance
from Catalog.Azure.WindowsOSUpgrade.WindowsOSUpgrade import AzWindowsVmUpgrade
from Events.Azure.BackupFailure import BackupFailure
from Events.Azure.DiskCleanup import DiskCleanup
from Events.Azure.CpuHighAlert import CpuHighAlert
from Events.Azure.MemoryHighAlert import MemoryHighAlert
from Catalog.Azure.InactiveRbac.InactiveRbac import AzInactiveRbac
from Catalog.Azure.RbacInventoryReview.RbacInventoryReview import RbacInventoryReview
from Catalog.Azure.VmInventoryReview.VmInventoryReview import VmInventoryReview
from Catalog.Azure.GroupMemberReview.VmGroupMemberReview import VmGroupMemberReview
from Catalog.Azure.GroupMemberReview.RbacGroupMemberReview import RbacGroupMemberReview
from Catalog.Azure.InactiveVMAccounts.InactiveVMAccounts import InactiveVMAccounts
from Catalog.Azure.PolicyExemption.PolicyExemption import AzPolicyExemption
from Catalog.Azure.KeyVaultMgmt.KeyVaultMgmt import AzKeyVaultMgmt

class AzPayloadDeserializer:
    def __init__(self) -> None:
        self.objsnow = SNOWClient()
        self.objactivitymgr = DbActivityManager()
        self.objapprole = AzAppRole()
        self.objazrbac = AzRbac()
        self.objaztags = AzTags()
        self.objazendtaskprocess = AzEndTaskProcess()
        self.objazinstancestatus = AzInstanceStatus()
        self.objazvmresize = AzVmResize()
        self.objazvmdiskresize = AzVmDiskResize()
        self.objazmssqldbresize = AzMsSqlDbResize()
        self.objazmssqlaccess = AzMsSqlAccess()
        self.objazpostgresqlaccess = AzPostgreSqlAccess()
        self.objlockmanagement = LockManagement()
        self.objazdecomm = AzDecommission()
        self.objazdecommpreactivity = AzDecommissionPreactivity()
        self.objazprovisioning = AzProvisioning()
        self.objazsnapshot = AzSnapshotCreation()
        self.objazvmaccessmgmt = AzVmAccessMgmt()
        self.objazvmcredmgmt = AzVmCredMgmt()
        self.objazrbacexceptional = AzRbacExceptional()
        self.objazhoursoperation = AzHoursOfOperation()
        self.objazhoursoperationinstance = AzHoursOfOperationInstance()
        self.objwindowsosupgrade = AzWindowsVmUpgrade()
        self.objbackupfailure = BackupFailure()
        self.objdiskcleanup = DiskCleanup()
        self.objcpuhighalert = CpuHighAlert()
        self.objmemoryhighalert = MemoryHighAlert()
        self.objinactiverbac = AzInactiveRbac()
        self.objvminvreview = VmInventoryReview()
        self.objrbacrinvreview = RbacInventoryReview()
        self.objgroupmemberreview = VmGroupMemberReview()
        self.objrbacgroupmemberreview = RbacGroupMemberReview()
        self.objinactivevmaccounts = InactiveVMAccounts()
        self.objpolicyexemption = AzPolicyExemption()
        self.objkeyvaultmgmt = AzKeyVaultMgmt()

    def deserialize(self,dataset):
        pass
        match dataset.ActivityName:      
            # case "RBAC":
            #     self.objazrbac.activity_data(dataset)
            # case "APPROLE":
            #     self.objapprole.activity_data(dataset)
            # case "TAGS":
            #     self.objaztags.activity_data(dataset)
            # case "ENDTASKPROCESS":
            #     self.objazendtaskprocess.activity_data(dataset)
            # case "INSTANCESTATUS":
            #     self.objazinstancestatus.activity_data(dataset)
            # case "RESIZEVMSKU":
            #     self.objazvmresize.activity_data(dataset)
            # case "RESIZEVMDISK":
            #     self.objazvmdiskresize.activity_data(dataset)
            # case "RESIZESQLDB":
            #     self.objazmssqldbresize.activity_data(dataset)
            # case "MSSQLACCESS":
            #     self.objazmssqlaccess.activity_data(dataset)
            # case "POSTGRESQLACCESS":
            #     self.objazpostgresqlaccess.activity_data(dataset)
            # case "LOCKMANAGEMENT":
            #     self.objlockmanagement.activity_data(dataset)
            # case "DECOMM":
            #     self.objazdecomm.activity_data(dataset)
            # case "DECOMMPREACTIVITY":
            #     self.objazdecommpreactivity.activity_data(dataset)
            # case "RGPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "SNAPSHOTCREATION":
            #     self.objazsnapshot.activity_data(dataset)
            # case "VMACCESSMGMT":
            #     self.objazvmaccessmgmt.activity_data(dataset)
            # case "VMPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "VMCREDMGMT":
            #     self.objazvmcredmgmt.activity_data(dataset)
            # case "KEYVAULTPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "RBACEXCEPTIONAL":
            #     self.objazrbacexceptional.activity_data(dataset)
            # case "STORAGEACCOUNTPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "WEBAPPPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "LOGICAPPPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "FUNCTIONAPPPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "POSTGREDBPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "COSMOSDBPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "MSSQLDBPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "MSSQLELASTICPOOLPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "IT_ACCESS_06":
            #     logging.info(f"Activity {dataset.SnowItemId} event id {dataset.EventId} is handled by AD Team")           
            # case "MSSQLSERVERPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "MSSQLMGMTINSTANCEPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "APPINSIGHTSPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "DATABRICKSPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "DATAFACTORYPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "EVENTHUBPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "REDISCACHEPROVISION" :
            #     self.objazprovisioning.activity_data(dataset)
            # case "SERVICEBUSPROVISION" :
            #     self.objazprovisioning.activity_data(dataset)
            # case "PRIVATEENDPOINTPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "HOURSOFOPERATION":
            #     self.objazhoursoperation.activity_data(dataset)
            # case "HOURSOFOPERATIONINSTANCE":
            #     self.objazhoursoperationinstance.activity_data(dataset)
            # case "WINDOWSVMUPGRADE":
            #     self.objwindowsosupgrade.activity_data(dataset)
            # case "BACKUPFAILURE":
            #     self.objbackupfailure.activity_data(dataset)
            # case "DISKCLEANUP":
            #     self.objdiskcleanup.activity_data(dataset)
            # case "CPUHIGHALERT":
            #     self.objcpuhighalert.activity_data(dataset)
            # case "MEMORYHIGHALERT":
            #     self.objmemoryhighalert.activity_data(dataset)
            # case "INACTIVERBAC":
            #     self.objinactiverbac.activity_data(dataset)
            # case "VMINVREVIEW":
            #     self.objvminvreview.activity_data(dataset)
            # case "RBACINVENTORYREVIEW":
            #     self.objrbacrinvreview.activity_data(dataset)
            # case "VMGROUPMEMBERREVIEW":
            #     self.objgroupmemberreview.activity_data(dataset)
            # case "RBACGROUPMEMBERREVIEW":
            #     self.objrbacgroupmemberreview.activity_data(dataset)
            # case "INACTIVEVMACCOUNTS":
            #     self.objinactivevmaccounts.activity_data(dataset)
            # case "RBAC":
            #     self.objazrbac.activity_data(dataset)
            # case "APPROLE":
            #     self.objapprole.activity_data(dataset)
            # case "TAGS":
            #     self.objaztags.activity_data(dataset)
            # case "ENDTASKPROCESS":
            #     self.objazendtaskprocess.activity_data(dataset)
            # case "INSTANCESTATUS":
            #     self.objazinstancestatus.activity_data(dataset)
            # case "RESIZEVMSKU":
            #     self.objazvmresize.activity_data(dataset)
            # case "RESIZEVMDISK":
            #     self.objazvmdiskresize.activity_data(dataset)
            # case "RESIZESQLDB":
            #     self.objazmssqldbresize.activity_data(dataset)
            # case "MSSQLACCESS":
            #     self.objazmssqlaccess.activity_data(dataset)
            # case "POSTGRESQLACCESS":
            #     self.objazpostgresqlaccess.activity_data(dataset)
            # case "LOCKMANAGEMENT":
            #     self.objlockmanagement.activity_data(dataset)
            # case "DECOMM":
            #     self.objazdecomm.activity_data(dataset)
            # case "DECOMMPREACTIVITY":
            #     self.objazdecommpreactivity.activity_data(dataset)
            # case "RGPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "SNAPSHOTCREATION":
            #     self.objazsnapshot.activity_data(dataset)
            # case "VMACCESSMGMT":
            #     self.objazvmaccessmgmt.activity_data(dataset)
            # case "VMPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "VMCREDMGMT":
            #     self.objazvmcredmgmt.activity_data(dataset)
            # case "KEYVAULTPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "RBACEXCEPTIONAL":
            #     self.objazrbacexceptional.activity_data(dataset)
            # case "STORAGEACCOUNTPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "WEBAPPPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "LOGICAPPPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "FUNCTIONAPPPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "POSTGREDBPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "COSMOSDBPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "MSSQLDBPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "MSSQLELASTICPOOLPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "IT_ACCESS_06":
            #     logging.info(f"Activity {dataset.SnowItemId} event id {dataset.EventId} is handled by AD Team")           
            # case "MSSQLSERVERPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "MSSQLMGMTINSTANCEPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "APPINSIGHTSPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "DATABRICKSPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "DATAFACTORYPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "EVENTHUBPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "REDISCACHEPROVISION" :
            #     self.objazprovisioning.activity_data(dataset)
            # case "SERVICEBUSPROVISION" :
            #     self.objazprovisioning.activity_data(dataset)
            # case "PRIVATEENDPOINTPROVISION":
            #     self.objazprovisioning.activity_data(dataset)
            # case "HOURSOFOPERATION":
            #     self.objazhoursoperation.activity_data(dataset)
            # case "HOURSOFOPERATIONINSTANCE":
            #     self.objazhoursoperationinstance.activity_data(dataset)
            # case "WINDOWSVMUPGRADE":
            #     self.objwindowsosupgrade.activity_data(dataset)
            # case "BACKUPFAILURE":
            #     self.objbackupfailure.activity_data(dataset)
            # case "DISKCLEANUP":
            #     self.objdiskcleanup.activity_data(dataset)
            # case "CPUHIGHALERT":
            #     self.objcpuhighalert.activity_data(dataset)
            # case "MEMORYHIGHALERT":
            #     self.objmemoryhighalert.activity_data(dataset)
            # case "INACTIVERBAC":
            #     self.objinactiverbac.activity_data(dataset)
            # case "POLICYEXEMPTION":
            #     self.objpolicyexemption.activity_data(dataset)
            case "KEYVAULTMGMT":
                self.objkeyvaultmgmt.activity_data(dataset)
            # case "VMINVREVIEW":
            #     logging.info(f"Activity {dataset.SnowItemId} - Processing VM Inventory Review for Event ID: {dataset.EventId}")
            #     self.objvminvreview.activity_data(dataset)
            # case "RBACINVENTORYREVIEW":
            #     logging.info(f"Activity {dataset.SnowItemId} - Processing RBAC Inventory Review for Event ID: {dataset.EventId}")
            #     self.objrbacrinvreview.activity_data(dataset)
            # case "VMGROUPMEMBERREVIEW":
            #     logging.info(f"Activity {dataset.SnowItemId} - Processing Group Member Review for Event ID: {dataset.EventId}")
            #     self.objgroupmemberreview.activity_data(dataset)
            # case "RBACGROUPMEMBERREVIEW":
            #     logging.info(f"Activity {dataset.SnowItemId} - Processing RBAC Group Member Review for Event ID: {dataset.EventId}")
            #     self.objrbacgroupmemberreview.activity_data(dataset)
            # case "INACTIVEVMACCOUNTS":
            #     logging.info(f"Activity {dataset.SnowItemId} - Processing Inactive VM Accounts for Event ID: {dataset.EventId}")
            #     self.objinactivevmaccounts.activity_data(dataset)
            case _:
                logging.error(f"Unknown Azure Activity Name: {dataset.ActivityName}")