import azure.functions as func
from shared_code.constants import Constants
from shared_code.notification import Notification
from shared_code.db import DB
from RequestReceiver.RequestReceiver import RequestReceiver
from RequestProcessor.RequestProcessor import RequestProcessor
from shared_code.servicebus_client import ServiceBusClientAbstract
from azure.servicebus import ServiceBusMessage
from Events.Azure.EventClassifier import EventClassifier
import logging,json,os,asyncio
from shared_code.EmailNotification.NotifyUser import NotifyUser

app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)

@app.route(route="request_receiver")
async def request_receiver(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    data = req.get_json()
    sb_obj = ServiceBusClientAbstract()
    servicebus_client = sb_obj.get_servicebus_client()
    unique_key = sb_obj.generate_unique_key(data)
    data["message_id"] = unique_key
    objdb= DB()
    query="""
        SELECT EventId, ActivityName, ActivityType, SnowItemId, Status 
        FROM tblEventMaster 
        WHERE MessageId = ? AND Status IN ('Queued', 'Pending Approval', 'In-Progress')
    """
    duplicate_id = objdb.executescalar(sql_query=query,action="check",values=(unique_key,))
    if duplicate_id is not None:
        await NotifyUser().send_email_notification({'EventId':duplicate_id.EventId,'ActivityName':duplicate_id.ActivityName,'SnowItemId':duplicate_id.SnowItemId,'Status':duplicate_id.Status},data['RequestorEmail'])
        return func.HttpResponse(f"Duplicate {duplicate_id.ActivityType} {duplicate_id.SnowItemId}",status_code=200)
    else:
        sender = servicebus_client.get_topic_sender(topic_name="request_receiver")
        async def send_message():
            async with sender:
                message = ServiceBusMessage(json.dumps(data), message_id=unique_key)
                test = await sender.send_messages(message)
                logging.info(f"testrer {test}")
        # Schedule the async task to run in the background
        asyncio.create_task(send_message())
        return func.HttpResponse("Submitted",status_code=200)


@app.timer_trigger(schedule="0 */4 * * * *", arg_name="myTimer", run_on_startup=False,
              use_monitor=True) 
async def request_processor(myTimer: func.TimerRequest) -> None:
    try:
        logging.info('Starting request processor...')
        await RequestProcessor().process_request()

        if myTimer.past_due:
            logging.info('The timer is past due!')

        logging.info('Python timer trigger function executed.')
    except Exception as e:
        message = "Error message - %s" % repr(e)
        # await Notification().send_email_notification(f'{os.environ["Environment"]} - Event Processor error -',message,Constants.SMTP_KEYVAULT_SECRET)
        raise e
    

@app.service_bus_topic_trigger(arg_name="azservicebus", subscription_name="request_receiver", topic_name="request_receiver",
                               connection="AzureWebJobsMyServiceBus") 
async def request_receiver_trigger(azservicebus: func.ServiceBusMessage):
    try:
        data = json.loads(azservicebus.get_body().decode('utf-8'))
        request_receiver_obj = RequestReceiver()
        snow_tkt = await request_receiver_obj.request_initilize(data)
    except Exception as e:
        message = "Error message - %s" % repr(e)
        await Notification().send_email_notification(f'{os.environ["Environment"]} - Event Receiver error -',message,Constants.SMTP_KEYVAULT_SECRET)
        raise e   


# @app.route(route="incident_receiver", auth_level=func.AuthLevel.FUNCTION)
@app.route(route="incident_receiver", auth_level=func.AuthLevel.ANONYMOUS)
async def incident_receiver(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('\n\nPython HTTP trigger function processed a request.')

    data = req.get_json()
    logging.info(f"payload data: {data}")
    sb_obj = ServiceBusClientAbstract()
    servicebus_client = sb_obj.get_servicebus_client()
    objdb= DB()
    query="""
        SELECT EventId, ActivityName, ActivityType, SnowItemId, Status 
        FROM tblEventMaster 
        WHERE SnowItemId = ?
    """
    duplicate_id = objdb.executescalar(sql_query=query,action="check",values=(data['SnowId'],))
    if duplicate_id is not None:
        logging.info(f"Duplicate {duplicate_id.ActivityType} {duplicate_id.SnowItemId}")
        return func.HttpResponse(f"Duplicate {duplicate_id.ActivityType} {duplicate_id.SnowItemId}",status_code=200)
    else:
        try:
            unique_key = sb_obj.generate_unique_key(data)
            data["message_id"] = unique_key
            sender = servicebus_client.get_topic_sender(topic_name="incident_receiver")
            async def send_message():
                async with sender:
                    message = ServiceBusMessage(json.dumps(data), message_id=unique_key)
                    await sender.send_messages(message)
            # Schedule the async task to run in the background
            asyncio.create_task(send_message())
        except Exception as e:
            logging.error(f"Error processing incident receiver: {e}")
            logging.error(f"payload data: {data}")
            message = "Error message - %s" % repr(e)
            await Notification().send_email_notification(f'{os.environ["Environment"]} - Incident Receiver error -',message,Constants.SMTP_KEYVAULT_SECRET)
        return func.HttpResponse("Submitted",status_code=200)


@app.service_bus_topic_trigger(arg_name="azservicebus", subscription_name="incident_receiver", topic_name="incident_receiver",
                               connection="AzureWebJobsMyServiceBus") 
async def incident_receiver_trigger(azservicebus: func.ServiceBusMessage):
    try:
        data = json.loads(azservicebus.get_body().decode('utf-8'))
        payload = EventClassifier().classify_event(data)
        if payload is None:
            return
        payload['message_id'] = data.get('message_id')
        request_receiver_obj = RequestReceiver()
        snow_tkt = await request_receiver_obj.request_initilize(payload)
    except Exception as e:
        message = "Error message - %s" % repr(e)
        message += f"\n\npayload data: {data}"
        logging.error(message)
        await Notification().send_email_notification(f'{os.environ["Environment"]} - Incident Receiver error -',message,Constants.SMTP_KEYVAULT_SECRET)
        raise e   
    data = req.get_json()
    logging.info(f"payload data: {data}")
    # sb_obj = ServiceBusClientAbstract()
    # servicebus_client = sb_obj.get_servicebus_client()
    objdb= DB()
    query="""
        SELECT EventId, ActivityName, ActivityType, SnowItemId, Status 
        FROM tblEventMaster 
        WHERE SnowItemId = ?
    """
    duplicate_id = objdb.executescalar(sql_query=query,action="check",values=(data['SnowId'],))
    if duplicate_id is not None:
        logging.info(f"Duplicate {duplicate_id.ActivityType} {duplicate_id.SnowItemId}")
        return func.HttpResponse(f"Duplicate {duplicate_id.ActivityType} {duplicate_id.SnowItemId}",status_code=200)
    else:
        try:
            payload = EventClassifier().classify_event(data)
            if payload is None:
                return func.HttpResponse("No Action Required",status_code=200)
            # unique_key = sb_obj.generate_unique_key(payload)
            # payload["message_id"] = unique_key
            # sender = servicebus_client.get_topic_sender(topic_name="incident_receiver")
            # async def send_message():
            #     async with sender:
            #         message = ServiceBusMessage(json.dumps(payload), message_id=unique_key)
            #         logging.info(f"[TEST MODE] Payload that would be sent to Service Bus: {json.dumps(payload, indent=2)}")
                    
            #         await sender.send_messages(message)
            # # Schedule the async task to run in the background
            # asyncio.create_task(send_message())
            
            # FOR TESTING: Log what would be sent instead
            logging.info(f"[TEST MODE] Payload that would be sent to Service Bus: {json.dumps(payload, indent=2)}")
           
            # import uuid
            # payload["message_id"] = str(uuid.uuid4())
            # await RequestReceiver().request_initilize(payload)
                    
            # logging.info(f"[TEST MODE] Message ID: {payload['message_id']}")
        
        except Exception as e:
            logging.error(f"Error processing incident receiver: {e}")
            logging.error(f"payload data: {data}")
            # message = "Error message - %s" % repr(e)
            # await Notification().send_email_notification(f'{os.environ["Environment"]} - Incident Receiver error -',message,Constants.SMTP_KEYVAULT_SECRET)
        return func.HttpResponse("Submitted",status_code=200)


@app.service_bus_topic_trigger(arg_name="azservicebus", subscription_name="incident_receiver", topic_name="incident_receiver",
                               connection="AzureWebJobsMyServiceBus") 
async def incident_receiver_trigger(azservicebus: func.ServiceBusMessage):
    try:
        data = json.loads(azservicebus.get_body().decode('utf-8'))
        request_receiver_obj = RequestReceiver()
        logging.info(f"\n\n\n[FLOW-1] incident_receiver_trigger called | ActivityType: {data['ActivityType']} | SnowItemId: {data['SnowItemId']}")
        snow_tkt = await request_receiver_obj.request_initilize(data)
    except Exception as e:
        message = "Error message - %s" % repr(e)
        await Notification().send_email_notification(f'{os.environ["Environment"]} - Event Receiver error -',message,Constants.SMTP_KEYVAULT_SECRET)
        raise e   


@app.service_bus_topic_trigger(arg_name="azservicebus", subscription_name="zero_touch", topic_name="zero_touch",
                               connection="AzureWebJobsMyServiceBus") 
async def zero_touch_receiver_trigger(azservicebus: func.ServiceBusMessage):
    try:
        data = json.loads(azservicebus.get_body().decode('utf-8'))

        if 'message_id' not in data:
            sb_obj = ServiceBusClientAbstract()
            data['message_id'] = sb_obj.generate_unique_key(data)

        request_receiver_obj = RequestReceiver()
        snow_tkt = await request_receiver_obj.request_initilize(data)
    except Exception as e:
        message = "Error message - %s" % repr(e)
        await Notification().send_email_notification(f'{os.environ["Environment"]} - Event Receiver error Zero Touch -',message,Constants.SMTP_KEYVAULT_SECRET)
        raise e   


@app.route(route="test_request_receiver", auth_level=func.AuthLevel.ANONYMOUS)
async def test_request_receiver(req: func.HttpRequest) -> func.HttpResponse:
    import uuid
    data = req.get_json()
    logging.info(f"\n\n\n[FLOW-7] test_request_receiver called {data}")
    data["message_id"] = str(uuid.uuid4())
    snow_tkt = await RequestReceiver().request_initilize(data)
    return func.HttpResponse(f"Done. SnowItemId: {snow_tkt}", status_code=200)



@app.route(route="test_processor", auth_level=func.AuthLevel.ANONYMOUS)
async def test_processor(req: func.HttpRequest) -> func.HttpResponse:
    await RequestProcessor().process_request()
    return func.HttpResponse("Done", status_code=200)