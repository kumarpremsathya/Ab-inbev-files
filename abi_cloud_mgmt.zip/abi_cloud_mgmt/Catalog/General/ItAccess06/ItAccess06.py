from shared_code.snow_client import SNOWClient

class ItAccess06:

    def __init__(self) -> None:
        self.objsnow = SNOWClient()

    def snow_data(self,data):
        self.request_data = data
        self.request_data["short_description"] = f"ABI Cloud Management Portal request for {data['payload']['data']['action']} user to AD Group"
        self.request_data["description"] = f"The user {data['RequestorEmail']} has requested for {data['payload']['data']['action']} user to AD Group {data['payload']['data']['ad_group']} in ABI Cloud Management"
        self.request_data["business_service"] = "ee722b2edb46fb08e444fcb6ae96190b"
        self.request_data["cat_item"] = "fd27857d1be7b810f861a640604bcbdc"        
        self.request_data["assignment_group"] = "d4c4b485dbc623402f1b51a4ce9619f4"
        self.request_data["sys_domain"] = "global"
        self.request_data["variables"] = {}
        if data['payload']['data']['action'] == "Add":
            self.request_data["variables"]["action"] = "add_group_members" #"Add Group Members (Automated Process)"
        if data['payload']['data']['action'] == "Remove":
            self.request_data["variables"]["action"] = "remove_group_members"
        self.request_data["variables"]["select_the_tokens_you_would_like_to_be_issued_by_the_authorisation_endpoint"] = "false"
        self.request_data["variables"]["id_tokens_used_for_implicit_and_hybrid_flows"] = "false"
        self.request_data["variables"]["name"] = data['payload']['data']['ad_group']
        self.request_data["variables"]["name_of_group"] = f"____{data['payload']['data']['ad_group'].upper()}"
        members = []
        for member in data['payload']['data']['members']:
            user_details = self.objsnow.get_user_details_by_email(member['display_name'])
            if user_details:
                members.append(user_details["sys_id"])
        self.request_data["variables"]["members"] = members
        self.request_data["variables"]["additional_information"] = data['payload']['data']['justification']

        return self.request_data        