import json
from datetime import datetime, timezone, timedelta
import logging
from shared_code.db import DB
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from shared_code.snow_client import SNOWClient


class AzKeyVaultMgmt:
    def __init__(self) -> None:
        self.KEYVAULTMGMT_RETRY_ATTEMPT = timedelta(minutes=5, hours=0, days=0)
        self.TABLE_NAME = "tblActivityAzKeyVaultMgmt"
        self.objdb = DB()
        self.objactivitymgr = DbActivityManager()
        self.objsnow = SNOWClient()

    def snow_data(self, data):
        self.request_data = data

        payload_data = data['payload']['data']
        action = data.get('action', '')
        key_vault_name = payload_data.get('key_vault_name', '')
        secret_name = payload_data.get('secret_name', '')
        content_type = payload_data.get('content_type', '')
        expires_on = payload_data.get('expires_on', '')
        zone = payload_data.get('zone', '')
        subscription_name = payload_data.get('subscription_name', '')
        resource_group_name = payload_data.get('resource_group_name', '')

        self.request_data["short_description"] = (
            f"ABI Cloud Management Portal - Azure - Key Vault Management - "
            f"{action} Secret '{secret_name}' in '{key_vault_name}'"
        )

        self.request_data["description"] = (
            f"The user {data['RequestorEmail']} has requested to {action} a secret in Azure Key Vault.\n\n"
            f"Zone: {zone}\n"
            f"Subscription: {subscription_name} ({payload_data.get('subscription_id', '')})\n"
            f"Resource Group: {resource_group_name}\n"
            f"Key Vault: {key_vault_name}\n"
            f"Secret Name: {secret_name}\n"
            f"Content Type: {content_type}\n"
            f"Expires On: {expires_on if expires_on else 'N/A'}\n"
            f"Justification: {data['payload'].get('justification', '')}"
        )

        logging.info(f"\n\nKEYVAULTMGMT short_description: {self.request_data['short_description']}")
        logging.info(f"\n\nKEYVAULTMGMT description: {self.request_data['description']}")

        # persist action inside payload so activity_data() can retrieve it from tblEventMaster
        self.request_data["payload"]["action"] = action

        self.request_data.update(
            {
                "business_service": "41b9ca581ba250d04a803150cd4bcbbe",
                "variables": {
                    "catalog_name": f"Key Vault Management - {action} Secret",
                    "category": "Key Vault Management",
                    "catalog_description": f"{action} secret in Azure Key Vault",
                    "zone": zone,
                    "subscription_id": payload_data.get("subscription_id", ""),
                    "subscription_name": subscription_name,
                    "resource_group_name": resource_group_name,
                    "key_vault_name": key_vault_name,
                    "secret_name": secret_name,
                    "content_type": content_type,
                    "expires_on": expires_on,
                    "action": action,
                    "justification": data['payload'].get("justification", ""),
                    "devowners": data['payload'].get("devowners", ""),
                }
            }
        )

        return self.request_data

    def activity_data(self, dataset):
        sql_query = """
            MERGE INTO tblActivityAzKeyVaultMgmt AS Target
            USING (
                SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
            ) AS Source
            (EventId, SubscriptionId, SubscriptionName, ResourceGroupName,
            KeyVaultName, SecretName, ContentType, ExpiresOn, Action,
            Zone, Cloud, Status, Comments, RetryAttemptedAt,
            SecretValue, IV, Tag, Tags, Justification)
            ON Target.EventId = Source.EventId
            WHEN NOT MATCHED THEN
                INSERT (EventId, SubscriptionId, SubscriptionName, ResourceGroupName,
                        KeyVaultName, SecretName, ContentType, ExpiresOn, Action,
                        Zone, Cloud, Status, Comments, RetryAttemptedAt,
                        SecretValue, IV, Tag, Tags, Justification)
                VALUES (Source.EventId, Source.SubscriptionId, Source.SubscriptionName, Source.ResourceGroupName,
                        Source.KeyVaultName, Source.SecretName, Source.ContentType, Source.ExpiresOn, Source.Action,
                        Source.Zone, Source.Cloud, Source.Status, Source.Comments, Source.RetryAttemptedAt,
                        Source.SecretValue, Source.IV, Source.Tag, Source.Tags, Source.Justification);
            """
        
        try:
            payload = json.loads(dataset.Payload)
            payload_data = payload.get("data", {})

            values = (
                dataset.EventId,
                payload_data.get("subscription_id", ""),
                payload_data.get("subscription_name", ""),
                payload_data.get("resource_group_name", ""),
                payload_data.get("key_vault_name", ""),
                payload_data.get("secret_name", ""),
                payload_data.get("content_type") or None,
                payload_data.get("expires_on") or None,
                payload.get("action", ""),
                payload_data.get("zone", ""),
                dataset.Cloud,
                "In-Progress",
                "Pending key vault secret operation",
                datetime.now(timezone.utc),
                payload_data.get("secret_value", None),
                payload_data.get("iv", None),
                payload_data.get("tag", None),
                json.dumps(payload_data.get("tags")) if payload_data.get("tags") is not None else None,
                payload.get("justification", None),   # top-level payload field, not inside data
            )

            self.objdb.executescalar(sql_query=sql_query, action="insert", values=values)
        except Exception as e:
            logging.error(f"Failed to insert record for key vault management: {str(e)} {dataset}")
            raise

        self.objactivitymgr.insert_activity_pending(dataset)
        logging.info(f"EventId {dataset.EventId} marked as Pending for KEYVAULTMGMT processing")
