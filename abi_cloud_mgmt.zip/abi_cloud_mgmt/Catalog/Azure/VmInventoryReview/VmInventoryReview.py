import json,logging
from datetime import datetime,timezone,timedelta
from shared_code.db import DB
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from shared_code.snow_client import SNOWClient

class VmInventoryReview:

    def __init__(self) -> None:
        self.VM_INV_REVIEW_RETRY_ATTEMPT = timedelta(minutes=5,hours=0,days=0)
        self.TABLE_NAME = 'tblActivityVmInventoryReview'
        self.objdb= DB()
        self.objactivitymgr = DbActivityManager()
        self.objsnow = SNOWClient()
    
    def snow_data(self,data):
        self.request_data = data
        # vms = []
        # for vm in data["payload"]["data"]:
        #     vms.append(vm["vms"]["node"])
        accounts = []
        for account in data["payload"]["data"]:
            accounts.append(account["accountName"])

        self.request_data["short_description"] = f"ABI Cloud Management Portal request for reviewing accounts {','.join(accounts)} requested by - {data['RequestorEmail']}"
        self.request_data["description"] = (
            f"The user {data['RequestorEmail']} has reviewed the following accounts: {','.join(accounts)} in ABI Cloud Management Portal"
            f"in zone {data['zone']}."
        )

        # Regular Request
        self.request_data.update(
            {
                "business_service": "41b9ca581ba250d04a803150cd4bcbbe",
                "variables": {
                    "catalog_name": "VM Inventory Review",
                    "category": "IT_ACCESS_01",
                    "catalog_description": "Review of VM inventory",
                    "zone": data["zone"],
                    "approver": data["RequestorEmail"],
                    "accounts": ",".join(accounts)
                }
            }
        )

        return self.request_data 
    
    def activity_data(self,dataset):
        sql_query = """        
            MERGE INTO tblActivityVmInventoryReview as Target
            USING (SELECT ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            AS SOURCE(EventId, UniqueId, AccountId, AccountName, Node, Ipaddress, ApplicationUID, ProjectName, PrivilegedAccess, AccountEnabled, Action, Approver, Zone, Status,RetryAttemptedAt)
            ON Target.EventId=Source.EventId
            AND Target.UniqueId=Source.UniqueId
            AND Target.AccountId=Source.AccountId
            AND Target.AccountName=Source.AccountName
            AND Target.Node=Source.Node
            AND Target.Ipaddress=Source.Ipaddress
            AND Target.ApplicationUID=Source.ApplicationUID
            AND Target.ProjectName=Source.ProjectName
            AND Target.PrivilegedAccess=Source.PrivilegedAccess
            AND Target.AccountEnabled=Source.AccountEnabled
            AND Target.Action=Source.Action
            AND Target.Approver=Source.Approver
            AND Target.Zone=Source.Zone
            AND Target.Status='In-Progress'
            WHEN NOT MATCHED THEN
            INSERT (EventId, UniqueId, AccountId, AccountName, Node, Ipaddress, ApplicationUID, ProjectName, PrivilegedAccess, AccountEnabled, Action, Approver, Zone, Status, RetryAttemptedAt)
            VALUES (Source.EventId, Source.UniqueId, Source.AccountId, Source.AccountName, Source.Node, Source.Ipaddress, Source.ApplicationUID, Source.ProjectName, Source.PrivilegedAccess, Source.AccountEnabled, Source.Action, Source.Approver, Source.Zone, Source.Status, Source.RetryAttemptedAt);
        """
        payload = json.loads(dataset.Payload)
        for account in payload["data"]:
            for vm in account["vms"]:
                values = (
                    dataset.EventId,
                    vm["uniqueId"],
                    account["accountId"],
                    account["accountName"],
                    vm["node"],
                    vm["ipaddress"],
                    vm["applicationUID"],
                    vm["projectName"],
                    vm["privilegedAccess"],
                    vm["accountEnabled"],
                    vm["action"],
                    vm["approvers"],
                    dataset.Zone,
                    "In-Progress",
                    datetime.now(timezone.utc)  # RetryAttemptedAt
                )
                logging.info(f"Insert values {values}")
                self.objdb.executescalar(
                    sql_query=sql_query, action="insert", values=values
                )
        self.objactivitymgr.insert_activity_pending(dataset)