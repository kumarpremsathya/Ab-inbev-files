import json,logging
from shared_code.db import DB
from datetime import datetime,timezone,timedelta
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from shared_code.snow_client import SNOWClient

class AzRbacExceptional:

    def __init__(self) -> None:
        self.AZRBAC_RETRY_ATTEMPT = timedelta(minutes=5,hours=0,days=0)
        self.TABLE_NAME = 'tblActivityAzRbac'              
        self.TOPIC_NAME = 'azrbac'
        self.objsnow = SNOWClient()
        self.objdb= DB()
        self.objactivitymgr = DbActivityManager()

    def snow_data(self,data):
        self.request_data = data        
        self.request_data["business_service"] = "41b9ca581ba250d04a803150cd4bcbbe"
        self.request_data["variables"] = {}
        self.request_data["variables"]["catalog_description"] = "Provide RBAC Exceptional roles to Alt|Srv|Bot Account,Users/Groups/Service Principals"
        self.request_data["variables"]["justification"] = data['payload']['data']['justification']
        self.request_data["variables"]["catalog_name"] = "RBAC Exceptional"
        self.request_data["variables"]["category"] = "rbac-exceptional"

        roles = []
        for role in data['payload']['data']['roles']:
            roles.append(role['role_name'])
        self.request_data["variables"]["role_name"] = roles

        members = []
        for member in data['payload']['data']['member_ids']:
            members.append(member['display_name'])

        if data['payload']['data']['scope'].lower() == 'subscription':
            self.request_data["short_description"] = f"Azure - RBAC Exceptional - {data['RequestorEmail']} - Subscription - {data['payload']['data']['subscription_name']} - Roles - {','.join(roles)}"
            self.request_data["variables"]["subscription"] = data['payload']['data']['subscription_name']
            self.request_data["variables"]["resource_name"] = data['payload']['data']['subscription_id']
            self.request_data["description"] = f"The user {data['RequestorEmail']} has requested a access for the Subscription - {data['payload']['data']['subscription_name']} in ABI Cloud Management Portal."


        if data['payload']['data']['scope'].lower() == 'managementgroup':
            mgmt_group_name = data['payload']['data']['management_group_name']
            mgmt_group_name = mgmt_group_name.replace('Tenant Root Group', 'Root')
            self.request_data["short_description"] = f"Azure - RBAC Exceptional - {data['RequestorEmail']} - Mgmt Group - {mgmt_group_name} - Roles - {','.join(roles)}"
            self.request_data["description"] = f"The user {data['RequestorEmail']} has requested a access for the Management Group - {data['payload']['data']['management_group_name']} in ABI Cloud Management Portal."
            self.request_data["variables"]["management_group"] = data['payload']['data']['management_group_name']
            self.request_data["variables"]["resource_name"] = data['payload']['data']['management_group_id']
            
        if data['payload']['data']['member_type'].lower() in ['user','botaccount','serviceaccount']:
            self.request_data["variables"]["domain_users"] = members
        if data['payload']['data']['member_type'].lower() == 'group':
            self.request_data["variables"]["group_name"] = members
        if data['payload']['data']['member_type'].lower() == 'spn':
            self.request_data["variables"]["spn_name"] = members
        if data['payload']['data']['member_type'].lower() == 'altaccount':
            self.request_data["variables"]["altaccount_name"] = members
        if data['payload']['data']['is_temporary'] == True or data['payload']['data']['member_type'].lower() == 'altaccount':
            self.request_data["description"] += f"\r\n The access will be valid for {data['payload']['data']['duration']} Hours from time of provisioning."

        if data['zone'] == 'NAZ':
            self.request_data["variables"]["devowner"] = ["10e2d7d3dbec78109cb8cde405961932"]


        return self.request_data        
    
    def activity_data(self,dataset):
        sql_query = """        
            MERGE INTO tblActivityAzRbac as Target
            USING (SELECT ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            AS SOURCE(EventId,ManagementGroupId,ManagementGroupName,SubscriptionId,SubscriptionName,ResourceGroupId,ResourceName,ResourceId,Scope,MemberType,
                        MemberIds,Roles,IsTemporary,Duration,Justification,Zone,Cloud,Status,RetryAttemptedAt)
            ON Target.EventId=Source.EventId
            AND Target.ManagementGroupId=Source.ManagementGroupId            
            AND Target.SubscriptionId=Source.SubscriptionId
            AND Target.ResourceGroupId=Source.ResourceGroupId
            AND Target.ResourceId=Source.ResourceId
            AND Target.Scope=Source.Scope
            AND Target.MemberType=Source.MemberType
            AND Target.Status='In-Progress'            
            WHEN NOT MATCHED THEN
            INSERT (EventId,ManagementGroupId,ManagementGroupName,SubscriptionId,SubscriptionName,ResourceGroupId,ResourceName,ResourceId,Scope,MemberType,
                        MemberIds,Roles,IsTemporary,Duration,Justification,Zone,Cloud,Status,RetryAttemptedAt)
            VALUES (Source.EventId,Source.ManagementGroupId,Source.ManagementGroupName,Source.SubscriptionId,Source.SubscriptionName,Source.ResourceGroupId,
                    Source.ResourceName,Source.ResourceId,Source.Scope,Source.MemberType,Source.MemberIds,Source.Roles,Source.IsTemporary,
                    Source.Duration,Source.Justification,Source.Zone,Source.Cloud,Source.Status,Source.RetryAttemptedAt);
        """
        payload = json.loads(dataset.Payload)
        values=(
                dataset.EventId,
                payload['data'].get('management_group_id'),
                payload['data'].get('management_group_name'),
                payload['data'].get('subscription_id'),
                payload['data'].get('subscription_name'),
                payload['data'].get('resource_group'),
                payload['data'].get('resource_name'),
                payload['data'].get('resource_id'),
                payload['data']['scope'],
                payload['data']['member_type'],
                json.dumps(payload['data']['member_ids']),
                json.dumps(payload['data']['roles']),
                payload['data']['is_temporary'],
                payload['data']['duration'],
                payload['data']['justification'],
                payload['data']['zone'],
                dataset.Cloud,
                'In-Progress',
                datetime.now(timezone.utc)
            )
        self.objdb.executescalar(sql_query=sql_query,action="insert",values=values)
        self.objactivitymgr.insert_activity_pending(dataset)