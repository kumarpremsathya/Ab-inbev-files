import json,logging
import traceback
from shared_code.db import DB
from datetime import datetime,timezone,timedelta
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from shared_code.snow_client import SNOWClient
from shared_code.graphservice_client import GraphClient
from msgraph.generated.groups.groups_request_builder import GroupsRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration

class AzRbac:

    def __init__(self) -> None:
        self.AZRBAC_RETRY_ATTEMPT = timedelta(minutes=5,hours=0,days=0)
        self.TABLE_NAME = 'tblActivityAzRbac'              
        self.TOPIC_NAME = 'azrbac'
        self.objsnow = SNOWClient()
        self.objdb= DB()
        self.objactivitymgr = DbActivityManager()
        self.graph_client_obj = GraphClient()

    async def is_member_of_group(self,group_id,user_id):
        logging.info(f"Checking if member is present in group - {group_id} , member - {user_id}")
        try: 
            for group in group_id.split(','):
                self.graph_client= self.graph_client_obj.get_client_request_adapter("AzurePublicCloud")
                query_params = GroupsRequestBuilder.GroupsRequestBuilderGetQueryParameters(
                            select=["id","displayName"],
                            filter = f"id eq '{user_id}'",
                            count=True
                )
                request_configuration = RequestConfiguration(query_parameters = query_params,)
                request_configuration.headers.add("ConsistencyLevel", "eventual")
                result = await self.graph_client.groups.by_group_id(group).transitive_members.get(request_configuration=request_configuration)
                logging.info(result)
                if result.odata_count != 0:
                    return True
            return False
        except Exception as e:
            logging.error(traceback.format_exc())
            return None

    async def snow_data(self,data):
        self.request_data = data
        self.request_data["short_description"] = f"ABI Cloud Management Portal - Azure - RBAC - {data['RequestorEmail']}"
        self.request_data["business_service"] = "41b9ca581ba250d04a803150cd4bcbbe"
        self.request_data["variables"] = {}
        self.request_data["variables"]["catalog_description"] = "Provide RBAC roles to Alt|Srv|Bot Account,Users/Groups/Service Principals"
        self.request_data["variables"]["justification"] = data['payload']['data']['justification']

        roles = []
        saz_group = None
        for role in data['payload']['data']['roles']:
            roles.append(role['role_name'])
            if role['role_id'].lower() == '/providers/microsoft.authorization/roledefinitions/1e410830-c17b-4da8-b13a-be2dc2600433':
                saz_group =  '93d29f9a-64c4-4025-a126-be7aab652c9f' ## ZSA-Ambev-SREs
            elif role['role_id'].lower() == '/providers/microsoft.authorization/roledefinitions/dbaa5179-dad3-49a7-a102-f60c84a5d639':
                saz_group = '1c87d4f4-4309-48ba-8f25-21d40b53c5b6' ## ZSA-Ambev-CloudOps
            elif role['role_id'].lower() == '/providers/microsoft.authorization/roledefinitions/e5c25ae4-b756-4494-8f94-40dc44d4fddb':
                saz_group = 'fc7b2633-f864-421d-848f-1f2e0f09f7d0' ## ZSA-Ambev-SecOps
            elif role['role_id'].lower() == '/providers/microsoft.authorization/roledefinitions/3d37ddd4-5411-4a69-9d41-eefce20965dc':
                saz_group = '93d29f9a-64c4-4025-a126-be7aab652c9f,1c87d4f4-4309-48ba-8f25-21d40b53c5b6,fc7b2633-f864-421d-848f-1f2e0f09f7d0' ## Ambev-Readers
            
        self.request_data["variables"]["role_name"] = roles

        members = []
        for member in data['payload']['data']['member_ids']:
            members.append(member['display_name'])

        if data['payload']['data']['scope'].lower() == 'resource' or data['payload']['data']['scope'].lower() == 'resourcegroup':
            devowner_sys_ids = []
            for email in data["payload"]["devowners"].split(';'):
                user_details = self.objsnow.get_user_details_by_email(email)
                if user_details:
                    devowner_sys_ids.append(user_details["sys_id"])
                else:
                    print(f"Warning: Email {email} not found in sys_user table")
            if data['payload']['data']['subscription_name'] in ['ABI GLZ SUPPLY GHQ PROD','ABI GLZ SUPPLY GHQ NON-PROD']:
                self.request_data["variables"]["catalog_name"] = "RBAC Supply"
                self.request_data["variables"]["category"] = "rbac-supply"
            elif data['zone'] == 'BREWDAT':
                self.request_data["variables"]["catalog_name"] = "RBAC Brewdat"
                self.request_data["variables"]["category"] = "rbac-brewdat"
            elif saz_group:
                if await self.is_member_of_group(saz_group,data['OID']):
                    self.request_data["variables"]["catalog_name"] = "RBAC SAZ"
                    self.request_data["variables"]["category"] = "RBAC SAZ"
                else:
                    self.request_data["variables"]["catalog_name"] = "RBAC"
                    self.request_data["variables"]["category"] = "RBAC"
            else:        
                self.request_data["variables"]["catalog_name"] = "RBAC"
                self.request_data["variables"]["category"] = "RBAC"
            self.request_data["variables"]["subscription"] = data['payload']['data']['subscription_name']
            self.request_data["variables"]["resource_group_name"] = data['payload']['data']['resource_group']            
            self.request_data["variables"]["devowner"] = ",".join(devowner_sys_ids)

        if data['payload']['data']['scope'].lower() == 'resource':
            self.request_data["description"] = f"The user {data['RequestorEmail']} has requested a access for the Subscription - {data['payload']['data']['subscription_name']} for the resource id - {data['payload']['data']['resource_id']} in ABI Cloud Management Portal."
            self.request_data["variables"]["resource_name"] = data['payload']['data']['resource_id']

        if data['payload']['data']['scope'].lower() == 'resourcegroup':
            self.request_data["description"] = f"The user {data['RequestorEmail']} has requested a access for the Subscription - {data['payload']['data']['subscription_name']} for the resource group id - {data['payload']['data']['resource_group_id']} in ABI Cloud Management Portal."
            self.request_data["variables"]["resource_name"] = data['payload']['data']['resource_group_id']

        if data['payload']['data']['scope'].lower() == 'subscription':
            self.request_data["variables"]["subscription"] = data['payload']['data']['subscription_name']
            self.request_data["variables"]["resource_name"] = data['payload']['data']['subscription_id']
            self.request_data["description"] = f"The user {data['RequestorEmail']} has requested a access for the Subscription - {data['payload']['data']['subscription_name']} in ABI Cloud Management Portal."
            if data['payload']['data']['subscription_name'] in ['ABI GLZ SUPPLY GHQ PROD','ABI GLZ SUPPLY GHQ NON-PROD']:
                self.request_data["variables"]["catalog_name"] = "RBAC Supply"
                self.request_data["variables"]["category"] = "rbac-supply"
            elif  data['payload']['data']['member_type'].lower() == 'spn':
                self.request_data["variables"]["catalog_name"] = "RBAC Privileged SPN"
                self.request_data["variables"]["category"] = "rbac-privileged-spn"
            elif data['zone'] == 'BREWDAT':
                self.request_data["variables"]["catalog_name"] = "RBAC Brewdat"
                self.request_data["variables"]["category"] = "rbac-brewdat"
            else:
                self.request_data["variables"]["catalog_name"] = "RBAC Privileged"
                self.request_data["variables"]["category"] = "rbac-privileged"

        if data['payload']['data']['scope'].lower() == 'managementgroup':
            self.request_data["description"] = f"The user {data['RequestorEmail']} has requested a access for the Management Group - {data['payload']['data']['management_group_name']} in ABI Cloud Management Portal."
            self.request_data["variables"]["catalog_name"] = "RBAC Privileged"
            self.request_data["variables"]["category"] = "rbac-privileged"
            self.request_data["variables"]["management_group"] = data['payload']['data']['management_group_name']
            self.request_data["variables"]["resource_name"] = data['payload']['data']['management_group_id']
            
        if data['payload']['data']['member_type'].lower() in ['user','botaccount','serviceaccount']:
            self.request_data["variables"]["domain_users"] = members
        if data['payload']['data']['member_type'].lower() == 'group':
            self.request_data["variables"]["group_name"] = members
        if data['payload']['data']['member_type'].lower() == 'spn':
            self.request_data["variables"]["spn_name"] = members
        if data['payload']['data']['member_type'].lower() == 'altaccount':
            self.request_data["variables"]["altaccount_name"] = members
        self.request_data["description"] += f"\n The access will be valid for {data['payload']['data']['duration']} Hours from time of provisioning." if data['payload']['data']['is_temporary'] == True else ""


        return self.request_data        
    
    def activity_data(self,dataset):
        sql_query = """        
            MERGE INTO tblActivityAzRbac as Target
            USING (SELECT ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            AS SOURCE(EventId,ManagementGroupId,ManagementGroupName,SubscriptionId,SubscriptionName,ResourceGroupId,ResourceName,ResourceId,Scope,MemberType,
                        MemberIds,Roles,IsTemporary,Duration,Justification,Zone,Cloud,Status,RetryAttemptedAt)
            ON Target.EventId=Source.EventId
            AND Target.ManagementGroupId=Source.ManagementGroupId            
            AND Target.SubscriptionId=Source.SubscriptionId
            AND Target.ResourceGroupId=Source.ResourceGroupId
            AND Target.ResourceId=Source.ResourceId
            AND Target.Scope=Source.Scope
            AND Target.MemberType=Source.MemberType
            AND Target.Status='In-Progress'            
            WHEN NOT MATCHED THEN
            INSERT (EventId,ManagementGroupId,ManagementGroupName,SubscriptionId,SubscriptionName,ResourceGroupId,ResourceName,ResourceId,Scope,MemberType,
                        MemberIds,Roles,IsTemporary,Duration,Justification,Zone,Cloud,Status,RetryAttemptedAt)
            VALUES (Source.EventId,Source.ManagementGroupId,Source.ManagementGroupName,Source.SubscriptionId,Source.SubscriptionName,Source.ResourceGroupId,
                    Source.ResourceName,Source.ResourceId,Source.Scope,Source.MemberType,Source.MemberIds,Source.Roles,Source.IsTemporary,
                    Source.Duration,Source.Justification,Source.Zone,Source.Cloud,Source.Status,Source.RetryAttemptedAt);
        """
        payload = json.loads(dataset.Payload)
        values=(
                dataset.EventId,
                payload['data'].get('management_group_id'),
                payload['data'].get('management_group_name'),
                payload['data'].get('subscription_id'),
                payload['data'].get('subscription_name'),
                payload['data'].get('resource_group'),
                payload['data'].get('resource_name'),
                payload['data'].get('resource_id'),
                payload['data']['scope'],
                payload['data']['member_type'],
                json.dumps(payload['data']['member_ids']),
                json.dumps(payload['data']['roles']),
                payload['data']['is_temporary'],
                payload['data']['duration'],
                payload['data']['justification'],
                payload['data']['zone'],
                dataset.Cloud,
                'In-Progress',
                datetime.now(timezone.utc)
            )
        self.objdb.executescalar(sql_query=sql_query,action="insert",values=values)
        self.objactivitymgr.insert_activity_pending(dataset)