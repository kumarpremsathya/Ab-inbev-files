import json
from datetime import datetime, timezone, timedelta
import logging
from shared_code.db import DB
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from shared_code.snow_client import SNOWClient


class AzInactiveRbac:
    def __init__(self) -> None:
        self.AZINACTIVERBAC_RETRY_ATTEMPT = timedelta(minutes=5, hours=0, days=0)
        self.TABLE_NAME = "tblActivityAzInactiveRbac"
        self.objdb = DB()
        self.objactivitymgr = DbActivityManager()
        self.objsnow = SNOWClient()

    def snow_data(self, data):

        self.request_data = data
    
        inactive_user_records = []
        deleted_user_records = []
        
        for inactive_user_detail in data['payload']['inactive_user_details']:
            user_email = inactive_user_detail.get('inactive_user_email')
            user_status = inactive_user_detail.get('user_status', '')
            principal_id = inactive_user_detail.get('principal_id', '')
            scopes = inactive_user_detail.get('scopes', '')
            
            if user_status == 'Deleted User':
                deleted_user_records.append(
                    f"Deleted User (Principal ID: {principal_id})\n"
                    f"Scopes: {scopes}\n"
                )
            else:
                inactive_user_records.append(
                    f"Inactive User: {user_email}\n"
                    f"Scopes: {scopes}\n"
                )

        # Build description based on user types
        description_parts = []
        
        if deleted_user_records:
            deleted_text = "\n".join(deleted_user_records)
            description_parts.append(
                f"Auto cleanup of RBAC assignments of Deleted Users\n\n"
                f"Role Assignments to be deleted:\n{deleted_text}"
            )
        
        if inactive_user_records:
            inactive_text = "\n".join(inactive_user_records)
            description_parts.append(
                f"Auto cleanup of RBAC assignments of Inactive Users\n\n"
                f"Role Assignments to be deleted:\n{inactive_text}"
            )

        self.request_data["description"] = "\n\n".join(description_parts)

        logging.info(f"\n\n\nDescription set to: {self.request_data['description']}")

        # Build short description based on user types
        short_desc_parts = []
        inactive_users_list = data['payload'].get('inactive_users', [])
        
        if inactive_user_records and inactive_users_list:
            short_desc_parts.append(
                f"inactive_users: {', '.join(inactive_users_list[:2])}{'...' if len(inactive_users_list) > 2 else ''}"
            )
        
        if deleted_user_records:
            short_desc_parts.append(f"deleted_users: {len(deleted_user_records)}")

        # Determine cleanup type for short description
        if deleted_user_records and inactive_user_records:
            cleanup_type = "Inactive & Deleted RBAC Cleanup"
        elif deleted_user_records:
            cleanup_type = "Deleted RBAC Cleanup"
        else:
            cleanup_type = "Inactive RBAC Cleanup"

        self.request_data["short_description"] = (
            f"ABI Cloud Management Portal - Azure - {cleanup_type} - "
            f"RequestorEmail: {data['RequestorEmail']} - "
            f"{' - '.join(short_desc_parts)}"
        )

        logging.info(f"\n\n\nShort description set to: {self.request_data['short_description']}\n\n\n")

        # ServiceNow Request payload
        self.request_data.update(
           {
            "business_service": "41b9ca581ba250d04a803150cd4bcbbe",
            "variables": {
                "catalog_name": "Inactive RBAC Cleanup",
                "category": "Access Management",
                "catalog_description": "Remove RBAC assignments for inactive users in Azure",
                "zone": data.get("zone", ""),
                "tenant": data["payload"].get("tenant", ""),
                "inactive_user_details": str(data["payload"].get("inactive_user_details", [])),
                "inactive_users": ",".join(data["payload"].get("inactive_users", []))
            }
        }
        )

        return self.request_data 
      
    
    def activity_data(self, dataset):
      
        sql_query = """
        MERGE INTO tblActivityAzInactiveRbac AS Target
        USING (
            SELECT 
            S.EventId, 
            S.PrincipalId, 
            CASE WHEN U.AccountType is NULL or U.AccountType = 'NULL' THEN 'UNKNOWN' ELSE U.AccountType END AS AccountType,
            CASE WHEN U.UserId is NULL or U.UserId = 'NULL' THEN 'UNKNOWN' ELSE U.UserId END AS UserId,
            CASE WHEN U.DisplayName is NULL or U.DisplayName = 'NULL' THEN 'UNKNOWN' ELSE U.DisplayName END AS DisplayName,
            CASE WHEN U.ManagerEmail is NULL or U.ManagerEmail = 'NULL' THEN 'UNKNOWN' ELSE S.ManagerEmail END AS ManagerEmail, 
            CASE WHEN U.Email is NULL or U.Email = 'NULL' THEN 'UNKNOWN' ELSE U.Email END AS Email, 
            S.RoleAssignmentsId, 
            R.Scope, 
            R.ScopeType,
            R.PrincipalType,
            R.RoleName,
            R.RoleType,
            R.RoleDescription, 
            S.SubscriptionId,
            R.SubscriptionName,
            R.ResourceName,
            R.ResourceType,
            R.ResourceId,
            R.ManagementGroup,
            S.Cloud, 
            R.Zone, 
            S.Status, 
            S.Comments,
            S.RetryAttemptedAt, 
            S.UserStatus, 
            Case WHEN L.EmployeeId is not null THEN 'WORKDAY' ELSE S.CleanType END AS CleanType
            FROM (
                SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
            ) AS S
            (EventId, PrincipalId, UserId, ManagerEmail, Email, RoleAssignmentsId, Scope, ScopeType, SubscriptionId, Cloud, Zone, Status, Comments,
                RetryAttemptedAt, UserStatus, CleanType)
            left outer JOIN tblAbiLeaversReport L
                ON S.principalid = L.userid
            left outer JOIN tblazureusersreport U
                ON S.principalid = U.userid
            left outer JOIN tblazureroleassignmentsreport R
                ON S.RoleAssignmentsId = R.RoleAssignmentsId
        ) AS Source
        ON Target.EventId = Source.EventId
        AND Target.RoleAssignmentsId = Source.RoleAssignmentsId
        WHEN NOT MATCHED THEN
            INSERT (EventId, PrincipalId, AccountType, UserId, DisplayName, ManagerEmail, Email, RoleAssignmentsId, Scope, ScopeType,
                    PrincipalType, RoleName, RoleType, RoleDescription, SubscriptionId, SubscriptionName, ResourceName,
                    ResourceType, ResourceId, ManagementGroup, Cloud, Zone, Status, Comments, RetryAttemptedAt,
                    UserStatus, CleanType)
            VALUES (Source.EventId, Source.PrincipalId, Source.AccountType, Source.UserId, Source.DisplayName,
                    Source.ManagerEmail, Source.Email, Source.RoleAssignmentsId, Source.Scope, Source.ScopeType,
                    Source.PrincipalType, Source.RoleName, Source.RoleType, Source.RoleDescription,
                    Source.SubscriptionId, Source.SubscriptionName, Source.ResourceName,
                    Source.ResourceType, Source.ResourceId, Source.ManagementGroup,
                    Source.Cloud, Source.Zone, Source.Status, Source.Comments,
                    Source.RetryAttemptedAt, Source.UserStatus, Source.CleanType);
        """
        try:
            payload = json.loads(dataset.Payload)
            manager_email = payload.get("manager_email")
            inactive_user_details = payload.get("inactive_user_details", [])

            zone_data = {}

            for inactive_user_detail in inactive_user_details:
                email = inactive_user_detail.get("inactive_user_email","UNKNOWN")
                principal_id = inactive_user_detail.get("principal_id")
                user_id = inactive_user_detail.get("user_id","UNKNOWN")
                user_status = inactive_user_detail.get("user_status")
                role_assignments_ids = inactive_user_detail.get("role_assignments_ids",[]).split(",")
                scopes = inactive_user_detail.get("scopes",[]).split(",")
                for role_assignments_id, scope in zip(role_assignments_ids, scopes):
                    if scope.split("/")[1].lower() == "subscriptions":
                        if len(scope.split("/")) == 3:
                            scope_type = "Subscription"
                        elif len(scope.split("/")) == 5:
                            scope_type = "Resource Group"
                        elif len(scope.split("/")) > 5:
                            scope_type = "Resource"
                    elif scope.split("/")[3].lower() == "managementgroups":
                        scope_type = "Management Group"
                    else: 
                        scope_type = None
                    subscription_id = scope.split("/")[2] if scope and "subscriptions" in scope else None
                    if subscription_id:
                        if subscription_id not in zone_data:
                            zone_data[subscription_id] = self.objactivitymgr.get_zone(subscription_id)
                        zone = zone_data[subscription_id]
                    else:
                        zone = None
                    values = (
                        dataset.EventId,
                        principal_id,
                        user_id,
                        manager_email,
                        email,
                        role_assignments_id,
                        scope,
                        scope_type,
                        subscription_id,
                        dataset.Cloud,
                        zone,
                        "In-Progress",
                        f"Pending removal for user: {email}" if email else "Pending removal for users",
                        datetime.now(timezone.utc),
                        user_status,
                        "LEAVERS"
                    )
                    self.objdb.executescalar(sql_query=sql_query, action="insert", values=values)
        except Exception as e:
            logging.error(f"Failed to insert record for inactive users: {str(e)} {dataset} user:{inactive_user_detail}")
            raise

        # Mark activity as pending in tblEventPendingActivity
        self.objactivitymgr.insert_activity_pending(dataset)
        logging.info(f"EventId {dataset.EventId} marked as Pending for INACTIVERBAC processing")
