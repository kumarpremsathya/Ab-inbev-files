from shared_code.snow_client import SNOWClient
import json,logging

class PrivateEndpointSnowData:

    def __init__(self) -> None:
        self.objsnow = SNOWClient()

    def snow_data(self, data):
        devowner_sys_ids = []
        devowners = data["payload"].get("devowners", "")
        if devowners:
            for email in devowners.split(';'):
                user_details = self.objsnow.get_user_details_by_email(email)
                if user_details:
                    devowner_sys_ids.append(user_details["sys_id"])
                else:
                    print(f"Warning: Email {email} not found in sys_user table")

        target_resource_id = data['payload']['data'].get('target_resource_id', '')
        target_resource_name = target_resource_id.split('/')[-1] if target_resource_id else 'Unknown'
        
        self.request_data = data
        self.request_data["short_description"] = f"ABI Cloud Management Portal - Creating Private Endpoint in RG {data['payload']['data']['resource_group_name']} - Name {data['payload']['data']['private_endpoint_name']}"
        self.request_data["description"] = f"""The user {data['RequestorEmail']} has requested for creating Private Endpoint in Resource Group {data['payload']['data']['resource_group_name']} in 
        ABI Cloud Management Portal under the location {data['payload']['data'].get('location', 'N/A')} as Name {data['payload']['data']['private_endpoint_name']}.
        
        Target Resource: {target_resource_name}
        Group ID: {data['payload']['data'].get('group_id', 'N/A')}
        Network Interface: {data['payload']['data'].get('network_interface_name', 'N/A')}"""
        
        self.request_data["business_service"] = "41b9ca581ba250d04a803150cd4bcbbe"
        self.request_data["variables"] = {}
        self.request_data["variables"]["catalog_name"] = f"Azure Private Endpoint Provisioning - Name {data['payload']['data']['private_endpoint_name']}"
        self.request_data["variables"]["category"] = "resource provisioning"
        self.request_data["variables"]["catalog_description"] = "Create a new Private Endpoint in Azure"
        self.request_data["variables"]["subscription"] = data['payload']['data'].get('subscription_name', data['payload']['data'].get('subscription_id', 'N/A'))
        self.request_data["variables"]["rg_name"] = data['payload']['data']['resource_group_name']
        self.request_data["variables"]["location"] = data['payload']['data'].get('location', 'N/A')
        self.request_data["variables"]["resource_name"] = data['payload']['data']['private_endpoint_name']
        self.request_data["variables"]["network_interface_name"] = data['payload']['data'].get('network_interface_name', 'N/A')
        self.request_data["variables"]["target_resource"] = target_resource_name
        self.request_data["variables"]["group_id"] = data['payload']['data'].get('group_id', 'N/A')
        self.request_data["variables"]["public_network_access"] = data['payload']['data'].get('public_network_access', 'N/A')
        self.request_data["variables"]["devowner"] = ",".join(devowner_sys_ids)
        
        tags = data['payload']['data'].get("tags", {})
        self.request_data["variables"]["dev_owner_email"] = tags.get('DevOwnerEmail', 'N/A')
        self.request_data["variables"]["business_owner_email"] = tags.get('BusinessOwnerEmail', 'N/A')
        self.request_data["variables"]["cost_center"] = tags.get('CostCenter', 'N/A')
        self.request_data["variables"]["project_name"] = tags.get('ProjectName', 'N/A')
        self.request_data["variables"]["department"] = tags.get('Department', 'N/A')
        self.request_data["variables"]["criticality"] = tags.get('Criticality', 'N/A')
        self.request_data["variables"]["maintenance_window"] = tags.get('MaintenanceWindow', 'N/A')
        self.request_data["variables"]["applicationuid"] = tags.get('applicationUID', 'N/A')
        self.request_data["variables"]["justification"] = data['payload'].get('justification', 'N/A')
        self.request_data["variables"]["capex_dollar_impact"] = tags.get('CapexDollarImpact', 'NA')
        self.request_data["variables"]["opex_dollar_impact"] = tags.get('OpexDollarImpact', 'NA')
        self.request_data["variables"]["opex_cc"] = tags.get('OpexCC', 'NA')
        self.request_data["variables"]["primary_function"] = tags.get('PrimaryFunction', 'NA')
        self.request_data["variables"]["gl"] = tags.get('GL', 'NA')
        self.request_data["variables"]["cost_element"] = tags.get('CostElement', 'NA')
        self.request_data["variables"]["hours_of_operation"] = tags.get('HoursOfOperation', 'NA')

        return self.request_data
