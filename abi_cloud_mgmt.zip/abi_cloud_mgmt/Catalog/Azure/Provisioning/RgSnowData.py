class AzRgSnowData:

    def __init__(self) -> None:
        pass

    def snow_data(self,data):
        self.request_data = data
        self.request_data["short_description"] = f"ABI Cloud Management Portal - Creating Resource Group - {data['payload']['data']['resource_group_name']}" 
        self.request_data["description"] = f"""The user {data['RequestorEmail']} has requested for creating Resource Group {data['payload']['data']['resource_group_name']}  in 
        ABI Cloud Management Portal under the loation {data['payload']['data']['location']}."""
        self.request_data["business_service"] = "41b9ca581ba250d04a803150cd4bcbbe" 
        self.request_data["variables"] = {}
        self.request_data["variables"]["catalog_name"] = "Azure Resource Group Provisioning"
        self.request_data["variables"]["category"] = "resource group provisioning"        
        self.request_data["variables"]["catalog_description"] = "Create a new Resource Group in Azure"
        self.request_data["variables"]["subscription"] = data['payload']['data']['subscription_name']
        self.request_data["variables"]["rg_name"] = data['payload']['data']['resource_group_name']        
        self.request_data["variables"]["location"] = data['payload']['data']['location']
        self.request_data["variables"]["dev_owner_email"] = data['payload']['data']["tags"]['DevOwnerEmail']
        self.request_data["variables"]["business_owner_email"] = data['payload']['data']["tags"]['BusinessOwnerEmail']
        self.request_data["variables"]["cost_center"] = data['payload']['data']["tags"]['CostCenter']
        self.request_data["variables"]["project_name"] = data['payload']['data']["tags"]['ProjectName']
        self.request_data["variables"]["department"] = data['payload']['data']["tags"]['Department']
        self.request_data["variables"]["criticality"] = data['payload']['data']["tags"]['Criticality']        
        self.request_data["variables"]["maintenance_window"] = data['payload']['data']["tags"]['MaintenanceWindow']        
        self.request_data["variables"]["applicationuid"] = data['payload']['data']["tags"]['applicationUID']
        self.request_data["variables"]["justification"] = data['payload']['justification']
        self.request_data["variables"]["capex_dollar_impact"] = data['payload']['data']["tags"].get('CapexDollarImpact',"NA")      
        self.request_data["variables"]["opex_dollar_impact"] = data['payload']['data']["tags"].get('OpexDollarImpact',"NA")
        self.request_data["variables"]["opex_cc"] = data['payload']['data']["tags"].get('OpexCC',"NA")
        self.request_data["variables"]["primary_function"] = data['payload']['data']["tags"].get('PrimaryFunction',"NA")
        self.request_data["variables"]["gl"] = data['payload']['data']["tags"].get('GL',"NA")
        self.request_data["variables"]["cost_element"] = data['payload']['data']["tags"].get('CostElement',"NA")
        self.request_data["variables"]["hours_of_operation"] = data['payload']['data']["tags"].get('HoursOfOperation',"NA")

        return self.request_data 

