from shared_code.snow_client import SNOWClient
import json
import logging

class AzVmSnowData:

    def __init__(self) -> None:
        self.objsnow = SNOWClient()

    def snow_data(self,data):
        devowner_sys_ids = []
        for email in data["payload"]["devowners"].split(';'):
            user_details = self.objsnow.get_user_details_by_email(email)
            if user_details:
                devowner_sys_ids.append(user_details["sys_id"])
            else:
                print(f"Warning: Email {email} not found in sys_user table")

        members = []
        for member in data['payload']['data']['member_ids']:
            members.append(member['display_name'])

        self.request_data = data
        self.request_data["short_description"] = f"ABI Cloud Management Portal - Creating Virtual Machine in RG {data['payload']['data']['resource_group_name']} - Hostname {data['payload']['data']['hostname_range']}" 
        self.request_data["description"] = f"""The user {data['RequestorEmail']} has requested for creating virtual machine in Resource Group {data['payload']['data']['resource_group_name']}  in 
        ABI Cloud Management Portal under the loation {data['payload']['data']['vm_location']} as Hostname {data['payload']['data']['hostname_range']}."""
        self.request_data["business_service"] = "41b9ca581ba250d04a803150cd4bcbbe" 
        self.request_data["variables"] = {}
        self.request_data["variables"]["catalog_name"] = f"Azure Virtual Machine Provisioning - {data['payload']['data']['vm_image']}"
        self.request_data["variables"]["category"] = "resource provisioning"        
        self.request_data["variables"]["catalog_description"] = "Create a new Virtual Machine in Azure"
        self.request_data["variables"]["subscription"] = data['payload']['data']['subscription_name']
        self.request_data["variables"]["rg_name"] = data['payload']['data']['resource_group_name']        
        self.request_data["variables"]["location"] = data['payload']['data']['vm_location']
        self.request_data["variables"]["env"] = data['payload']['data']['environment']
        self.request_data["variables"]["resource_name"] = data['payload']['data']['hostname_range']
        self.request_data["variables"]["vm_size"] = data['payload']['data']['vm_size']
        self.request_data["variables"]["devowner"] = ",".join(devowner_sys_ids)
        self.request_data["variables"]["dev_owner_email"] = data['payload']['data']["tags"]['DevOwnerEmail']
        self.request_data["variables"]["business_owner_email"] = data['payload']['data']["tags"]['BusinessOwnerEmail']
        self.request_data["variables"]["cost_center"] = data['payload']['data']["tags"]['CostCenter']
        self.request_data["variables"]["project_name"] = data['payload']['data']["tags"]['ProjectName']
        self.request_data["variables"]["department"] = data['payload']['data']["tags"]['Department']
        self.request_data["variables"]["criticality"] = data['payload']['data']["tags"]['Criticality']        
        self.request_data["variables"]["maintenance_window"] = data['payload']['data']["tags"]['MaintenanceWindow']        
        self.request_data["variables"]["applicationuid"] = data['payload']['data']["tags"]['applicationUID']
        self.request_data["variables"]["justification"] = data['payload']['justification']
        self.request_data["variables"]["capex_dollar_impact"] = data['payload']['data']["tags"].get('CapexDollarImpact',"NA")      
        self.request_data["variables"]["opex_dollar_impact"] = data['payload']['data']["tags"].get('OpexDollarImpact',"NA")
        self.request_data["variables"]["opex_cc"] = data['payload']['data']["tags"].get('OpexCC',"NA")
        self.request_data["variables"]["primary_function"] = data['payload']['data']["tags"].get('PrimaryFunction',"NA")
        self.request_data["variables"]["gl"] = data['payload']['data']["tags"].get('GL',"NA")
        self.request_data["variables"]["cost_element"] = data['payload']['data']["tags"].get('CostElement',"NA")
        self.request_data["variables"]["hours_of_operation"] = data['payload']['data']["tags"].get('HoursOfOperation',"NA")
        self.request_data["variables"]["licensed_software"] = data['payload']['data'].get('licensed_software',"NA")
        #self.request_data["variables"]["licensed_software"] = "no"
        self.request_data["variables"]["db_on_vm"] = data['payload']['data'].get('db_on_vm',"NA")
        self.request_data["variables"]["db_to_installed"] = data['payload']['data'].get('db_to_installed',"NA")
        self.request_data["variables"]["software_ritm"] = data['payload']['data'].get('software_ritm',"NA")
        self.request_data["variables"]["software_ritm_number"] = data['payload']['data'].get('software_ritm_number',"NA")
        self.request_data["variables"]["software_evidence"] = data['payload']['data'].get('software_evidence',"NA")


        return self.request_data 
