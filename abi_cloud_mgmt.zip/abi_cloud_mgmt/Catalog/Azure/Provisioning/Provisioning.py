import json
from datetime import datetime, timedelta, timezone
import logging
from shared_code.db import DB
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from shared_code.snow_client import SNOWClient
from shared_code.constants import Constants
from shared_code.servicebus_client import ServiceBusClientAbstract

class AzProvisioning:
    def __init__(self) -> None:
        self.PROVISIONING_RETRY_ATTEMPT = timedelta(minutes=10, hours=0, days=0)
        self.TABLE_NAME = "tblActivityAzProvisioning"
        self.objactivitymgr = DbActivityManager()
        self.objsnow = SNOWClient()
        self.objdb= DB()
        self.objsbuscli = ServiceBusClientAbstract()

    def activity_data(self, dataset):
        logging.info(f"Activity data called with dataset: {dataset}")
        sql_query = """
            MERGE INTO tblActivityAzProvisioning AS Target
            USING (SELECT ?, ?, ?, ?, ?, ?, ?,?)
            AS SOURCE(EventId,MessageId,ActivityName,Payload,Cloud,Zone,Status,RetryAttemptedAt)
            ON Target.EventId = Source.EventId
            AND Target.MessageId = Source.MessageId
            AND Target.ActivityName = Source.ActivityName
            AND Target.Cloud = Source.Cloud
            AND Target.Zone = Source.Zone
            AND Target.Status = 'In-Progress'
            WHEN NOT MATCHED THEN
            INSERT (EventId,MessageId,ActivityName,Payload,Cloud,Zone,Status,RetryAttemptedAt)
            VALUES (Source.EventId, Source.MessageId,Source.ActivityName,Source.Payload, Source.Cloud,
                    Source.Zone, Source.Status, Source.RetryAttemptedAt);
        """
        fullpayload = {}
        fullpayload["ActivityName"] = dataset.ActivityName
        payload = json.loads(dataset.Payload)
        fullpayload["payload"] = payload
        unique_key = self.objsbuscli.generate_unique_key(payload)
        
        values = (
            dataset.EventId,
            unique_key,
            dataset.ActivityName,
            json.dumps(fullpayload),
            dataset.Cloud,
            dataset.Zone,
            "In-Progress",
            datetime.now(timezone.utc)  # RetryAttemptedAt
        )
        self.objdb.executescalar(
            sql_query=sql_query, action="insert", values=values
        )
        
        self.objactivitymgr.insert_activity_pending(dataset)