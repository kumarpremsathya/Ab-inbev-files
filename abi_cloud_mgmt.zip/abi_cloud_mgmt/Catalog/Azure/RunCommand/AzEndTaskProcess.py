import json,logging
from datetime import datetime,timezone,timedelta
from shared_code.db import DB
from RequestProcessor.DAL.DbActivityManager import DbActivityManager

class AzEndTaskProcess:
    def __init__(self) -> None:
        self.AZRUNCOMMAND_RETRY_ATTEMPT = timedelta(minutes=60,hours=0,days=0)
        self.objdb= DB()
        self.objactivitymgr = DbActivityManager()

    def snow_data(self,data):
        self.request_data = data
        self.request_data["short_description"] = f"ABI Multi Cloud Management - Process to kill in vm {data['payload']['data']['node']}"
        self.request_data["description"] = f"The user {data['RequestorEmail']} has requested to kill the process {data['payload']['data']['process_id']} in the vm {data['payload']['data']['node']}."
        self.request_data["business_service"] = "41b9ca581ba250d04a803150cd4bcbbe"
        self.request_data["u_symptom"] = "u_broken_damage"
        self.request_data["category"]  = "Other Issues"

        return self.request_data    
    
    def activity_data(self,dataset):
        sql_query = """        
            MERGE INTO tblActivityRunCommand as Target
            USING (SELECT ?,?,?,?,?,?,?,?)
            AS SOURCE(EventId,Node,RunCommand,Kernel,Zone,Cloud,Status,RetryAttemptedAt)
            ON Target.EventId=Source.EventId
            AND Target.Node=Source.Node
            AND Target.RunCommand=Source.RunCommand
            AND Target.Kernel=Source.Kernel
            WHEN NOT MATCHED THEN
            INSERT (EventId,Node,RunCommand,Kernel,Zone,Cloud,Status,RetryAttemptedAt)
            VALUES (Source.EventId,Source.Node,Source.RunCommand,Source.Kernel,Source.Zone,Source.Cloud,Source.Status,Source.RetryAttemptedAt);
        """
        payload = json.loads(dataset.Payload)
        match payload['data']['kernel']:
            case 'Linux':
                command = f'kill -9 {payload["data"]["process_id"]}'
            case 'Windows':
                command = f'powershell -command "Get-Process -Id {payload["data"]["process_id"]} | ? {{$_.Kill()}}"'
        values=(
                dataset.EventId,
                payload['data']['node'],                    
                command,
                payload['data']['kernel'],
                payload['data']['zone'],
                dataset.Cloud,
                'In-Progress',
                datetime.now(timezone.utc)
            )
        self.objdb.executescalar(sql_query=sql_query,action="insert",values=values)
        self.objactivitymgr.insert_activity_pending(dataset)