from azure.mgmt.compute.models import RunCommandInput
from shared_code.compute_client import ComputeClient
import logging

class AzRunCommandPublic:
    def __init__(self,data) -> None:
        self.compute_client = ComputeClient().get_compute_client('AzurePublicCloud',data["SubscriptionId"])
        self.resource_group = data["ResourceGroup"]
        self.node = data["Node"]
        self.script = data["RunCommand"]
        self.kernel = data["Kernel"]
        self.command_id = "RunShellScript" if self.kernel == 'Linux' else "RunPowerShellScript"
    
    def vm_running(self):
        if self.compute_client.virtual_machines.instance_view(self.resource_group,self.node).statuses[1].display_status == 'VM running':
            return True
        return False

    def run_command(self):
        try: 
            if not self.vm_running():
                logging.error(f"VM is not in running state")
                return False,"VM is not in running state"
            command = RunCommandInput(command_id=self.command_id, script=self.script)
            result = self.compute_client.virtual_machines.begin_run_command(
                resource_group_name=self.resource_group,
                vm_name=self.node,
                parameters=command,
            )
            logging.info(f"RunCommand initiate successfull for {self.node}")
            token = result.continuation_token()
            return token
        except Exception as e:
            logging.error(f"Error RunCommand for {self.node} - {e}")
            return False,e