import json,logging
from datetime import datetime,timezone,timedelta
from shared_code.db import DB
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from shared_code.snow_client import SNOWClient

class VmGroupMemberReview:

    def __init__(self) -> None:
        self.GROUP_MEMBER_RETRY_ATTEMPT = timedelta(minutes=5,hours=0,days=0)
        self.TABLE_NAME = 'tblActivityVmGroupMemberReview'
        self.objdb= DB()
        self.objactivitymgr = DbActivityManager()
        self.objsnow = SNOWClient()
    
    def snow_data(self,data):
        self.request_data = data
        account_name = data["payload"]["data"]["accountName"]
        account_id = data["payload"]["data"]["accountId"]
        domain = data["payload"]["data"]["domain"]
        node = data["payload"]["data"]["node"]
        ipaddress = data["payload"]["data"]["ipaddress"]
        kernel = data["payload"]["data"]["kernel"]
        action = data["payload"]["data"]["action"]

        request_data = {
            "RequestorEmail": data["RequestorEmail"],
            "zone": data["zone"],
            "short_description": f"Group Membership Review - {action} action in group {account_name}",
            "description": (
                f"{action} group membership action in group {account_name} (ID: {account_id}).\n"
                f"Domain: {domain}\n"
                f"Node: {node}\n"
                f"IP Address: {ipaddress}\n"
                f"Kernel: {kernel}\n"
                f"Requested by: {data['RequestorEmail']}"
            ),
        }

        if action.lower() == "approved":
            request_data["business_service"] = "41b9ca581ba250d04a803150cd4bcbbe"
            request_data["variables"] = {
                "catalog_name": "Group Membership Review",
                "category": "IT_ACCESS_01",
                "catalog_description": "Review of group membership",
                "zone": data["zone"],
                "approver": data["RequestorEmail"],
            }
        elif action.lower() == "revoked":
            request_data["business_service"] = "ee722b2edb46fb08e444fcb6ae96190b"
            request_data["cat_item"] = "fd27857d1be7b810f861a640604bcbdc"
            request_data["assignment_group"] = "d4c4b485dbc623402f1b51a4ce9619f4"
            request_data["sys_domain"] = "global"
            members = []
            for member in data["payload"]["data"]["members"]:
                user_details = self.objsnow.get_user_details_by_email(member["name"])
                if user_details:
                    members.append(user_details["sys_id"])
            request_data["variables"] = {
                "action": "remove_group_members",
                "select_the_tokens_you_would_like_to_be_issued_by_the_authorisation_endpoint": "false",
                "id_tokens_used_for_implicit_and_hybrid_flows": "false",
                "name": account_name,
                "name_of_group": f"____{account_name.upper()}",
                "members": members,
                "additional_information": request_data["description"],
            }

        self.request_data.update(request_data)
        return self.request_data 
    
    def activity_data(self,dataset):
        sql_query = """        
            MERGE INTO tblActivityVmGroupMemberReview as Target
            USING (SELECT ?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            AS SOURCE(EventId, GroupId, GroupName, MemberId, MemberName, Domain, Node, Ipaddress, Kernel, Action, Approver, Zone, Status, RetryAttemptedAt)
            ON Target.EventId=Source.EventId
            AND Target.GroupId=Source.GroupId
            AND Target.GroupName=Source.GroupName
            AND Target.MemberId=Source.MemberId
            AND Target.MemberName=Source.MemberName
            AND Target.Domain=Source.Domain
            AND Target.Node=Source.Node
            AND Target.Ipaddress=Source.Ipaddress
            AND Target.Kernel=Source.Kernel
            AND Target.Action=Source.Action
            AND Target.Approver=Source.Approver
            AND Target.Zone=Source.Zone
            AND Target.Status='Success'
            WHEN NOT MATCHED THEN
            INSERT (EventId,GroupId,GroupName,MemberId,MemberName,Domain,Node,Ipaddress,Kernel,Action,Approver,Zone,Status,RetryAttemptedAt)
            VALUES (Source.EventId,Source.GroupId,Source.GroupName,Source.MemberId,Source.MemberName,Source.Domain,Source.Node,Source.Ipaddress,Source.Kernel,Source.Action,Source.Approver,Source.Zone,Source.Status,Source.RetryAttemptedAt);
        """

       
        payload = json.loads(dataset.Payload)
        account_name = payload["data"]["accountName"]
        account_id = payload["data"]["accountId"]

        for member in payload["data"]["members"]:
            values = (
                dataset.EventId,
                account_id,
                account_name,
                member["id"],
                member["name"],
                payload["data"]["domain"],
                payload["data"]["node"],
                payload["data"]["ipaddress"],
                payload["data"]["kernel"],
                member["action"],
                dataset.RequestedBy,
                dataset.Zone,
                'Success',
                datetime.now(timezone.utc)
            )
            self.objdb.executescalar(
                sql_query=sql_query, action="insert", values=values
            )

        self.objactivitymgr.insert_activity_pending(dataset)