import json,logging
from datetime import datetime,timezone,timedelta
from shared_code.db import DB
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from shared_code.snow_client import SNOWClient

class RbacGroupMemberReview:

    def __init__(self) -> None:
        self.GROUP_MEMBER_RETRY_ATTEMPT = timedelta(minutes=5,hours=0,days=0)
        self.TABLE_NAME = 'tblActivityRbacGroupMemberReview'
        self.objdb= DB()
        self.objactivitymgr = DbActivityManager()
        self.objsnow = SNOWClient()
    
    def snow_data(self,data):
        self.request_data = data

        self.request_data["short_description"] = f"ABI Cloud Management Portal request for reviewing group membership for {data['payload']['groupId']} requested by - {data['RequestorEmail']}"
        self.request_data["description"] = (
            f"The user {data['RequestorEmail']} has reviewed the group membership for the following accounts: {data['payload']['groupId']} in ABI Cloud Management Portal"
            f"in zone {data['zone']}."
        )

        # Regular Request
        self.request_data.update(
            {
                "business_service": "41b9ca581ba250d04a803150cd4bcbbe",
                "variables": {
                    "catalog_name": "RBAC Group Membership Review",
                    "category": "IT_ACCESS_01",
                    "catalog_description": "Review of group membership",
                    "zone": data["zone"],
                    "approver": data["RequestorEmail"]
                }
            }
        )

        return self.request_data 
    
    def activity_data(self,dataset):
        sql_query = """        
            MERGE INTO tblActivityRbacGroupMemberReview as Target
            USING (SELECT ?,?,?,?,?,?,?,?,?,?)
            AS SOURCE(EventId, GroupId, GroupName, MemberId, MemberName, Action, Approver, Zone, Status, RetryAttemptedAt)
            ON Target.EventId=Source.EventId
            AND Target.GroupId=Source.GroupId
            AND Target.GroupName=Source.GroupName
            AND Target.MemberId=Source.MemberId
            AND Target.MemberName=Source.MemberName
            AND Target.Action=Source.Action
            AND Target.Approver=Source.Approver
            AND Target.Zone=Source.Zone
            AND Target.Status='In-Progress'
            WHEN NOT MATCHED THEN
            INSERT (EventId,GroupId,GroupName,MemberId,MemberName,Action,Approver,Zone,Status,RetryAttemptedAt)
            VALUES (Source.EventId,Source.GroupId,Source.GroupName,Source.MemberId,Source.MemberName,Source.Action,Source.Approver,Source.Zone,Source.Status,Source.RetryAttemptedAt);
        """
        payload = json.loads(dataset.Payload)
        logging.info(f"Payload for activity data: {dataset}")

        account_name = payload["data"]["accountName"]
        account_id = payload["data"]["accountId"]
       
        for member in payload["data"]["members"]:
            values = (
                dataset.EventId,
                account_id,
                account_name,
                member["id"],
                member["name"],
                member["action"],
                dataset.RequestedBy,
                dataset.Zone,
                'In-Progress',
                datetime.now(timezone.utc)
            )
            logging.info(f"Insert values {values}")
            self.objdb.executescalar(
                sql_query=sql_query, action="insert", values=values
            )
                
        self.objactivitymgr.insert_activity_pending(dataset)