import json,logging,os
from datetime import datetime,timezone,timedelta
from shared_code.db import DB
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from shared_code.snow_client import SNOWClient

class AzMsSqlAccess:

    def __init__(self) -> None:
        self.APPROLE_RETRY_ATTEMPT = timedelta(minutes=5,hours=0,days=0)
        self.TABLE_NAME = 'tblActivityAzMsSqlAccess'              
        self.objdb= DB()
        self.objactivitymgr = DbActivityManager()
        self.objsnow = SNOWClient()

    def snow_data(self,data):
        devowner_sys_ids = []
        for email in data["payload"]["devowners"].split(';'):
            user_details = self.objsnow.get_user_details_by_email(email)
            if user_details:
                devowner_sys_ids.append(user_details["sys_id"])
            else:
                logging.info(f"Warning: Email {email} not found in sys_user table")

        db_name = []
        for db in data["payload"]["data"]:
            db_name.append(db["sql_db_name"].split('/')[-1])
        self.request_data = data
        self.request_data["short_description"] = f"ABI Cloud Management Portal SQL Access for {','.join(db_name)}"
        self.request_data["description"] = (f"The users {','.join([u['display_name'] for u in data['payload']['data'][0]['member_ids']])} has requested for {','.join(db_name)} access in ABI Cloud Management")
        
        if data.get("ActivityType") == "Change":
            self.request_data.update({
                    "category": "Service",
                    "u_impacted_applications": data["payload"]["chg_impacted_application"],
                    "start_date": data["payload"]["chg_start_datetime"],
                    "end_date": data["payload"]["chg_end_datetime"],
                    "implementation_plan": f"Once change will be approved user will be provided access for {data['payload']['data'][0]['sql_db_name'].split('/')[-1]} at the scheduled time",
                    "risk_impact_analysis": "Make sure user is able to access the database",
                    "backout_plan": data["payload"]["chg_backout_plan"],
                    "test_plan": f"Test if the access is successfully",
                    "watch_list": ",".join(devowner_sys_ids),
                    "devowner": ",".join(devowner_sys_ids),
                    "timezone": data["payload"]["timezone"],
                    "risk": "4",
                    "impact": "3"
                    }
            )
        else:   
            self.request_data["business_service"] = "41b9ca581ba250d04a803150cd4bcbbe" 
            self.request_data["variables"] = {}
            self.request_data["variables"]["catalog_name"] = "SQL DB Access"
            self.request_data["variables"]["category"] = "sql-access"
            self.request_data["variables"]["catalog_description"] = "To provide SQL access to user"
            self.request_data["variables"]["domain_users"] = ','.join([u['display_name'] for u in data['payload']['data'][0]['member_ids']])
            self.request_data["variables"]["zone"] = data["zone"]
            self.request_data["variables"]["subscription"] = data['payload']['data'][0]['subscription_name']
            self.request_data["variables"]["resource_group_name"] = data['payload']['data'][0]['resource_group_name']
            self.request_data["variables"]["sql_database"] = ",".join(db_name)
            self.request_data["variables"]["role_name"] = data['payload']['data'][0]['sql_db_role']
            #self.request_data["variables"]["resource_id"] = data['payload']['data'][0]['resource_id']
            self.request_data["variables"]["devowner"] = ",".join(devowner_sys_ids)

        return self.request_data        
    
    def activity_data(self,dataset):

        sql_query = """
        MERGE INTO tblActivityAzMsSqlAccess AS Target
        USING (VALUES (?,?,?,?,?,?,?,?,?,?,?,?)) 
        AS Source (EventId,SubscriptionId,SubscriptionName,ResourceGroupId,ResourceGroupName,SqlServerName,SqlDbName,MemberIds,SqlDbRole,Zone,Status,RetryAttemptedAt)
        ON Target.EventId = Source.EventId
        AND Target.SubscriptionId = Source.SubscriptionId
        AND Target.SubscriptionName = Source.SubscriptionName
        AND Target.ResourceGroupId = Source.ResourceGroupId
        AND Target.ResourceGroupName = Source.ResourceGroupName
        AND Target.SqlServerName = Source.SqlServerName
        AND Target.SqlDbName = Source.SqlDbName
        AND Target.MemberIds = Source.MemberIds
        AND Target.SqlDbRole = Source.SqlDbRole
        AND Target.Status = 'In-Progress'
        WHEN NOT MATCHED THEN
        INSERT (EventId,SubscriptionId,SubscriptionName,ResourceGroupId,ResourceGroupName,SqlServerName,
        SqlDbName,MemberIds,SqlDbRole,Zone,Status,RetryAttemptedAt)
        VALUES (Source.EventId,Source.SubscriptionId,Source.SubscriptionName,Source.ResourceGroupId,Source.ResourceGroupName,
        Source.SqlServerName,Source.SqlDbName,Source.MemberIds,Source.SqlDbRole,Source.Zone,Source.Status,Source.RetryAttemptedAt);
        """

        payload = json.loads(dataset.Payload)

        db_name = []
        for db in payload['data']:
            db_name.append(db["sql_db_name"].split('/')[-1])
        values = (
                dataset.EventId,
                payload['data'][0]['subscription_id'],
                payload['data'][0]['subscription_name'],
                payload['data'][0]['resource_group_id'],
                payload['data'][0]['resource_group_name'],
                payload['data'][0]['sql_server_name'],
                ",".join(db_name),
                json.dumps(payload['data'][0]['member_ids']),
                payload['data'][0]['sql_db_role'],
                dataset.Zone,
                'In-Progress',
                datetime.now(timezone.utc)
            )
        self.objdb.executescalar(sql_query=sql_query,action="insert",values=values)
        self.objactivitymgr.insert_activity_pending(dataset)