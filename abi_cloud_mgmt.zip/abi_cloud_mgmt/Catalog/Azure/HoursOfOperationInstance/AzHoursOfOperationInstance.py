import json
import logging
from datetime import datetime, timezone, timedelta
from shared_code.db import DB
from shared_code.snow_client import SNOWClient
from shared_code.resourcemgmt_client import ResourceMgmtClient
from azure.mgmt.resource.resources.models import TagsPatchResource
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
import traceback


class AzHoursOfOperationInstance:

    def __init__(self):
        self.TABLE_NAME = 'tblActivityAzHoursOfOperationInstance'
        self.RETRY_ATTEMPT_INTERVAL = timedelta(minutes=5)
        self.objdb = DB()
        self.objsnow = SNOWClient()
        self.objactivitymgr = DbActivityManager()

    def snow_data(self, data):
        try:
            devowner_sys_ids = []
            payload = data.get('payload', {})
            if isinstance(payload, str):
                payload = json.loads(payload)

            devowners_email = payload.get('devowners', '')
            if devowners_email:
                for email in devowners_email.split(';'):
                    user_details = self.objsnow.get_user_details_by_email(email.strip())
                    if user_details:
                        devowner_sys_ids.append(user_details["sys_id"])

            resources = payload.get('resources', [])
            resource_names = []
            resource_group_name = ''
            subscription_name = ''

            for resource_group in resources:
                if 'instances' in resource_group:
                    resource_group_name = resource_group.get('resource_group_name', '')
                    subscription_name = resource_group.get('subscription_name', '')
                    instances = resource_group.get('instances', [])
                    for instance in instances:
                        resource_names.append(instance.get('resource_name', ''))

            self.request_data = data
            self.request_data["short_description"] = (
                f"Configure Hours of Operation for VMs: {', '.join(resource_names)} in RG {resource_group_name}"
            )
            self.request_data["description"] = (
                f"The user {data.get('RequestorEmail', '')} has requested to configure Hours of Operation for "
                f"Virtual Machines {', '.join(resource_names)} in resource group {resource_group_name} "
                f"under subscription {subscription_name}. The VMs will be automatically started and stopped "
                f"based on the configured schedule to optimize costs."
            )
            self.request_data["business_service"] = "41b9ca581ba250d04a803150cd4bcbbe"
            self.request_data["variables"] = {
                "catalog_name": "Hours of Operation Instance Management",
                "category": "hoursofoperation",
                "catalog_description": "Configure automated VM start/stop schedules",
                "resource_names": ",".join(resource_names),
                "resource_group_name": resource_group_name,
                "subscription_name": subscription_name,
                "zone": data.get('Zone', ''),
                "devowner": ",".join(devowner_sys_ids),
            }
            

            return self.request_data

        except Exception:
            return data

    def _remove_hours_of_operation_tag(self, resource_id: str, tag_value: str, resource_client) -> None:
        try:
            tag_patch = TagsPatchResource(
                operation="Delete",
                properties={"tags": {"HoursOfOperation": tag_value}}
            )
            resource_client.tags.begin_update_at_scope(resource_id, tag_patch)
            logging.info(f"Removed HoursOfOperation tag from resource {resource_id}")
        except Exception as e:
            logging.warning(f"Failed to remove HoursOfOperation tag from resource {resource_id}: {e}")

    def activity_data(self, dataset):
        try:
            payload = json.loads(dataset.Payload)
            cloud = "AzureChinaCloud" if dataset.Zone.lower() == "china" else "AzurePublicCloud"
            for resource_group in payload.get('resources', []):
                subscription_id = resource_group.get('subscription_id', '')
                if not subscription_id:
                    continue
                resource_client = ResourceMgmtClient().get_resource_client(cloud, subscription_id)
                for instance in resource_group.get('instances', []):
                    tags = instance.get('tags', {})
                    if isinstance(tags, dict) and 'HoursOfOperation' in tags:
                        resource_id = instance.get('resource_id', '')
                        if resource_id:
                            self._remove_hours_of_operation_tag(
                                resource_id, tags['HoursOfOperation'], resource_client
                            )

            success_count = self.objactivitymgr.insert_hoursofoperation_instances_from_payload(
                event_id=dataset.EventId,
                payload=payload,
                zone=dataset.Zone
            )

            if success_count > 0:
                dataset.Status = "Success"
                dataset.Comments = f"Created {success_count} schedule(s)"
            else:
                dataset.Status = "Failed"
                dataset.Comments = "No schedules created"

            self.objactivitymgr.insert_activity_completed(
                dataset, dataset.Status, dataset.Comments
            )

        except Exception:
            raise