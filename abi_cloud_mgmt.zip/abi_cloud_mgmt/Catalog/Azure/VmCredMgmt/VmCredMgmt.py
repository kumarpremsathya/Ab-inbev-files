import json
from datetime import datetime, timezone, timedelta
import logging
from shared_code.db import DB
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from shared_code.snow_client import SNOWClient


class AzVmCredMgmt:
    def __init__(self) -> None:
        self.AZVMCREDMGMT_RETRY_ATTEMPT = timedelta(minutes=5, hours=0, days=0)
        self.TABLE_NAME = "tblActivityAzVmCredMgmt"
        self.objdb = DB()
        self.objactivitymgr = DbActivityManager()
        self.objsnow = SNOWClient()

    def snow_data(self, data):
        # devowner_sys_ids = []
        # for email in data["payload"]["devowners"].split(';'):
        #     user_details = self.objsnow.get_user_details_by_email(email)
        #     if user_details:
        #         devowner_sys_ids.append(user_details["sys_id"])
        #     else:
        #         print(f"Warning: Email {email} not found in sys_user table")

        self.request_data = data
        vms = []
        for vm in data["payload"]["data"]:
            vms.append(vm["resource_name"])

        # members = []
        # for member in data['payload']['member_ids']:
        #     members.append(member['display_name'])

        self.request_data["short_description"] = (
            f"ABI Cloud Management Portal - Azure - {data['payload']['data'][0]['resource_group_name']} VM {','.join(vms)} credential requested by - {data['RequestorEmail']}"
        )
        self.request_data["description"] = (
            f"The user {data['RequestorEmail']} has requested credential for the specified VMs"
            f"Azure - {data['payload']['data'][0]['resource_group_name']} VM {','.join(vms)}"
            f"in zone {data['zone']}."
        )

        # Regular Request
        self.request_data.update(
            {
                "business_service": "41b9ca581ba250d04a803150cd4bcbbe",
                "variables": {
                    "catalog_name": "VM Credential Management",
                    "category": "Cred to VM",
                    "catalog_description": "Credential reset to Azure VM",
                    "zone": data["zone"],
                    "subscription": data["payload"]["data"][0]["subscription_name"],
                    #"resource_name": data["payload"]["data"][0]["resource_name"],
                    "resource_name": ",".join(vms),
                    "resource_group_name": data["payload"]["data"][0]["resource_group_name"],
                    #"devowner": ",".join(devowner_sys_ids),
                    #"domain_users": ",".join(members),
                    "justification": data["payload"]["justification"]
                }
            }
        )

        return self.request_data

    def activity_data(self, dataset):
        logging.info(f"Activity data called with dataset: {dataset}")
        sql_query = """
            MERGE INTO tblActivityAzVmCredMgmt as Target
            USING (SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)
            AS SOURCE(EventId, SubscriptionId, SubscriptionName, ResourceGroupId, ResourceGroupName, ResourceName, ResourceId, AccessKey, Zone, Status, RetryAttemptedAt)
            ON Target.EventId = Source.EventId
            AND Target.SubscriptionId = Source.SubscriptionId
            AND Target.ResourceGroupId = Source.ResourceGroupId
            AND Target.ResourceId = Source.ResourceId
            AND Target.Status = 'In-Progress'
            WHEN NOT MATCHED THEN
            INSERT (EventId, SubscriptionId, SubscriptionName, ResourceGroupId, ResourceGroupName, ResourceName, ResourceId,AccessKey, Zone, Status, RetryAttemptedAt)
            VALUES (Source.EventId, Source.SubscriptionId, Source.SubscriptionName, Source.ResourceGroupId, Source.ResourceGroupName, Source.ResourceName, Source.ResourceId,Source.AccessKey, Source.Zone, Source.Status, Source.RetryAttemptedAt);
        """

        payload = json.loads(dataset.Payload)
        for vm in payload["data"]:
            values = (
                dataset.EventId,
                vm["subscription_id"],
                vm["subscription_name"],
                vm["resource_group_id"],
                vm["resource_group_name"],
                vm["resource_name"],
                vm["resource_id"],
                payload["access_key"],
                dataset.Zone,
                "In-Progress",
                datetime.now(timezone.utc)  # RetryAttemptedAt
            )
            self.objdb.executescalar(
                sql_query=sql_query, action="insert", values=values
            )
        self.objactivitymgr.insert_activity_pending(dataset)
