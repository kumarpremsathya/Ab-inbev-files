import json,logging,os
from datetime import datetime,timezone,timedelta
from shared_code.db import DB
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from msgraph.generated.users.item.app_role_assignments.app_role_assignments_request_builder import AppRoleAssignmentsRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from shared_code.graphservice_client import GraphClient
from msgraph.generated.models.app_role_assignment import AppRoleAssignment
from shared_code.constants import Constants
from uuid import UUID

class AzAppRole:

    def __init__(self) -> None:
        self.APPROLE_RETRY_ATTEMPT = timedelta(minutes=5,hours=0,days=0)
        self.TABLE_NAME = 'tblActivityAppRole'              
        self.TOPIC_NAME = 'azapprole' 
        self.objdb= DB()
        self.objactivitymgr = DbActivityManager()
        self.graph_client_obj = GraphClient()
        self.graph_client= self.graph_client_obj.get_client_request_adapter("AzurePublicCloud")

    def snow_data(self,data):
        self.request_data = data
        self.request_data["short_description"] = f"ABI Cloud Management Portal Access for {data['payload']['data']['AppRoleName']}"
        self.request_data["description"] = f"The user {data['RequestorEmail']} has requested for {data['payload']['data']['AppRoleName']} access in ABI Cloud Management"
        self.request_data["business_service"] = "41b9ca581ba250d04a803150cd4bcbbe" 
        self.request_data["variables"] = {}
        self.request_data["variables"]["catalog_name"] = "APPROLE"
        self.request_data["variables"]["category"] = "APPROLE"
        self.request_data["variables"]["catalog_description"] = "To provide access to the catalog portal"
        self.request_data["variables"]["app_role_name"] = data['payload']['data']['AppRoleName']        

        return self.request_data        
    
    def activity_data(self,dataset):
        sql_query = """        
            MERGE INTO tblActivityAppRole as Target
            USING (SELECT ?,?,?,?,?,?,?)
            AS SOURCE(EventId,AppRoleName,OID,Zone,Cloud,Status,RetryAttemptedAt)
            ON Target.EventId=Source.EventId
            AND Target.AppRoleName=Source.AppRoleName
            AND Target.OID=Source.OID
            AND Target.Status='In-Progress'
            WHEN NOT MATCHED THEN
            INSERT (EventId,AppRoleName,OID,Zone,Cloud,Status,RetryAttemptedAt)
            VALUES (Source.EventId,Source.AppRoleName,Source.OID,Source.Zone,Source.Cloud,Source.Status,Source.RetryAttemptedAt);
        """
        payload = json.loads(dataset.Payload)
        values=(
                dataset.EventId,
                payload['data']['AppRoleName'],
                payload['data']['OID'],
                payload['data']['zone'],
                dataset.Cloud,
                'In-Progress',
                datetime.now(timezone.utc)
            )
        self.objdb.executescalar(sql_query=sql_query,action="insert",values=values)
        self.objactivitymgr.insert_activity_pending(dataset)