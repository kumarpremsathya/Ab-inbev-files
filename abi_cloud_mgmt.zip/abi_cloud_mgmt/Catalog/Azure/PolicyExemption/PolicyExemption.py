import json
from datetime import datetime, timezone, timedelta
import logging
from shared_code.db import DB
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from shared_code.snow_client import SNOWClient


class AzPolicyExemption:
    def __init__(self) -> None:
        self.AZPOLICYEXEMPTION_RETRY_ATTEMPT = timedelta(minutes=5, hours=0, days=0)
        self.TABLE_NAME = "tblActivityAzPolicyExemption"
        self.objdb = DB()
        self.objactivitymgr = DbActivityManager()
        self.objsnow = SNOWClient()

    def snow_data(self, data):
        self.request_data = data

        payload_data = data['payload']['data']
        resources = payload_data.get('policy_exemption_resources', [])
        is_temporary = payload_data.get('is_temporary', '')
        exemption_duration = payload_data.get('duration', '')
        technical_justification = payload_data.get('technical_justification', '')
        business_impact = payload_data.get('business_impact', '')

        # Build description
        resource_lines = []
        for idx, resource in enumerate(resources, 1):
            resource_lines.append(
                f"Resource {idx}:\n"
                f"  Resource Name: {resource.get('resource_name', 'N/A')}\n"
                f"  Resource ID: {resource.get('resource_id', 'N/A')}\n"
                f"  Policy Display Name: {resource.get('policy_display_name', 'N/A')}\n"
                f"  Policy Assignment ID: {resource.get('policy_assignment_id', 'N/A')}\n"
                f"  Policy Definition Reference ID: {resource.get('policy_definition_reference_id', 'N/A')}"
            )

        resources_text = "\n\n".join(resource_lines)

        self.request_data["description"] = (
            f"Azure Policy Exemption Request\n\n"
            f"Subscription: {payload_data.get('subscription_name', '')} ({payload_data.get('subscription_id', '')})\n"
            f"Resource Group: {payload_data.get('resource_group', '')}\n"
            f"Is Temporary: {is_temporary}\n"
            f"Duration: {exemption_duration}\n"
            f"Technical Justification: {technical_justification}\n"
            f"Business Impact: {business_impact}\n\n"
            f"Resources for Policy Exemption:\n{resources_text}"
        )

        # Build short description
        resource_count = len(resources)
        self.request_data["short_description"] = (
            f"ABI Cloud Management Portal - Azure - Policy Exemption - "
            f"RequestorEmail: {data['RequestorEmail']} - "
            f"Subscription: {payload_data.get('subscription_name', '')} - "
            f"Is Temporary: {is_temporary} - "
            f"Resources: {resource_count}"
        )

        # ServiceNow Request payload
        self.request_data.update(
            {
                "business_service": "41b9ca581ba250d04a803150cd4bcbbe",
                "variables": {
                    "catalog_name": "Policy Exemption",
                    "category": "Policy Management",
                    "catalog_description": "Create policy exemption for Azure resources",
                    "zone": payload_data.get("zone", ""),
                    "subscription_id": payload_data.get("subscription_id", ""),
                    "subscription_name": payload_data.get("subscription_name", ""),
                    "resource_group": payload_data.get("resource_group", ""),
                    "policy_exemption_resources": str(resources),
                    "is_temporary": is_temporary,
                    "duration": exemption_duration,
                    "technical_justification": technical_justification,
                    "business_impact": business_impact
                }
            }
        )
       
        return self.request_data

    def activity_data(self, dataset):
        sql_query = """
            MERGE INTO tblActivityAzPolicyExemption AS Target
            USING (
                SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
            ) AS Source
            (EventId, SubscriptionId, SubscriptionName, ResourceGroupId, ResourceGroupName,
            PolicyAuditors, PolicyExemptionResources, IsTemporary, Duration,
            TechnicalJustification, BusinessImpact, Zone, Cloud, Status, Comments, RetryAttemptedAt, SnowItemId)
            ON Target.EventId = Source.EventId
            WHEN NOT MATCHED THEN
                INSERT (EventId, SubscriptionId, SubscriptionName, ResourceGroupId, ResourceGroupName,
                        PolicyAuditors, PolicyExemptionResources, IsTemporary, Duration,
                        TechnicalJustification, BusinessImpact, Zone, Cloud, Status, Comments, RetryAttemptedAt, SnowItemId)
                VALUES (Source.EventId, Source.SubscriptionId, Source.SubscriptionName, Source.ResourceGroupId,
                        Source.ResourceGroupName, Source.PolicyAuditors, Source.PolicyExemptionResources,
                        Source.IsTemporary, Source.Duration, Source.TechnicalJustification, Source.BusinessImpact,
                        Source.Zone, Source.Cloud, Source.Status, Source.Comments, Source.RetryAttemptedAt, Source.SnowItemId);
            """
        try:
            payload = json.loads(dataset.Payload)
            payload_data = payload.get("data", {})
    
            values = (
                dataset.EventId,
                payload_data.get("subscription_id", ""),
                payload_data.get("subscription_name", ""),
                payload_data.get("resource_group_id", ""),
                payload_data.get("resource_group", ""),
                payload_data.get("policy_auditors", ""),
                json.dumps(payload_data.get("policy_exemption_resources", [])),
                payload_data.get("is_temporary", ""),
                payload_data.get("duration", ""),
                payload_data.get("technical_justification", ""),
                payload_data.get("business_impact", ""),
                payload_data.get("zone", ""),
                dataset.Cloud,
                "In-Progress",
                "Pending policy exemption creation",
                datetime.now(timezone.utc),
                dataset.SnowItemId
            )
            self.objdb.executescalar(sql_query=sql_query, action="insert", values=values)
        except Exception as e:
            logging.error(f"Failed to insert record for policy exemption: {str(e)} {dataset}")
            raise

        self.objactivitymgr.insert_activity_pending(dataset)
        logging.info(f"EventId {dataset.EventId} marked as Pending for POLICYEXEMPTION processing")
