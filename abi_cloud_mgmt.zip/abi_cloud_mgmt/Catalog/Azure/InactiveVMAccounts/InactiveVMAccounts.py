import json
from datetime import datetime, timezone, timedelta
import logging
from shared_code.db import DB
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from shared_code.snow_client import SNOWClient


class InactiveVMAccounts:
    def __init__(self) -> None:
        self.AZINACTIVERBAC_RETRY_ATTEMPT = timedelta(minutes=5, hours=0, days=0)
        self.TABLE_NAME = "tblActivityAzInactiveVMAccounts"
        self.objdb = DB()
        self.objactivitymgr = DbActivityManager()
        self.objsnow = SNOWClient()

    def snow_data(self, data):

        self.request_data = data
    
        inactive_user_records = []
        deleted_user_records = []
        
        for inactive_user_detail in data['payload']['inactive_account_details']:
            account_name = inactive_user_detail.get('account_name')
            user_status = inactive_user_detail.get('account_status', '')
            user_email = inactive_user_detail.get('user_email', '')
            node = inactive_user_detail.get('node', '')
            kernel = inactive_user_detail.get('kernel', '')
            user_id = inactive_user_detail.get('user_id', '')
            vmids = inactive_user_detail.get('vmids', '')
            domain = inactive_user_detail.get('domain', '')
            account_type = inactive_user_detail.get('account_type', '')
            
            if user_status == 'Deleted User':
                deleted_user_records.append(
                    f"Deleted User (Email: {user_email})\n"
                    f"Node: {node}\n"
                    f"Kernel: {kernel}\n"
                    f"User ID: {user_id}\n"
                    f"VM IDs: {vmids}\n"
                    f"Domain: {domain}\n"
                    f"Account Type: {account_type}\n"
                )
            else:
                inactive_user_records.append(
                    f"Inactive User: {user_email}\n"
                    f"Node: {node}\n"
                    f"Kernel: {kernel}\n"
                    f"User ID: {user_id}\n"
                    f"VM IDs: {vmids}\n"
                    f"Domain: {domain}\n"
                    f"Account Type: {account_type}\n"
                )

        # Build description based on user types
        description_parts = []
        
        if deleted_user_records:
            deleted_text = "\n".join(deleted_user_records)
            description_parts.append(
                f"Auto cleanup of VM Accounts of Deleted Users\n\n"
                f"Role Assignments to be deleted:\n{deleted_text}"
            )
        
        if inactive_user_records:
            inactive_text = "\n".join(inactive_user_records)
            description_parts.append(
                f"Auto cleanup of VM Accounts of Inactive Users\n\n"
                f"Role Assignments to be deleted:\n{inactive_text}"
            )

        self.request_data["description"] = "\n\n".join(description_parts)

        logging.info(f"\n\n\nDescription set to: {self.request_data['description']}")

        # Build short description based on user types
        short_desc_parts = []
        inactive_users_list = data['payload'].get('inactive_accounts', [])
        
        if inactive_user_records and inactive_users_list:
            short_desc_parts.append(
                f"inactive_accounts: {', '.join(inactive_users_list[:2])}{'...' if len(inactive_users_list) > 2 else ''}"
            )
        
        if deleted_user_records:
            short_desc_parts.append(f"deleted_users: {len(deleted_user_records)}")

        # Determine cleanup type for short description
        if deleted_user_records and inactive_user_records:
            cleanup_type = "Inactive & Deleted RBAC Cleanup"
        elif deleted_user_records:
            cleanup_type = "Deleted VM Accounts Cleanup"
        else:
            cleanup_type = "Inactive VM Accounts Cleanup"

        self.request_data["short_description"] = (
            f"ABI Cloud Management Portal - Azure - {cleanup_type} - "
            f"RequestorEmail: {data['RequestorEmail']} - "
            f"{' - '.join(short_desc_parts)}"
        )

        logging.info(f"\n\n\nShort description set to: {self.request_data['short_description']}\n\n\n")

        # ServiceNow Request payload
        self.request_data.update(
           {
            "business_service": "41b9ca581ba250d04a803150cd4bcbbe",
            "variables": {
                "catalog_name": "Inactive VM Accounts Cleanup",
                "category": "Access Management",
                "catalog_description": "Remove VM Accounts of inactive users",
                "zone": data.get("zone", ""),
                "tenant": data["payload"].get("tenant", ""),
                "inactive_accounts_details": str(data["payload"].get("inactive_accounts_details", [])),
                "inactive_accounts": ",".join(data["payload"].get("inactive_accounts", []))
            }
        }
        )

        return self.request_data 
      
    
    def activity_data(self, dataset):
      
        sql_query = """
        MERGE INTO tblActivityAzInactiveVmAccounts AS Target
        USING (
            SELECT 
            S.EventId,
            S.Node,
            S.Kernel,
            S.UserId,
            S.Email,
            S.UserPrincipalName,
            U.DisplayName,
            S.ManagerEmail,
            S.AccountName,
            S.AccountType,
            S.Domain,
            S.Vmid,
            S.PrivilegedAccess,
            S.SubscriptionId,
            S.SubscriptionName,
            S.ResourceGroupName,
            S.Resource,
            S.Cloud,
            S.Zone,
            S.Status,
            S.Comments,
            S.RetryAttemptedAt,
            S.AccountStatus,
            CASE WHEN L.EmployeeId IS NOT NULL THEN 'WORKDAY' ELSE S.CleanType END AS CleanType
            FROM (
            SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
            ) AS S
            (EventId, Node, Kernel, UserId, Email, UserPrincipalName, ManagerEmail,
             AccountName, AccountType, Domain, Vmid, PrivilegedAccess, SubscriptionId, SubscriptionName,
             ResourceGroupName, Resource, Cloud, Zone, Status, Comments, RetryAttemptedAt, AccountStatus,
             CleanType)
            LEFT OUTER JOIN tblAbiLeaversReport L
            ON S.UserId = L.UserId
            LEFT OUTER JOIN tblazureusersreport U
            ON S.UserId = U.UserId
        ) AS Source
        ON Target.EventId = Source.EventId
        AND Target.UserPrincipalName = Source.UserPrincipalName
        AND Target.Vmid = Source.Vmid
        WHEN NOT MATCHED THEN
            INSERT (
            EventId, Node, Kernel, UserId, Email, UserPrincipalName, DisplayName, ManagerEmail,
            AccountName, AccountType, Domain, Vmid, PrivilegedAccess, SubscriptionId, SubscriptionName,
            ResourceGroupName, Resource, Cloud, Zone, Status, Comments, RetryAttemptedAt, AccountStatus,
            CleanType
            )
            VALUES (
            Source.EventId, Source.Node, Source.Kernel, Source.UserId, Source.Email,
            Source.UserPrincipalName, Source.DisplayName, Source.ManagerEmail, Source.AccountName,
            Source.AccountType, Source.Domain, Source.Vmid, Source.PrivilegedAccess, Source.SubscriptionId,
            Source.SubscriptionName, Source.ResourceGroupName, Source.Resource, Source.Cloud, Source.Zone,
            Source.Status, Source.Comments, Source.RetryAttemptedAt, Source.AccountStatus, Source.CleanType
            );
        """
        try:
            payload = json.loads(dataset.Payload)
            manager_email = payload.get("manager_email")
            inactive_user_details = payload.get("inactive_account_details", [])

            zone_data = {}
            subscription_data = {}
            subscription_id = None

            for record in inactive_user_details:
                email = record.get("user_email","UNKNOWN")
                user_id = record.get("user_id","UNKNOWN")
                account_status = record.get("account_status")
                node = record.get("node")
                kernel = record.get("kernel")
                accounnt_name = record.get("account_name")
                account_type = record.get("account_type")
                domain = record.get("domain")
                privileged_access = record.get("privileged", False)
                user_principal_name = record.get("user_principal_name")
                account_type = record.get("account_type", "UNKNOWN")
                vmids = record.get("vmids",[]).split(",")
                for vmid in vmids:
                    if vmid.split("/")[1].lower() == "subscriptions":
                        subscription_id = vmid.split("/")[2] if vmid and "subscriptions" in vmid else None
                        resource_group = vmid.split("/")[4] if len(vmid.split("/")) > 4 else None
                        resource = vmid.split("/")[8] if len(vmid.split("/")) > 8 else None
                    if subscription_id:
                        if subscription_id not in zone_data:
                            zone_data[subscription_id] = self.objactivitymgr.get_zone(subscription_id)
                        if subscription_id not in subscription_data:
                            subscription_data[subscription_id] = self.objactivitymgr.get_subscription_name(subscription_id)
                        zone = zone_data[subscription_id]
                        subscriptionname = subscription_data[subscription_id]
                    else:
                        zone = None
                    values = (
                        dataset.EventId,
                        node,
                        kernel,
                        user_id,
                        email,
                        user_principal_name,
                        manager_email,
                        accounnt_name,
                        account_type,
                        domain,
                        vmid,
                        privileged_access,
                        subscription_id,
                        subscriptionname,
                        resource_group,
                        resource,
                        dataset.Cloud,
                        zone,
                        "In-Progress",
                        f"Pending removal for user: {email}" if email else "Pending removal for users",
                        datetime.now(timezone.utc),
                        account_status,
                        "LEAVERS"
                    )
                    self.objdb.executescalar(sql_query=sql_query, action="insert", values=values)
        except Exception as e:
            logging.error(f"Failed to insert record for inactive users: {str(e)} {dataset}")
            raise

        # Mark activity as pending in tblEventPendingActivity
        self.objactivitymgr.insert_activity_pending(dataset)
        logging.info(f"EventId {dataset.EventId} marked as Pending for INACTIVERBAC processing")