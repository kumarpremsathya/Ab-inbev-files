import json,os
from datetime import datetime, timedelta, timezone
import logging
from shared_code.db import DB
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from shared_code.snow_client import SNOWClient
from shared_code.constants import Constants
from shared_code.servicebus_client import ServiceBusClientAbstract

class AzDecommission:

    def __init__(self) -> None:
        self.DECOMM_RETRY_ATTEMPT = timedelta(minutes=5, hours=0, days=0)
        self.TABLE_NAME = "tblActivityAzDecommission"
        self.objactivitymgr = DbActivityManager()
        self.objsnow = SNOWClient()
        self.objdb= DB()
        self.objsbuscli = ServiceBusClientAbstract()

    def snow_data(self, data):
        devowner_sys_ids = []
        if data["payload"]["devowners"]:
            for email in data["payload"]["devowners"].split(";"):
                user_details = self.objsnow.get_user_details_by_email(email)
                if user_details:
                    devowner_sys_ids.append(user_details["sys_id"])
                else:
                    print(f"Warning: Email {email} not found in sys_user table")

        self.request_data = data
        resources=[]
        for vm in data["payload"]["data"]:
            if data["payload"]["decomm_type"] == "resource_group_only":
                    resources.append(vm["resource_group_name"])
                    break
            resources.append(vm["resource_name"])

        self.request_data["short_description"] = (
            f"ABI Cloud Management Portal - Azure {data['payload']['data'][0]['resource_group_name']} - Decommission - {data['RequestorEmail']}"
        )
        self.request_data["description"] = (
            f"The user {data['RequestorEmail']} has requested for Decommission of resource "
            f"in the Azure cloud under the zone {data['zone']}. and the affected resource are {','.join(resources)}"
        )

        if data.get("ActivityType") == "Change":
            self.request_data.update(
                {
                    "category": "Service",
                    "u_impacted_applications": data["payload"]["chg_impacted_application"],
                    "start_date": data["payload"]["chg_start_datetime"],
                    "end_date": data["payload"]["chg_end_datetime"],
                    "implementation_plan": f"once change the resources will be decommisioned",
                    "risk_impact_analysis": "Make sure resources are decomissioned",
                    "backout_plan": data["payload"]["chg_backout_plan"],
                    "test_plan": f"Test if respurces are successfully decomissioned",
                    "watch_list": ",".join(devowner_sys_ids),
                    "devowner": ",".join(devowner_sys_ids),
                    "timezone": data["payload"]["timezone"],
                    "risk": "2",
                    "impact": "3",
                    "reason": "maintenance",
                    "type": os.environ.get("SNOW_CHANGE_TYPE", "normal"),
                    "justification": data["payload"]["justification"],
                }
            )
        else:
            self.request_data.update(
                {
                    "business_service": "41b9ca581ba250d04a803150cd4bcbbe",
                    "variables": {
                        "catalog_name": "decomission",
                        "category": "decomission",
                        "catalog_description": "Decomission the resources", 
                        "zone": data["zone"],
                        "subscription": data["payload"]["data"][0]["subscription_name"],
                        "resource_name": ','.join(resources),
                        "resource_group_name": data["payload"]["data"][0][ "resource_group_name"],
                        "devowner": ",".join(devowner_sys_ids),
                        "justification": data["payload"]["justification"],
                    },
                }
            )

        return self.request_data
    
    def activity_data(self, dataset):
        logging.info(f"Activity data called with dataset: {dataset}")
        sql_query = """
            MERGE INTO tblActivityAzDecommission AS Target
            USING (SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)
            AS SOURCE(EventId, MessageId,SubscriptionId, SubscriptionName, ResourceGroupId, ResourceGroupName, Payload, DecommissionType,
            IsDecommissionPreActivity, CoolingPeriod, Zone, Status,  RetryAttemptedAt)
            ON Target.EventId = Source.EventId
            AND Target.MessageId = Source.MessageId
            AND Target.SubscriptionId = Source.SubscriptionId
            AND Target.SubscriptionName = Source.SubscriptionName
            AND Target.ResourceGroupId = Source.ResourceGroupId
            AND Target.ResourceGroupName = Source.ResourceGroupName
            AND Target.DecommissionType = Source.DecommissionType
            AND Target.IsDecommissionPreActivity = Source.IsDecommissionPreActivity
            AND Target.CoolingPeriod = Source.CoolingPeriod
            AND Target.Status = 'In-Progress'
            WHEN NOT MATCHED THEN
            INSERT (EventId, MessageId,SubscriptionId, SubscriptionName, ResourceGroupId, ResourceGroupName, Payload, DecommissionType, IsDecommissionPreActivity, CoolingPeriod, Zone, Status, RetryAttemptedAt)
            VALUES (Source.EventId, Source.MessageId,Source.SubscriptionId, Source.SubscriptionName, Source.ResourceGroupId, Source.ResourceGroupName,
                    Source.Payload, Source.DecommissionType, Source.IsDecommissionPreActivity, Source.CoolingPeriod,
                    Source.Zone, Source.Status, Source.RetryAttemptedAt);
        """
        
        payload = json.loads(dataset.Payload)
        unique_key = self.objsbuscli.generate_unique_key(payload)
        cooling_period = payload["cooling_period"] if payload["cooling_period"] else 0
        RetryAttemptedAt = datetime.now(timezone.utc) + timedelta(days=int(cooling_period)) if dataset.ActivityType == 'Request' else datetime.now(timezone.utc)
        values = (
            dataset.EventId,
            unique_key,
            payload["data"][0]["subscription_id"],
            payload["data"][0]["subscription_name"],
            payload["data"][0]["resource_group_id"],
            payload["data"][0]["resource_group_name"],
            json.dumps(payload),
            payload["decomm_type"],
            payload["decomm_preactivity"],
            cooling_period,
            dataset.Zone,
            "In-Progress",
            RetryAttemptedAt
        )
        self.objdb.executescalar(
            sql_query=sql_query, action="insert", values=values
        )
        
        self.objactivitymgr.insert_activity_pending(dataset)