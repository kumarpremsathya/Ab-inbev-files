import json
from datetime import datetime, timezone, timedelta
import logging
from ServiceNow.SnowChangeRequest import SnowChangeRequest
from shared_code.db import DB
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from shared_code.snow_client import SNOWClient
from shared_code.constants import Constants


class AzVmResize:
    def __init__(self) -> None:
        self.AZVMRESIZE_RETRY_ATTEMPT = timedelta(minutes=5, hours=0, days=0)
        self.TABLE_NAME = "tblActivityAzVmResize"
        self.TOPIC_NAME = "azvmresizesku"
        self.objdb = DB()
        self.objactivitymgr = DbActivityManager()
        self.objsnow = SNOWClient()

    def snow_data(self, data):
        devowner_sys_ids = []
        if data["payload"]["devowners"]:
            for email in data["payload"]["devowners"].split(';'):
                user_details = self.objsnow.get_user_details_by_email(email)
                if user_details:
                    devowner_sys_ids.append(user_details["sys_id"])
                else:
                    print(f"Warning: Email {email} not found in sys_user table")

        self.request_data = data

        self.request_data["short_description"] = (
            f"ABI Cloud Management Portal - Azure - {data['payload']['data']['resource_group_name']} - Resize VM SKU to {data['payload']['data']['new_size']} - {data['RequestorEmail']}"
        )
        self.request_data["description"] = (
            f"The user {data['RequestorEmail']} has requested to resize VM SKUs "
            f"to {data['payload']['data']['new_size']} "
            f"in the Azure cloud under the zone {data['zone']}. and the affected VM is {data['payload']['data']['resource_name']}"
        )

        if data.get("ActivityType") == "Change":
            # Change Request
            self.request_data.update(
                {
                    "category": "Hardware",
                    "implementation_plan": f"once change will be approved VM will be automatically resized at the scheduled time - {data['payload']['data']['new_size']}",
                    "risk_impact_analysis": "Make sure VM agent is up and running",
                    "backout_plan": data["payload"]["chg_backout_plan"],
                    "test_plan": f"Test if the vm is successfully resized to {data['payload']['data']['new_size']}",
                    "u_impacted_applications": data["payload"]["chg_impacted_application"],
                    "start_date": data["payload"]["chg_start_datetime"],
                    "end_date": data["payload"]["chg_end_datetime"],
                    "timezone": data["payload"]["timezone"],
                    "watch_list": ",".join(devowner_sys_ids),
                    "devowner": ",".join(devowner_sys_ids),
                    "timezone": data["payload"]["timezone"],
                    "risk": "2",
                    "impact": "3",
                    # "variables": {
                    #     "catalog_name": "Resize VM SKU",
                    #     "category": "VM SKU Change",
                    #     "catalog_description": "Change the SKU size of Azure VMs",
                    #     "zone": data["zone"],
                    #     "subscription": data["payload"]["data"][0]["subscription_name"],
                    #     "resource_name": data["payload"]["data"][0]["resource_name"],
                    #     "resource_group_name": data["payload"]["data"][0]["resource_group_name"],
                    #     "devowner": ",".join(devowner_sys_ids),
                    # },
                }
            )
        else:
            variables = {
                "catalog_name": "Resize VM",
                "category": "Resize VM",
                "catalog_description": "Change the SKU size of Azure VMs",
                "zone": data["zone"],
                "subscription": data["payload"]["data"]["subscription_name"],
                "resource_name": data["payload"]["data"]["resource_name"],
                "resource_group_name": data["payload"]["data"]["resource_group_name"],
                "vm_size": data["payload"]["data"]["new_size"],
                "devowner": ",".join(devowner_sys_ids),
            }
            
            if data["payload"].get("post_start_config"):
                variables["post_start_config"] = data["payload"]["post_start_config"]
            if data["payload"].get("pre_stop_config"):
                variables["pre_stop_config"] = data["payload"]["pre_stop_config"]
            
            self.request_data.update(
                {
                    "business_service": "41b9ca581ba250d04a803150cd4bcbbe",
                    "variables": variables,
                }
            )

        return self.request_data

    def activity_data(self, dataset):
        logging.info(f"Activity data called with dataset: {dataset}")
        sql_query = """
            MERGE INTO tblActivityAzVmResize as Target
            USING (SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            AS SOURCE(EventId, SubscriptionId, SubscriptionName, ResourceGroupId, ResourceGroupName, ResourceName, 
                     ResourceId, TargetSkuSize, Zone, Status, RetryAttemptedAt, PostStartConfig, PreStopConfig)
            ON Target.EventId = Source.EventId
            AND Target.SubscriptionId = Source.SubscriptionId
            AND Target.ResourceGroupId = Source.ResourceGroupId
            AND Target.ResourceId = Source.ResourceId
            AND Target.Status = 'In-Progress'
            WHEN NOT MATCHED THEN
            INSERT (EventId, SubscriptionId, SubscriptionName, ResourceGroupId, ResourceGroupName, ResourceName, 
                   ResourceId, TargetSkuSize, Zone, Status, RetryAttemptedAt, PostStartConfig, PreStopConfig)
            VALUES (Source.EventId, Source.SubscriptionId, Source.SubscriptionName, Source.ResourceGroupId, Source.ResourceGroupName,
                   Source.ResourceName, Source.ResourceId, Source.TargetSkuSize, 
                   Source.Zone, Source.Status, Source.RetryAttemptedAt, Source.PostStartConfig, Source.PreStopConfig);
        """

        payload = json.loads(dataset.Payload)
        
        post_start_config = payload.get("post_start_config")
        pre_stop_config = payload.get("pre_stop_config")
        post_start_json = json.dumps(post_start_config) if post_start_config else None
        pre_stop_json = json.dumps(pre_stop_config) if pre_stop_config else None

        values = (
            dataset.EventId,
            payload["data"]["subscription_id"],
            payload["data"]["subscription_name"],
            payload["data"]["resource_group_id"],
            payload["data"]["resource_group_name"],
            payload["data"]["resource_name"],
            payload["data"]["resource_id"],
            payload["data"]["new_size"],
            dataset.Zone,
            "In-Progress",
            datetime.now(timezone.utc),
            post_start_json,
            pre_stop_json
        )
        self.objdb.executescalar(
            sql_query=sql_query, action="insert", values=values
        )
        self.objactivitymgr.insert_activity_pending(dataset)
