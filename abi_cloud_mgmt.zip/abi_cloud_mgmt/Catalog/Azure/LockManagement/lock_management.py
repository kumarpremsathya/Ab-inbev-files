import json
from datetime import datetime, timedelta, timezone
import logging
from shared_code.db import DB
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from shared_code.snow_client import SNOWClient

class LockManagement:
    def __init__(self) -> None:
        self.LOCKMANAGEMENT_RETRY_ATTEMPT = timedelta(minutes=5, hours=0, days=0)
        self.TABLE_NAME = "tblActivityLockManagement"
        self.objactivitymgr = DbActivityManager()
        self.objsnow = SNOWClient()
        self.objdb= DB()

    def snow_data(self, data):
        devowner_sys_ids = []
        if data["payload"]["devowners"]:
            for email in data["payload"]["devowners"].split(";"):
                user_details = self.objsnow.get_user_details_by_email(email)
                if user_details:
                    devowner_sys_ids.append(user_details["sys_id"])
                else:
                    print(f"Warning: Email {email} not found in sys_user table")

        self.request_data = data

        self.request_data["short_description"] = (
            f"ABI Cloud Management Portal - Azure {data['payload']['data']['resource_group_name']} - Lock Management - {data['RequestorEmail']}"
        )
        self.request_data["description"] = (
            f"The user {data['RequestorEmail']} has requested to perform Lock management "
            f"to {data['payload']['data']['lock_action']} "
            f"in the Azure cloud under the zone {data['zone']}. ans the affected resource is {data['payload']['data']['resource_name']}"
        )

        self.request_data.update(
            {
                "business_service": "41b9ca581ba250d04a803150cd4bcbbe",
                "variables": {
                    "catalog_name": "Lock Management",
                    "category": "lock",
                    "catalog_description": "Add/Remove locks at Resource Group level and Resource Level", 
                    "zone": data["zone"],
                    "subscription": data["payload"]["data"]["subscription_name"],
                    "resource_name": data["payload"]["data"]["resource_name"],
                    "resource_group_name": data["payload"]["data"][ "resource_group_name"],
                    "lock_action": data["payload"]["data"]["lock_action"],
                    "lock_scope": data["payload"]["data"]["lock_scope"],
                    "lock_type": data["payload"]["data"]["lock_type"],
                    "devowner": ",".join(devowner_sys_ids),
                },
            }
        )

        return self.request_data
    
    def activity_data(self, dataset):
        logging.info(f"Activity data called with dataset: {dataset}")
        sql_query = """
            MERGE INTO tblActivityLockManagement AS Target
            USING (SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            AS SOURCE(EventId, SubscriptionId, SubscriptionName, ResourceGroupId, ResourceGroupName, ResourceName, 
                     ResourceId, LockAction, LockScope, LockType, Zone, Status,  RetryAttemptedAt)
            ON Target.EventId = Source.EventId
            AND Target.SubscriptionId = Source.SubscriptionId
            AND Target.SubscriptionName = Source.SubscriptionName
            AND Target.ResourceGroupId = Source.ResourceGroupId
            AND Target.ResourceGroupName = Source.ResourceGroupName
            AND Target.ResourceName = Source.ResourceName
            AND Target.ResourceId = Source.ResourceId
            AND Target.LockAction = Source.LockAction
            AND Target.LockScope = Source.LockScope
            AND Target.LockType = Source.LockType
            AND Target.Status = 'In-Progress'
            WHEN NOT MATCHED THEN
            INSERT (EventId, SubscriptionId, SubscriptionName, ResourceGroupId, ResourceGroupName, ResourceName,
                    ResourceId, LockAction, LockScope, LockType, Zone, Status, RetryAttemptedAt)
            VALUES (Source.EventId, Source.SubscriptionId, Source.SubscriptionName, Source.ResourceGroupId, Source.ResourceGroupName,
                    Source.ResourceName, Source.ResourceId, Source.LockAction, Source.LockScope, Source.LockType, 
                    Source.Zone, Source.Status, Source.RetryAttemptedAt);
        """
        
        payload = json.loads(dataset.Payload)
        
        values = (
            dataset.EventId,
            payload["data"]["subscription_id"],
            payload["data"]["subscription_name"],
            payload["data"]["resource_group_id"],
            payload["data"]["resource_group_name"],
            payload["data"]["resource_name"],
            payload["data"]["resource_id"],
            payload["data"]["lock_action"],
            payload["data"]["lock_scope"],
            payload["data"]["lock_type"],
            dataset.Zone,
            "In-Progress",
            datetime.now(timezone.utc)  # RetryAttemptedAt
        )
        self.objdb.executescalar(
            sql_query=sql_query, action="insert", values=values
        )
        
        self.objactivitymgr.insert_activity_pending(dataset)