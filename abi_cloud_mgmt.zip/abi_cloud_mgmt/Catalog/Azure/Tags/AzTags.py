import json,logging
from datetime import datetime,timezone,timedelta
from shared_code.db import DB
from RequestProcessor.DAL.DbActivityManager import DbActivityManager

class AzTags:

    def __init__(self) -> None:
        self.AZTAGS_RETRY_ATTEMPT = timedelta(minutes=5,hours=0,days=0)
        self.TABLE_NAME = 'tblActivityAzTags'
        self.TOPIC_NAME = 'aztags'
        self.objdb= DB()
        self.objactivitymgr = DbActivityManager()

    def snow_data(self,data):
        self.request_data = data
        self.request_data["short_description"] = f"ABI Cloud Management Portal - Tags Update for RG"
        self.request_data["description"] = f"The user {data['RequestorEmail']} has requested for tags update in ABI Cloud Management"
        self.request_data["business_service"] = "41b9ca581ba250d04a803150cd4bcbbe" 
        self.request_data["variables"] = {}
        self.request_data["variables"]["catalog_name"] = "TAGS"
        self.request_data["variables"]["category"] = "TAGS"
        self.request_data["variables"]["catalog_description"] = "To update Azure tags of resource group"
        self.request_data["variables"]["dev_owner_email"] = data['payload']['data'][0]["tags"]['DevOwnerEmail']
        self.request_data["variables"]["business_owner_email"] = data['payload']['data'][0]["tags"]['BusinessOwnerEmail']
        self.request_data["variables"]["cost_center"] = data['payload']['data'][0]["tags"]['CostCenter']
        self.request_data["variables"]["project_name"] = data['payload']['data'][0]["tags"]['ProjectName']
        self.request_data["variables"]["department"] = data['payload']['data'][0]["tags"]['Department']
        self.request_data["variables"]["criticality"] = data['payload']['data'][0]["tags"]['Criticality']        
        self.request_data["variables"]["maintenance_window"] = data['payload']['data'][0]["tags"]['MaintenanceWindow']        
        self.request_data["variables"]["applicationuid"] = data['payload']['data'][0]["tags"]['applicationUID']        

        return self.request_data        
    
    def activity_data(self,dataset):
        sql_query = """        
            MERGE INTO tblActivityAzTags as Target
            USING (SELECT ?,?,?,?,?,?,?,?)
            AS SOURCE(EventId,SubscriptionId,ResourceGroupName,Tags,Zone,Cloud,Status,RetryAttemptedAt)
            ON Target.EventId=Source.EventId
            AND Target.SubscriptionId=Source.SubscriptionId
            AND Target.ResourceGroupName=Source.ResourceGroupName
            AND Target.Tags=Source.Tags
            AND Target.Status='In-Progress'
            WHEN NOT MATCHED THEN
            INSERT (EventId,SubscriptionId,ResourceGroupName,Tags,Zone,Cloud,Status,RetryAttemptedAt)
            VALUES (Source.EventId,Source.SubscriptionId,Source.ResourceGroupName,Source.Tags,Source.Zone,Source.Cloud,Source.Status,Source.RetryAttemptedAt);
        """
        payload = json.loads(dataset.Payload)
        for val in payload["data"]:
            values=(
                    dataset.EventId,
                    val['subscription_id'],
                    val['resource_group_name'],
                    json.dumps(val['tags']),
                    val['zone'],
                    dataset.Cloud,
                    'In-Progress',
                    datetime.now(timezone.utc)
                )
            self.objdb.executescalar(sql_query=sql_query,action="insert",values=values)
        self.objactivitymgr.insert_activity_pending(dataset)