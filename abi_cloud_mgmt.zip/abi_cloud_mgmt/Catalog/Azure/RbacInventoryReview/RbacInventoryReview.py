import json,logging
from datetime import datetime,timezone,timedelta
from shared_code.db import DB
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from shared_code.snow_client import SNOWClient

class RbacInventoryReview:

    def __init__(self) -> None:
        self.RBAC_INV_REVIEW_RETRY_ATTEMPT = timedelta(minutes=5,hours=0,days=0)
        self.TABLE_NAME = 'tblActivityRbacInventoryReview'
        self.objdb= DB()
        self.objactivitymgr = DbActivityManager()
        self.objsnow = SNOWClient()
    
    def snow_data(self,data):
        self.request_data = data

        accounts = []
        for account in data["payload"]["data"]:
            accounts.append(account["accountName"])

        self.request_data["short_description"] = f"ABI Cloud Management Portal request for reviewing RBAC roles for accounts {','.join(accounts)} requested by - {data['RequestorEmail']}"
        self.request_data["description"] = (
            f"The user {data['RequestorEmail']} has reviewed the RBAC roles for the following accounts: {','.join(accounts)} in ABI Cloud Management Portal"
            f"in zone {data['zone']}."
        )

        # Regular Request
        self.request_data.update(
            {
                "business_service": "41b9ca581ba250d04a803150cd4bcbbe",
                "variables": {
                    "catalog_name": "RBAC Inventory Review",
                    "category": "IT_ACCESS_01",
                    "catalog_description": "Review of RBAC roles",
                    "zone": data["zone"],
                    "approver": data["RequestorEmail"],
                    "accounts": ",".join(accounts)
                }
            }
        )

        return self.request_data 
    
    def activity_data(self,dataset):
        sql_query = """        
            MERGE INTO tblActivityRbacInventoryReview as Target
            USING (SELECT ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            AS SOURCE(EventId, RoleAssignmentsId, UniqueId, AccountName, AccountId, RoleName, ScopeType, ApplicationUID, ProjectName, ManagementGroupName, SubscriptionName, ResourceGroupName, ResourceName, Action, Approver, Zone, Status,RetryAttemptedAt)
            ON Target.EventId=Source.EventId
            AND Target.RoleAssignmentsId=Source.RoleAssignmentsId
            AND Target.UniqueId=Source.UniqueId
            AND Target.AccountName=Source.AccountName
            AND Target.AccountId=Source.AccountId
            AND Target.RoleName=Source.RoleName
            AND Target.ScopeType=Source.ScopeType
            AND Target.ApplicationUID=Source.ApplicationUID
            AND Target.ProjectName=Source.ProjectName
            AND Target.ManagementGroupName=Source.ManagementGroupName
            AND Target.SubscriptionName=Source.SubscriptionName
            AND Target.ResourceGroupName=Source.ResourceGroupName
            AND Target.ResourceName=Source.ResourceName
            AND Target.Action=Source.Action
            AND Target.Approver=Source.Approver
            AND Target.Zone=Source.Zone
            AND Target.Status='In-Progress'
            WHEN NOT MATCHED THEN
            INSERT (EventId,RoleAssignmentsId,UniqueId,AccountName,AccountId,RoleName,ScopeType,ApplicationUID,ProjectName,ManagementGroupName,SubscriptionName,ResourceGroupName,ResourceName,Action,Approver,Zone,Status,RetryAttemptedAt)
            VALUES (Source.EventId,Source.RoleAssignmentsId,Source.UniqueId,Source.AccountName,Source.AccountId,Source.RoleName,Source.ScopeType,Source.ApplicationUID,Source.ProjectName,Source.ManagementGroupName,Source.SubscriptionName,Source.ResourceGroupName,Source.ResourceName,Source.Action,Source.Approver,Source.Zone,Source.Status,Source.RetryAttemptedAt);
        """
        payload = json.loads(dataset.Payload)
        for account in payload["data"]:
            for role in account["roles"]:
                values = (
                    dataset.EventId,
                    role["roleAssignmentsId"],
                    role["uniqueId"],
                    account["accountName"],
                    account["accountId"],
                    role["roleName"],
                    role["scopeType"],
                    role["applicationUID"],
                    role["projectName"],
                    role["managementGroupName"],
                    role["subscriptionName"],
                    role["resourceGroupName"],
                    role["resourceName"],
                    role["action"],
                    role["approvers"],
                    dataset.Zone,
                    "In-Progress",
                    datetime.now(timezone.utc)  # RetryAttemptedAt
                )
                logging.info(f"Insert values {values}")
                self.objdb.executescalar(
                    sql_query=sql_query, action="insert", values=values
                )
                
        self.objactivitymgr.insert_activity_pending(dataset)