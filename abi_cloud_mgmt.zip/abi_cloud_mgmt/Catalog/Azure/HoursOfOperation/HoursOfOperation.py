import json
from datetime import datetime, timezone, timedelta
from shared_code.db import DB
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from shared_code.snow_client import SNOWClient

class AzHoursOfOperation:
    def __init__(self) -> None:
        self.HOURSOP_RETRY_ATTEMPT = timedelta(minutes=5, hours=0, days=0)
        self.TABLE_NAME = 'tblActivityAzHoursOfOperation'
        self.objdb = DB()
        self.objactivitymgr = DbActivityManager()
        self.objsnow = SNOWClient()

    def snow_data(self, data):
        devowner_sys_ids = []
        for email in data["payload"]["devowners"].split(';'):
            user_details = self.objsnow.get_user_details_by_email(email.strip())
            if user_details:
                devowner_sys_ids.append(user_details["sys_id"])
        resources = [r["resource_name"] for r in data["payload"]["data"]]
        self.request_data = data
        self.request_data["short_description"] = (
            f"Update Hours of Operation for resources: {', '.join(resources)} in RG {data['payload']['data'][0]['resource_group_name']}"
        )
        self.request_data["description"] = (
            f"The user {data['RequestorEmail']} has requested to update Hours of Operation for "
            f"resources {', '.join(resources)} in resource group {data['payload']['data'][0]['resource_group_name']}."
        )
        self.request_data["business_service"] = "41b9ca581ba250d04a803150cd4bcbbe"
        self.request_data["variables"] = {
            "catalog_name": "Update Hours of Operation",
            "category": "hoursofoperation",
            "catalog_description": "Update the hours of operation for selected VMs",
            "resource_names": ",".join(resources),
            "resource_group_name": data["payload"]["data"][0]["resource_group_name"],
            "subscription_name": data["payload"]["data"][0]["subscription_name"],
            "zone": data["payload"]["data"][0]["zone"],
            "hours_of_operation": ",".join([r["hours_of_operation"] for r in data["payload"]["data"]]),
            "justification": ",".join([r.get("justification", "") for r in data["payload"]["data"]]),
            "timezone": ",".join([r.get("timezone", "") for r in data["payload"]["data"]]),
            "devowner": ",".join(devowner_sys_ids),
        }
        return self.request_data

    def activity_data(self, dataset):
        sql_query = """
            MERGE INTO tblActivityAzHoursOfOperation AS Target
            USING (SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            AS Source (EventId, SubscriptionId, SubscriptionName, ResourceGroupId, ResourceGroupName, ResourceId, ResourceName, HoursOfOperation, Zone, DevOwners, Status, RetryAttemptedAt)
            ON Target.EventId = Source.EventId
            AND Target.ResourceId = Source.ResourceId
            AND Target.Status = 'In-Progress'
            WHEN NOT MATCHED THEN
            INSERT (EventId, SubscriptionId, SubscriptionName, ResourceGroupId, ResourceGroupName, ResourceId, ResourceName, HoursOfOperation, Zone, DevOwners, Status, RetryAttemptedAt)
            VALUES (Source.EventId, Source.SubscriptionId, Source.SubscriptionName, Source.ResourceGroupId, Source.ResourceGroupName, Source.ResourceId, Source.ResourceName, Source.HoursOfOperation, Source.Zone, Source.DevOwners, Source.Status, Source.RetryAttemptedAt);
        """
        payload = json.loads(dataset.Payload)
        devowners = payload.get("devowners")
        for resource in payload["data"]:
            values = (
                dataset.EventId,
                resource['subscription_id'],
                resource['subscription_name'],
                resource['resource_group_id'],
                resource['resource_group_name'],
                resource['resource_id'],
                resource['resource_name'],
                resource['hours_of_operation'],
                dataset.Zone,
                devowners,
                "In-Progress",
                datetime.now(timezone.utc)
            )
            self.objdb.executescalar(sql_query=sql_query, action="insert", values=values)
        self.objactivitymgr.insert_activity_pending(dataset)