import json
from datetime import datetime, timezone, timedelta
import logging
from shared_code.db import DB
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from shared_code.snow_client import SNOWClient


class AzInstanceStatus:
    def __init__(self) -> None:
        self.AZINSTANCESTATUS_RETRY_ATTEMPT = timedelta(minutes=5, hours=0, days=0)
        self.TABLE_NAME = "tblActivityAzInstanceStatus"
        self.TOPIC_NAME = "azinstancestatus"
        self.objdb = DB()
        self.objactivitymgr = DbActivityManager()
        self.objsnow = SNOWClient()

    def snow_data(self, data):
        devowner_sys_ids = []
        for email in data["payload"]["devowners"].split(';'):
            user_details = self.objsnow.get_user_details_by_email(email)
            if user_details:
                devowner_sys_ids.append(user_details["sys_id"])
            else:
                print(f"Warning: Email {email} not found in sys_user table")

        self.request_data = data
        vms = []
        for vm in data["payload"]["data"]:
            vms.append(vm["resource_name"])

        self.request_data["short_description"] = (
            f"ABI Cloud Management Portal - Azure - {data['payload']['data'][0]['resource_group_name']} VM {','.join(vms)} action - {data['payload']['data'][0]['action']} - {data['RequestorEmail']}"
        )
        self.request_data["description"] = (
            f"The user {data['RequestorEmail']} has requested to perform {data['payload']['data'][0]['action']} actions on the specified VMs"
            f"Azure - {data['payload']['data'][0]['resource_group_name']} VM {','.join(vms)}"
            f"in zone {data['zone']}."
        )

        if data.get("ActivityType") == "Change":
            # Change Request
            self.request_data.update(
                {
                    "category": "Service",
                    "u_impacted_applications": data["payload"]["chg_impacted_application"],
                    "start_date": data["payload"]["chg_start_datetime"],
                    "end_date": data["payload"]["chg_end_datetime"],
                    "implementation_plan": f"once change will be approved VM will be {data['payload']['data'][0]['action']} at the scheduled time",
                    "risk_impact_analysis": "Make sure VM agent is up and running",
                    "backout_plan": data["payload"]["chg_backout_plan"],
                    "test_plan": f"Test if the vm is successfully {data['payload']['data'][0]['action']}",
                    "watch_list": ",".join(devowner_sys_ids),
                    "devowner": ",".join(devowner_sys_ids),
                    "timezone": data["payload"]["timezone"],
                    "risk": "4",
                    "impact": "3",
                    "reason": "maintenance",
                    # "variables": {
                    #     "catalog_name": "Start/Stop/Restart VM",
                    #     "category": f"{data['payload']['data'][0]['action']} VM",
                    #     "catalog_description": "Manage the state (Start/Stop/Restart) of Azure VMs",
                    #     "zone": data["zone"],
                    #     "subscription": data["payload"]["data"][0]["subscription_name"],
                    #     "resource_name": data["payload"]["data"][0]["resource_name"],
                    #     "resource_group_name": data["payload"]["data"][0]["resource_group_name"],
                    #     "devowner": ",".join(devowner_sys_ids),
                    # },
                }
            )
        else:
            # Regular Request
            self.request_data.update(
                {
                    "business_service": "41b9ca581ba250d04a803150cd4bcbbe",
                    "variables": {
                        "catalog_name": "Start/Stop/Restart VM" if data['zone'].lower() != 'naz' else "Start/Stop/Restart VM NAZ",
                        "category": f"{data['payload']['data'][0]['action']} VM" if data['zone'].lower() != 'naz' else f"{data['payload']['data'][0]['action']} VM NAZ",
                        "catalog_description": "Manage the state (Start/Stop/Restart) of Azure VMs",
                        "zone": data["zone"],
                        "subscription": data["payload"]["data"][0]["subscription_name"],
                        #"resource_name": data["payload"]["data"][0]["resource_name"],
                        "resource_name": ",".join(vms),
                        "resource_group_name": data["payload"]["data"][0]["resource_group_name"],
                        "devowner": ",".join(devowner_sys_ids),
                    },
                }
            )

        return self.request_data

    def activity_data(self, dataset):
        logging.info(f"Activity data called with dataset: {dataset}")
        sql_query = """
            MERGE INTO tblActivityAzInstanceStatus as Target
            USING (SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            AS SOURCE(EventId, SubscriptionId, SubscriptionName, ResourceGroupId, ResourceGroupName, ResourceName, ResourceId, ResourceType, Action, Zone, Status, RetryAttemptedAt)
            ON Target.EventId = Source.EventId
            AND Target.SubscriptionId = Source.SubscriptionId
            AND Target.ResourceGroupId = Source.ResourceGroupId
            AND Target.ResourceId = Source.ResourceId
            AND Target.Status = 'In-Progress'
            WHEN NOT MATCHED THEN
            INSERT (EventId, SubscriptionId, SubscriptionName, ResourceGroupId, ResourceGroupName, ResourceName, ResourceId, ResourceType, Action, Zone, Status, RetryAttemptedAt)
            VALUES (Source.EventId, Source.SubscriptionId, Source.SubscriptionName, Source.ResourceGroupId, Source.ResourceGroupName, Source.ResourceName, Source.ResourceId, Source.ResourceType, Source.Action, Source.Zone, Source.Status, Source.RetryAttemptedAt);
        """

        payload = json.loads(dataset.Payload)
        for vm in payload["data"]:
            values = (
                dataset.EventId,
                vm["subscription_id"],
                vm["subscription_name"],
                vm["resource_group_id"],
                vm["resource_group_name"],
                vm["resource_name"],
                vm["resource_id"],
                vm["resource_type"],
                vm["action"],
                dataset.Zone,
                "In-Progress",
                datetime.now(timezone.utc)  # RetryAttemptedAt
            )
            self.objdb.executescalar(
                sql_query=sql_query, action="insert", values=values
            )
        self.objactivitymgr.insert_activity_pending(dataset)
