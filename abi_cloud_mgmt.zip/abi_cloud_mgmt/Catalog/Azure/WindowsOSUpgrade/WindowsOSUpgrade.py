import json
from datetime import datetime, timezone, timedelta
from shared_code.db import DB
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from shared_code.snow_client import SNOWClient

class AzWindowsVmUpgrade:
    def __init__(self) -> None:
        self.RETRY_ATTEMPT = timedelta(minutes=5)
        self.TABLE_NAME = 'tblActivityAzWindowsVmUpgrade'
        self.objdb = DB()
        self.objactivitymgr = DbActivityManager()
        self.objsnow = SNOWClient()

    def snow_data(self, data):
        devowner_sys_ids = []
        for email in data["payload"]["devowners"].split(';'):
            user_details = self.objsnow.get_user_details_by_email(email.strip())
            if user_details:
                devowner_sys_ids.append(user_details["sys_id"])
        vms = [r["vm_name"] for r in data["payload"]["data"]]
        self.request_data = data
        self.request_data["short_description"] = (
            f"Windows OS Upgrade for VMs: {', '.join(vms)} in RG {data['payload']['data'][0]['resourceGroup']}"
        )
        self.request_data["description"] = (
            f"The user {data['RequestorEmail']} has requested to upgrade Windows OS for VMs "
            f"{', '.join(vms)} in resource group {data['payload']['data'][0]['resourceGroup']} "
            f"to version {data['payload']['data'][0]['target_version']}."
        )
        self.request_data["business_service"] = "41b9ca581ba250d04a803150cd4bcbbe"
        self.request_data["variables"] = {
            "catalog_name": "Windows OS Upgrade",
            "category": "windows-os-upgrade",
            "catalog_description": "Upgrade the Windows operating system version for selected Azure VMs",
            "vm_names": ",".join(vms),
            "resource_group": data["payload"]["data"][0]["resourceGroup"],
            "subscription_id": data["payload"]["data"][0]["subscriptionId"],
            "subscription_name": data["payload"]["data"][0]["subscriptionName"],
            "zone": data["payload"]["data"][0]["zone"],
            # "target_version": ",".join([r["target_version"] for r in data["payload"]["data"]]),
            # "current_version": ",".join([r["current_version"] for r in data["payload"]["data"]]), ## Not needed as per new there are multiple entries
            "justification": data["payload"].get("justification", ""),
            "devowner": ",".join(devowner_sys_ids),
        }
        return self.request_data

    def activity_data(self, dataset):
        sql_query = """
            MERGE INTO tblActivityAzWindowsVmUpgrade AS Target
            USING (SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            AS Source (EventId, SubscriptionId, SubscriptionName, ResourceGroup, VmName, TargetVersion, CurrentVersion, Zone, Justification, DevOwners, Status, RetryAttemptedAt, ActivityName)
            ON Target.EventId = Source.EventId
            AND Target.VmName = Source.VmName
            AND Target.Status = 'In-Progress'
            WHEN NOT MATCHED THEN
            INSERT (EventId, SubscriptionId, SubscriptionName, ResourceGroup, VmName, TargetVersion, CurrentVersion, Zone, Justification, DevOwners, Status, RetryAttemptedAt, ActivityName)
            VALUES (Source.EventId, Source.SubscriptionId, Source.SubscriptionName, Source.ResourceGroup, Source.VmName, Source.TargetVersion, Source.CurrentVersion, Source.Zone, Source.Justification, Source.DevOwners, Source.Status, Source.RetryAttemptedAt, Source.ActivityName);
        """
        payload = json.loads(dataset.Payload)
        devowners = payload.get("devowners", "")
        for resource in payload["data"]:
            values = (
                dataset.EventId,
                resource.get('subscriptionId'),
                resource.get('subscriptionName'),
                resource.get('resourceGroup'),
                resource.get('vm_name'),
                resource.get('target_version'),
                resource.get('current_version'),
                resource.get('zone'),
                payload.get('justification', ''),
                devowners,
                "In-Progress",
                datetime.now(timezone.utc),
                dataset.ActivityName,
            )
            self.objdb.executescalar(sql_query=sql_query, action="insert", values=values)
        self.objactivitymgr.insert_activity_pending(dataset)