import json
from datetime import datetime, timezone, timedelta
import logging
from ServiceNow.SnowChangeRequest import SnowChangeRequest
from shared_code.db import DB
from RequestProcessor.DAL.DbActivityManager import DbActivityManager
from shared_code.snow_client import SNOWClient
from shared_code.constants import Constants

class AzMsSqlDbResize:
    def __init__(self) -> None:
        self.AZVMRESIZE_RETRY_ATTEMPT = timedelta(minutes=5, hours=0, days=0)
        self.TABLE_NAME = "tblActivityAzMsSqlDbResize"
        self.objactivitymgr = DbActivityManager()
        self.objsnow = SNOWClient()
        self.objdb= DB()

    def snow_data(self, data):
        devowner_sys_ids = []
        if data["payload"]["devowners"]:
            for email in data["payload"]["devowners"].split(";"):
                user_details = self.objsnow.get_user_details_by_email(email)
                if user_details:
                    devowner_sys_ids.append(user_details["sys_id"])
                else:
                    print(f"Warning: Email {email} not found in sys_user table")

        self.request_data = data

        self.request_data["short_description"] = (
            f"ABI Cloud Management Portal - Azure - MsSql DB Resize - {data['RequestorEmail']}"
        )
        self.request_data["description"] = (
            f"The user {data['RequestorEmail']} has requested to MsSql DB Resize "
            f"in the Azure cloud under the zone {data['zone']}."
        )

        if data.get("ActivityType") == "Change":
            # Change Request
            self.request_data.update(
                {
                    "category": "Hardware",
                    "implementation_plan": f"once change will be approved SQL DB will be automatically resized at the scheduled time - {data['payload']['data']['sku_name']}",
                    "risk_impact_analysis": "Make sure DB is not in use",
                    "backout_plan": data["payload"]["chg_backout_plan"],
                    "test_plan": f"Test if the SQL DB is successfully resized to {data['payload']['data']['sku_name']}",
                    "u_impacted_applications": data["payload"]["chg_impacted_application"],
                    "start_date": data["payload"]["chg_start_datetime"],
                    "end_date": data["payload"]["chg_end_datetime"],
                    "watch_list": ",".join(devowner_sys_ids),
                    "devowner": ",".join(devowner_sys_ids),
                    "timezone": data["payload"]["timezone"],
                    "risk": "2",
                    "impact": "3",
                    # "variables": {
                    #     "catalog_name": f"Resize MsSql DB {data['payload']['data']['sku_name']}",
                    #     "category": "Resize MsSql DB",
                    #     "catalog_description": "Change the Disk size of Azure VMs",
                    #     "zone": data["zone"],
                    #     "subscription": data["payload"]["data"][0]["subscription_name"],
                    #     "resource_name": data["payload"]["data"][0]["resource_name"],
                    #     "resource_group_name": data["payload"]["data"][0]["resource_group_name"],
                    #     "devowner": ",".join(devowner_sys_ids),
                    # },
                }
            )
        else:
            # Regular Request
            self.request_data.update(
                {
                    "business_service": Constants.SNOW_BUSINESS_SERVICE,
                    "variables": {
                        "catalog_name": "SQL DB resize",
                        "category": "sql-resize",
                        "catalog_description": "Change the MSSQL DB size of Azure",
                        "zone": data["zone"],
                        "subscription": data["payload"]["data"]["subscription_name"],
                        "resource_group_name": data["payload"]["data"]["resource_group_name"],
                        "sql_database": data["payload"]["data"]["sql_db_name"],  
                        "sql_db_sku": data["payload"]["data"]["sku_name"],
                        "sql_db_tier": data["payload"]["data"]["sku_tier"],                        
                        "devowner": ",".join(devowner_sys_ids),
                    },
                }
            )

        return self.request_data

    def activity_data(self, dataset):
        logging.info(f"Activity data called with dataset: {dataset}")
        sql_query = """
            MERGE INTO tblActivityAzMsSqlDbResize as Target
            USING (SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            AS SOURCE(EventId, SubscriptionId, SubscriptionName, ResourceGroupId, ResourceGroupName, DbServer,DbName, 
                     DbId, TargetSize, Zone, Status, RetryAttemptedAt)
            ON Target.EventId = Source.EventId
            AND Target.SubscriptionId = Source.SubscriptionId
            AND Target.SubscriptionName = Source.SubscriptionName
            AND Target.ResourceGroupId = Source.ResourceGroupId
            AND Target.ResourceGroupName = Source.ResourceGroupName
            AND Target.DbServer = Source.DbServer
            AND Target.DbName = Source.DbName
            AND Target.DbId = Source.DbId
            AND Target.TargetSize = Source.TargetSize
            AND Target.Status = 'In-Progress'
            WHEN NOT MATCHED THEN
            INSERT (EventId, SubscriptionId, SubscriptionName, ResourceGroupId, ResourceGroupName, DbServer,DbName, 
                    DbId, TargetSize, Zone, Status, RetryAttemptedAt)
            VALUES (Source.EventId, Source.SubscriptionId, Source.SubscriptionName, Source.ResourceGroupId, Source.ResourceGroupName,
                    Source.DbServer, Source.DbName, Source.DbId, Source.TargetSize, 
                    Source.Zone, Source.Status, Source.RetryAttemptedAt);

        """

        payload = json.loads(dataset.Payload)
        values = (
            dataset.EventId,
            payload["data"]["subscription_id"],
            payload["data"]["subscription_name"],
            payload["data"]["resource_group_id"],
            payload["data"]["resource_group_name"],
            payload["data"]["sql_server_name"],
            payload["data"]["sql_db_name"],
            payload["data"]["resource_id"],
            payload["data"]["sku_name"],
            dataset.Zone,
            "In-Progress",
            datetime.now(timezone.utc)  # RetryAttemptedAt
        )
        self.objdb.executescalar(
            sql_query=sql_query, action="insert", values=values
        )
        self.objactivitymgr.insert_activity_pending(dataset)
