from Catalog.Gcp.GcpRbac import GcpRbac

class GcpActivityNames:
    def __init__(self):
        pass

    def get_activity_type_data(self,data):
        match data["ActivityName"]:      
            case "RBAC":
                self.request_data = GcpRbac().snow_data(data)

        return self.request_data