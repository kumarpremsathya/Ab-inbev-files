import logging
import json
from Catalog.Azure.Rbac.AzRbac import AzRbac
from Catalog.Azure.AppRoles.AzAppRole import AzAppRole
from Catalog.Azure.RbacInventoryReview.RbacInventoryReview import RbacInventoryReview
from Catalog.Azure.Tags.AzTags import AzTags
from Catalog.Azure.RunCommand.AzEndTaskProcess import AzEndTaskProcess
from Catalog.Azure.AzInstanceStatus.AzInstanceStatus import AzInstanceStatus
from Catalog.Azure.VmInventoryReview.VmInventoryReview import VmInventoryReview
from Catalog.Azure.GroupMemberReview.VmGroupMemberReview import VmGroupMemberReview
from Catalog.Azure.GroupMemberReview.RbacGroupMemberReview import RbacGroupMemberReview
from Catalog.Azure.VmResize.AzVmResize import AzVmResize
from Catalog.Azure.VmDiskResize.AzVmDiskResize import AzVmDiskResize
from Catalog.Azure.MsSqlDbResize.AzMsSqlDbResize import AzMsSqlDbResize
from Catalog.Azure.MSSqlAccess.mssql_access import AzMsSqlAccess
from Catalog.Azure.PostgreSqlAccess.postgresql_access import AzPostgreSqlAccess
from Catalog.Azure.LockManagement.lock_management import LockManagement
from Catalog.Azure.Decommission.decommission import AzDecommission
from Catalog.Azure.Decommission.decommission_preactivity import AzDecommissionPreactivity
from Catalog.Azure.Provisioning.RgSnowData import AzRgSnowData
from Catalog.Azure.AzSnapshot.AzSnapshotCreation import AzSnapshotCreation
from Catalog.Azure.VmAccessMgmt.VmAccessMgmt import AzVmAccessMgmt
from Catalog.Azure.Provisioning.VMSnowData import AzVmSnowData
from Catalog.Azure.VmCredMgmt.VmCredMgmt import AzVmCredMgmt
from Catalog.Azure.Provisioning.KeyVaultSnowData import AzKeyVaultSnowData
from Catalog.Azure.Rbac.AzRbacExceptional import AzRbacExceptional
from Catalog.Azure.Provisioning.StorageAccountSnowData import AzStorageAccountSnowData
from Catalog.Azure.Provisioning.WebAppSnowData import AzWebAppSnowData
from Catalog.Azure.Provisioning.LogicAppSnowData import AzLogicAppSnowData
from Catalog.Azure.Provisioning.FunctionAppSnowData import AzFunctionAppSnowData
from Catalog.Azure.Provisioning.PostgreSqlFlexiSnowData import PostgreSqlFlexiSnowData
from Catalog.Azure.Provisioning.CosmosDbSnowData import CosmosDbSnowData
from Catalog.General.ItAccess06.ItAccess06 import ItAccess06
from Catalog.Azure.Provisioning.MSSQLServerSnowData import MSSQLServerSnowData
from Catalog.Azure.Provisioning.MSSQLManagedInstanceSnowData import MSSQLManagedInstanceSnowData
from Catalog.Azure.Provisioning.MSSQLDBSnowData import MSSQLDBSnowData
from Catalog.Azure.Provisioning.MSSQLElasticPoolSnowData import MSSQLElasticPoolSnowData
from Catalog.Azure.Provisioning.AppInsightsSnowData import AppInsightsSnowData
from Catalog.Azure.Provisioning.AzDatabricksSnowData import AzDatabricksSnowData
from Catalog.Azure.Provisioning.AzDatafactorySnowData import AzDatafactorySnowData
from Catalog.Azure.Provisioning.AzEventHubSnowData import AzEventHubSnowData
from Catalog.Azure.Provisioning.AzRedisCacheSnowData import AzRedisCacheSnowData
from Catalog.Azure.Provisioning.AzServiceBusSnowData import AzServiceBusSnowData
from Catalog.Azure.Provisioning.PrivateEndpointSnowData import PrivateEndpointSnowData
from Catalog.Azure.HoursOfOperation.HoursOfOperation import AzHoursOfOperation
from Catalog.Azure.HoursOfOperationInstance.AzHoursOfOperationInstance import AzHoursOfOperationInstance
from Catalog.Azure.WindowsOSUpgrade.WindowsOSUpgrade import AzWindowsVmUpgrade
from Catalog.Azure.InactiveRbac.InactiveRbac import AzInactiveRbac
from Catalog.Azure.InactiveVMAccounts.InactiveVMAccounts import InactiveVMAccounts
from Catalog.Azure.PolicyExemption.PolicyExemption import AzPolicyExemption
from Catalog.Azure.KeyVaultMgmt.KeyVaultMgmt import AzKeyVaultMgmt

class AzActivityNames:
    def __init__(self):
        pass

    async def get_activity_type_data(self,data):

        match data["ActivityName"]: 
            # case "INACTIVERBAC":
            #     self.request_data = AzInactiveRbac().snow_data(data)                
            # case "RBAC":
            #     self.request_data = await AzRbac().snow_data(data)
            # case "APPROLE":
            #     self.request_data = AzAppRole().snow_data(data)
            # case "TAGS":
            #     self.request_data = AzTags().snow_data(data)
            # case "ENDTASKPROCESS":
            #     self.request_data = AzEndTaskProcess().snow_data(data)
            # case "INSTANCESTATUS":
            #     self.request_data = AzInstanceStatus().snow_data(data)
            # case "RESIZEVMSKU":
            #     self.request_data = AzVmResize().snow_data(data)
            # case "RESIZEVMDISK":
            #     self.request_data = AzVmDiskResize().snow_data(data)
            # case "RESIZESQLDB":
            #     self.request_data = AzMsSqlDbResize().snow_data(data)
            # case "MSSQLACCESS":
            #     self.request_data = AzMsSqlAccess().snow_data(data)
            # case "POSTGRESQLACCESS":
            #     self.request_data = AzPostgreSqlAccess().snow_data(data)
            # case "LOCKMANAGEMENT":
            #     self.request_data = LockManagement().snow_data(data)
            # case "DECOMM":
            #     self.request_data = AzDecommission().snow_data(data)
            # case "DECOMMPREACTIVITY":
            #     self.request_data = AzDecommissionPreactivity().snow_data(data)
            # case "RGPROVISION":
            #     self.request_data = AzRgSnowData().snow_data(data)
            # case "SNAPSHOTCREATION":
            #     self.request_data = AzSnapshotCreation().snow_data(data)
            # case "VMACCESSMGMT":
            #     self.request_data = AzVmAccessMgmt().snow_data(data)
            # case "VMPROVISION":
            #     self.request_data = AzVmSnowData().snow_data(data)
            # case "VMCREDMGMT":
            #     self.request_data = AzVmCredMgmt().snow_data(data)
            # case "KEYVAULTPROVISION":
            #     self.request_data = AzKeyVaultSnowData().snow_data(data)
            # case "RBACEXCEPTIONAL":
            #     self.request_data = AzRbacExceptional().snow_data(data)
            # case "STORAGEACCOUNTPROVISION":
            #     self.request_data = AzStorageAccountSnowData().snow_data(data)
            # case "WEBAPPPROVISION":
            #     self.request_data = AzWebAppSnowData().snow_data(data)
            # case "LOGICAPPPROVISION":
            #     self.request_data = AzLogicAppSnowData().snow_data(data)
            # case "FUNCTIONAPPPROVISION":
            #     self.request_data = AzFunctionAppSnowData().snow_data(data)
            # case "POSTGREDBPROVISION":
            #     self.request_data = PostgreSqlFlexiSnowData().snow_data(data)
            # case "COSMOSDBPROVISION":
            #     self.request_data = CosmosDbSnowData().snow_data(data)
            # case "IT_ACCESS_06":
            #     self.request_data = ItAccess06().snow_data(data)
            # case "MSSQLSERVERPROVISION":
            #     self.request_data = MSSQLServerSnowData().snow_data(data)
            # case "MSSQLMGMTINSTANCEPROVISION":
            #     self.request_data = MSSQLManagedInstanceSnowData().snow_data(data)
            # case "MSSQLDBPROVISION":
            #     self.request_data = MSSQLDBSnowData().snow_data(data)
            # case "MSSQLELASTICPOOLPROVISION":
            #     self.request_data = MSSQLElasticPoolSnowData().snow_data(data)  
            # case "APPINSIGHTSPROVISION":
            #     self.request_data = AppInsightsSnowData().snow_data(data)  
            # case "DATABRICKSPROVISION":
            #     self.request_data = AzDatabricksSnowData().snow_data(data) 
            # case "DATAFACTORYPROVISION":
            #     self.request_data = AzDatafactorySnowData().snow_data(data) 
            # case "EVENTHUBPROVISION":
            #     self.request_data = AzEventHubSnowData().snow_data(data) 
            # case "REDISCACHEPROVISION":
            #     self.request_data = AzRedisCacheSnowData().snow_data(data) 
            # case "SERVICEBUSPROVISION":
            #     self.request_data = AzServiceBusSnowData().snow_data(data) 
            # case "PRIVATEENDPOINTPROVISION":
            #     self.request_data = PrivateEndpointSnowData().snow_data(data)
            # case "HOURSOFOPERATION":
            #     self.request_data = AzHoursOfOperation().snow_data(data)
            # case "HOURSOFOPERATIONINSTANCE":
            #     self.request_data = AzHoursOfOperationInstance().snow_data(data)
            # case "WINDOWSVMUPGRADE":
            #     self.request_data = AzWindowsVmUpgrade().snow_data(data)
            # case "DISKCLEANUP":
            #     self.request_data = []
            # case "BACKUPFAILURE":
            #     self.request_data = []
            # case "MEMORYHIGHALERT":
            #     self.request_data = []
            # case "CPUHIGHALERT":
            #     self.request_data = []
            # case "VMINVREVIEW":
            #     self.request_data = VmInventoryReview().snow_data(data)
            # case "RBACINVENTORYREVIEW":
            #     self.request_data = RbacInventoryReview().snow_data(data)
            # case "VMGROUPMEMBERREVIEW":
            #     self.request_data = VmGroupMemberReview().snow_data(data)
            # case "RBACGROUPMEMBERREVIEW":
            #     self.request_data = RbacGroupMemberReview().snow_data(data)
            # case "INACTIVEVMACCOUNTS":
            #     self.request_data = InactiveVMAccounts().snow_data(data)
            # case "INACTIVERBAC":
            #     self.request_data = AzInactiveRbac().snow_data(data)                
            case "POLICYEXEMPTION":
                self.request_data = AzPolicyExemption().snow_data(data)
            case "KEYVAULTMGMT":
                self.request_data = AzKeyVaultMgmt().snow_data(data)
            # case "RBAC":
            #     self.request_data = await AzRbac().snow_data(data)
            # case "APPROLE":
            #     self.request_data = AzAppRole().snow_data(data)
            # case "TAGS":
            #     self.request_data = AzTags().snow_data(data)
            # case "ENDTASKPROCESS":
            #     self.request_data = AzEndTaskProcess().snow_data(data)
            # case "INSTANCESTATUS":
            #     self.request_data = AzInstanceStatus().snow_data(data)
            # case "RESIZEVMSKU":
            #     self.request_data = AzVmResize().snow_data(data)
            # case "RESIZEVMDISK":
            #     self.request_data = AzVmDiskResize().snow_data(data)
            # case "RESIZESQLDB":
            #     self.request_data = AzMsSqlDbResize().snow_data(data)
            # case "MSSQLACCESS":
            #     self.request_data = AzMsSqlAccess().snow_data(data)
            # case "POSTGRESQLACCESS":
            #     self.request_data = AzPostgreSqlAccess().snow_data(data)
            # case "LOCKMANAGEMENT":
            #     self.request_data = LockManagement().snow_data(data)
            # case "DECOMM":
            #     self.request_data = AzDecommission().snow_data(data)
            # case "DECOMMPREACTIVITY":
            #     self.request_data = AzDecommissionPreactivity().snow_data(data)
            # case "RGPROVISION":
            #     self.request_data = AzRgSnowData().snow_data(data)
            # case "SNAPSHOTCREATION":
            #     self.request_data = AzSnapshotCreation().snow_data(data)
            # case "VMACCESSMGMT":
            #     self.request_data = AzVmAccessMgmt().snow_data(data)
            # case "VMPROVISION":
            #     self.request_data = AzVmSnowData().snow_data(data)
            # case "VMCREDMGMT":
            #     self.request_data = AzVmCredMgmt().snow_data(data)
            # case "KEYVAULTPROVISION":
            #     self.request_data = AzKeyVaultSnowData().snow_data(data)
            # case "RBACEXCEPTIONAL":
            #     self.request_data = AzRbacExceptional().snow_data(data)
            # case "STORAGEACCOUNTPROVISION":
            #     self.request_data = AzStorageAccountSnowData().snow_data(data)
            # case "WEBAPPPROVISION":
            #     self.request_data = AzWebAppSnowData().snow_data(data)
            # case "LOGICAPPPROVISION":
            #     self.request_data = AzLogicAppSnowData().snow_data(data)
            # case "FUNCTIONAPPPROVISION":
            #     self.request_data = AzFunctionAppSnowData().snow_data(data)
            # case "POSTGREDBPROVISION":
            #     self.request_data = PostgreSqlFlexiSnowData().snow_data(data)
            # case "COSMOSDBPROVISION":
            #     self.request_data = CosmosDbSnowData().snow_data(data)
            # case "IT_ACCESS_06":
            #     self.request_data = ItAccess06().snow_data(data)
            # case "MSSQLSERVERPROVISION":
            #     self.request_data = MSSQLServerSnowData().snow_data(data)
            # case "MSSQLMGMTINSTANCEPROVISION":
            #     self.request_data = MSSQLManagedInstanceSnowData().snow_data(data)
            # case "MSSQLDBPROVISION":
            #     self.request_data = MSSQLDBSnowData().snow_data(data)
            # case "MSSQLELASTICPOOLPROVISION":
            #     self.request_data = MSSQLElasticPoolSnowData().snow_data(data)  
            # case "APPINSIGHTSPROVISION":
            #     self.request_data = AppInsightsSnowData().snow_data(data)  
            # case "DATABRICKSPROVISION":
            #     self.request_data = AzDatabricksSnowData().snow_data(data) 
            # case "DATAFACTORYPROVISION":
            #     self.request_data = AzDatafactorySnowData().snow_data(data) 
            # case "EVENTHUBPROVISION":
            #     self.request_data = AzEventHubSnowData().snow_data(data) 
            # case "REDISCACHEPROVISION":
            #     self.request_data = AzRedisCacheSnowData().snow_data(data) 
            # case "SERVICEBUSPROVISION":
            #     self.request_data = AzServiceBusSnowData().snow_data(data) 
            # case "PRIVATEENDPOINTPROVISION":
            #     self.request_data = PrivateEndpointSnowData().snow_data(data)
            # case "HOURSOFOPERATION":
            #     self.request_data = AzHoursOfOperation().snow_data(data)
            # case "HOURSOFOPERATIONINSTANCE":
            #     self.request_data = AzHoursOfOperationInstance().snow_data(data)
            # case "WINDOWSVMUPGRADE":
            #     self.request_data = AzWindowsVmUpgrade().snow_data(data)
            # case "DISKCLEANUP":
            #     self.request_data = []
            # case "BACKUPFAILURE":
            #     self.request_data = []
            # case "VMINVREVIEW":
            #     self.request_data = VmInventoryReview().snow_data(data)
            # case "RBACINVENTORYREVIEW":
            #     self.request_data = RbacInventoryReview().snow_data(data)
            # case "VMGROUPMEMBERREVIEW":
            #     self.request_data = VmGroupMemberReview().snow_data(data)
            # case "RBACGROUPMEMBERREVIEW":
            #     self.request_data = RbacGroupMemberReview().snow_data(data)
            # case "INACTIVEVMACCOUNTS":
            #     self.request_data = InactiveVMAccounts().snow_data(data)
        return self.request_data