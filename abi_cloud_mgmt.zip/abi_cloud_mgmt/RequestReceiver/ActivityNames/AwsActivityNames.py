from Catalog.Aws.AwsRbac import AwsRbac

class AwsActivityNames:
    def __init__(self):
        pass

    def get_activity_type_data(self,data):
        match data["ActivityName"]:      
            case "RBAC":
                self.request_data = AwsRbac().snow_data(data)

        return self.request_data