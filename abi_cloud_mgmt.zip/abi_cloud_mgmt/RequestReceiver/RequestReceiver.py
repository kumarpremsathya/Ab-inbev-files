import json,logging,asyncio,datetime
from shared_code.db import DB
from RequestReceiver.ActivityNames.AzActivityNames import AzActivityNames
from RequestReceiver.ActivityNames.AwsActivityNames import AwsActivityNames
from RequestReceiver.ActivityNames.GcpActivityNames import GcpActivityNames
from ServiceNow.SnowRequest import SnowRequest
from shared_code.EmailNotification.NotifyUserIncident import NotifyUserIncident
from ServiceNow.SnowChangeRequest import SnowChangeRequest
from shared_code.EmailNotification.NotifyUser import NotifyUser
from shared_code.servicebus_client import ServiceBusClientAbstract

class RequestReceiver:
    def __init__(self) -> None:
        self.objdb= DB()
        
    async def request_initilize(self,data):
        logging.info(f"\n\n\n[FLOW-1] request_initilize called | ActivityType: {data['ActivityType']}")
             
        match  data['payload']['cloud']:
            case "Azure":
                activity_type_data = await AzActivityNames().get_activity_type_data(data)
            case "Gcp":
                activity_type_data = GcpActivityNames().get_activity_type_data(data)
            case "Aws":
                activity_type_data = AwsActivityNames().get_activity_type_data(data)        
        match data["ActivityType"]:
            case "Alert":
                self.data = data
                self.status = 'Queued'
                eventid = self.event_db_insert(self.data)
                await NotifyUserIncident().send_email_notification({'EventId':eventid,'ActivityName':self.data["ActivityName"],'SnowItemId':self.data["SnowItemId"],'Status':"Received",'Recommendations':self.data['payload']['data'].get("recommendations","")},self.data['RequestorEmail'])
                return self.data["SnowItemId"]
            case 'Incident':
                self.data = data
                self.status = 'Queued'
                eventid = self.event_db_insert(self.data)
                # await NotifyUserIncident().send_email_notification({'EventId':eventid,'ActivityName':self.data["ActivityName"],'SnowItemId':self.data["SnowItemId"],'Status':"Received",'Recommendations':self.data['payload']['data'].get("recommendations","")},self.data['RequestorEmail'])
                # await NotifyUserIncident().send_email_notification({'EventId':eventid,'ActivityName':self.data["ActivityName"],'SnowItemId':self.data["SnowItemId"],'Status':"Received",'Recommendations':self.data.get("Recommendations","")},self.data['RequestorEmail'])
                logging.info(f"[PHASE-2] tblEventMaster insert done. EventId={eventid}, SnowItemId={self.data['SnowItemId']}")
                return self.data["SnowItemId"]
            case 'Request':
                self.data = SnowRequest().create(activity_type_data)
                self.status = 'Pending Approval'
            case 'Change':
                self.data = SnowChangeRequest().create(activity_type_data)
                self.status = 'Pending Approval'                
            
        eventid = self.event_db_insert(self.data)
        # await NotifyUser().send_email_notification({'EventId':eventid,'ActivityName':self.data["ActivityName"],'SnowItemId':self.data["SnowItemId"],'Status':"Submitted"},self.data['RequestorEmail'])
        return self.data["SnowItemId"]
        
    
    def event_db_insert(self,data):
        logging.info(f"\n\n\n[FLOW-1] event_db_insert called | ActivityType: {data['ActivityType']} | SnowItemId: {data['SnowItemId']}")
        try:
            sql_query = """
            MERGE INTO tblEventMaster as Target
            USING (SELECT ?,?,?,?,?,?,?,?,?,?,?,?,?)
            AS SOURCE(MessageId,ActivityName,ActivityType,SnowId,SnowItemId,SnowItemStatusCode,SnowItemStatus,RequestedBy,Cloud,Zone,Payload,LastUpdateTime,Status)
            ON Target.MessageId=Source.MessageId
            AND Target.ActivityName=Source.ActivityName
            AND Target.ActivityType=Source.ActivityType
            AND Target.Status=Source.Status
            WHEN NOT MATCHED THEN            
            INSERT (MessageId,ActivityName,ActivityType,SnowId,SnowItemId,SnowItemStatusCode,SnowItemStatus,RequestedBy,Cloud,Zone,Payload,LastUpdateTime,Status)
            VALUES (Source.MessageId, Source.ActivityName, Source.ActivityType,Source.SnowId, Source.SnowItemId, Source.SnowItemStatusCode,Source.SnowItemStatus, Source.RequestedBy,
                    Source.Cloud,Source.Zone, Source.Payload, Source.LastUpdateTime, Source.Status)
            output inserted.EventId;
            """
            values =(
                     data['message_id'],
                     data['ActivityName'],
                     data['ActivityType'],
                     data['SnowId'],
                     data['SnowItemId'],
                     data['SnowItemStatusCode'],
                     data['SnowItemStatus'],
                     data['RequestorEmail'],
                     data['payload']['cloud'],
                     data['zone'],
                     json.dumps(data['payload']),
                     datetime.datetime.now(datetime.timezone.utc),
                     self.status                     
                     )
            return self.objdb.executescalar(sql_query=sql_query,action="eventinsert",values=values)
        except Exception as e:
            logging.error(f"Error Updating Database: {e} Dataset {data}")
            raise Exception(f"Error Updating Database: {e} Dataset {data}")