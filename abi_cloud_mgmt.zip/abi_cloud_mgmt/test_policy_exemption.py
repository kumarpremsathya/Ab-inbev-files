import requests
import json


url = "http://localhost:7071/api/test_request_receiver"


payload = {
    "RequestorEmail": "Sukanya.S@AB-inbev.com",
    "OID": "eec0d38d-6486-4199-8cec-e3e2aee5b520",
    "ActivityName": "POLICYEXEMPTION",
    "ActivityType": "Request",
    "zone": "GHQ",
    "payload": {
        "cloud": "Azure",
        "devowners": "",
        "data": {
            "zone": "GHQ",
            "subscription_id": "1920c23f-e3e5-47b3-98cd-c904cc2b9671",
            "subscription_name": "ABI GHQ  DigitalSolutions NON-PROD",
            "resource_group": "abi-ghq-00000-digitalsolutions-datadog-weu-dev-rg",
            "resource_group_id": "/subscriptions/1920c23f-e3e5-47b3-98cd-c904cc2b9671/resourceGroups/abi-ghq-00000-digitalsolutions-datadog-weu-dev-rg",
            "policy_exemption_resources": [
                {
                    "resource_name": "ghq-00000-datadog-sin-dev-evh",
                    "resource_id": "/subscriptions/1920c23f-e3e5-47b3-98cd-c904cc2b9671/resourcegroups/abi-ghq-00000-digitalsolutions-datadog-weu-dev-rg/providers/microsoft.eventhub/namespaces/ghq-00000-datadog-sin-dev-evh",
                    "policy_display_name": "Event Hub namespaces should use a valid TLS version ",
                    "policy_assignment_id": "/providers/microsoft.management/managementgroups/b3efa24a-aeda-4d6b-a2d6-b84936258e7c/providers/microsoft.authorization/policyassignments/abi_ghq_pol_nprd_v6_0",
                    "policy_definition_reference_id": "/providers/microsoft.management/managementgroups/9bb8e8e3-d02b-4b6f-8ae4-80bf17d6a13c/providers/microsoft.authorization/policydefinitions/deny-eh-mintls-v6-1"
                },
                {
                    "resource_name": "ghq-00000-datadog-scu-dev-evh",
                    "resource_id": "/subscriptions/1920c23f-e3e5-47b3-98cd-c904cc2b9671/resourcegroups/abi-ghq-00000-digitalsolutions-datadog-weu-dev-rg/providers/microsoft.eventhub/namespaces/ghq-00000-datadog-scu-dev-evh",
                    "policy_display_name": "Event Hub namespaces should use a valid TLS version ",
                    "policy_assignment_id": "/providers/microsoft.management/managementgroups/b3efa24a-aeda-4d6b-a2d6-b84936258e7c/providers/microsoft.authorization/policyassignments/abi_ghq_pol_nprd_v6_0",
                    "policy_definition_reference_id": "/providers/microsoft.management/managementgroups/9bb8e8e3-d02b-4b6f-8ae4-80bf17d6a13c/providers/microsoft.authorization/policydefinitions/deny-eh-mintls-v6-1"
                },
                {
                    "resource_name": "ghq-00000-datadog-weu-dev-evh",
                    "resource_id": "/subscriptions/1920c23f-e3e5-47b3-98cd-c904cc2b9671/resourcegroups/abi-ghq-00000-digitalsolutions-datadog-weu-dev-rg/providers/microsoft.eventhub/namespaces/ghq-00000-datadog-weu-dev-evh",
                    "policy_display_name": "Event Hub namespaces should use a valid TLS version ",
                    "policy_assignment_id": "/providers/microsoft.management/managementgroups/b3efa24a-aeda-4d6b-a2d6-b84936258e7c/providers/microsoft.authorization/policyassignments/abi_ghq_pol_nprd_v6_0",
                    "policy_definition_reference_id": "/providers/microsoft.management/managementgroups/9bb8e8e3-d02b-4b6f-8ae4-80bf17d6a13c/providers/microsoft.authorization/policydefinitions/deny-eh-mintls-v6-1"
                }
            ],
            "policy_auditors": "true",
            "is_temporary": "true",
            "duration": "4h",
            "business_impact": "testing",
            "technical_justification": "testing"
        }
    }
}


response = requests.post(url, json=payload)
print(f"Status: {response.status_code}")
print(f"Response: {response.text}")

#  Invoke-RestMethod -Uri "http://localhost:7071/api/test_processor"