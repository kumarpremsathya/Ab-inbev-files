import json,logging
from shared_code.constants import Constants
from shared_code.snow_client import SNOWClient

class SnowIncident:
    def __init__(self):
        self.objsnow = SNOWClient()

    def create(self,data):
        try:
            match data['zone']:
                case 'GHQ':
                    data["u_select_zone"] = "388556871b3f00104aae202a2d4bcb43"
                case 'TECHOPS':
                    data["u_select_zone"] = "388556871b3f00104aae202a2d4bcb43"
                case 'AURORA':
                    data["u_select_zone"] = "388556871b3f00104aae202a2d4bcb43"
                case 'BREWDAT':
                    data["u_select_zone"] = "388556871b3f00104aae202a2d4bcb43"
                case 'NAZ':
                    data["u_select_zone"] = "9c359a471b3f00104aae202a2d4bcbe9"
                case 'KOREA':
                    data["u_select_zone"] = "59c41a471b3f00104aae202a2d4bcba6"
                case 'MAZ':
                    data["u_select_zone"] = "4ab316071b3f00104aae202a2d4bcb87"
                case 'CHINA':
                    data["u_select_zone"] = "59c41a471b3f00104aae202a2d4bcba6"
                case 'SAZ':
                    data["u_select_zone"] = "4c83bd21db7f88506ee970c4f3961922"
                case 'EUROPE':
                    data["u_select_zone"] = "55ccca0f1bfb00104aae202a2d4bcbb5"
                case 'AFRICA':
                    data["u_select_zone"] = "155412471b3f00104aae202a2d4bcbd9"
                case 'LAS':
                    data["u_select_zone"] = "30d7f7a797be465082bffaa6f053afb0"
            data["caller_id"]  = Constants.SNOW_INCIDENT_CALLER_ID
            data["assignment_group"] = Constants.SNOW_ASSIGNMENT_GROUP
            snow_inc = self.objsnow.create_incident(data)
        except Exception as e:
            logging.error(e)
            raise Exception(f"Error Creating SNOW: {e}")

        data['SnowId'] = snow_inc['number']
        data['SnowItemId'] = snow_inc['number']
        data['SnowItemStatusCode'] = snow_inc['state']
        data['SnowItemStatus'] = 'Queued'
        return data
    
    def snow_update_incident(self,dataset):
        if dataset.Status == 'Success':
            state = '7'
            assigned_to = Constants.SNOW_ASSIGNMENT_USER
            assignment_group = Constants.SNOW_ASSIGNMENT_GROUP
            result = self.objsnow.update_incident_status(dataset.SnowItemId,state,"Resolved",close_notes="Resolved",work_notes="Resolved",assigned_to=assigned_to,assignment_group=assignment_group)
        if dataset.Status == 'Failed':
            state = '2'
            assignment_group = "bc8f21181bc0cc50dd907739cd4bcb27"
            result = self.objsnow.update_incident_status(dataset.SnowItemId,state,"Hand Over",assignment_group=assignment_group,assigned_to='')
        if dataset.Status == 'Queued':
            state = '2'
            assigned_to = Constants.SNOW_ASSIGNMENT_USER
            result = self.objsnow.update_incident_status(dataset.SnowItemId,state,"In-Progress",assigned_to=assigned_to,work_notes="In-Progress")       
        return result
    
    def snow_update_alert(self,dataset):
        if dataset.Status == 'Success':
            state = 'Closed'
            assigned_to = Constants.SNOW_ASSIGNMENT_USER
            assignment_group = Constants.SNOW_ASSIGNMENT_GROUP
            result = self.objsnow.update_alert_status(dataset.SnowItemId,state,"Resolved",close_notes="Resolved",work_notes="Resolved",assigned_to=assigned_to,assignment_group=assignment_group)
        if dataset.Status == 'Failed':
            state = 'Open'
            assignment_group = "bc8f21181bc0cc50dd907739cd4bcb27"
            result = self.objsnow.update_alert_status(dataset.SnowItemId,state,"Hand Over",assignment_group=assignment_group,assigned_to='')
        if dataset.Status == 'Queued':
            state = 'Open'
            assigned_to = Constants.SNOW_ASSIGNMENT_USER
            result = self.objsnow.update_alert_status(dataset.SnowItemId,state,"In-Progress",assigned_to=assigned_to,work_notes="In-Progress")
        return result
    
    def snow_get_incident_status(self,inc):
        snow_inc = self.objsnow.get_incident_status(inc)
        return snow_inc

    def snow_get_alert_status(self,alert):
        snow_alert = self.objsnow.get_alert_status(alert)
        return snow_alert