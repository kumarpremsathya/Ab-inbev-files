import json,logging
from shared_code.constants import Constants
from shared_code.snow_client import SNOWClient

class SnowRequest:
    def __init__(self):
        self.objsnow = SNOWClient()

    def create(self,data):
        try:
            requestor = self.objsnow.get_user_details_by_email(data['RequestorEmail'])
            if not requestor:
                requestor = self.objsnow.get_user_details_by_oid(data['OID'])
            if not requestor:
                requestor = self.objsnow.get_user_details_by_sys_id(data['OID'])
            if data['ActivityName'] == "IT_ACCESS_06":
                request_data = {
                                    "sysparm_quantity": 1,
                                    "business_service" : data['business_service'],
                                    "cat_item": data['cat_item'],
                                    "sys_domain": data['sys_domain'],                                    
                                    "assignment_group": data['assignment_group'],
                                    "contact_type": "self-service",
                                    
                                    "variables":
                                                {
                                                    "u_requester": requestor['sys_id'],
                                                    "u_employee_email": requestor.get('email'),
                                                    "u_employee_zone": requestor.get('u_preferred_zone'),                                                    
                                                    "u_on_behalf_of": requestor.get('sys_id'),
                                                    "u_phone_number": requestor.get('mobile_phone'),
                                                    "line_manager": requestor.get('manager'),
                                                    "u_location": requestor.get('location')
                                                }
                                }
            else:
                request_data = {
                                    "sysparm_quantity": 1,
                                    "variables":
                                                {
                                                    "u_requester": requestor.get('sys_id'),
                                                    "u_employee_email": requestor.get('email'),
                                                    "u_employee_zone": requestor.get('u_preferred_zone'),
                                                    "zone": "GHQ" if data.get('zone') in ["BREWDAT", "AURORA", "TECHOPS","BEES"] else data.get('zone'),
                                                    "u_on_behalf_of": requestor.get('sys_id'),
                                                    "u_phone_number": requestor.get('mobile_phone'),
                                                    "u_requester": requestor['sys_id'],
                                                    "u_employee_email": requestor['email'],
                                                    "u_employee_zone": requestor['u_preferred_zone'],
                                                    "zone": "GHQ" if data['zone'] in ["BREWDAT", "AURORA", "TECHOPS","BEES"] else data['zone'],
                                                    "u_on_behalf_of": requestor['sys_id'],
                                                    # "u_phone_number": requestor['mobile_phone'],
                                                    "u_phone_number": requestor.get('mobile_phone', ''),
                                                }
                                }
        except Exception as e:
            logging.error(f"Error Getting SNOW User details: {e}")
            raise Exception(f"Error Getting SNOW User details: {e}")
        request_data['description'] = data['description']
        request_data['short_description'] = data['short_description']
        request_data['variables'].update(data['variables'])
        if request_data.get('assignment_group') is None:
            request_data['assignment_group'] = Constants.SNOW_ASSIGNMENT_GROUP
        try:
            snow_ritm, snow_req = self.objsnow.create_request(request_data)
            self.objsnow.upload_attachment_json(snow_ritm['number'],data)
            data['SnowId'] = snow_req['number']
            data['SnowStatusCode'] = snow_req['state']
            data['SnowStatus'] = snow_req['stage']
            data['SnowItemId'] = snow_ritm['number']
            data['SnowItemStatusCode'] = snow_ritm['state']
            data['SnowItemStatus'] = snow_ritm['stage']
        except Exception as e:
            logging.error(f"Error Creating SNOW: {e}")
            raise Exception(f"Error Creating SNOW: {e}")
        return data
    
    def snow_update_ritm(self,dataset):
        if dataset.Status == 'Success':
            state = '3'
        else:
            state = '4'
        result = self.objsnow.update_ritm(dataset.SnowItemId,state,dataset.Comments,dataset.Comments)
        return result
    
    def snow_get_ritm_status(self,ritm):
        snow_ritm = self.objsnow.get_ritm_status(ritm)
        return snow_ritm