import json,logging
from shared_code.constants import Constants
from shared_code.snow_client import SNOWClient
from shared_code.time_zone_converter import TimezoneConverter

class SnowChangeRequest:
    def __init__(self):
        self.objsnow = SNOWClient()
        self.tzconverter = TimezoneConverter() 

    def create(self,data): 
        self.data = data
        try:
            requestor = self.objsnow.get_user_details_by_email(data['RequestorEmail'])
            if not requestor:
                requestor = self.objsnow.get_user_details_by_oid(data['OID'])
            request_data = {
                "sysparm_quantity": 1,
                "u_environment": "production",
                "state": -4,
                "variables":
                    {
                        "u_requester": requestor.get("sys_id"),
                        "u_employee_email": requestor.get("email"),
                        "u_employee_zone": requestor.get("u_preferred_zone"),
                        "u_on_behalf_of": requestor.get("sys_id"),
                        "u_phone_number": requestor.get("mobile_phone"),
                        "line_manager": requestor.get("manager")
                    }
            }
        except Exception as e:
            logging.error(f"Error Getting SNOW User details: {e}")
            raise Exception(f"Error Getting SNOW User details: {e}")
        match self.data["zone"]:
            case "GHQ": 
                request_data["u_zone_ghq"]= True
                request_data["u_change_zone"] = Constants.SNOW_ZONE_GHQ
            case "TECHOPS": 
                request_data["u_zone_ghq"]= True
                request_data["u_change_zone"] = Constants.SNOW_ZONE_GHQ
            case "AFRICA":
                request_data["u_zone_afr"]= True
                request_data["u_change_zone"] = Constants.SNOW_ZONE_AFRICA
            case "MAZ": 
                request_data["u_zone_maz"]= True                
                request_data["u_change_zone"] = Constants.SNOW_ZONE_MAZ
            case "NAZ": 
                request_data["u_zone_naz"]= True
                request_data["u_change_zone"] = Constants.SNOW_ZONE_NAZ
            case "SAZ": 
                request_data["u_zone_saz"]= True
                request_data["u_change_zone"] = Constants.SNOW_ZONE_SAZ
            case "EUROPE":
                request_data["u_zone_eur"]= True
                request_data["u_change_zone"] = Constants.SNOW_ZONE_EU
            case "KOREA":
                request_data["u_zone_ghq"]= True
                request_data["u_change_zone"] = Constants.SNOW_ZONE_GHQ
            case "CHINA":
                request_data["u_zone_apac"]= True
                request_data["u_change_zone"] = Constants.SNOW_ZONE_CHINA
            case "BREWDAT":
                request_data["u_zone_ghq"]= True
                request_data["u_change_zone"] = Constants.SNOW_ZONE_GHQ
            case "AURORA":
                request_data["u_zone_ghq"]= True
                request_data["u_change_zone"] = Constants.SNOW_ZONE_GHQ

        request_data["business_service"] = Constants.SNOW_BUSINESS_SERVICE
        request_data["assigned_to"] = Constants.SNOW_ASSIGNMENT_USER
        request_data["assignment_group"] = Constants.SNOW_ASSIGNMENT_GROUP
        request_data["requested_by"] = requestor["sys_id"]
        request_data["category"] = self.data["category"]
        request_data["description"] = self.data["description"]
        request_data["short_description"] = self.data["short_description"]
        request_data["implementation_plan"] = self.data["implementation_plan"]
        request_data["risk_impact_analysis"] = self.data["risk_impact_analysis"]
        request_data["backout_plan"] = self.data["backout_plan"]
        request_data["test_plan"] = self.data["test_plan"]
        request_data["u_impacted_applications"] = self.data["u_impacted_applications"]
        request_data["start_date"] = self.tzconverter.to_utc(self.data["start_date"],self.data["timezone"])
        request_data["end_date"] = self.tzconverter.to_utc(self.data["end_date"],self.data["timezone"])
        request_data["watch_list"] = self.data["watch_list"]
        request_data["devowner"] = self.data["devowner"]
        request_data["risk"] = self.data["risk"]
        request_data["impact"] = self.data["impact"]
        request_data["u_time_zone"] = "UTC"
        request_data["reason"] = "maintenance"
        if self.data.get("type"):
            request_data["type"] = self.data["type"]
        #request_data["variables"].update(self.data["variables"])
        try:
            snow_req = self.objsnow.create_change_request(request_data)
            self.data["SnowId"] = snow_req["result"]["number"]["value"]
            self.data["SnowStatusCode"] = snow_req["result"]["state"]["value"]
            self.data["SnowStatus"] = snow_req["result"]["state"]["display_value"]
            self.data["SnowItemId"] = snow_req["result"]["number"]["value"]
            self.data["SnowItemStatusCode"] = snow_req["result"]["state"]["value"]
            self.data["SnowItemStatus"] = snow_req["result"]["state"]["display_value"]
        except Exception as e:
            logging.error(f"Error Creating Change Request: {e}")
            raise Exception(f"Error Creating Change Request: {e}")
        return self.data
    
    def snow_get_change_status(self,change_id):
        snow_change = self.objsnow.get_change_status(change_id)
        return snow_change
    
    def close_ctasks(self,change_id,state,assign_to,close_code,comments):
        tasks = self.objsnow.get_ctasks_by_change(change_id)
        implement_task = None
        post_implement_task = None
        for task in tasks:
            implement_task = task["number"] if task["short_description"].startswith("Implementation") else implement_task
            post_implement_task = task["number"] if task["short_description"].startswith("Post-Implementation") else post_implement_task
        if implement_task and post_implement_task:
            self.objsnow.update_ctask_status(implement_task,state,assign_to,close_code,comments)        
            self.objsnow.update_ctask_status(post_implement_task,state,assign_to,close_code,comments) 
    
    def snow_update_change(self,dataset):
        if dataset.Status == 'Success':
            close_code = 'successful'
        else:
            close_code = 'unsuccessful'
        state = '3'
        assign_to = Constants.SNOW_ASSIGNMENT_USER
        self.close_ctasks(dataset.SnowItemId,state,assign_to,close_code,dataset.Comments)
        return True