import requests

# payload = {
#     "ActivityType": "Incident",
#     "SnowId": "INC9419044",
#     "category": "Backup Failed"
# }

payload = {'ActivityType': 'Incident', 'SnowId': 'INC9997580', 'category': 'Backup Failed'}

# payload = {'ActivityType': 'Incident', 'SnowId': 'INC9419042', 'category': 'Backup Failed', 'description': '[CSSE-ABI] Hazel Sandstorm Actor activity detected - 12a99417-8234-6b67-03d9-0a67919ff607'}

response = requests.post(
    "http://localhost:7071/api/incident_receiver",
    json=payload
)

print("\n\nresponse status code ", response.status_code)
print("\n\nresponse text ", response.text)

# import requests
# import json

# # Replace these with your actual values
# FUNCTION_APP_URL = "https://your-function-app-name.azurewebsites.net"
# FUNCTION_KEY = "your-function-key-here"

# # Your test data
# payload = {
#     "ActivityType": "Incident",
#     "SnowId": "INC9419044",
#     "category": "Backup Failed"
# }

# # Build the full URL
# url = f"{FUNCTION_APP_URL}/api/incident_receiver"
# params = {"code": FUNCTION_KEY}

# print("=" * 60)
# print("Testing Incident Receiver")
# print("=" * 60)
# print(f"URL: {url}")
# print(f"Payload: {json.dumps(payload, indent=2)}")
# print("=" * 60)
# print("\nSending request...")

# try:
#     response = requests.post(url, params=params, json=payload, timeout=30)
    
#     print(f"\n✅ Status Code: {response.status_code}")
#     print(f"✅ Response: {response.text}")
    
#     if response.status_code == 200:
#         print("\n✅ Test completed successfully!")
#         print("\nNext steps:")
#         print("1. Check Azure Function logs for [TEST MODE] messages")
#         print("2. Check email inbox for notifications")
#         print("3. Check Application Insights for detailed logs")
#     else:
#         print(f"\n⚠️ Unexpected status code: {response.status_code}")
        
# except requests.exceptions.Timeout:
#     print("\n❌ Request timed out (30 seconds)")
#     print("The function might be taking longer to process")
    
# except requests.exceptions.RequestException as e:
#     print(f"\n❌ Error making request: {e}")
    
# except Exception as e:
#     print(f"\n❌ Unexpected error: {e}")

# print("\n" + "=" * 60)